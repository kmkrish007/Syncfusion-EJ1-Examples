import { ComboBox } from '@syncfusion/ej2-dropdowns';
import { Dialog } from '@syncfusion/ej2-popups';
import { Config } from '../config/config';

export class ServerFilesDialog 
{
    private comboBox: ComboBox;
    public dialog: Dialog = null;

    //private files: { [key: string]: Object }[] = [];
    private files: Array<string>;

    private parent: any = null; 
    private parentType: number;
    private fileType: number;

    public static FILE_TYPE_NONE = 0;
    public static FILE_TYPE_DIAG = 1;
    public static FILE_TYPE_SOE = 2;
    
    constructor(parent: any, type:number)
    {
        console.log("Executing SOEDialog.constructor()");

        this.parent = parent;
        this.parentType = type;
    }


    // Creates the dialog.
    public CreateDialog(show:boolean)
    {
        console.log("Executing ServerFilesDialog.CreateDialog()");

        let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='forceForm'> 
        <div class="row"> 
          <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10">
          <div id=comboelem></div> 
          </div>
        </form> 
        </div> 
        </div>` 

        this.dialog = new Dialog({ 
            header: 'Files Dialog', 
            target: document.getElementById('target'), 
            content: dialogContent, 
            allowDragging: true,
            visible: show,
            isModal: false, 
            showCloseIcon: false,
            width: '500px', 
            open: this.onDialogOpen, 
            close: this.onDialogClose, 
            created: this.onDialogCreate,
            animationSettings: { 
                effect: 'None' 
            }, 
            buttons: [
            { 
                'click': () => 
                {
                    debugger
                    if( this.parent != null)
                    {
                        if(this.fileType == ServerFilesDialog.FILE_TYPE_SOE)
                        {
                            // TODO:  
                            // Find callback when combo box text field is populated
                            // in order to enable the OK button.
                            this.parent.ReadSOEFileFromServer(this.comboBox.value.toString());
                        }
                        else if(this.fileType == ServerFilesDialog.FILE_TYPE_DIAG)
                        {
                            // TODO:  
                            // Find callback when combo box text field is populated
                            // in order to enable the OK button.
                            this.parent.ReadDiagramFileFromServer(this.comboBox.value.toString());
                        }
                    }        
                    this.dialog.visible = false;
                },
        
                buttonModel:         
                { 
                    content: 'OK', 
                    isPrimary: true, 
                    cssClass: 'e-outline'
                }
            },
            { 
              'click': () => 
              {
                  this.dialog.visible = false;
              },
        
              buttonModel: 
              { 
                  content: 'Cancel', 
                  isPrimary: true, 
                  cssClass: 'e-outline'
              }
            }
          ], 
          }); 

          if( this.parentType == Config.PARENT_TYPE_DBC)
          { 
              this.dialog.appendTo('#filedialog-dbc');
          }
          else if( this.parentType == Config.PARENT_TYPE_TREEVIEW)
          { 
              this.dialog.appendTo('#filedialog-tvc');
          }
  
          this.CreateControls();
    }  


    private CreateControls()
    {
        console.log("Executing CreateControls()");

        // initialize ComboBox component
        this.comboBox = new ComboBox({
          placeholder: "Select a File"
        });
    
        // render initialized ComboBox
        if( this.comboBox != null )
        {
            this.comboBox.appendTo('#comboelem');
        }           
    }


    // Dialog created Event callback.
    private onDialogCreate(args:any) 
    {
        console.log("Executing ServerFilesDialog.onDialogCreate()");
        //this.CreateControls();
    } 

    // Dialog opened event callback
    private onDialogOpen()
    {
        //debugger;
        console.log("Executing ServerFilesDialog.onDialogOpen()");    
    }

    // Dialog closed event callback.
    private onDialogClose()
    {
        //debugger;
        console.log("Executing ServerFilesDialog.onDialogClose()");
        //this.dialog.destroy();
    }

    // Destroy (called when drawing board exits).
    public Destroy()
    {
        //debugger;
        console.log("Executing ServerFilesDialog.Destroy()");

        if( this.comboBox != null )
        {
            this.comboBox.destroy();
        }
        this.dialog.destroy();  
    }

    public SetFileType(val:number)
    {
        this.fileType = val;
        if(this.fileType == ServerFilesDialog.FILE_TYPE_SOE )
        {
            this.comboBox.placeholder = "Select an SOE File";
            this.dialog.header = "SOE File Selection Dialog";
        }
        else if(this.fileType == ServerFilesDialog.FILE_TYPE_DIAG )
        {
            this.comboBox.placeholder = "Select a diagram file";
            this.dialog.header = "Diagram File Selection Dialog";
        }

    }
    
    public CopyData(data: Array<any>)
    {   
      //debugger
      this.files = [];
      this.files = Array.from(data);
    }

    public Reset()
    {
        //debugger
        this.comboBox.dataSource = [];
        this.comboBox.dataSource = this.files;    
    }

}
