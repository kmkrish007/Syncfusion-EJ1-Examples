import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';
import { Config } from '../config/config';

export class AnalogPointComponent extends DevicePointComponent{

    private text_type = AnalogPointComponent.POINT_TYPE_ANALOG;

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_COLOR_NORMAL: string = "darkmagenta";
    public static DEFAULT_COLOR_LOW: string = "yellow";
    public static DEFAULT_COLOR_HIGH: string = "yellowgreen";
    public static DEFAULT_PRECISION: number = 0;

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_FILLCOLOR: string = "black";
    public static DEFAULT_BORDERCOLOR: string = "red";
    public static DEFAULT_TEXTCOLOR: string = "black";
    public static DEFAULT_DISPLAYTEXT: string = "";
    public static DEFAULT_FONTFAMILY: string = "Arial";
    public static DEFAULT_FONTSIZE: number = 50;

    // Configurable when point mapped to symbol on map.
    protected highColor: string = AnalogPointComponent.DEFAULT_COLOR_HIGH;
    protected lowColor: string = AnalogPointComponent.DEFAULT_COLOR_LOW;
    protected normalColor: string = AnalogPointComponent.DEFAULT_COLOR_NORMAL;

    // Configurable when point mapped to symbol on map.    
    //protected borderColor: string = AnalogPointComponent.DEFAULT_BORDERCOLOR;
    //protected fillColor: string = AnalogPointComponent.DEFAULT_FILLCOLOR;
    //protected displayText: string = AnalogPointComponent.DEFAULT_DISPLAYTEXT;
    //protected fontFamily: string = AnalogPointComponent.DEFAULT_FONTFAMILY;
    //protected fontSize: number = AnalogPointComponent.DEFAULT_FONTSIZE;
    //protected textColor: string = AnalogPointComponent.DEFAULT_TEXTCOLOR;

    //protected failedColor: string = DevicePointComponent.DEFAULT_COLOR_FAILED;
    //protected forcedColor: string = DevicePointComponent.DEFAULT_COLOR_FORCED;

    protected precision: number = AnalogPointComponent.DEFAULT_PRECISION;
    protected forced: number = 0;
    

    constructor(
        protected deviceType: string,
        protected deviceName: string,
        protected sn: number,
        protected ied: number,
        protected pointid: string,
        protected pointname: string,
        protected units: number,
        private scale: number,
        private offset: number,
        private highlimit: number,
        private lowlimit: number
    ) 
    {
        super(deviceType, deviceName, sn, ied, pointid, pointname, units);

        this.borderColor = AnalogPointComponent.DEFAULT_BORDERCOLOR;
        this.fillColor = AnalogPointComponent.DEFAULT_FILLCOLOR;
        this.displayText = AnalogPointComponent.DEFAULT_DISPLAYTEXT;
        this.fontFamily = AnalogPointComponent.DEFAULT_FONTFAMILY;
        this.fontSize = AnalogPointComponent.DEFAULT_FONTSIZE;
        this.textColor = AnalogPointComponent.DEFAULT_TEXTCOLOR;

        this.Init(Config.configdata);     
    }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
    }
    
    protected ApplyConfig(config: Array<any>)
    {
        if( ! config )
        {
            return;
        }

        super.ApplyConfig(config);

        for( let i:number=0;i<config.length; ++i )
        {
            let item: any = config[i];
            if( item.type == ConfigDialog.CONFIGTYPE_ANALOG)
            {
                if( item.name == "high text color")
                {
                    this.highColor = item.value;
                }
                else if( item.name == "low text color")
                {
                    this.lowColor = item.value;
                }
                else if( item.name == "normal text color")
                {
                    this.normalColor = item.value;
                }
                else if( item.name == "precision")
                {
                    this.precision = parseInt(item.value);
                }
                else if( item.name == "font size")
                {
                    this.fontSize = parseInt(item.value);
                }
                else if( item.name == "font family")
                {
                    this.fontFamily = item.value;
                }          
                else if( item.name == "border color")
                {
                    this.borderColor = item.value;
                }                
            }
        }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
        if( ! config )
        {
            return;
        }

        for( let i:number=0;i>config.length; ++i )
        {
            let item: any = config[i];
            if( item.type == ConfigDialog.CONFIGTYPE_ANALOG)
            {
                if( item.name == "high text color")
                {
                    AnalogPointComponent.DEFAULT_COLOR_HIGH = item.default;
                }
                else if( item.name == "low text color")
                {
                    AnalogPointComponent.DEFAULT_COLOR_LOW = item.default;
                }
                else if( item.name == "normal text color")
                {
                    AnalogPointComponent.DEFAULT_COLOR_NORMAL = item.default;
                }
                else if( item.name == "precision")
                {
                    AnalogPointComponent.DEFAULT_PRECISION = parseInt(item.default);
                }
                else if( item.name == "font size")
                {
                  AnalogPointComponent.DEFAULT_FONTSIZE = parseInt(item.default);
                }
                else if( item.name == "font family")
                {
                  AnalogPointComponent.DEFAULT_FONTFAMILY = item.default;
                }          
                else if( item.name == "border color")
                {
                  AnalogPointComponent.DEFAULT_BORDERCOLOR = item.default;
                }                
            }
        }
    }
  
      public deserialize(obj:any)
      {
          //debugger
          this.borderColor = obj.devicePoint.borderColor;
          this.fillColor = obj.devicePoint.fillColor;
          this.displayText = obj.devicePoint.displayText;
          this.fontFamily = obj.devicePoint.fontFamily;
          this.fontSize = obj.devicePoint.fontSize;
          this.textColor = obj.devicePoint.textColor;
          this.highColor = obj.devicePoint.highColor;
          this.lowColor = obj.devicePoint.lowColor;
          this.normalColor = obj.devicePoint.normalColor;
          this.setTextColor();
      }

    //   public GetFontString(): string
    //   {
    //       return this.fontSize.toString() + "px" + this.fontFamily;
    //   }

      public getLowLimit(): number
      {
          return this.lowlimit;
      }
  
      public getHighLimit(): number
      {
          return this.highlimit;
      }

      public getScale(): number
      {
          return this.scale;
      }

      public getOffset(): number
      {
          return this.offset;
      }

      public setForced(val: number)
      {
         //console.log("AnalogPointComponent.setForced() for val: " + val);
          this.forced = val;
      }

      public getForced(): number
      {
          console.log("AnalogPointComponent.getForced() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
          return this.forced;
      }
  

      public getHighColor(): string
      {
      //console.log("AnalogPointComponent.getHighColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
      return this.highColor;
      }
  
      public getLowColor(): string
      {
      //console.log("AnalogPointComponent.getLowColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
      return this.lowColor;
      }

      public getNormalColor(): string
      {
      //console.log("AnalogPointComponent.getNormalColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
      return this.normalColor;
      }

    //   public getTextColor(): string
    //   {
    //   //console.log("DevicePointComponent.getTextColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    //   return this.textColor;
    //   }
  
      public setTextColor()
      {
        // TODO: TEST ONLY.
        //this.setFailed(1);
        //this.setForced(1);

        //debugger
        // console.log("AnalogPointComponent.getFillColor() for: " + 
        //               this.getSN() + ":" + 
        //               this.getIed() + "-" + 
        //               this.getPointId());
        if( this.getFailed() )
        {
          // Failed Point.
          //console.log("Returning LOW LIMIT COLOR.");
          this.textColor = this.failedColor;
        }
        else if( this.getForced() )
        {
          // Forced Point.
          //console.log("Returning FORCED COLOR: " + this.forcedColor + " For Pt: " + this.getExtName());
          this.textColor = this.forcedColor;
        }
        else if( this.value <= this.lowlimit  )
        {
          // Low Limit.
          //console.log("Returning LOW LIMIT COLOR.");
          this.textColor = this.lowColor;
        }
        else if( this.value >= this.highlimit  )
        {
          // High Limit.
          //console.log("Returning HIGH LIMIT COLOR.");
          this.textColor =  this.highColor;
        }
        else
        {
          // Normal Limit.
          //console.log("Returning NORMAL LIMIT COLOR.");
          this.textColor = this.normalColor;
        }
      }

  
      public getFillColor(): string
      {
        // console.log("AnalogPointComponent.getFillColor() for: " + 
        //               this.getSN() + ":" + 
        //               this.getIed() + "-" + 
        //               this.getPointId());

        // if( this.value <= this.lowlimit  )
        // {
        //   // Low Limit.
        //   //console.log("Returning LOW LIMIT COLOR.");
        //   return this.lowColor;
        // }
        // else if( this.value >= this.highlimit  )
        // {
        //   // High Limit.
        //   //console.log("Returning HIGH LIMIT COLOR.");
        //   return this.highColor;
        // }
        // else
        // {
        //   // Normal Limit.
        //   //console.log("Returning NORMAL LIMIT COLOR.");
        //   return this.normalColor;
        // }

        return this.fillColor;
      }

      public getDisplayText(): string
      {
        // console.log("AnalogPointComponent.getDisplayText() for: " + 
        //               this.getSN() + ":" + 
        //               this.getIed() + "-" + 
        //               this.getPointId());
        // console.log("Returning Value: " + this.value.toString());
        
        // DEBUG - SIMULATION ONLY.
        //this.value += 1;

        let tag:string = "";

        if( this.getFailed() )
        {
            tag = "Failed";
        }
        if( this.getForced() )
        {
            tag = "Forced";
        }

        let txt = this.value.toString();

        if( tag.length > 0 )
        {
            txt += " " + tag;
        }

        return txt;        
        //return this.value.toString();
      }
      
      public LoadProperties(propdata: { [key: string]: Object }[])
      {
        //debugger
        console.log("Executing AnalogPointComponent.LoadProperties().");

        // Load the property array with point properties.
        let item:any = {name: "type", value: this.getPointType()};
        propdata.push(item);

        item = {name: "ext name", value: this.getExtName()};
        propdata.push(item);
        item = {name: "sn", value: this.getSN()};
        propdata.push(item);
        item = {name: "ied", value: this.getIed()};
        propdata.push(item);
        item = {name: "pt", value: this.getPointId()};
        propdata.push(item);
        item = {name: "pid", value: this.getPid()};
        propdata.push(item);

        item = {name: "units", value: this.getUnits()};
        propdata.push(item);
        item = {name: "scale", value: this.getScale()};
        propdata.push(item);
        item = {name: "offset", value: this.getOffset()};
        propdata.push(item);
        item = {name: "high", value: this.getHighLimit()};
        propdata.push(item);
        item = {name: "low", value: this.getLowLimit()};
        propdata.push(item);

        item = {name: "normal color", value: this.normalColor};
        propdata.push(item);
        item = {name: "high color", value: this.highColor};
        propdata.push(item);
        item = {name: "low color", value: this.lowColor};
        propdata.push(item);
        item = {name: "failed color", value: this.failedColor};
        propdata.push(item);
        item = {name: "forced color", value: this.forcedColor};
        propdata.push(item);

        item = {name: "bordercolor", value: this.borderColor};
        propdata.push(item);
        item = {name: "fontfamily", value: this.fontFamily};
        propdata.push(item);
        item = {name: "fontsize", value: this.fontSize};
        propdata.push(item);
        item = {name: "text color", value: this.textColor};
        propdata.push(item);
      }
      
      public saveProperty(name: string, value: string): boolean
      {
          console.log("Executing AnalogPointComponent.SaveProperty().");

          if( name == "normal color")
          {
              //debugger
              this.normalColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "high color")
          {
              //debugger
              this.highColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "low color")
          {
              //debugger
              this.lowColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "failed color")
          {
              //debugger
              this.failedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "forced color")
          {
              //debugger
              this.forcedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "fontsize")
          {
              this.fontSize = parseInt(value);
              return true;
          }
          else if( name == "fontfamily")
          {
              this.fontFamily = value;
              return true;
          }

          return false;
      }
  
      public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
      {
        //console.log("Executing AnalogPointComponent.LoadDefaultProperties().");

        let item:any = {name: "type", value: AnalogPointComponent.POINT_TYPE_ANALOG};
        propdata.push(item);

        // Load the property array with point properties.
        item = {name: "bordercolor", value: AnalogPointComponent.DEFAULT_BORDERCOLOR};
        propdata.push(item);
        item = {name: "fillcolor", value: AnalogPointComponent.DEFAULT_FILLCOLOR};
        propdata.push(item);
        item = {name: "displaytext", value: AnalogPointComponent.DEFAULT_DISPLAYTEXT};
        propdata.push(item);
        item = {name: "fontfamily", value: AnalogPointComponent.DEFAULT_FONTFAMILY};
        propdata.push(item);
        item = {name: "fontsize", value: AnalogPointComponent.DEFAULT_FONTSIZE};
        propdata.push(item);
        item = {name: "text color", value: AnalogPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "normal color", value: AnalogPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "low color", value: AnalogPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "high color", value: AnalogPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        
        //super.LoadDefaultProperties(propdata);
      }

      public static saveDefaultProperty(name: string, value: string)
      {
        //console.log("Executing AnalogPointComponent.SaveDefaultProperty().");
    
        if( name == "bordercolor")
        {
            AnalogPointComponent.DEFAULT_BORDERCOLOR = value;
        }
        else if( name == "fillcolor")
        {
            AnalogPointComponent.DEFAULT_FILLCOLOR = value;
        }
        else if( name == "displayText")
        {
            AnalogPointComponent.DEFAULT_DISPLAYTEXT = value;
        }
        else if( name == "fontFamily")
        {
            AnalogPointComponent.DEFAULT_FONTFAMILY = value;
        }
        else if( name == "fontsize")
        {
            AnalogPointComponent.DEFAULT_FONTSIZE = parseInt(value);
        }
        else if( name == "text color")
        {
            AnalogPointComponent.DEFAULT_TEXTCOLOR = value;
        }
        else if( name == "normal color")
        {
            AnalogPointComponent.DEFAULT_COLOR_NORMAL = value;
        }
        else if( name == "low color")
        {
            AnalogPointComponent.DEFAULT_COLOR_LOW = value;
        }
        else if( name == "high color")
        {
            AnalogPointComponent.DEFAULT_COLOR_HIGH = value;
        }  
      }

      public AdjustProperties(): boolean
      {
          //this.fontSize = 20;
          this.borderColor = "black";
          this.fillColor = "black";
          this.setTextColor();

          return true;
      }
 
}