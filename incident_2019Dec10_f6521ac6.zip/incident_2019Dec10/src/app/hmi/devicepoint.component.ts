import { ConfigDialog } from '../dialogs/configdialog';
import { Config } from '../config/config';

export class DevicePointComponent {

    public static POINT_TYPE_STATUS: string = "st";
    public static POINT_TYPE_ANALOG: string = "an";
    public static POINT_TYPE_ACCUMULATOR: string = "ac";
    public static POINT_TYPE_CONTROL: string = "co";
    public static POINT_TYPE_SETPOINT: string = "se";

    public static UNITS:number = 1;

    protected snDescription: string = "";
    // Raw value.
    protected value: number = -1;
    protected failed: number = 0;
    protected pid: number = -1;

    public static DEFAULT_COLOR_FAILED: string = "aqua";
    public static DEFAULT_COLOR_FORCED: string = "blue";

    public static FILLCOLOR_DEFAULT: string = "black";
    public static BORDERCOLOR_DEFAULT: string = "red";
    public static TEXTCOLOR_DEFAULT: string = "black";
    public static DISPLAYTEXT_DEFAULT: string = "";
    private static FONTFAMILY_DEFAULT: string = "Arial";
    private static FONTSIZE_DEFAULT: number = 50;

    //private static NAME_DEFAULT: string = "DEVICE POINT";

    // TODO:  Do we need to handle inverted bit or is this done via on/off text?
    // Eventually move this to status/control point.
    public onValue: number = 1;
    public offValue: number = 0;

    protected borderColor: string = DevicePointComponent.BORDERCOLOR_DEFAULT;
    protected fillColor: string = DevicePointComponent.FILLCOLOR_DEFAULT;
    protected displayText: string = DevicePointComponent.DISPLAYTEXT_DEFAULT;
    protected fontFamily: string = DevicePointComponent.FONTFAMILY_DEFAULT;
    protected fontSize: number = DevicePointComponent.FONTSIZE_DEFAULT;
    protected textColor: string = DevicePointComponent.TEXTCOLOR_DEFAULT;

    protected failedColor: string = DevicePointComponent.DEFAULT_COLOR_FAILED;
    protected forcedColor: string = DevicePointComponent.DEFAULT_COLOR_FORCED;
    

    constructor(
        protected pointType: string,
        protected deviceName: string,
        protected sn: number,
        protected ied: number,
        protected pointid: string,
        protected pointname: string,
        protected units: number        
    ) 
    {
        //debugger
        // TODO:  Get serial number description.
        this.snDescription = "DNP Client";

        this.pid = parseInt(pointid.slice(2, pointid.length));
        //console.log("pid: " + this.pid);

        this.Init(Config.configdata);
    }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
    }

    protected ApplyConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_ALLPOINTS)
        {
          if( item.name == "failed color")
          {
            //RectangleComponent.DEFAULT_COLOR_BORDER = item.default;
            this.failedColor= item.value;
          }
          else if( item.name == "forced color")
          {
            //RectangleComponent.DEFAULT_COLOR_FILL = item.default;
            this.forcedColor = item.value;
          }
        }
      }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
        if( ! config )
        {
            return;
        }
  
      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_ALLPOINTS)
        {
          if( item.name == "border color")
          {
            DevicePointComponent.BORDERCOLOR_DEFAULT = item.default;
          }
          else if( item.name == "fill color")
          {
            DevicePointComponent.FILLCOLOR_DEFAULT = item.default;
          }
        }
      }
    }

    public deserialize(obj:any)
    {
        //debugger
        this.borderColor = obj.devicePoint.borderColor;
        this.fillColor = obj.devicePoint.fillColor;
        this.displayText = obj.devicePoint.displayText;
        this.fontFamily = obj.devicePoint.fontFamily;
        this.fontSize = obj.devicePoint.fontSize;
        this.textColor = obj.devicePoint.textColor;
    }


    public getPointId(): string
    {
        //debugger
        return this.pointid;
    }

    public getFullPointId(): string
    {
        //debugger
        return this.sn + ":" + this.ied + "-" + this.pointid;
    }

    public getPid(): number
    {
        return this.pid;
    }

    public getPointName(): string
    {
        return this.pointname;
    }

    public getPointType(): string
    {
        return this.pointType
    }

    public getSN(): number
    {
        return this.sn;
    }

    public getIed(): number
    {
        return this.ied;
    }

    public getdeviceName(): string
    {
        return this.deviceName;
    }

    public getExtName(): string
    {
        return this.getSN() + ":" + this.getIed() + "-" + this.getPointId();
    }

    public setValue(val: number)
    {
        //console.log("Executing DevicePointComponent.setValue() to value: " + val);
        this.value = val;
    }

    public getValue(): number
    {
        return this.value;
    }

    public setFailed(val: number)
    {
        //console.log("Executing DevicePointComponent.setFailed() to value: " + val);
        this.failed = val;
    }

    public getFailed(): number
    {
        return this.failed;
    }

    public getUnits(): number
    {
        return this.units;
    }

    public setTimestamp(val: number)
    {
        console.log("DevicePointComponent.setTimestamp() for val: " + val);
    }

    public setForced(val: number)
    {
        console.log("DevicePointComponent.setForced() for val: " + val);
    }

    public getForced(): number
    {
        console.log("DevicePointComponent.getForced() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return 0;
    }

    public getLowLimit(): number
    {
        //console.log("DevicePointComponent.getLowLimit() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return -1;
    }

    public getHighLimit(): number
    {
        //console.log("DevicePointComponent.getHighLimit() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return -1;
    }

    public getScale(): number
    {
        //console.log("DevicePointComponent.getScale() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return -1;
    }

    public getOffset(): number
    {
        //console.log("DevicePointComponent.getOffset() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return -1;
    }

    public getFillColor(): string
    {
    //console.log("DevicePointComponent.getFillColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    return this.fillColor;
    }

    public getBorderColor(): string
    {
    //console.log("DevicePointComponent.getBorderColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    return this.borderColor;
    }
 
    public getDisplayText(): string
    {
    //console.log("DevicePointComponent.getDisplayText() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    return this.displayText;
    }

    public getFontFamily(): string
    {
    //console.log("DevicePointComponent.getFontFamily() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    return this.fontFamily;
    }

    public getFontSize(): number
    {
    //console.log("DevicePointComponent.getFontFamily() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    return this.fontSize;
    }

    public static GetFontString(): string
    {
        return DevicePointComponent.FONTSIZE_DEFAULT + "px " + DevicePointComponent.FONTFAMILY_DEFAULT;
    }

    public getFontString(): string
    {
        debugger
    //console.log("DevicePointComponent.getFontString() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    let fontstring:string = this.fontSize.toString() + "px " + this.fontFamily;
    console.log("DevicePoint.getFontString() - returning fontstring: " + fontstring);
    return fontstring;

    // let fontstring:string = this.fontSize.toString() + "px " + this.font;
    // ctx.font = fontstring;

    }

    public getTextColor(): string
    {
    //console.log("DevicePointComponent.getTextColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
    return this.textColor;
    }

    public setTextColor()
    {
        return;
    }

    public LoadProperties(propdata: { [key: string]: Object }[])
    {
        //console.log("Executing DevicePointComponent.LoadProperties().");

        // Load the property array with point properties.
        let item:any = {name: "type", value: this.getPointType()};
        propdata.push(item);

        item = {name: "ext name", value: this.getExtName()};
        propdata.push(item);
        item = {name: "sn", value: this.getSN()};
        propdata.push(item);
        item = {name: "ied", value: this.getIed()};
        propdata.push(item);
        item = {name: "pt", value: this.getPointId()};
        propdata.push(item);
        item = {name: "pid", value: this.getPid()};
        propdata.push(item);
        item = {name: "bordercolor", value: this.borderColor};
        propdata.push(item);
        item = {name: "fillcolor", value: this.fillColor};
        propdata.push(item);
        item = {name: "fontfamily", value: this.fontFamily};
        propdata.push(item);
        item = {name: "fontsize", value: this.fontSize};
        propdata.push(item);
        item = {name: "text color", value: this.textColor};
        propdata.push(item);    
    }

    public saveProperty(name: string, value: string)
    {
        //console.log("Executing DevicePointComponent.SaveProperty().");

        if( name == "bordercolor")
        {
            this.borderColor = value;
        }
        else if( name == "fillcolor")
        {
            this.fillColor = value;
        }
        else if( name == "fontsize")
        {
            //debugger
            this.fontSize = parseInt(value);
        }
        else if( name == "fontfamily")
        {
            this.fontFamily = value;
        }
        else if( name == "text color")
        {
            this.textColor = value;
        }
    }

    public saveProperties(propdata: { [key: string]: Object }[])
    {
        //console.log("Executing DevicePointComponent.SaveProperties().");

        // Load the property array with point properties.
        for( let i:number=0;i<propdata.length; ++i)
        {
            let prop:any = propdata[i];

            if( prop.name == "bordercolor")
            {
                this.borderColor = prop.value;
            }
            else if( prop.name == "fillcolor")
            {
                this.fillColor = prop.value;
            }
            else if( prop.name == "fontsize")
            {
                this.fontSize = prop.value;
            }
            else if( prop.name == "fontfamily")
            {
                this.fontFamily = prop.value;
            }

        }
    }


    public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
    {
        //console.log("Executing DevicePointComponent.LoadProperties().");

        // Load the property array with point properties.
        let item:any = {name: "bordercolor", value: DevicePointComponent.BORDERCOLOR_DEFAULT};
        propdata.push(item);
        item = {name: "fillcolor", value: DevicePointComponent.FILLCOLOR_DEFAULT};
        propdata.push(item);
        item = {name: "displaytext", value: DevicePointComponent.DISPLAYTEXT_DEFAULT};
        propdata.push(item);
        item = {name: "fontfamily", value: DevicePointComponent.FONTFAMILY_DEFAULT};
        propdata.push(item);
        item = {name: "fontsize", value: DevicePointComponent.FONTSIZE_DEFAULT};
        propdata.push(item);
        item = {name: "text color", value: DevicePointComponent.TEXTCOLOR_DEFAULT};
        propdata.push(item);    
    }
    
    public static saveDefaultProperty(name: string, value: string)
    {
        //console.log("Executing DevicePointComponent.SaveDefaultProperty().");
    
        if( name == "bordercolor")
        {
            DevicePointComponent.BORDERCOLOR_DEFAULT = value;
        }
        else if( name == "fillcolor")
        {
            DevicePointComponent.FILLCOLOR_DEFAULT = value;
        }
        else if( name == "displaytext")
        {
            DevicePointComponent.DISPLAYTEXT_DEFAULT = value;
        }
        else if( name == "fontfamily")
        {
            DevicePointComponent.FONTFAMILY_DEFAULT = value;
        }
        else if( name == "fontsize")
        {
            DevicePointComponent.FONTSIZE_DEFAULT = parseInt(value);
        }
        else if( name == "text color")
        {
            DevicePointComponent.TEXTCOLOR_DEFAULT = value;
        }
    }

    public AdjustProperties(): boolean
    {
        return true;
    }

    

    


    


 
 
}