import {ShapeComponent} from './shape.component';
//import {DevicePointComponent} from './devicepoint.component';

export class ImageComponent extends ShapeComponent{

  protected type = ShapeComponent.SYMBOL_TYPE_IMAGE;

  //public static  COLOR_BORDER: string = "red";
  //public static COLOR_FILL: string = "green";
  public static DEFAULT_HEIGHT = 100;
  public static DEFAULT_WIDTH = 100;

  //protected borderColor:string = RectangleComponent.COLOR_BORDER;
  //protected fillColor:string = RectangleComponent.COLOR_FILL;

    constructor(
        protected x: number,
        protected y: number,
        public width: number,
        public height: number,
        private imgFile: string
    ) { super(x,y); }
  
    public getType(): string
    {
         return this.type;
    }
 
  public deserialize(obj:any)
  {
    this.dragging = obj.dragging;
    this.dragTL = obj.dragTL;
    this.dragTR = obj.dragTR;
    this.dragBL = obj.dragBL;
    this.dragBR = obj.dragBR;
    this.closeEnough = obj.closeEnough;
    this.displayText = obj.displayText;
    this.borderColor = obj.borderColor;
    this.fillColor =obj.fillColor;
  }
      
   public draw( ctx: CanvasRenderingContext2D )
   {
      console.log("Executing ImageComponent.draw()");

      var img = new Image();
      img.src = this.imgFile;
      ctx.drawImage(img, this.x, this.y, this.width, this.height);

      if( this.drawBR )
      {
        this.drawBoundedRect(ctx);
      }
   }


  public drawBoundedRect( ctx: CanvasRenderingContext2D )
  {
    ctx.beginPath();
    // Draw Border.
    ctx.strokeStyle = "pink";
    ctx.lineWidth = 1;
    ctx.setLineDash([1, 2]);
    ctx.rect( this.x-10, this.y-10, this.width+20, this.height+20);
    ctx.stroke();
    ctx.closePath();
  }

   public isSelected(pos_x: number, pos_y: number): boolean
   {
       console.log("Executing RectangleComponent.isSelected() for x: " + pos_x + "  y:" + pos_y);

        // Make sure the given position's [x,y] coordinates 
        // fall within this shape's bounding rectangle.
        if ( (this.x <= pos_x) && 
             (this.x + this.width >= pos_x) &&
             (this.y <= pos_y) && 
             (this.y + this.height >= pos_y))
        {
          console.log("Rectangle Selected.");
          this.checkForResizing(pos_x, pos_y);
          return true;
        }

        return false;
   }

   checkForResizing(pos_x: number, pos_y: number) 
   {
     console.log("Executing RectangleComponent.checkForResizing() for x: " + pos_x + "  y:" + pos_y);

     this.initDraggingStates();

     if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Left corner.
          this.dragTL = true;
          console.log("dragTL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.width) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Right corner.
          this.dragTR = true;
          console.log("dragTR = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y + this.height) )
     {
          // Dragging Bottom-Left corner.
          this.dragBL = true;
          console.log("dragBL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.width) && this.isCloseEnough(pos_y, this.y + this.height) )
     {
          // Dragging Bottom-Right corner.
          this.dragBR = true;
          console.log("dragBR = true");
     }
     else
     {
          // Dragging entire symbol.
          this.dragging = true;
          console.log("dragging = true");
     }
   }


   public resizeTL(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeTL() for x: " + pos_x + "  y: " + pos_y);

     this.width += this.x - pos_x;
     this.height += this.y - pos_y;
     this.x = pos_x;
     this.y = pos_y;
   }

   public resizeTR(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeTR() for x: " + pos_x + "  y: " + pos_y);

     this.width = Math.abs(this.x - pos_x);
     this.height += this.y - pos_y;
     this.y = pos_y;
   }

   public resizeBL(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeBL() for x: " + pos_x + "  y: " + pos_y);

     this.width += this.x - pos_x;
     this.height = Math.abs(this.y - pos_y);
     this.x = pos_x;
   }

   public resizeBR(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeBR() for x: " + pos_x + "  y: " + pos_y);

     this.width = Math.abs(this.x - pos_x);
     this.height = Math.abs(this.y - pos_y);
   }

  //  protected getFillColor(): string
  //  {
  //    if( this.devicePoint == null)
  //    {
  //        return this.fillColor;
  //    }
  //    return this.devicePoint.getFillColor();
  //  }

  //  protected getBorderColor(): string
  //  {
  //    if( this.devicePoint == null )
  //    {
  //        return this.borderColor;
  //    }
  //    else
  //    {
  //        return this.devicePoint.getBorderColor();
  //    }
  //  }

  //  protected setBorderColor(val: string)
  //  {
  //    this.borderColor = val;
  //  }

  //  protected setFillColor(val: string)
  //  {
  //    this.fillColor = val;
  //  }


public LoadProperties(propdata: { [key: string]: Object }[])
{
  console.log("Executing RectangleComponent.LoadProperties().");

  // Load the property array with symbol properties.

  // TODO:  Make this property non-editable in grid.
  let item:any = {name: "type", value: this.type};
  propdata.push(item);

  item = {name: "x", value: this.x};
  propdata.push(item);
  item = {name: "y", value: this.y};
  propdata.push(item);
  item = {name: "width", value: this.width};
  propdata.push(item);
  item = {name: "height", value: this.height};
  propdata.push(item);

  
  // if( this.devicePoint != null )
  // {
  //   //item = {name: "", value: ""};
  //   //propdata.push(item);

  //   this.devicePoint.LoadProperties(propdata);
  // }
  // else
  // {
  //   // Load the property array with symbol properties.
  //   let item:any = {name: "bordercolor", value: this.borderColor};
  //   propdata.push(item);
  //   item = {name: "fillcolor", value: this.fillColor};
  //   propdata.push(item);
  // }
}

public saveProperty(name: string, value: string): boolean
{
    console.log("Executing RectangleComponent.SaveProperty().");
    
    if( name == "x")
    {
        this.x = parseInt(value);
        return true;
    }
    else if( name == "y")
    {
        this.x = parseInt(value);
        return true;
    }
    else if( name == "width")
    {
        this.width = parseInt(value);
        return true;
    }
    else if( name == "height")
    {
        this.height = parseInt(value);
        return true;
    }

    //super.saveProperty(name, value);

    return false;
} 


public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
{
  console.log("Executing RectangleComponent.LoadDefaultProperties().");

  let item:any = {name: "type", value: ShapeComponent.SYMBOL_TYPE_IMAGE};
  propdata.push(item);

  item = {name: "width", value: ImageComponent.DEFAULT_WIDTH};
  propdata.push(item);
  item = {name: "height", value: ImageComponent.DEFAULT_HEIGHT};
  propdata.push(item);

  //super.LoadDefaultProperties(propdata);
}


public static saveDefaultProperty(name: string, value: string)
{
     console.log("Executing RectangleComponent.SaveDefaultProperty().");

     if( name == "width")
     {
         ImageComponent.DEFAULT_WIDTH = parseInt(value);
     }
     else if( name == "height")
     {
         ImageComponent.DEFAULT_HEIGHT = parseInt(value);
     }
      
     //super.saveDefaultProperty(name, value);
}  



 
}