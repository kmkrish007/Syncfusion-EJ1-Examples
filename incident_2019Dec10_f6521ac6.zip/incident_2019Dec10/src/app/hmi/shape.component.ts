import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';

export class ShapeComponent {
    public static SYMBOL_TYPE_RECTANGLE: string = "rect";
    public static SYMBOL_TYPE_CIRCLE: string = "circle";
    public static SYMBOL_TYPE_LINE: string = "line";
    public static SYMBOL_TYPE_TEXT: string = "text";
    public static SYMBOL_TYPE_IMAGE: string = "image";
    public static SYMBOL_TYPE_SHAPE: string = "shape";
    public static SYMBOL_TYPE_SWITCH: string = "switch";

    constructor(
        protected x: number,
        protected y: number
    ) 
    {  
      //this.ApplyConfig();
    }

    public Init(config: Array<any>)
    {    
    }

    protected ApplyConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_ALL)
        {
          if( item.name == "border color")
          {
            //RectangleComponent.DEFAULT_COLOR_BORDER = item.default;
            this.setBorderColor(item.value);
          }
          else if( item.name == "fill color")
          {
            //RectangleComponent.DEFAULT_COLOR_FILL = item.default;
            this.setFillColor(item.value);
          }
        }
      }

      if(this.devicePoint)
      {
        this.devicePoint.Init(config);
      }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_RECT)
        {
          if( item.name == "border color")
          {
            ShapeComponent.DEFAULT_COLOR_BORDER = item.default;
          }
          else if( item.name == "fill color")
          {
            ShapeComponent.DEFAULT_COLOR_FILL = item.default;
          }
        }
      }
    }
    

    public setHeight(val:number)
    {
    }
  
    public setWidth(val:number)
    {
    }

    public setRadius(val:number)
    {
    }

    public setStartAngle(val:number)
    {
    }

    public setEndAngle(val:number)
    {
    }

    public setCounterclockwise(val:boolean)
    {
    }

    public setRotation(val: number)
    {
    }

    public setRotationClosed(val: number)
    {
    }

    public setRotationOpen(val: number)
    {
    }
 
    public setLength(val: number)
    {
    }

    public SetFontFamily(val: string)
    {
    }
  
    public SetFontSize(val: number)
    {
    }
  
    public SetText(val: string)
    {
    }
  
    public SetIsFill(val: boolean)
    {
    }
   
    closeEnough: number = 10;

    // True when moving a symbol.
    public dragging: boolean = false;

    // True when resizing a symbol.
    public dragTL: boolean = false;
    public dragTR: boolean = false;
    public dragBL: boolean = false;
    public dragBR: boolean = false;

    protected type = ShapeComponent.SYMBOL_TYPE_SHAPE;

    // This field will display the symbols text value.
    // For status and controls points, it will display the on/off text value (e.g. "open", "closed").
    // For analog, accumulator and setpoints, it will display the numeric raw value.
    public displayText: string = "Display Text";

    // Array to store mapped device point(s).
    protected devicePoint: DevicePointComponent = null;

    public static  DEFAULT_COLOR_BORDER: string = "red";
    public static DEFAULT_COLOR_FILL: string = "green";

    protected borderColor:string = ShapeComponent.DEFAULT_COLOR_BORDER;
    protected fillColor:string = ShapeComponent.DEFAULT_COLOR_FILL;

    // Draw Bounded Rectangle.
    public drawBR: boolean = false;



    public getType(): string
    {
         return this.type;
    }
     
    public getX(): number
    {
        return this.x;
    }

    public getY(): number
    {
        return this.y;
    }

    public setX(val: number)
    {
        this.x = val;
    }

    public setY(val: number)
    {
        this.y = val;
    }

    public updateXY(pos_x: number, pos_y: number)
    {
        this.setX(pos_x);
        this.setY(pos_y);
    }

    public draw( ctx: CanvasRenderingContext2D  )
    { 
      console.log("Executing ShapeComponent.draw() for x: " + this.x + "  y:" + this.y);
    }

    public drawBoundedRect( ctx: CanvasRenderingContext2D )
  {
    console.log("Executing ShapeComponent.drawBoundedRect() for x: " + this.x + "  y:" + this.y);
  }

    public deserialize(obj:any)
    {
      debugger
      this.dragging = obj.dragging;
      this.dragTL = obj.dragTL;
      this.dragTR = obj.dragTR;
      this.dragBL = obj.dragBL;
      this.dragBR = obj.dragBR;
      this.closeEnough = obj.closeEnough;
      this.displayText = obj.displayText;
      this.borderColor = obj.borderColor;
      this.fillColor = obj.fillColor;
    }
  

    public isSelected(pos_x: number, pos_y: number): boolean
    {
       console.log("Executing ShapeComponent.isSelected() for x: " + pos_x + "  y:" + pos_y);
        return false;
    }

    protected isCloseEnough(p1: number, p2: number): boolean
    {
      console.log("Executing ShapeComponent.isCloseEnough() for p1: " + p1 + "  p2:" + p2);

      return Math.abs(p1 - p2) <= this.closeEnough;
    }


    public resizeTL(pos_x: number, pos_y: number)
    {
        console.log("Executing ShapeComponent.resizeTL() for x: " + this.x + "  y:" + this.y);
    }
 
    public resizeTR(pos_x: number, pos_y: number)
    {
        console.log("Executing ShapeComponent.resizeTR() for x: " + this.x + "  y:" + this.y);
    }
 
    public resizeBL(pos_x: number, pos_y: number)
    {
        console.log("Executing ShapeComponent.resizeBL() for x: " + this.x + "  y:" + this.y);
    }
 
    public resizeBR(pos_x: number, pos_y: number)
    {
        console.log("Executing ShapeComponent.resizeBR() for x: " + this.x + "  y:" + this.y);
    }

    public initDraggingStates()
    {
        console.log("Executing ShapeComponent.initDraggingStates().");

        this.dragTR = false;
        this.dragTL = false;
        this.dragBL = false;
        this.dragBR = false;
        this.dragging = false;
    }

    public getDevicePoint()
    {
        return this.devicePoint;
    }

    public addDevicePoint( dp: DevicePointComponent)
    {
        debugger
        this.devicePoint = dp;
        if( this.devicePoint )
        {
          console.log("ShapeComponent.addDevicePoint() for id: " + dp.getSN() + ":" + dp.getIed() + "-" + dp.getPointId() );
        }
    }

    public unmapDevicePoint()
    {
      console.log("ShapeComponent.unmapDevicePoint() for id: " + this.devicePoint.getSN() + ":" + this.devicePoint.getIed() + "-" + this.devicePoint.getPointId() );
      this.devicePoint = null;
    }


    protected getFillColor(): string
    {
      if( this.devicePoint == null)
      {
          return ShapeComponent.DEFAULT_COLOR_FILL;
      }
      return this.devicePoint.getFillColor();
    }

    protected getBorderColor(): string
    {
      if( this.devicePoint == null )
      {
          return DevicePointComponent.BORDERCOLOR_DEFAULT;
      }
      else
      {
          return this.devicePoint.getBorderColor();
      }
    }

    protected setBorderColor(val: string)
    {
      this.borderColor = val;
    }
 
    protected setFillColor(val: string)
    {
      this.fillColor = val;
    }
 
    protected getTextColor(): string
    {
      if( this.devicePoint == null)
      {
          return DevicePointComponent.TEXTCOLOR_DEFAULT;
      }
      return this.devicePoint.getTextColor();
    }

    protected getDisplayText(): string
    {
      if( this.devicePoint == null )
      {
          return DevicePointComponent.DISPLAYTEXT_DEFAULT;
      }
      else
      {
          return this.devicePoint.getDisplayText();
      }
    }

    protected getFontString(): string
    {
      debugger
      if( this.devicePoint == null )
      {
        console.log("ShapeComponent.getFontString(): " + DevicePointComponent.GetFontString());
        return DevicePointComponent.GetFontString();
      }
      else
      {
        console.log("ShapeComponent.getFontString(): " + this.devicePoint.getFontString());
        return this.devicePoint.getFontString();
      }
    }


public LoadProperties(propdata: { [key: string]: Object }[])
{
  console.log("Executing ShapeComponent.LoadProperties().");

  // Load the property array with symbol properties.
  let item:any = {name: "bordercolor", value: this.borderColor};
  propdata.push(item);
  item = {name: "fillcolor", value: this.fillColor};
  propdata.push(item);
}

public saveProperty(name: string, value: string): boolean
{
    console.log("Executing ShapeComponent.SaveProperty().");

    if( name == "bordercolor")
    {
        this.borderColor = value;
        return true;
    }
    else if( name == "fillcolor")
    {
        this.fillColor = value;
        return true;
    }

    return false;
}

public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
{
  console.log("Executing ShapeComponent.LoadDefaultProperties().");

  // Load the property array with symbol properties.
  let item:any = {name: "bordercolor", value: ShapeComponent.DEFAULT_COLOR_BORDER};
  propdata.push(item);
  item = {name: "fillcolor", value: ShapeComponent.DEFAULT_COLOR_FILL};
  propdata.push(item);
}

public static saveDefaultProperty(name: string, value: string)
{
    console.log("Executing ShapeComponent.SaveDefaultProperty().");

    if( name == "bordercolor")
    {
        ShapeComponent.DEFAULT_COLOR_BORDER = value;
    }
    else if( name == "fillcolor")
    {
        ShapeComponent.DEFAULT_COLOR_FILL = value;
    }
}

public AdjustProperties(): boolean
{
  return true;
}






}