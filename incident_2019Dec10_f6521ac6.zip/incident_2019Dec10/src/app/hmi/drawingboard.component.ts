import { AfterViewInit, Component, ElementRef, Input, OnInit, OnDestroy, ViewChild, HostListener, ViewEncapsulation } from '@angular/core';
import { fromEvent } from 'rxjs';
import { pairwise, switchMap, takeUntil} from 'rxjs/operators';
import { Subscription} from 'rxjs';
import { timer } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Router} from '@angular/router';
import { LineComponent } from './line.component';
import { SwitchComponent } from './switch.component';
import { CircleComponent } from './circle.component';
import { RectangleComponent } from './rectangle.component';
import { TextComponent } from './text.component';
import { LinearGradientComponent } from './lineargradient.component';
import { CircularGradientComponent } from './circulargradient.component';
import { ShapeComponent } from './shape.component';
import { ImageComponent } from './image.component';
import { DevicePointComponent } from './devicepoint.component';
import { StatusPointComponent } from './statuspoint.component';
import { ControlPointComponent } from './controlpoint.component';
import { AnalogPointComponent } from './analogpoint.component';
import { AccumulatorPointComponent } from './accumulatorpoint.component';
import { SetpointComponent } from './setpoint.component';
import { WebsocketServiceDrawingBoard} from './websocketdrawingboard.service';
import { TreeviewService } from '../treeview/treeview.service';
import { Sidebar, ContextMenu, MenuItemModel, ContextMenuModel, MenuEventArgs} from '@syncfusion/ej2-navigations'
import { Button} from '@syncfusion/ej2-buttons';
//import { ComboBox } from '@syncfusion/ej2-dropdowns';
import { Dialog } from '@syncfusion/ej2-popups';
import { DropDownButton, BeforeOpenCloseMenuEventArgs, OpenCloseMenuEventArgs } from '@syncfusion/ej2-splitbuttons';
import { TreeView, NodeClickEventArgs, Toolbar as NavigationToolBar, DragAndDropEventArgs, Tab } from '@syncfusion/ej2-navigations'
import { Grid, Edit, Column, Toolbar} from '@syncfusion/ej2-grids';
import { ColorPicker, ColorPickerEventArgs, TextBox } from '@syncfusion/ej2-inputs';
import { StreamWriter} from '@syncfusion/ej2-file-utils';
import { isNullOrUndefined } from 'util';

import { Draggable, Droppable, DragEventArgs, closest} from "@syncfusion/ej2-base"; 

import { PropGridComponent} from './propgrid.component';
import { ConfigDialog} from '../dialogs/configdialog';
import { SaveDialogComponent} from './savedialog.component';
import { Config } from '../config/config';
import {AppComponent} from '../app.component';
import { SOEDialog } from '../dialogs/soedialog';
import { ServerFilesDialog } from '../dialogs/serverfilesdialog';


Grid.Inject(Edit, Toolbar);

@Component({
  selector: 'app-drawingboard',
  //template: `<canvas #canvas></canvas>`,
  providers: [ TreeviewService ],
  encapsulation: ViewEncapsulation.None,
  templateUrl: './drawingboard.component.html',
  styleUrls: ['./drawingboard.component.css'],
  styles: [
    `
      canvas {
        border: 1px solid #000;
      }
      #loader {
        // color: #008cff;
        color: white
        font-family: 'Helvetica Neue','calibiri';
        font-size: 10px;
        height: 100px;
        left: 100%;
        position: absolute;
        top: 100%;
        width: 100%;
      }
    `
  ]
})
export class DrawingBoardComponent implements AfterViewInit, OnDestroy{
  @Input() width = 2000;
  @Input() height = 1500;
   @ViewChild('canvas') canvas: ElementRef;
  ctx: CanvasRenderingContext2D;
  
  drawingSubscription: Subscription;
  draggingSubscription: Subscription;
  subscribeTimer: any;
  interval;

  // canvasEl: HTMLCanvasElement = this.canvas.nativeElement;


  // Triggers map redraw when true.
  // True when new symbol added, moved or resized on map.
  public invalid: boolean = false;

  // True if editing prior to saving.
  private DirtyBit: boolean = false;
 
  // Array to store map symbols.
  public Shapes: ShapeComponent[] = [];

  public DevicePoints:  DevicePointComponent[] = [];

  // The selected symbol.
  selectedShape: ShapeComponent = null;

  selectedDevicePoint: DevicePointComponent = null;

  //targetShape: ShapeComponent = null;

  // How often to redraw the map in ms.
  // Only gets redrawn if map is marked as invalid.
  timerInterval: number = 30;

  contexMenu: ContextMenu = null;

  sidebar: Sidebar = null;
  pb_dropdown: DropDownButton = null;

  toolbar: Toolbar = null;

  // pb_toggle: Button = null;
  // pb_logout: Button = null;
  // rb_left: RadioButton = null;
  // rb_right: RadioButton = null;
  //dropzone: HTMLElement = null;
  // draggableRect: HTMLElement = null;
  // draggableCircle: HTMLElement = null;
  // draggableLine: HTMLElement = null;
  // draggableText: HTMLElement = null;

  draggableElem: HTMLElement = null;

  private sub: any;

  status: any;
  wsSubscription: Subscription = null;

  // TODO:  Build this from SERVER_IP.
  //url_commServer = "ws://10.210.6.147:1113"
  private url_commServer: string = "";

  cmd_userState: string = "get userstate";
  cmd_sessionClose: string = "session close";

  // TODO: Use this.
  cmd_put: string = "";

  sessionId: string = "";
  //sessionId: string = "S383886777";

  //cmd_sessionOpen: string = "session open root root 10.210.3.63";

  view: string = "data";
  id: string = "";
  pttype: string = "";
  streamId: number = 0;

  public parser: DOMParser;
  public xmlData: Document = null;

  // TODO:  Retrieve from url.
  private SERVER_IP: string = "";
  //private SERVER_IP: string = "10.210.6.147";
  //LOCAL_IP: string = "10.210.6.245"

  //private contents: string = "";
  //rtuFile: string = 'assets/rtu.xml';
  public rtuFile: string = "http://" + this.SERVER_IP + "/wtp/rtu.xml";

  //txtFile: string = 'assets/test.txt';
  //diagramFileLocal: string = 'assets/diagram.txt';
  //diagramFileLocal: string = 'assets/diagram1.sld';

  private diagramFile:string = "";
  private diagramPath: string = "http://" + this.SERVER_IP + "/wtp/diagrams/";

  private soeFile:string = "";
  private soePath: string = "http://" + this.SERVER_IP + "/Soe/";

  private static FILE_TYPE_NONE = 0;
  private static FILE_TYPE_DIAG = 1;
  private static FILE_TYPE_SOE = 2;


  //localFile: string = 'diagram.txt';
  private static DEFAULT_SLD:string = "diagram.sld";

  // Used for local file load.
  private fileReader:FileReader = null;

  public rtuLicense: string;
  public rtuVersion: string;
  public rtuModel: string;
  public rtuName: string;
  public ID: number = 0;

  private static view_DATA = "data";
  private static view_COMM = "comm";  
  private static file_LOCAL:number = 0;
  private static file_REMOTE: number = 1;

  imgpath: string = "";
  imgServers: string = "";
  imgServer: string = "";
  imgClients: string = "";
  imgClient: string = "";
  imgIed: string = "";
  imgPort: string = "";
  imgComponents: string = "";
  imgComponent: string = "";
  imgBlank: string = "";
  imgUnknown: string = "";


  // imgpath: string = "http://" + this.SERVER_IP + "/wtp/images/";
  // imgServers: string = this.imgpath + "serversIcon.gif";
  // imgServer: string = this.imgpath + "serverIcon.gif";
  // imgClients: string = this.imgpath + "clientsIcon.gif";
  // imgClient: string = this.imgpath + "clientIcon.gif";
  // imgIed: string = this.imgpath + "componentIcon.gif";
  // imgPort: string = this.imgpath + "portIcon.gif";
  // imgComponents: string = this.imgpath + "componentsIcon.gif";
  // imgComponent: string = this.imgpath + "componentIcon.gif";
  // imgBlank: string = this.imgpath + "blankIcon.gif";
  // imgUnknown: string = this.imgpath + "unknownIcon.gif";

  qeiLogo: string = this.imgpath + "qeilogo_artfile.jpg";
  exp9430frontal: string = this.imgpath + "exp-9430-frontal.jpg"
  
  // Temporary for now.
  private static deviceName: string = "147wtp";
  private static deviceModel: string = "ePaq-9410";

  // Temp data store for serialized string data.
  private serialData: string[] = []; 

  // Temp data store for serialized string data.
  private soeData: { [key: string]: Object }[] = [];

  elem: HTMLElement = null;
  colorPickerObj: ColorPicker = null;

  private rectangleBtn: Button = null;
  private circleBtn: Button = null;
  private textBtn: Button = null;
  private lineBtn: Button = null;
  private switchBtn: Button = null;

  private image1Btn: Button = null;
  private image2Btn: Button = null;
  private image3Btn: Button = null;
  private image4Btn: Button = null;

  private clearDiagramBtn: Button = null;
  private saveLocalBtn: Button = null;
  private loadLocalBtn: Button = null;
  private saveRemoteBtn: Button = null;
  private loadRemoteBtn: Button = null;

  private leftBtn: Button = null;
  private rightBtn: Button = null;
  private toggleBtn: Button = null;

  private closeBtn: Button = null;
  private newTerminalBtn: Button = null;
  private newTreeBtn: Button = null;

  private configBtn: Button = null;
  private soeBtn: Button = null;

  private propertyGrid: PropGridComponent;

  // Master configuration dialog.
  public configDialog: ConfigDialog;
  public soeDialog: SOEDialog;
  public filesDialog: ServerFilesDialog;
  public saveDialog: SaveDialogComponent;

  // Container to store the master configuration once it
  // downloads from the epaq or is applied from the 
  // master configuration dialog.
  //private configdata: { [key: string]: Object }[] = []; 


  // Data store for tree view items.
treedata: { [key: string]: Object }[] = []; 

tabs: Tab = null;

public rowData: object;

private pointTypes: { [key: string]: Object }[] =  
  [
  {
     id: 'st', label: 'Status Points', image: this.imgComponents, expanded: false, 
  },
  {
    id: 'an', label: 'Analog Points', image: this.imgComponents, expanded: false,
  },
  {
    id: 'ac', label: 'Accumulator Points', image: this.imgComponents, expanded: false,
  },
  {
    id: 'co', label: 'Control Points', image: this.imgComponents, expanded: false,
  },
  {
    id: 'se', label: 'Setpoints', image: this.imgComponents, expanded: false,
  }
];

private symbolTypes: { [key: string]: Object }[] =  
  [   
    { id: '01', label: 'Symbols', expanded: true, image: this.imgComponents,
       subChild: [
          {
            id: 'rectangle', label: 'Rectangle', image: this.imgComponents, expanded: false, 
          },
          {
            id: 'circle', label: 'Circle', image: this.imgComponents, expanded: false,
          },
          {
            id: 'line', label: 'Line', image: this.imgComponents, expanded: false,
          },
          {
            id: 'text', label: 'Text', image: this.imgComponents, expanded: false,
          },
      ]
    },
    {
      id: '02', label: 'Images', expanded: true, image: this.imgComponents,
      subChild: [
        {
          id: 'img01', label: 'qeiLogo', image: this.qeiLogo, expanded: false, 
        },
        {
          id: 'img02', label: 'exp9430frontal', image: this.exp9430frontal, expanded: false,
        },
        {
          id: 'img03', label: 'image03', image: this.imgIed, expanded: false,
        },
        {
          id: 'img04', label: 'image04', image: this.imgClient, expanded: false,
        },
    ]
    }
];



// private static PROPTYPE_NONE: number = 0;
// private static PROPTYPE_SYMBOL: number = 1;
// private static PROPTYPE_DEVICEPOINT: number = 2;  

public static OP_CODE_NONE = 0;
public static OP_CODE_CLOSE = 1;
public static OP_CODE_TREEVIEW = 2;
public static OP_CODE_TERMVIEW = 3;

private op_code:number = DrawingBoardComponent.OP_CODE_NONE;


nodeExpanding: boolean = false;
nodeExpanded: boolean = false;
nodeCollapsing: boolean = false;
nodeCollapsed: boolean = false;


private static FILE_DELIMITER: string = "^";

  // Stores the point data.
  public pointdata: { [key: string]: Object }[] = [];

  // Displays rtu.xml file.
  treeViewInstance: TreeView = null;

  toolBoxTree: TreeView = null;

  //propEditor: InPlaceEditor = null;

  propGrid_Tree: Grid = null;
  public propdata_tree: { [key: string]: Object }[] = []; 

  //propGrid_toolbox: Grid = null;
 //public propdata_toolbox: { [key: string]: Object }[] = []; 


  //  Timer for periodic map drawing.
  //  First argument is initial timeout interval.  
  //  Second argument is subsequently timeout interval.
  source = timer(this.timerInterval, this.timerInterval);
  subscribe = this.source.subscribe(
    val => this.drawMap()
  );

  //loadStaticPointData:boolean = false;
    
  constructor( private wsServiceComm: WebsocketServiceDrawingBoard,
               public treeviewService: TreeviewService, 
               private route: ActivatedRoute, 
               private router: Router
               ){}

  StopTimer()
  {
  }

  public GetDiagramPath(): string
  {
    return this.diagramPath;
  }


  ngOnInit()
  {
    this.IncremementView();
  }


  ngAfterViewInit()
  {
    console.log("Executing ngAfterViewInit()");
    // get the context
    const canvasEl: HTMLCanvasElement = this.canvas.nativeElement;
    //this.canvasEl = this.canvas.nativeElement;

    this.ctx = canvasEl.getContext('2d');

    // set the width and height
    canvasEl.width = this.width;
    canvasEl.height = this.height;

    // set some default properties about the line
    this.ctx.lineWidth = 3;
    this.ctx.lineCap = 'round';
    this.ctx.strokeStyle = '#000';

    //this.canvasEl.addEventListener('mousemove', this.OnMouseMove);

    // First capture the mouse down event.
    this.captureMouseDownEvent(canvasEl);

    // Initialize menu items.
    let menuItems: MenuItemModel[] = [
    {
        text: 'Delete'
    },
    {
      text: 'Unmap'
    },
    {
        text: 'Copy'
    },
    {
        text: 'Paste'
    }];

    // Initialize ContextMenu options.
    let menuOptions: ContextMenuModel = 
    {
      items: menuItems,
      select: (args: MenuEventArgs) => 
      {
        if(args.item.text === 'Delete') 
        {
            this.DeleteSymbol();
        }
        if(args.item.text === 'Unmap') 
        {
            this.UnmapSymbol();
        }
      }
    };

    // Initialize ContextMenu component.
    this.contexMenu = new ContextMenu(menuOptions, '#contextmenu');
    //menuObj.open(60, 20);

    // Disable the browser context menu.
    document.oncontextmenu = function()
    {
      return false;
    }

    this.setPaths();
   
    // this.sub = this.route.params.subscribe(params => {
    //   this.sessionId = params['sessionId']; // (+) converts string 'id' to a number
    //   console.log("Extracted Session Id: " + this.sessionId);
    // });  
    
    this.sessionId = localStorage.getItem("sessionid");
    console.log("DrawingBoardComponent.ngOnInit() - Session ID: " + this.sessionId);

    //debugger
    this.RequestAllClientPoints();

    //this.processXML();
    this.CreateControls();

    this.ApplyDefaultConfig();

    this.CreateSidebar();       
    //this.CreateDropDown();
    //this.CreateFileManager();

    this.CreateToolbar();

    // debugger
    // // DEBUG:
    // this.sub = this.route.params.subscribe(params => {
    //   this.sessionId = params['sessionId']; // (+) converts string 'id' to a number
    //   console.log("Extracted Session Id: " + this.sessionId);
    // });

    // Receive point static/dynamic data.
    //this.createDataSubscription();
    
    // this.wsSubscription = this.wsServiceComm.createObservableSocket(
    //   this.url_commServer, this.cmd_userState + " " + this.sessionId) 
    //   //this.cmd_sessionOpen)
    //   .subscribe(
    //   data=>this.handleMessage(data),+++++++++

    //   err=>alert('err: DrawingComponent Initial Subscribe'),
    //   ()=>
    //   { console.log('The DrawingComponent Initial Subscription Is Complete'); }
    //   );

  }


  private IncremementView()
  {
      let num:number = parseInt(localStorage.getItem("numSLDView"));
      console.log("IncrementView() - numSLDView read: " + num);
      num += 1;
      localStorage.setItem("numSLDView", num.toString() );      
      console.log("numSLDView written: " + num);
  }

  // call this event handler before browser refresh/close tab.
  @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) 
  {
    console.log("Processing beforeunload...");
    this.StopStream();
    this.DestroyControls();
    this.DecrementView();
  }

  // execute this function before browser refresh
  DecrementView(){
    // decrement into local storage before browser refresh
    let num:number = parseInt(localStorage.getItem("numSLDView"));
    console.log("DecrementView() - numSLDView read: " + num);
    num -= 1;
    console.log("numSLDView written: " + num);
    localStorage.setItem("numSLDView", num.toString() );      
    console.log("numSLDView written: " + num);  
  }
  
  

  onDrag(e) 
  {
    console.log("Executing onDragRect() Event Handler for: " + e.target.id);
    e.dataTransfer.setData("text", e.target.id);
  }


  getServerIP()
  {
    // TODO:  Use this line for development mode.
    //var url = "http://10.210.6.147";

    // TODO:  For production mode, use first line to set the url.
    // Get the server ip from user entered url.
    //url = window.location.href;
    // var pos1 = url.indexOf('//');
    // var tok = url.slice(pos1+2);
    // var pos2 = tok.indexOf('/');
    // if( pos2 >= 0 )
    // {    
    //   this.SERVER_IP = tok.slice(0,pos2);
    // }
    // else
    // {
    //   this.SERVER_IP = tok;
    // }

    this.SERVER_IP = localStorage.getItem("serverIP");
    console.log("SERVER_IP: " + this.SERVER_IP);
  }

  CreateControls()
  {
    this.CreateTabs();
         
    // Display the tree view.
    this.CreateTreeView();

    //this.CreateToolBoxTree();

    this.CreatePropGrid_Tree();

    this.CreateDialogs();

    // this.propertyGrid = new PropGridComponent(this);
    // if( this.propertyGrid )
    // {
    //   // Display property grid but in invisible state.
    //   this.propertyGrid.CreatePropGridDialog(false);
    // }

    // //debugger
    // this.configDialog = new ConfigDialog(this, ConfigDialog.PARENT_TYPE_DBC);
    // if( this.configDialog )
    // {
    //   // Display Configuration Dialog but in invisible state.
    //   this.configDialog.CreateDialog(false);
    // }

    // this.soeDialog = new SOEDialog(this, ConfigDialog.PARENT_TYPE_DBC);
    // if( this.soeDialog )
    // {
    //   // Display SOE Dialog but in invisible state.
    //   this.soeDialog.CreateDialog(false);
    // }

    //this.CreatePropGrid_ToolBox();

  }

  private CreateDialogs()
  {
    this.propertyGrid = new PropGridComponent(this);
    if( this.propertyGrid )
    {
      // Display property grid but in invisible state.
      this.propertyGrid.CreatePropGridDialog(false);
    }

    //debugger
    this.configDialog = new ConfigDialog(this, Config.PARENT_TYPE_DBC);
    if( this.configDialog )
    {
      // Display Configuration Dialog but in invisible state.
      this.configDialog.CreateDialog(false);
    }

    this.soeDialog = new SOEDialog(this, Config.PARENT_TYPE_DBC);
    if( this.soeDialog )
    {
      // Display SOE Dialog but in invisible state.
      this.soeDialog.CreateDialog(false);
    }

    this.filesDialog = new ServerFilesDialog(this, Config.PARENT_TYPE_DBC);
    if( this.filesDialog )
    {
      // Display SOE Dialog but in invisible state.
      this.filesDialog.CreateDialog(false);
    }
    
    this.saveDialog = new SaveDialogComponent(this);
    if( this.saveDialog )
    {
      // Display Save Dialog but in invisible state.
      this.saveDialog.CreateSaveDialog(false);
    }          
    
  }

  setPaths()
  {
    //debugger
    this.getServerIP();

    this.url_commServer = "ws://" + this.SERVER_IP + ":" + Config.PORT_COMMSERVER;

    this.rtuFile = "http://" + this.SERVER_IP + "/wtp/rtu.xml/";
    this.diagramPath = "http://" + this.SERVER_IP + "/wtp/diagrams/";
    this.soePath = "http://" + this.SERVER_IP + "/Soe/";
  
    this.imgpath = "http://" + this.SERVER_IP + "/wtp/images/";
    this.imgServers = this.imgpath + "serversIcon.gif";
    this.imgServer = this.imgpath + "serverIcon.gif";
    this.imgClients = this.imgpath + "clientsIcon.gif";
    this.imgClient = this.imgpath + "clientIcon.gif";
    this.imgIed = this.imgpath + "componentIcon.gif";
    this.imgPort = this.imgpath + "portIcon.gif";
    this.imgComponents = this.imgpath + "componentsIcon.gif";
    this.imgComponent = this.imgpath + "componentIcon.gif";
    this.imgBlank = this.imgpath + "blankIcon.gif";
    this.imgUnknown = this.imgpath + "unknownIcon.gif";

    this.qeiLogo = this.imgpath + "qeilogo_artfile.jpg";
    this.exp9430frontal = this.imgpath + "exp-9430-frontal.jpg"

  }

  // public SaveConfig(config: Array<any>)
  // {
  //   this.configdata = [];

  //   for( let i:number=0; i < config.length; ++i )
  //   {
  //     let item:any = config[i];
  //     if( item )
  //     {
  //       this.configdata[i] = item;
  //     }
  //   }
  // }

  public ApplyConfig_ActiveDiagram()
  {
    for( let i:number=0; i<this.Shapes.length; ++i )
    {
      let shape:ShapeComponent = this.Shapes[i];
      if( shape )
      {
        //if( this.configDialog )
        //{
          shape.Init(Config.configdata);
        //}
      }
    }

    this.invalid = true;
  }

  // Apply default configuration to symbol types and point types.
  private ApplyDefaultConfig()
  {
    if( ! this.configDialog )
    {
      return;
    }

    // Apply default configuration to symbol types.
    ShapeComponent.ApplyDefaultConfig(Config.configdata);
    CircleComponent.ApplyDefaultConfig(Config.configdata);
    LineComponent.ApplyDefaultConfig(Config.configdata);
    RectangleComponent.ApplyDefaultConfig(Config.configdata);
    TextComponent.ApplyDefaultConfig(Config.configdata);
    SwitchComponent.ApplyDefaultConfig(Config.configdata);

    // Apply default configuration to point types.
    DevicePointComponent.ApplyDefaultConfig(Config.configdata);
    AnalogPointComponent.ApplyDefaultConfig(Config.configdata);
    AccumulatorPointComponent.ApplyDefaultConfig(Config.configdata);
    ControlPointComponent.ApplyDefaultConfig(Config.configdata);
    SetpointComponent.ApplyDefaultConfig(Config.configdata);
    StatusPointComponent.ApplyDefaultConfig(Config.configdata);
  }


  InitStates()
  {
    if( this.selectedShape != null)
    {  
      this.selectedShape.dragging = false;
      this.selectedShape.dragTL = false;
      this.selectedShape.dragTR = false;
      this.selectedShape.dragBR = false;
      this.selectedShape.dragBL = false;
      //this.selectedShape = null;
    }
  }


CreateToolbar()
{
  let symbolTypes: string[] = ['Symbols', 'Rectangle', 'Circle', 'Line', 'Text'];
  let imageTypes: string[] = ['Images','images1', 'image2', 'image3', 'image4'];
  let diagramOptions: string[] = ['Diagram','Clear Diagram', 'Save Diagram Local', 'Load Diagram Local', 'Save Diagram Remote', 'Load Diagram Remote'];
  let sidebarOptions: string[] = ['Sidebar', 'Left', 'Right', 'Toggle'];

  let toolbar: NavigationToolBar = new NavigationToolBar({
  created: this.CreateToolBarButtons.bind(this),
      items: [
        { template: '<button class="e-btn" id="rectangle_btn" style="background-color:yellowgreen;padding:0px"></button>' },
        { template: '<button class="e-btn" id="circle_btn" style="background-color:magenta;padding:0px"></button>' },
        { template: '<button class="e-btn" id="line_btn" style="background-color:blue;padding:0px"></button>' },
        { template: '<button class="e-btn" id="text_btn" style="background-color:red;padding:0px"></button>' },
        { template: '<button class="e-btn" id="switch_btn" style="background-color:aqua;padding:0px"></button>' },

        { type: "Separator" },
        { template: '<button class="e-btn" id="image01_btn" style="padding:0"><img src="http://10.210.6.147/wtp/images/qeilogo_artfile.jpg" height="25px" width="25px"/></button>' },
        { template: '<button class="e-btn" id="image02_btn" style="padding:0"><img src="http://10.210.6.147/wtp/images/exp-9430-frontal.jpg" height="25px" width="25px"/></button>' },
        { template: '<button class="e-btn" id="image03_btn" style="padding:0"><img src="http://10.210.6.147/wtp/images/componentsIcon.gif" height="25px" width="25px"/></button>' },
        { template: '<button class="e-btn" id="image04_btn" style="padding:0"><img src="http://10.210.6.147/wtp/images/clientIcon.gif" height="25px" width="25px"/></button>' },

        { type: "Separator" },
        { template: '<button class="e-btn" id="clearDiagram_btn" style="background-color:magenta;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="saveLocal_btn" style="background-color:yellow;padding:0px"></button>' },
        { template: '<button class="e-btn" id="loadLocal_btn" style="background-color:blue;padding:0px"></button>' },
        { template: '<button class="e-btn" id="saveRemote_btn" style="background-color:yellowgreen;padding:0px"></button>' },
        { template: '<button class="e-btn" id="loadRemote_btn" style="background-color:violet;padding:0px"></button>' },

        { type: "Separator" },
        { template: '<button class="e-btn" id="left_btn" style="background-color:orange;padding:0px"></button>' },
        { template: '<button class="e-btn" id="right_btn" style="background-color:violet;padding:0px"></button>' },
        { template: '<button class="e-btn" id="toggle_btn" style="background-color:blue;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="tree_btn" style="background-color:yellowgreen;padding:0px"></button>' },
        { template: '<button class="e-btn" id="terminal_btn" style="background-color:magenta;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="config_btn" style="background-color:yellow;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="soe_btn" style="background-color:aqua;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="close_btn" style="background-color:#E91E63"></button>' },
    ]
  });
  toolbar.appendTo('#toolbar');

  //debugger
  // Support to drag/drop toolbar items:
  for (let i = 0; i < document.querySelectorAll('.e-icons').length; i++) 
  { 
    //Draggable 
    let elements: any = document.getElementsByClassName('e-icon-btn');

    let elem: Element = document.getElementsByClassName('e-icon-btn')[i] as HTMLElement
    if( !elem )
    {
      console.log("DrawingComponent.CreateToolbar - NULL elem for drag/drop support.");
      return;
    }
    if( elem.id == "rectangle_btn" ||
        elem.id == "circle_btn" ||
        elem.id == "line_btn" ||
        elem.id == "text_btn" ||
        elem.id == "switch_btn" ||
        elem.id == "image01_btn" ||
        elem.id == "image02_btn" ||
        elem.id == "image03_btn" || 
        elem.id == "image04_btn" )
     {
      console.log("Found " + elem.id);
      let draggable: Draggable = new Draggable(document.getElementsByClassName('e-icon-btn')[i] as HTMLElement, 
      { 
        clone: true,
         helper: (e: { sender: MouseEvent & TouchEvent, element: HTMLElement }) => { 
          console.log("Helper Event") 
           // create the clone element like this 
           let virtualEle: HTMLElement; 
           let dragTarget = <Element>e.sender.target; 
          
           let dragEle = closest(dragTarget, '.e-toolbar-item'); 
           let cloneEle: Element = <Element>(dragEle.cloneNode(true)); 
           virtualEle = document.createElement('div'); 
           virtualEle.appendChild(cloneEle); 
           document.body.appendChild(virtualEle); 
           return virtualEle; 
         }, 
        dragStart: (e: DragEventArgs) => 
        { 
          console.log("Drag start event"); 
        }, 
        drag: (e: DragEventArgs) => 
        { 
          console.log("Drag  event"); 
        }, 
        dragStop: (e: { event: MouseEvent & TouchEvent, 
                        element: HTMLElement, 
                        target: Element, 
                        helper: HTMLElement }) => 
        {
          console.log("Drag stop event");
          //debugger;
          e.helper.remove();
          let newEle: HTMLElement;
          newEle = document.getElementById('myCanvas');
          let dropEle: HTMLElement = <HTMLElement>newEle.cloneNode(true);
          dropEle.style.display = 'block';
          let droparea: HTMLElement = document.getElementById('droparea');
          droparea.appendChild(dropEle);

          const currentPos = 
          {
            //x: e.event.x - e.event.offsetX,
            //y: e.event.y - e.event.offsetY
            x: e.event.x,
            y: e.event.y
          };

          //if((e.element == document.getElementById('e-tbr-btn_0') && document.getElementById('myCanvas'))) 
          if( e.element.id == "rectangle_btn")
          {
            this.addRectangle(currentPos);  
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id == "circle_btn")
          {
            this.addCircle(currentPos);  
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id == "line_btn")
          {
            this.addLine(currentPos);  
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id == "text_btn")
          {
            this.addText(currentPos, true);  
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id == "switch_btn")
          {
            this.addSwitch(currentPos);  
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id.startsWith("image01_btn"))
          {
            this.addImage(currentPos, this.qeiLogo);
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id.startsWith("image02_btn"))
          {
            this.addImage(currentPos, this.exp9430frontal);
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id.startsWith("image03_btn"))
          {
            this.addImage(currentPos, this.imgComponent);
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else if( e.element.id.startsWith("image04_btn"))
          {
            this.addImage(currentPos, this.imgClient);
            this.InitStates();
            this.treeViewInstance.ensureVisible(elem.id);
          }
          else
          {
            //this.selectedShape = null;
            console.log("ID Not Recognized: " + e.element.id)
          }
        }, 
     });
     } 
  } 

//Dropppable 

   let droppable: Droppable = new Droppable(document.getElementById('droparea'), 
   { 
       drop: (e: DragEventArgs) => 
       { 
          console.log("Drag item dropped event");
       } 
   }); 
  
}

CreateToolBarButtons()
{
  this.rectangleBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: false });
  this.rectangleBtn.appendTo('#rectangle_btn');
  this.rectangleBtn.element.setAttribute("title", "rectangle");

  this.circleBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: false });
  this.circleBtn.appendTo('#circle_btn');
  this.circleBtn.element.setAttribute("title", "circle");

  this.lineBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: false });
  this.lineBtn.appendTo('#line_btn');
  this.lineBtn.element.setAttribute("title", "line");

  this.textBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: false });
  this.textBtn.appendTo('#text_btn');
  this.textBtn.element.setAttribute("title", "text");

  this.switchBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: false });
  this.switchBtn.appendTo('#switch_btn');
  this.switchBtn.element.setAttribute("title", "switch");

  this.image1Btn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons', isToggle: false });
  this.image1Btn.appendTo('#image01_btn');
  this.image1Btn.element.setAttribute("title", "QEI Logo");

  this.image2Btn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons', isToggle: false });
  this.image2Btn.appendTo('#image02_btn');
  this.image2Btn.element.setAttribute("title", "EPAQ-9430 Frontal");

  this.image3Btn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons', isToggle: false });
  this.image3Btn.appendTo('#image03_btn');
  this.image3Btn.element.setAttribute("title", "Components Icon");

  this.image4Btn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons', isToggle: false });
  this.image4Btn.appendTo('#image04_btn');
  this.image4Btn.element.setAttribute("title", "Client Icon");

  this.clearDiagramBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-clear-icon', isToggle: true });
  this.clearDiagramBtn.appendTo('#clearDiagram_btn');
  this.clearDiagramBtn.element.setAttribute("title", "clear diagram");
  this.clearDiagramBtn.element.onclick = (): void => 
  {
      console.log("Executing clearDiagramBtn.onclick()");
      this.ClearDiagram();
  }

  this.saveLocalBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-save-icon', isToggle: true });
  this.saveLocalBtn.appendTo('#saveLocal_btn');
  this.saveLocalBtn.element.setAttribute("title", "save diagram to local");
  this.saveLocalBtn.element.onclick = (): void => 
  {
      console.log("Executing saveLocalBtn.onclick()");
      this.Serialize(false);
  }

  this.loadLocalBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-terminal-icon', isToggle: true });
  this.loadLocalBtn.appendTo('#loadLocal_btn');
  this.loadLocalBtn.element.setAttribute("title", "load diagram from local");
  this.loadLocalBtn.element.onclick = (): void => 
  {
      console.log("Executing loadLocalBtn.onclick()");
      //this.ReadDiagramFile(false);
      document.getElementById("loadfile").style.display = "block";    
  }

  this.saveRemoteBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-save-icon', isToggle: true });
  this.saveRemoteBtn.appendTo('#saveRemote_btn');
  this.saveRemoteBtn.element.setAttribute("title", "save diagram to server");
  this.saveRemoteBtn.element.onclick = (): void => 
  {
      console.log("Executing saveRemoteBtn.onclick()");
      this.Serialize(true);
  }

  this.loadRemoteBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-terminal-icon', isToggle: true });
  this.loadRemoteBtn.appendTo('#loadRemote_btn');
  this.loadRemoteBtn.element.setAttribute("title", "load diagram from server");
  this.loadRemoteBtn.element.onclick = (): void => 
  {
      console.log("Executing loadRemoteBtn.onclick()");
      //this.ReadDiagramFile(true);
      this.RequestDiagramFiles();
  }

  this.leftBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.leftBtn.appendTo('#left_btn');
  this.leftBtn.element.setAttribute("title", "left sidebar");
  this.leftBtn.element.onclick = (): void => 
  {
      console.log("Executing leftBtn.onclick()");
      this.sidebar.position = "Left";
      document.getElementById("toggle").style.cssFloat = "left";
  }

  this.rightBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.rightBtn.appendTo('#right_btn');
  this.rightBtn.element.setAttribute("title", "right sidebar");
  this.rightBtn.element.onclick = (): void => 
  {
      console.log("Executing rightBtn.onclick()");
      this.sidebar.position = "Right";
      document.getElementById("toggle").style.cssFloat = "right";
  }

  this.toggleBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.toggleBtn.appendTo('#toggle_btn');
  this.toggleBtn.element.setAttribute("title", "toggle sidebar");
  this.toggleBtn.element.onclick = (): void => 
  {
      console.log("Executing toggleBtn.onclick()");
      this.sidebar.toggle();
  }

  this.closeBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-logout-icon', isToggle: true });
  this.closeBtn.appendTo('#close_btn');
  this.closeBtn.element.setAttribute("title", "close");
  if( ! Config.MODE_MULTITABS )
  {
    this.closeBtn.element.setAttribute("title", "logout");
  }
  this.closeBtn.element.onclick = (): void => 
  {
      //debugger
      console.log("Executing closeBtn.onclick()");
      if( this.DirtyBit )
      {
        this.op_code = DrawingBoardComponent.OP_CODE_CLOSE;
        this.saveDialog.dialog.visible = true;
        // let savedialog: SaveDialogComponent = new SaveDialogComponent(this);
        // if( savedialog )
        // {
        //   // Display Save Dialog.
        //   savedialog.CreateSaveDialog();
        // }
      }
      else
      {
        //if( Config.MODE_DEV )
        if( Config.MODE_MULTITABS )
        {
          // DEV MODE:
          this.closeWindow();
        }
        else
        {
          // Test for production
          this.StopStream();
          this.DestroyControls();
        
          // Navigate back to login screen.
          this.router.navigateByUrl('/app');
        }      
      }
  }

  this.newTerminalBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.newTerminalBtn.appendTo('#terminal_btn');
  this.newTerminalBtn.element.setAttribute("title", "terminal view");
  this.newTerminalBtn.element.onclick = (): void => 
  {
    //if( Config.MODE_DEV )
    if( Config.MODE_MULTITABS )
    {
      let num:number = parseInt(localStorage.getItem("numTermView"));
      if( num < Config.MAX_TERMVIEWS)
      {
        console.log("Executing newTerminalBtn.onclick()");
        AppComponent.OpenInNewTab('/terminal');  
      }
      else
      {
        alert("Maximum Terminal Views Reached: Only " + Config.MAX_TERMVIEWS + " Allowed.");
      }
    }
    else
    {
      // Test for production
      this.StopStream();
      this.DestroyControls();
  
      // Navigate to terminal view.
      this.router.navigateByUrl('/terminal');
    }

    // OLD_CODE:
    // if( this.DirtyBit )
    // {
    //   // Prompt to save diagram.
    //   //debugger;
    //   this.op_code = DrawingBoardComponent.OP_CODE_TERMVIEW
    //   let savedialog: SaveDialogComponent = new SaveDialogComponent(this);
    //   if( savedialog )
    //   {
    //     // Display Save Dialog.
    //     savedialog.CreateSaveDialog();
    //   }
    // }
    // else
    // {
    //   // this.StopStream();

    //   // // Destroy the property grids.
    //   // this.DestroyPropGrid_Tree();
    //   // //this.DestroyPropGrid_ToolBox();
    //   // this.DestroyPropGridDialog();
    //   // this.DestroyConfigDialog();
      

    //   // // Destroy the tree views.
    //   // this.DestroyTreeView();
    //   // this.DestroyTBTreeView();

    //   //this.router.navigate(['/terminal', this.sessionId]);
    //   AppComponent.OpenInNewTab('/terminal');
      
    // }
  }

  this.newTreeBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.newTreeBtn.appendTo('#tree_btn');
  this.newTreeBtn.element.setAttribute("title", "tree view");
  this.newTreeBtn.element.onclick = (): void => 
  {
    //if( Config.MODE_DEV )
    if( Config.MODE_MULTITABS )
    {
      // DEV_MODE:
      console.log("Executing newTreeBtn.onclick()");

      let num:number = parseInt(localStorage.getItem("numTreeView"));
      console.log("Num Tree Views Read: " + num);
      if( num < Config.MAX_TREEVIEWS)
      {
        AppComponent.OpenInNewTab('/treeview');
      }
      else
      {
        alert("Maximum Tree Views Reached: Only " + Config.MAX_TREEVIEWS + " Allowed.");
      }
    }
    else
    {
      debugger
      // Test for production
      this.StopStream();
      this.pointdata = [];
      this.canvas = null;
      this.DestroyControls();
  
      // Navigate back to login screen.
      this.router.navigateByUrl('/treeview');
    }
    

    // OLD CODE
    // if( this.DirtyBit )
    // {
    //   // Prompt to save diagram.
    //   //debugger;
    //   this.op_code = DrawingBoardComponent.OP_CODE_TREEVIEW
    //   let savedialog: SaveDialogComponent = new SaveDialogComponent(this);
    //   if( savedialog )
    //   {
    //     // Display Save Dialog.
    //     savedialog.CreateSaveDialog();
    //   }
    // }
    // else
    // {  
    //   // this.StopStream();

    //   // // Destroy the property grids.
    //   // this.DestroyPropGrid_Tree();
    //   // //this.DestroyPropGrid_ToolBox();
    //   // this.DestroyPropGridDialog();
    //   // this.DestroyConfigDialog();

      
    //   // // Destroy the tree views.
    //   // this.DestroyTreeView();
    //   // this.DestroyTBTreeView();

    //   // this.router.navigate(['/treeview', this.sessionId]);
    //   AppComponent.OpenInNewTab('/treeview');
    // }
  }

  this.soeBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.soeBtn.appendTo('#soe_btn');
  this.soeBtn.element.setAttribute("title", "SOE logs");
  this.soeBtn.element.onclick = (): void => 
  {
    console.log("Executing soe.onclick()");
    this.RequestSOEFiles();
  }

  this.configBtn = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.configBtn.appendTo('#config_btn');
  this.configBtn.element.setAttribute("title", "config");
  this.configBtn.element.onclick = (): void => 
  {
    console.log("Executing configBtn.onclick()");

    // if( this.configDialog != null )
    // {
    //   this.DestroyConfigDialog();
    // }

    // if( this.configDialog == null )
    // {
    //   this.configDialog = new ConfigComponent(this, ConfigComponent.PARENT_TYPE_TREEVIEW);
    //   if( this.configDialog )
    //   {
    //     // Display Configuration Dialog.
    //     this.configDialog.CreateDialog(true);
    //   }
    // }

    if( this.configDialog != null )
    {
      this.configDialog.dialog.visible = true;
    }
  }  
}

public ClearConfigDialog()
{
  if( this.configDialog != null )
  {
    this.configDialog = null;
  }
}

 
CreateSidebar()
{
  this.sidebar = new Sidebar({
    width: '250px',
    showBackdrop: false,
    //dockSize:"44px",
    //enableDock: false,
    //height: '50%',
    //created:onCreate
    //type: "Slide"
    });
  this.sidebar.appendTo('#sidebar');
}

CreateColorPicker()
{
  console.log("Executing CreateColorPicker()");

  let colorPicker: ColorPicker = new ColorPicker(
    {
        inline: true,
        change: (args: ColorPickerEventArgs): void => {
            (ddb.element.children[0] as HTMLElement).style.backgroundColor = args.currentValue.rgba;
            closePopup();
        }
    });
    colorPicker.appendTo('#element');

  let ddb: DropDownButton = new DropDownButton(
    {
        target: ".e-colorpicker-wrapper",
        iconCss: "e-dropdownbtn-preview",
        beforeClose: (args: BeforeOpenCloseMenuEventArgs): void => {
            args.element.parentElement.querySelector('.e-cancel').removeEventListener('click', closePopup);
        },
        open: (args: OpenCloseMenuEventArgs): void => {
            args.element.parentElement.querySelector('.e-cancel').addEventListener('click', closePopup);
        }
    });
    ddb.appendTo('#dropdownbtn');

  function closePopup(): void {
    ddb.toggle();
  }
}


  // Mouse down event handler.
  captureMouseDownEvent(canvasEl: HTMLCanvasElement) {
    // this will capture all mousedown events from the canvas element
    this.drawingSubscription = fromEvent(canvasEl, 'mousedown' )
        .pipe( pairwise())
      .subscribe((res: [MouseEvent, MouseEvent]) => {
                
        const rect = canvasEl.getBoundingClientRect();

        // previous and current position with the offset
        const prevPos = {
          x: res[0].clientX - rect.left,
          y: res[0].clientY - rect.top
        };

        const currentPos = {
          x: res[1].clientX - rect.left,
          y: res[1].clientY - rect.top
        };

        //debugger
        this.selectedShape = this.FindSymbol(currentPos);
        if( this.selectedShape != null )
        {
          console.log("res: " + res[1].which);
          if( res[1].which == 0x3)
          {            
            console.log("Right Mouse Clicked.");
            this.contexMenu.open(currentPos.x, currentPos.y);
          }
          else
          {
            // Selected a shape.

            // Display the symbol prop sheet.
            //this.LoadSymbolProperties();

            this.ClearBRSymbols();
            this.selectedShape.drawBR = true;
            this.propertyGrid.dialog.visible = true;
            this.invalid = true;

            console.log("Symbol Selected - Capturing Mouse Events...");
            this.captureMouseMoveEvents(canvasEl);
          }
        }
        else
        {
          // No shape selected:
          // Clear both property grids.
          this.resetPropData_Tree();
          this.propertyGrid.resetPropData_Toolbox();
          this.propertyGrid.dialog.visible = false;
        }  
      });   
  }

  // Mouse Move Event Handler.
  captureMouseMoveEvents(canvasEl: HTMLCanvasElement) {
    // this will capture all mousedown events from the canvas element
    this.drawingSubscription = fromEvent(canvasEl, 'mousedown')
       .pipe(
        switchMap(e => {
          // after a mouse down, we'll record all mouse moves
           return fromEvent(canvasEl, 'mousemove').pipe(
             // we'll stop (and unsubscribe) once the user releases the mouse
             // this will trigger a 'mouseup' event
             takeUntil(fromEvent(canvasEl, 'mouseup')),
             // we'll also stop (and unsubscribe) once the mouse leaves the canvas (mouseleave event)
             takeUntil(fromEvent(canvasEl, 'mouseleave')),
             // pairwise lets us get the previous value to draw a line from
             // the previous point to the current point
             pairwise()
        );
        })
       )
      .subscribe((res: [MouseEvent, MouseEvent]) => {        
        const rect = canvasEl.getBoundingClientRect();

        // previous and current position with the offset
        const prevPos = {
          x: res[0].clientX - rect.left,
          y: res[0].clientY - rect.top
        };

        const currentPos = {
          x: res[1].clientX - rect.left,
          y: res[1].clientY - rect.top
        };

        // Update the shape's x,y coordinates.
        //if( this.dragging == true && this.selectedShape != null )
        if( this.selectedShape != null)
        {
          this.DirtyBit = true;

          if( this.selectedShape.dragTL )
          {
            this.selectedShape.resizeTL(currentPos.x, currentPos.y)
            this.invalid = true;
          }
          else if( this.selectedShape.dragTR )
          {
            this.selectedShape.resizeTR(currentPos.x, currentPos.y)
            this.invalid = true;
          }
          else if( this.selectedShape.dragBL )
          {
            this.selectedShape.resizeBL(currentPos.x, currentPos.y)
            this.invalid = true;
          }
          else if( this.selectedShape.dragBR )
          {
            this.selectedShape.resizeBR(currentPos.x, currentPos.y)
            this.invalid = true;
          }
          else if( this.selectedShape.dragging )
          {
            // let offsetX = currentPos.x-this.selectedShape.getX();
            // let offsetY = currentPos.y-this.selectedShape.getY();
            // this.selectedShape.updateXY(this.selectedShape.getX()-offsetX, this.selectedShape.getY()-offsetY);       
            this.selectedShape.updateXY(currentPos.x, currentPos.y);
            this.invalid = true;
          }

          // Draw Bounded Rectangle around moved symbol.
          //this.selectedShape.drawBoundedRect(this.ctx);
        }
      });   
  }


  ClearBRSymbols()
  {
    for(let i:number = 0; i<this.Shapes.length; ++i)
    {
      this.Shapes[i].drawBR = false;
    }
  }

  // This method determines if a symbol was found at the given point.
  FindSymbol( pos: { x: number; y: number }, includeImg:boolean = true) : ShapeComponent
  {
    console.log("Executing FindSymbol() for pos: " + pos.x + "," + pos.y );

    // in case the context is not set
    if (!this.ctx) 
    {
      return;
    }

    //debugger

    for( let i: number = 0; i<this.Shapes.length; ++i)
    {
      let shape: ShapeComponent = this.Shapes[i];

      if( shape != null)
      {
        if( shape.isSelected(pos.x, pos.y) == true )
        {
          if( includeImg || 
              !includeImg && shape.getType() != ShapeComponent.SYMBOL_TYPE_IMAGE )
          {
            console.log("DrawingComponent.FindSymbol() - Symbol Found.");
            return shape;
          }
        }
      }
    }

    console.log("DrawingComponent.FindSymbol() - Symbol NOT Found.");
    return null;
  }

  // This method determines if a symbol was found at the given point.
  FindMappedSymbol( pointId: string ) : ShapeComponent
  {
    console.log("Executing FindMappedSymbol() for point id: " + pointId );

    // in case the context is not set
    if (!this.ctx) 
    {
      return;
    }

    for( let i: number = 0; i<this.Shapes.length; ++i)
    {
      let shape: ShapeComponent = this.Shapes[i];

      if( shape != null)
      {
        let pt: DevicePointComponent = shape.getDevicePoint();
        if(pt != null )
        {
          //debugger
          //if( pt.getPointId() == pointId )
          if( pt.getFullPointId() == pointId )
          {
            console.log("DrawingComponent.FindMappedSymbol() - Symbol Found.");
            return shape;
          }
        }
      }
    }

    console.log("DrawingComponent.FindMappedSymbol() - Symbol NOT Found.");
    return null;
  }

  // This method serializes each symbol object and pushes it to an array for later file saving.
  public Serialize(isRemote: boolean) : boolean
  {
    console.log("Executing DrawingBoardComponet.Serialize().");

    if( this.Shapes == null )
    {
      alert("DrawingBoardComponent.Serialize() - NULL symbol data");
      return false;
    }

    if( this.Shapes.length == 0)
    {
      alert("DrawingBoardComponent.Serialize() - No symbols to serialize");
      return false;
    }

    this.serialData = [];

    for( let i: number = 0; i<this.Shapes.length; ++i)
    {
      let shape: ShapeComponent = this.Shapes[i];

      if( shape != null)
      {
        let serial: string = JSON.stringify(shape);
        this.serialData.push(serial);
      }
    }

    console.log("DrawingBoardComponent.Serialize() - SUCCESS.");

    if( isRemote)
    {
      this.OnSaveDiagram_Remote();
    }
    else
    {
      this.OnSaveDiagram_Local();
    }

    this.DirtyBit = false;
    return true;
  }

  // This method deserializes each symbol object and loads it into memory.
  Deserialize() : boolean
  {
    //debugger
    console.log("Executing DrawingBoardComponet.Deserialize().");

    if( this.serialData == null )
    {
      alert("DrawingBoardComponent.Deserialize() - NULL serial data");
      return false;
    }

    if( this.serialData.length == 0)
    {
      alert("DrawingBoardComponent.Deserialize() - No data to deserialize");
      return false;
    }

    this.Shapes = [];
    this.invalid = true;

    for( let i: number = 0; i<this.serialData.length; ++i)
    {
      let serial: string = this.serialData[i];

      if( serial != null && serial.length > 0)
      {
        let shape:ShapeComponent = null;

        let obj:any = JSON.parse(serial);
        if( obj.type == ShapeComponent.SYMBOL_TYPE_RECTANGLE)
        {
          //shape = new RectangleComponent(obj.x,obj.y, obj.width, obj.height);
          shape = new RectangleComponent(obj.x,obj.y);
          if( shape )
          {
            shape.setHeight(parseInt(obj.height));
            shape.setWidth(parseInt(obj.width));
          }
        }
        else if( obj.type == ShapeComponent.SYMBOL_TYPE_CIRCLE)
        {
          //shape = new CircleComponent(obj.x,obj.y, obj.radius, obj.startAngle,obj.endAngle,obj.counterClockwise);
          shape = new CircleComponent(obj.x,obj.y);
          if( shape )
          {
            shape.setRadius(parseInt(obj.radius));
            shape.setStartAngle(parseInt(obj.startAngle));
            shape.setEndAngle(parseInt(obj.endAngle));
            //shape.setCounterclockwise(Boolean(JSON.parse(obj.counterClockwise)));
          }
        }
        else if( obj.type == ShapeComponent.SYMBOL_TYPE_LINE)
        {
          //shape = new LineComponent(obj.x,obj.y, obj.len, obj.rotation);
          shape = new LineComponent(obj.x,obj.y);
          if( shape )
          {
            shape.setLength(parseInt(obj.length));
            shape.setRotation(parseInt(obj.rotation));
          }
        }
        else if( obj.type == ShapeComponent.SYMBOL_TYPE_SWITCH)
        {
          shape = new SwitchComponent(obj.x,obj.y);
          if( shape )
          {
            shape.setLength(parseInt(obj.length));
            shape.setRotationClosed(parseInt(obj.rotationClosed));
            shape.setRotationOpen(parseInt(obj.rotationOpen));
          }
        }
        else if( obj.type == ShapeComponent.SYMBOL_TYPE_TEXT)
        {
          //debugger
          // shape = new TextComponent(obj.x,obj.y, obj.font, obj.fontSize, obj.isFill, obj.text, this.ctx);
          shape = new TextComponent(obj.x,obj.y, this.ctx);
          if( shape )
          {
            shape.SetFontFamily(obj.font);
            shape.SetFontSize(parseInt(obj.fontSize));
            shape.SetText(obj.text);
            shape.SetIsFill(Boolean(JSON.parse(obj.isFill)));
          }
        }
        else if( obj.type == ShapeComponent.SYMBOL_TYPE_IMAGE)
        {
          shape = new ImageComponent(obj.x, obj.y, obj.width, obj.height, obj.imgFile);
        }

        if( shape != null)
        {
          //shape.Init();

          this.Shapes.push(shape);
          shape.deserialize(obj);

          //debugger
          let dev:any = obj.devicePoint;
          if( dev != null )
          {
            //debugger
            let dp:DevicePointComponent = this.FindDevPoint(dev.sn, dev.ied, dev.pointid);
            if( dp != null)
            {
              shape.addDevicePoint(dp);

              //debugger
              // Deserialize the device point.
              dp.deserialize(obj);

              // Adjust the properites.
              dp.AdjustProperties();
            }
          }
        }
      }
    }

    this.invalid = true;

    console.log("DrawingBoardComponent.Deserialize() - SUCCESS.");

    return true;
  }



  OnDiagramLoaded(e:ProgressEvent)
  {
    //debugger
    let data:any = this.fileReader.result;
    let arr: Array<string> = data.split('\r\n');
    this.serialData = [];
    for( let i=0; i<arr.length; ++i)
    {
      let line:string = arr[i];
      this.serialData.push(line);
    }  
    this.Deserialize();
  }

  OnLoadLocalDiagram(files: FileList)
  {
    console.log('Executing DrawingBoardComponent.OnLoadLocalDiagram().');

    if( this.configDialog != null && this.configDialog.GetLoadLocal() )
    {
      this.configDialog.OnLoadLocalConfig(files);
    }
 
    let file:File = files[0];
    this.fileReader = new FileReader();
    this.fileReader.onload = this.OnDiagramLoaded.bind(this);

    var blob = file.slice(0, file.size);
    this.fileReader.readAsText(blob);    
    document.getElementById("loadfile").style.display = "none"; 
  }

  OnSaveDiagram_Remote()
  {
    //debugger
    console.log('Executing DrawingBoardComponent.OnSaveDiagram_Remote()');
    this.ShowSaveServerFileDialog();
    //this.saveDialog.dialog.visible;
  }


  OnSaveDiagram_Local()
  {
    console.log('Executing DrawingBoardComponent.OnSaveDiagram_Local()');

    //debugger
    this.WriteLocalFile();    
  }


  // NOT USED.
  // ConvertToFile(): File
  // {
  //   let payload:string = this.FormatDiagram();
  //   let blob:Blob = new Blob([payload], {type:"text/plain"});
  //   blob['lastModifiedDate'] = (new Date()).toISOString();
  //   blob['name'] = 'diagram.txt';
  //   return <File>blob;
  // }





private ShowSaveServerFileDialog()
{
  let tb_filename: TextBox;

  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='LocalFileForm'> 
    <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="textboxelement" name="File Name: " />
        <div id="filenameError" class="error"></div> 
    </div>
  </form> 
  </div> 
  </div>` 


  let dialog: Dialog = new Dialog({ 
    header: 'Save to Server File Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {          
          this.SendDiagram(tb_filename.value);
        
          dialog.destroy();
        },

        buttonModel: 
        { 
            content: 'OK', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }
    },
    { 
      'click': () => 
      {
          dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Cancel', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }
  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#serverfiledialog'); 

  function onDialogCreate(args) 
  {
    console.log("Executing onDialogCreate()");
    // initialize ComboBox component
    tb_filename = new TextBox({
      //set the data to dataSource property
      floatLabelType: 'Always', 
      // set placeholder to ComboBox input element
      placeholder: "File Name:"
    });


    // render initialized ComboBox
    tb_filename.appendTo('#textboxelement');
  } 

  function onDialogOpen()
  {
    console.log("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    // alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}

WriteLocalFile()
{    
  console.log('Executing DrawingBoardComponent.WriteLocalFile()');

  //debugger
  let writer = new StreamWriter();
  for( let i: number = 0; i<this.serialData.length; ++i)
  {
    writer.writeLine(this.serialData[i]);
  }
  writer.save(DrawingBoardComponent.DEFAULT_SLD);

  //debugger
  if( this.op_code == DrawingBoardComponent.OP_CODE_CLOSE)
  {
    this.op_code = DrawingBoardComponent.OP_CODE_NONE;    
    this.closeWindow();

    // this.sendMessageToServer(this.cmd_sessionClose);
    // //this.propertyGrid.dialog.destroy();
    // this.DestroyPropGridDialog();
    // this.DestroyConfigDialog();
    // this.router.navigateByUrl('/app');
  }
  else if( this.op_code == DrawingBoardComponent.OP_CODE_TERMVIEW)
  {
    this.op_code = DrawingBoardComponent.OP_CODE_NONE;
    AppComponent.OpenInNewTab('/terminal');        

    // Destroy the property grids.
    // this.DestroyPropGrid_Tree();
    // this.DestroyPropGridDialog();
    // this.DestroyConfigDialog();      
    // // Destroy the tree views.
    // this.DestroyTreeView();
    // this.DestroyTBTreeView();
    //this.router.navigate(['/terminal', this.sessionId]);    
  }
  else if( this.op_code == DrawingBoardComponent.OP_CODE_TREEVIEW)
  {
    this.op_code = DrawingBoardComponent.OP_CODE_NONE;    
    AppComponent.OpenInNewTab('/treeview');        

    // this.StopStream();
    // // Destroy the property grids.
    // this.DestroyPropGrid_Tree();
    // //this.DestroyPropGrid_ToolBox();
    // this.DestroyPropGridDialog();
    // this.DestroyConfigDialog();    
    // // Destroy the tree views.
    // this.DestroyTreeView();
    // this.DestroyTBTreeView();
    // this.router.navigate(['/treeview', this.sessionId]);
  }  
}

public FormatDiagram(): string
{
  let lines:string = "";

  for( let i: number = 0; i<this.serialData.length; ++i)
  {
    let line: string = this.serialData[i];
    lines += line + "\r\n";
  }

  return lines;
}

private RequestDiagramFiles()
{
  //debugger
  // let cmd:string = "get diagrams" + "\r\n";
  let cmd:string = "get diagrams";
  this.sendMessageToServer(cmd);
}

private RequestSOEFiles()
{
  //debugger
  // let cmd:string = "get diagrams" + "\r\n";
  let cmd:string = "get soe";
  this.sendMessageToServer(cmd);
}

public SendDiagram(filename:string)
{
  //let hdr:string = "put " + "diagram.sld" + "\r\n";
  let hdr:string = "put " + filename + " \r\n";
  console.log("SendDiagram() - hdr: " + hdr);

  this.sendFileToServer(hdr);

  for( let i: number = 0; i<this.serialData.length; ++i)
  {
    let rline: string = this.serialData[i] + "\r\n";
   
    // TEST ONLY:
    //let line: string = this.serialData[i] + "\r\n";
    //let rline: string = line.replace(/"/g, '\\"');
    //console.log("rline: " + rline );
    //rline = "{\"x\":474,\"y\":66,\"closeEnough\":10,\"dragging\":false,\"dragTL\":false,\"dragTR\":false,\"dragBL\":false,\"dragBR\":false,\"type\":\"rect\",\"displayText\":\"Display Text\",\"devicePoint\":null,\"borderColor\":\"red\",\"fillColor\":\"green\",\"drawBR\":true,\"width\":100,\"height\":100}";
    //rline = "{\"x\":474,\"y\":66,\"closeEnough\":10,\"dragging\":false,\"dragTL\":false,\"dragTR\":false,\"dragBL\":false}";
    //rline += "\r\n";

    console.log("rline: " + rline );
    console.log("rline length: " + rline.length);
    this.sendFileToServer(rline);
  }

  let footer:string = "end put" + "\r\n";
  this.sendFileToServer(footer);
}


ClearDiagram()
{
  console.log("Executing ClearDiagram().");
  this.Shapes = [];
  this.invalid = true;
  this.propertyGrid.dialog.visible = false;
  this.DirtyBit = false;

  if( this.op_code == DrawingBoardComponent.OP_CODE_CLOSE)
  {
    this.op_code = DrawingBoardComponent.OP_CODE_NONE;
    this.closeWindow();    
    // this.sendMessageToServer(this.cmd_sessionClose);
    // this.propertyGrid.dialog.destroy();
    // this.DestroyConfigDialog();
    // // if( this.configDialog )
    // // {
    // //   this.configDialog.Destroy();
    // // }
    // this.router.navigateByUrl('/app');
  }
  else if( this.op_code == DrawingBoardComponent.OP_CODE_TERMVIEW)
  {
    this.op_code = DrawingBoardComponent.OP_CODE_NONE;
    AppComponent.OpenInNewTab('/terminal');

    // // Destroy the property grids.
    // this.DestroyPropGrid_Tree();
    // this.DestroyPropGridDialog();
    // this.DestroyConfigDialog();      
    // // Destroy the tree views.
    // this.DestroyTreeView();
    // this.DestroyTBTreeView();
    // this.router.navigate(['/terminal', this.sessionId]);        
  }
  else if( this.op_code == DrawingBoardComponent.OP_CODE_TREEVIEW)
  {
    this.op_code = DrawingBoardComponent.OP_CODE_NONE;
    AppComponent.OpenInNewTab('/treeview');

    // this.StopStream();
    // // Destroy the property grids.
    // this.DestroyPropGrid_Tree();
    // //this.DestroyPropGrid_ToolBox();
    // this.DestroyPropGridDialog();
    // this.DestroyConfigDialog();    
    // // Destroy the tree views.
    // this.DestroyTreeView();
    // this.DestroyTBTreeView();
    // this.router.navigate(['/treeview', this.sessionId]);
  }
}

// Sends and saves the master configuration to the wtp server on the target device.
public SendConfig(serialdata:Array<string>, filename:string)
{
  //let hdr:string = "put " + "diagram.sld" + "\r\n";
  let hdr:string = "put " + filename + " \r\n";
  console.log("SendConfig() - hdr: " + hdr);

  this.sendFileToServer(hdr);

  for( let i: number = 0; i<serialdata.length; ++i)
  {
    let rline: string = serialdata[i] + "\r\n";
   
    console.log("rline: " + rline + "  rline length: " + rline.length );
    //console.log("rline length: " + rline.length);
    this.sendFileToServer(rline);
  }

  let footer:string = "end put" + "\r\n";
  this.sendFileToServer(footer);
}



// This method deletes the selected symbol.
DeleteSymbol( ) : boolean
{
  console.log("Executing DeleteSymbol().");

  console.log("Num Symbols: " + this.Shapes.length);
  let inx: number = this.Shapes.indexOf(this.selectedShape);
  console.log("Found Inx: " + inx);
  let shapes: ShapeComponent[] = this.Shapes.splice(inx, 1);
  console.log("Num Symbols: " + this.Shapes.length);

  if( shapes.length > 0 )
  {
    this.invalid = true;
    return true;
  }

  alert("Error Deleting Symbol.");

  return false;
}

UnmapSymbol()
{
  if( this.selectedShape != null )
  {
    this.selectedShape.unmapDevicePoint();
    this.invalid = true;
  }
}


// This method finds the corresponding device point based on the given point id.
FindDevicePoint( id: string ) : DevicePointComponent
{
  //console.log("Executing FindDevicePoint() for pid: " + id );

  // let sn:number = this.getSelectedDeviceSN();
  // let ied:number = this.getSelectedDeviceIed();

  for( let i: number = 0; i<this.DevicePoints.length; ++i)
  {
    let pt: DevicePointComponent = this.DevicePoints[i];

    if( pt != null)
    {
      //debugger
      //if( pt.getPointId() == id && pt.getSN() == sn && pt.getIed() == ied )
      if( pt.getFullPointId() == id)
      {
        console.log("DrawingBoardComponent.FindDevicePoint() - DevicePoint Found.");
        return pt;
      }
    }
  }

  console.log("DrawingBoardComponent.FindDevicePoint() - DevicePoint NOT Found.");
  return null;
}


// This method finds the corresponding device point based on the given point id.
FindDevPoint( sn: number, ied:number, pointId:string ) : DevicePointComponent
{
  //console.log("Executing FindDevPoint() for sn: " + sn + "  ied: " + ied + "  pointId: " + pointId );

  //let sn:number = this.getSelectedDeviceSN();
  //let ied:number = this.getSelectedDeviceIed();

  for( let i: number = 0; i<this.DevicePoints.length; ++i)
  {
    let pt: DevicePointComponent = this.DevicePoints[i];

    if( pt != null)
    {
      //debugger
      //let key:string = pt.getSN().toString() + ":" + pt.getIed().toString();
      if( pt.getPointId() == pointId && pt.getSN() == sn && pt.getIed() == ied )
      {
        console.log("DrawingBoardComponent.FindDevPoint() - DevicePoint Found.");
        return pt;
      }
    }
  }

  console.log("DrawingBoardComponent.FindDevicePoint() - DevicePoint NOT Found.");
  return null;
}



// Draw the entire canvas.
drawMap()
{
  //alert("Executing drawMap()");

  if( this.invalid == false)
  {
    // Nothing to draw.
    return;
  }

  if (!this.ctx) 
  {
    // context not set.
    return;
  }

  this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);

  for( let i: number = 0; i<this.Shapes.length; ++i)
  {
    let shape: ShapeComponent = this.Shapes[i];

    if( shape != null)
    {
      shape.draw(this.ctx);
    }
  }

  if( this.selectedShape != null )
  {
    this.LoadSymbolProperties();
  }
  if( this.selectedDevicePoint != null )
  {
    this.LoadDevicePointProperties();
  }

  
  this.invalid = false;
}


// Implements a drawing tablet - currently not used but works.
drawOnCanvas( prevPos: { x: number; y: number },
              currentPos: { x: number; y: number } ) 
{
  console.log("drawOnCanvas() for prev: [" + prevPos.x + "," + prevPos.y + "] cur: [" + currentPos.x + "," + currentPos.y + "]");

  // incase the context is not set
  if (!this.ctx) {
    return;
  }

  // start our drawing path
  this.ctx.beginPath();

  // we're drawing lines so we need a previous position
  if (prevPos) 
  {
    //sets the start point
    this.ctx.moveTo(prevPos.x, prevPos.y); // from
    //draws a line from the start pos until the current position
    this.ctx.lineTo(currentPos.x, currentPos.y);

    //strokes the current path with the styles we set earlier
    this.ctx.stroke();
  }
}


// Adds a line sybmbol to the map drawing board.
private addLine( currentPos: { x: number; y: number }  )
{
    //alert("Executing DrawingBoardComponent.drawLine().")

    //let shape: any = new LineComponent(currentPos.x, currentPos.y, LineComponent.DEFAULT_LENGTH, LineComponent.DEFAULT_ROTATION );
    let shape: any = new LineComponent(currentPos.x, currentPos.y);
    if( shape)
    {
      shape.Init(Config.configdata);
      this.Shapes.push(shape);
      this.selectedShape = shape;
      this.ClearBRSymbols();
      this.selectedShape.drawBR = true;
      this.invalid = true;
      this.DirtyBit = true;  
    }
    else
    {
      alert("Line Not Created.");
    }
}

// Adds a line sybmbol to the map drawing board.
private addSwitch( currentPos: { x: number; y: number }  )
{
    //alert("Executing DrawingBoardComponent.drawLine().")
    debugger

    //let shape: any = new LineComponent(currentPos.x, currentPos.y, LineComponent.DEFAULT_LENGTH, LineComponent.DEFAULT_ROTATION );
    let shape: any = new SwitchComponent(currentPos.x, currentPos.y);
    if( shape)
    {
      shape.Init(Config.configdata);
      this.Shapes.push(shape);
      this.selectedShape = shape;
      this.ClearBRSymbols();
      this.selectedShape.drawBR = true;
      this.invalid = true;
      this.DirtyBit = true;  
    }
    else
    {
      alert("Switch Not Created.");
    }
}



// Adds a circle sybmbol to the map drawing board.
private addCircle( currentPos: { x: number; y: number } )
{
  console.log("Executing DrawingBoardComponent.addCircle().")

  let shape: ShapeComponent = new CircleComponent( currentPos.x, currentPos.y);
    // currentPos.x, currentPos.y, 
    // CircleComponent.DEFAULT_RADIUS, 
    // CircleComponent.DEFAULT_STARTANGLE, 
    // CircleComponent.DEFAULT_ENDANGLE,
    // CircleComponent.DEFAULT_COUNTERCLOCKWISE );

  if( shape)
  {
    // if( this.configDialog )
    // {
        shape.Init(Config.configdata);
    // }

    this.Shapes.push(shape);
    this.selectedShape = shape;
    this.ClearBRSymbols();
    this.selectedShape.drawBR = true;
    this.invalid = true;
    this.DirtyBit = true;  
  }
  else
  {
    alert("Circle Not Created.");
  }
}

// Adds a rectangle sybmbol to the map drawing board.
private addRectangle( currentPos: { x: number; y: number } )
{
  console.log("Executing DrawingBoardComponent.addRectangle().");

  debugger
  let shape: ShapeComponent = new RectangleComponent(currentPos.x, currentPos.y); 
    //RectangleComponent.DEFAULT_WIDTH, RectangleComponent.DEFAULT_HEIGHT );
  if( shape )
  {
    //if( this.configDialog )
    //{
      shape.Init(Config.configdata);
    //}  
    this.Shapes.push(shape);
    this.selectedShape = shape;
    this.ClearBRSymbols();
    this.selectedShape.drawBR = true;
    this.invalid = true;
    this.DirtyBit = true;  
  }
  else
  {
    alert("Rectangle Not Created.");
  }
}

// Adds a text sybmbol to the map drawing board.
private addText( currentPos: { x: number; y: number }, fill: boolean )
{
  console.log("Executing DrawingBoardComponent.addText().");

  let mWidth: number = this.ctx.measureText("Hello World").width;
  //alert("Measured Text Width: " + m);

  //let shape: any = new TextComponent(currentPos.x, currentPos.y, "Arial", 30, fill, "Hello World", this.ctx );
  let shape: any = new TextComponent(
    currentPos.x, currentPos.y, this.ctx );
    // TextComponent.DEFAULT_FONT_FAMILY, 
    // TextComponent.DEFAULT_FONT_SIZE, 
    // fill, 
    // TextComponent.DEFAULT_TEXT, 
    //this.ctx );

  if( shape)
  {
    shape.Init();
    this.Shapes.push(shape);
    this.selectedShape = shape;
    this.ClearBRSymbols();
    this.selectedShape.drawBR = true;
    this.invalid = true;
    this.DirtyBit = true;  
    //shape.show();
  }
  else
  {
    alert("Fill Text Not Created.");
  }
}

  // Adds a rectangle sybmbol to the map drawing board.
  private addImage( pos: { x: number; y: number }, imgFile: string )
  {
    console.log("Executing DrawingBoardComponent.addImage().");

    var img = new Image();
    img.src = imgFile;

    this.ctx.drawImage(img, pos.x, pos.y, 100, 100);

    let shape: ShapeComponent = new ImageComponent(
      pos.x, 
      pos.y, 
      ImageComponent.DEFAULT_WIDTH, 
      ImageComponent.DEFAULT_HEIGHT,
      imgFile );

    if( shape)
    {
      this.Shapes.push(shape);
      this.selectedShape = shape;
      this.ClearBRSymbols();
      this.selectedShape.drawBR = true;
      this.invalid = true;
      this.DirtyBit = true;  
    }
    else
    {
      alert("Image Not Created.");
    }
  }



// Adds a linear gradient sybmbol to the map drawing board.
private addLinearGradient( currentPos: { x: number; y: number } )
{
  let shape: any = new LinearGradientComponent(0, 0, 200, 0, "red", "white", 0, 1, currentPos.x, currentPos.y, 100, 100 );
  if( shape)
  {
    this.Shapes.push(shape);
    this.selectedShape = shape;
    this.ClearBRSymbols();
    this.selectedShape.drawBR = true;
    this.invalid = true;
    this.DirtyBit = true;  
  }
  else
  {
    alert("Linear Gradient Not Created.");
  }
}

// Adds a circular gradient sybmbol to the map drawing board.
private addCircularGradient( currentPos: { x: number; y: number } )
{
    let shape: any = new CircularGradientComponent( 75, 50, 5, 90, 60, 100, 
                                                    "red", "white", 0, 1, 
                                                    currentPos.x, currentPos.y, 300, 300);

    if( shape)
    {
      this.Shapes.push(shape);
      this.selectedShape = shape;
      this.ClearBRSymbols();
      this.selectedShape.drawBR = true;  
      this.invalid = true;
      this.DirtyBit = true;  
    }
    else
    {
      alert("Circular Gradient Not Created.");
    }    
}

// Subscribe to the receiving of point data.
// Connects to server (wtp on rtu) via web socket to receive static and dynamic point data.
// createDataSubscription()
// {
//     this.id = "1632:1";
//     this.streamId = 0;
//     //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
//     var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

//     console.log("DrawingBoardComponent.createDataSubscription() - Command sent to server: " + cmd);

//     this.wsSubscription = this.wsServiceComm.createObservableSocket(
//       this.url_commServer, cmd).subscribe(
//         data=>this.handleMessage(data),
//         // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
//         err=>this.Cleanup(),
//         ()=>
//         { }
//     );
// }

handleMessage(msg: string)
{
    //console.log(msg)

    if( msg == "ping" )
    {
        // Ignore ping message.
        return;
    }
    else if( msg == "OK to send" )
    {
        // Ignore ping message.
        alert("Received OK to send reply.");
        let contents:string = this.FormatDiagram();
        return;
    }
    else if( msg.startsWith("logout"))
    {
      console.log("DrawingBoardComponent.handleCommMessage() - Received logout message: " + msg);
      this.StopStream();
      this.DestroyControls();
      this.router.navigateByUrl('/app'); 
      return;
    }
    else if( msg.startsWith("DIAG:" ) )
    {
      //debugger
      if( this.configDialog )
      {
        this.configDialog.DisplayMsg(msg);
      }
    }
    else if( msg.startsWith("-S") )
    {
      debugger
      this.sessionId = msg.slice(1); 
      return;
    }
    else if( msg.startsWith("??"))
    {
      // Display the error.
      var err = msg.slice(2);
      alert("ERROR: " + err);
      return;
    }
    else if( msg.startsWith("show diagrams:"))
    {
      // Display the message for now.
      //alert("Msg: " + msg);
      this.processServerFiles(msg);
      return;
    }
    else if( msg.startsWith("show soe files:"))
    {
      // Display the message for now.
      //alert("Msg: " + msg);
      this.processSOEFiles(msg);
      return;
    }  
    else
    {
      let arr: Array<string> = msg.split(' ');

      // Recieve Static then Dynamic Point Data.
      this.processPointData(msg, arr);
    }    
}

processServerFiles(msg: string)
{
  // Display the message for now.
  //alert("Msg: " + msg);
  let arr:Array<string> = msg.split(':');
  if( arr.length == 2)
  {
    let files:Array<string> = arr[1].split(';');
    //this.ShowServerFilesDialog(files, DrawingBoardComponent.FILE_TYPE_DIAG);
    this.filesDialog.CopyData(files);
    this.filesDialog.Reset();
    this.filesDialog.SetFileType(ServerFilesDialog.FILE_TYPE_DIAG);
    this.filesDialog.dialog.visible = true;
  }
  else
  {
    alert("Error Retrieving Diagram Files from Server.");
  }
}

processSOEFiles(msg: string)
{
  // Display the message for now.
  console.log("Msg: " + msg);
  let arr:Array<string> = msg.split(':');
  if( arr.length == 2)
  {
    let files:Array<string> = arr[1].split(';');
    //this.ShowServerFilesDialog(files, DrawingBoardComponent.FILE_TYPE_SOE);
    this.filesDialog.CopyData(files);
    this.filesDialog.Reset();
    this.filesDialog.SetFileType(ServerFilesDialog.FILE_TYPE_SOE);
    this.filesDialog.dialog.visible = true;
  }
  else
  {
    alert("Error Retrieving Diagram Files from Server.");
  }
}


// ShowServerFilesDialog(files:Array<string>, type:number)
// {
//   let comboBox: ComboBox;

//   let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='forceForm'> 
//   <div class="row"> 
//     <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10">
//     <div id=comboelement></div> 
//     </div>
//   </form> 
//   </div> 
//   </div>` 


//   let dialog: Dialog = new Dialog({ 
//     header: 'Server Files Dialog', 
//     target: document.getElementById('target'), 
//     content: dialogContent, 
//     animationSettings: { 
//         effect: 'None' 
//     }, 
//     buttons: [
//       { 
//         'click': () => 
//         {
//           if( type == DrawingBoardComponent.FILE_TYPE_DIAG )
//           {          
//             this.diagramFile = this.diagramPath + comboBox.value;
//             this.ReadDiagramFileFromServer(comboBox.value.toString());
//           }
//           else if( type == DrawingBoardComponent.FILE_TYPE_SOE )
//           {          
//             this.soeFile = this.soePath + comboBox.value;
//             this.ReadSOEFileFromServer(comboBox.value.toString());
//           }
//           else
//           {
//             alert("ShowServerFilesDialog() - Invalid File Type.");
//           }        

//           dialog.destroy();
//         },

//         buttonModel: 

//         { 
//             content: 'OK', 
//             isPrimary: true, 
//             cssClass: 'e-outline'
//         }
//     },
//     { 
//       'click': () => 
//       {
//           dialog.destroy();
//       },

//       buttonModel: 
//       { 
//           content: 'Cancel', 
//           isPrimary: true, 
//           cssClass: 'e-outline'
//       }
//   }
//   ], 
//     showCloseIcon: true, 
//     width: '500px', 
//     open: onDialogOpen, 
//     close: onDialogClose, 
//     created: onDialogCreate
//   }); 
//   dialog.appendTo('#filedialog-dbc'); 

//   function onDialogCreate(args) 
//   {
//     console.log("Executing onDialogCreate()");
//     // initialize ComboBox component
//     comboBox = new ComboBox({
//       //set the data to dataSource property
//       dataSource: files,
//       // set placeholder to ComboBox input element
//       placeholder: "Select a File"
//     });

//     // render initialized ComboBox
//     comboBox.appendTo('#comboelement');
//   } 

//   function onDialogOpen()
//   {
//     console.log("Executing onDialogOpen()");
//   }

//   function onDialogClose()
//   {
//     // alert("Executing onDialogClose()");
//     dialog.destroy();  
//   }
// }


processPointData(msg: string, arr: Array<string>)
{
  var datatype = arr[2];

  // Static Data
  if( datatype == 's' )
  {
      this.ProcessStaticData(msg, arr);
  }
  // Dynamic Data
  else if( datatype == 'd' )
  {
      this.ProcessDynamicData(msg, arr);
  }
}

ProcessStaticData(msg: string, arr: Array<string>)
{
  console.log('DrawingBoardComponent.ProcessStaticData() for: ' + msg);

    //debugger

    var first = msg.indexOf('"');
    var last = msg.indexOf('"', first+1);
    var remaining = msg.slice(last+2);
    var toks = remaining.split(' ');

    let clientid:number = parseInt(arr[3], 16);
    let iedNum:number = parseInt(arr[4], 16);
    let iedName:string = arr[5];

    // Add to data store.
    let item: any;
    let id: string = arr[6];
    //console.log("DrawingBoardComponent.ProcessStaticData() - id: " + id)

    let dp:DevicePointComponent = null;

    if( id.startsWith("an") )
    {  
        //item =  { pointid: arr[3],
        item =  { clientid: clientid,
                  ied: iedNum,
                  iedname: iedName,
                  pointid: arr[6],
                  ptname: msg.slice(first+1, last),
                  scale: toks[0],
                  offset: toks[1],
                  highlimit: toks[2],
                  lowlimit: toks[3] ,
                  raw: 0,
                  units: DevicePointComponent.UNITS,
                  forced: 0,
                  failed: 0,
                  timestamp: new Date(8364186e5)        
                };

        let type:string = DevicePointComponent.POINT_TYPE_ANALOG;
        //console.log("Point Type: " + type);
        //let dev: Array<string> = this.id.split(':');
        //let sn: number = parseInt(dev[0]);
        let sn: number = clientid;

        //console.log("SN: " + sn);
        //let ied: number = parseInt(dev[1]);
        let ied: number = iedNum;
        //console.log("ied: " + ied);

        let pid:string = id.slice(2, id.length);
        //console.log("pid: " + pid);
        let ptname: string = msg.slice(first+1, last);
        //console.log("ptname: " + ptname);

        let scale:number = parseInt(toks[0]);        
        //console.log("scale: " + scale);

        let offset:number = parseInt(toks[1]);
        //console.log("offset: " + offset);

        let highlimit:number = parseInt(toks[2]);        
        //console.log("highlimit: " + highlimit);

        let lowlimit:number = parseInt(toks[3]);        
        //console.log("lowlimit: " + lowlimit);
            
        //let dp: AnalogPointComponent = new AnalogPointComponent(
        dp = new AnalogPointComponent(

          DevicePointComponent.POINT_TYPE_ANALOG, 
          DrawingBoardComponent.deviceName, 
          sn, 
          ied, 
          id,
          ptname, 
          DevicePointComponent.UNITS, 
          scale, 
          offset, 
          highlimit, 
          lowlimit );

          if( dp != null)
          {
            //if( this.configDialog )
            //{
              //dp.Init(Config.configdata);
            //}
            this.DevicePoints.push(dp);
          }
    }
    else if( id.startsWith("st") )
    {
      //debugger 
      var first_0 = msg.indexOf('"', last+1); 
      var last_0 = msg.indexOf('"', first_0+1);

      var first_1 = msg.indexOf('"', last_0+1);
      var last_1 = msg.indexOf('"', first_1+1);

      // item =  { pointid: arr[3],
              item =  { clientid: clientid,
                ied: iedNum,
                iedname: iedName,
                pointid: arr[6],
                ptname: msg.slice(first+1, last),
                scale: msg.slice(first_0+1, last_0),
                offset: msg.slice(first_1+1, last_1),
                highlimit: 0,
                lowlimit: 0,
                raw: 0,
                units: DevicePointComponent.UNITS,
                forced: 0,
                failed: 0,
                timestamp: new Date(8364186e5)
                };

                let type:string = DevicePointComponent.POINT_TYPE_STATUS;
                //console.log("Point Type: " + type);
                //let dev: Array<string> = this.id.split(':');
                // let sn: number = parseInt(dev[0]);
                let sn: number = clientid;

                //console.log("SN: " + sn);
                // let ied: number = parseInt(dev[1]);
                let ied: number = iedNum;
                //console.log("ied: " + ied);
      
                let pid:string = id.slice(2, id.length);
                //console.log("pid: " + pid);
                let ptname: string = msg.slice(first+1, last);
                //console.log("ptname: " + ptname);
      
                let textOff:string = toks[0];        
                //console.log("textOff: " + textOff);
      
                let textOn:string = toks[1];
                //console.log("textOn: " + textOn);

                let ts: number = 0;
                    
                //let dp: StatusPointComponent = new StatusPointComponent(
                dp = new StatusPointComponent(
                  DevicePointComponent.POINT_TYPE_STATUS, 
                  DrawingBoardComponent.deviceName, 
                  sn, 
                  ied, 
                  id,
                  ptname, 
                  DevicePointComponent.UNITS, 
                  ts, 
                  textOff, 
                  textOn );
      
                  if( dp != null)
                  {
                    //if( this.configDialog )
                    //{
                      //dp.Init(Config.configdata);
                    //}
                    this.DevicePoints.push(dp);
                  }       
    }
    else if( id.startsWith("co") )
    { 
      var first_0 = msg.indexOf('"', last+1); 
      var last_0 = msg.indexOf('"', first_0+1);

      var first_1 = msg.indexOf('"', last_0+1);
      var last_1 = msg.indexOf('"', first_1+1);

      //item =  { pointid: arr[3],
      item =  { clientid: clientid,
                ied: iedNum,
                iedname: iedName,
                pointid: arr[6],
                ptname: msg.slice(first+1, last),
                scale: msg.slice(first_0+1, last_0),
                offset: msg.slice(first_1+1, last_1),
                highlimit: 0,
                lowlimit: 0,
                raw: 0,
                units: DevicePointComponent.UNITS,
                forced: 0,
                failed: 0,
                timestamp: new Date(8364186e5)
                };

                let type:string = DevicePointComponent.POINT_TYPE_CONTROL;
                //console.log("Point Type: " + type);
                //let dev: Array<string> = this.id.split(':');
                //let sn: number = parseInt(dev[0]);
                //console.log("SN: " + sn);
                //let ied: number = parseInt(dev[1]);
                let sn: number = clientid;
                let ied: number = iedNum;
                //console.log("ied: " + ied);
      
                let pid:string = id.slice(2, id.length);
                //console.log("pid: " + pid);
                let ptname: string = msg.slice(first+1, last);
                ///console.log("ptname: " + ptname);
      
                let textOff:string = toks[0];        
                ///console.log("textOff: " + textOff);
      
                let textOn:string = toks[1];
                //console.log("textOn: " + textOn);

                let ts: number = 0;
                    
                //let dp: ControlPointComponent = new ControlPointComponent(
                dp = new ControlPointComponent(
                  DevicePointComponent.POINT_TYPE_CONTROL, 
                  DrawingBoardComponent.deviceName, 
                  sn, 
                  ied, 
                  id,
                  ptname, 
                  DevicePointComponent.UNITS, 
                  ts, 
                  textOff, 
                  textOn );
      
                  if( dp != null)
                  {
                    //if( this.configDialog )
                    //{
                      //dp.Init(Config.configdata);
                    //}
                    this.DevicePoints.push(dp);
                  }       
    }

    else if( id.startsWith("ac") )
    {
        //item =  { pointid: arr[3],
        item =  { clientid: clientid,
                  ied: iedNum,
                  iedname: iedName,
                  pointid: arr[6],
                  ptname: msg.slice(first+1, last),
                  scale: toks[0],
                  offset: 0,
                  highlimit: 0,
                  lowlimit: 0,
                  raw: 0,
                  units: DevicePointComponent.UNITS,
                  forced: 0,
                  failed: 0,
                  timestamp: new Date(8364186e5)
                };

                let type:string = DevicePointComponent.POINT_TYPE_ACCUMULATOR;
                //console.log("Point Type: " + type);
                //let dev: Array<string> = this.id.split(':');
                //let sn: number = parseInt(dev[0]);
                //console.log("SN: " + sn);
                //let ied: number = parseInt(dev[1]);
                //console.log("ied: " + ied);

                let sn: number = clientid;
                let ied: number = iedNum;
      
                let pid:string = id.slice(2, id.length);
                //console.log("pid: " + pid);
                let ptname: string = msg.slice(first+1, last);
                //console.log("ptname: " + ptname);
                              
                //let dp: AccumulatorPointComponent = new AccumulatorPointComponent(
                dp = new AccumulatorPointComponent(
                  DevicePointComponent.POINT_TYPE_ACCUMULATOR, 
                  DrawingBoardComponent.deviceName, 
                  sn, 
                  ied, 
                  id,
                  ptname, 
                  DevicePointComponent.UNITS );
      
                  if( dp != null)
                  {
                    //if( this.configDialog )
                    //{
                      //dp.Init(Config.configdata);
                    //}
                    this.DevicePoints.push(dp);
                  }        
    }
    else if( id.startsWith("se") )
    {
        //debugger
        //item =  { pointid: arr[3],
        item =  { clientid: clientid,
                  ied: iedNum,
                  iedname: iedName,
                  pointid: arr[6],
                  ptname: msg.slice(first+1, last),
                  scale: 0,
                  offset: 0,
                  highlimit: 0,
                  lowlimit: 0,
                  raw: 0,
                  units: DevicePointComponent.UNITS,
                  forced: 0,
                  failed: 0,
                  timestamp: new Date(8364186e5)
                };

                let type:string = DevicePointComponent.POINT_TYPE_SETPOINT;
                //console.log("Point Type: " + type);
                //let dev: Array<string> = this.id.split(':');
                //let sn: number = parseInt(dev[0]);
                //console.log("SN: " + sn);
                //let ied: number = parseInt(dev[1]);
                //console.log("ied: " + ied);

                let sn: number = clientid;
                let ied: number = iedNum;
      
                let pid:string = id.slice(2, id.length);
                //console.log("pid: " + pid);
                let ptname: string = msg.slice(first+1, last);
                //console.log("ptname: " + ptname);
                              
                //let dp: SetpointComponent = new SetpointComponent(
                dp = new SetpointComponent(
                  DevicePointComponent.POINT_TYPE_SETPOINT, 
                  DrawingBoardComponent.deviceName, 
                  sn, 
                  ied, 
                  id,
                  ptname, 
                  DevicePointComponent.UNITS );
      
                  if( dp != null)
                  {
                    //if( this.configDialog )
                    //{
                      //dp.Init(Config.configdata);
                    //}
                    this.DevicePoints.push(dp);
                  }        
    }

    this.pointdata.push(item);

    let pointsToDisplay: { [key: string]: Object }[] = []; 
    var point = {
      // id: this.id + "-" + item.pointid,
      id: clientid + ":" + iedNum + "-" + item.pointid,
      // id: dp.getSN() + ":" + dp.getIed() + ":" + dp.getPointId(),
      //label: item.ptname,
      label: iedName + ":" + item.pointid,
      // label: dp.getSN() + ":" + dp.getIed() + ":" + item.ptname,
      pointId: item.pointid,
      image: this.imgComponent,
      expanded: false,
      subChild: []      
    };
    //debugger
    // if( pointsToDisplay.includes(point.id))
    // {
    //   alert("Element already in device treeview - id not added: " + point.pointId);
    //   return;
    // }
    pointsToDisplay.push(point);  
    this.treeViewInstance.addNodes(pointsToDisplay, this.id);
    console.log("ProcessStaticData() - Added Node ID: " + point.id)

}

ProcessDynamicData(msg: string, arr: Array<string>)
{
  console.log('DrawingBoardComponent.ProcessDynamicData() for: ' + msg);

  let toks: Array<string> = msg.split(' ');

  // Client ID and ied num are sent as decimal string.
  let clientid:number = parseInt(arr[3], 10);
  let iedNum:number = parseInt(arr[4], 10);


  let id: string = arr[5].trim();
  //debugger
  //var pt = this.pointdata.find(x=>x.pointid == id);
  var pt = this.pointdata.find(x=>x.pointid == id && x.clientid == clientid && x.ied == iedNum);


  if( pt == null )
  {
      console.log('ProcessDynamicData - DevicePoint Not Found for ID: ', id);
      return;
  }

  // pt.raw = arr[4];
  // pt.forced = arr[5];
  // pt.failed = arr[6];

  pt.raw = arr[6];
  pt.forced = arr[7];
  pt.failed = arr[8];

  if( pt.forced == "1" )
  {
    alert("Pt Forced:  " +  id);
  }

  // if( id.startsWith("st") || id.startsWith("co") )
  // {
  //     var first = msg.indexOf('"');
  //     var last = msg.indexOf('"', first+1);
  //     pt.timestamp = msg.slice(first+1, last);
  // }
  // else
  // {
  //   pt.timestamp  = " ";
  // }

  var first = msg.indexOf('"');
  var last = msg.indexOf('"', first+1);
  pt.timestamp = msg.slice(first+1, last);

  let fullid: string = clientid + ":" + iedNum + "-" + id;

  let devpt: DevicePointComponent = this.FindDevicePoint(fullid);
  if( devpt == null)
  {
    console.log('ProcessDynamicData - DevicePoint Not Found for ID: ' +  fullid);
    return;
  }

  // let nval:number = parseInt(arr[4]);
  // let nforced:number = parseInt(arr[5]);
  // let nfailed:number = parseInt(arr[6]);
  let nval:number = parseInt(arr[6]);
  console.log("nval: " + nval);
  let nforced:number = parseInt(arr[7]);
  console.log("nforced: " + nforced);
  let nfailed:number = parseInt(arr[8]);
  console.log("nfailed: " + nfailed);

  let dt:string="";
  if(devpt.getPointType() == DevicePointComponent.POINT_TYPE_STATUS ||
      devpt.getPointType() == DevicePointComponent.POINT_TYPE_CONTROL)
  {
    //debugger
    dt = msg.slice(first+1, last);
    let timestamp: Date = new Date(dt);
    let ts: number = timestamp.getTime();
    devpt.setTimestamp(ts);
  }

  // SIMULATION ONLY.
  // if( devpt.getPointType() == DevicePointComponent.POINT_TYPE_ANALOG )
  // {
  //   nval += 1;
  // }

  devpt.setValue(nval);
  console.log("Set devpt value: " + nval);
  devpt.setFailed(nfailed);
  devpt.setForced(nforced);
  devpt.setTextColor();

  this.invalid = true;
  //console.log('ProcessDynamicData - DevicePoint Updated for ID: ' +  fullid);
}

// Called when socket error.
Cleanup()
{
  alert("Executing DrawingBoardComponent.Cleanup()");

  this.DestroyControls();
  //this.closeSocket();

  // Navigate back to login screen.
  this.router.navigateByUrl('/app');
}

DestroyControls()
{
  this.DestroyTreeView();
  this.DestroyTBTreeView();
  this.DestroySidebar();
  this.DestroyPropGrid_Tree();
  this.DestroyToolbarButtons();

  this.DestroyConfigDialog();
  this.DestroySOEDialog();
  this.DestroyFilesDialog();
  this.DestroyPropGridDialog();
  this.DestroySaveDialog();
}

DestroyToolbarButtons()
{
  if( this.rectangleBtn != null )
  {
    this.rectangleBtn.destroy();
    this.rectangleBtn = null;
  }
  if( this.circleBtn != null )
  {
    this.circleBtn.destroy();
    this.circleBtn = null;
  }
  if( this.textBtn != null )
  {
    this.textBtn.destroy();
    this.textBtn = null;
  }
  if( this.lineBtn != null )
  {
    this.lineBtn.destroy();
    this.lineBtn = null;
  }
  if( this.switchBtn != null )
  {
    this.switchBtn.destroy();
    this.switchBtn = null;
  }

  if( this.image1Btn != null )
  {
    this.image1Btn.destroy();
    this.image1Btn = null;

  }
  if( this.image2Btn != null )
  {
    this.image2Btn.destroy();
    this.image2Btn = null;
  }
  if( this.image3Btn != null )
  {
    this.image3Btn.destroy();
    this.image3Btn = null;
  }
  if( this.image4Btn != null )
  {
    this.image4Btn.destroy();
    this.image4Btn = null;
  }

  if( this.clearDiagramBtn != null )
  {
    this.clearDiagramBtn.destroy();
    this.clearDiagramBtn = null;
  }
  if( this.saveLocalBtn != null )
  {
    this.saveLocalBtn.destroy();
    this.saveLocalBtn = null;
  }
  if( this.loadLocalBtn != null )
  {
    this.loadLocalBtn.destroy();
    this.loadLocalBtn = null;
  }
  if( this.saveRemoteBtn != null )
  {
    this.saveRemoteBtn.destroy();
    this.saveRemoteBtn = null;
  }
  if( this.loadRemoteBtn != null )
  {
    this.loadRemoteBtn.destroy();
    this.loadRemoteBtn = null;
  }

  if( this.leftBtn != null )
  {
    this.leftBtn.destroy();
    this.leftBtn = null;
  }
  if( this.rightBtn != null )
  {
    this.rightBtn.destroy();
    this.rightBtn = null;
  }
  if( this.toggleBtn != null )
  {
    this.toggleBtn.destroy();
    this.toggleBtn = null;
  }

  if( this.closeBtn != null )
  {
    this.closeBtn.destroy();
    this.closeBtn = null;
  }
  if( this.newTerminalBtn != null )
  {
    this.newTerminalBtn.destroy();
    this.newTerminalBtn = null;
  }
  if( this.newTreeBtn != null )
  {
    this.newTreeBtn.destroy();
    this.newTreeBtn = null;
  }

  if( this.configBtn != null )
  {
    this.configBtn.destroy();
    this.configBtn = null;
  }
}

sendMessageToServer(msg: string)
{
  // Append session id to message.
  if( this.wsServiceComm == null )
  {
    console.log("DrawingBoardComponent.sendMessageToServer() - WS Subscription is null.");
    return;
  }

  msg += " " + this.sessionId;
  this.status = this.wsServiceComm.sendMessage(msg);
}

sendFileToServer(msg: string)
{
  // Append session id to message.
  if( this.wsServiceComm == null )
  {
    console.log("DrawingBoardComponent.sendFileToServer() - WS Subscription is null.");
    return;
  }

  //msg += " " + this.sessionId;
  this.status = this.wsServiceComm.sendMessage(msg);
}


// getSelectedDeviceSN(): number
// {
//   //console.log("Executing getSelecgtedDeviceSN() for: " + this.id);
//   let dev: Array<string> = this.id.split(':');
//   let sn: number = parseInt(dev[0]);
//   //console.log("getSelectedDeviceSN() - sn: " + sn);
//   return sn;
// }

// getSelectedDeviceIed(): number
// {
//   //console.log("Executing getSelectedDeviceIed() for: " + this.id);
//   let dev: Array<string> = this.id.split(':');
//   let ied: number = parseInt(dev[1]);
//   //console.log("getSelectedDeviceIed() - ied: " + ied);
//   return ied;
// }


closeSocket()
{
      this.wsSubscription.unsubscribe();
      this.wsServiceComm.ws.close();
      this.status = "The Socket Is Closed.";
      //alert("DrawingBoardComponent.closeSocket() - Socket Closed.");
}

ngOnDestroy()
{
  console.log("Execcuting DrawingBoardComponent.ngOnDestroy()");
  //this.StopStream();
  //this.drawingSubscription.unsubscribe();
}

StopStream()
{
  if( this.wsSubscription != null )
  {
    // Send stream stop message to the server.
    // let cmd: string = "stream" + " " + this.streamId + " " + "stop" + " " + this.sessionId;    
    let cmd: string = "stream" + " " + this.streamId + " " + "stop";    

    this.sendMessageToServer(cmd);

    // Close the socket.
    this.closeSocket();
    this.wsSubscription = null;
  }    
}

DestroySidebar()
{
  if( this.sidebar != null)
  {
    this.sidebar.destroy();    
    this.sidebar = null;
  }
}

DestroyTabs()
{
  if( this.tabs != null)
  {
    this.tabs.destroy();    
    this.tabs = null;
  }
}



DestroyTreeView()
{
  if( this.treeViewInstance != null)
  {
    this.treeViewInstance.destroy();    
    this.treeViewInstance = null;
  }
}

DestroyTBTreeView()
{
  if( this.toolBoxTree != null)
  {
    this.toolBoxTree.destroy();    
    this.toolBoxTree = null;
  }
}


CreateTreeView()
{
  //alert("Executing CreateTreeView()");
  this.treeViewInstance = new TreeView({
    fields: { dataSource: this.treedata, id: 'id', text: 'label', 
    child: 'subChild', imageUrl: 'image', iconCss: 'e-icons', hasChildren: 'hasChild',
  },
  allowDragAndDrop: true,
  expandOn: 'Click'
  });  

  //Render initialized TreeView
  this.treeViewInstance.appendTo("#treeview-dbc");
  //this.treeViewInstance.appendTo("#tab-tree");
  
  // Bind the OnClick Event and parent class (TreeViewComponent) to the callback.
  this.treeViewInstance.nodeClicked=this.OnDeviceTreeNodeClick.bind(this);

  this.treeViewInstance.nodeExpanded=this.OnDeviceTreeNodeExpanded.bind(this);
  this.treeViewInstance.nodeCollapsed=this.OnDeviceTreeNodeCollapsed.bind(this);
  this.treeViewInstance.nodeExpanding=this.OnDeviceTreeNodeExpanding.bind(this);
  this.treeViewInstance.nodeCollapsing=this.OnDeviceTreeNodeCollapsing.bind(this);
  this.treeViewInstance.nodeDragStop=this.OnDeviceTreeNodeDragStart.bind(this);
  this.treeViewInstance.nodeDragStop=this.OnDeviceTreeNodeDragStop.bind(this);

}

CreateToolBoxTree()
{
  //alert("Executing CreateToolBoxTree()");
  this.toolBoxTree = new TreeView({
    fields: { dataSource: this.symbolTypes, id: 'id', text: 'label', 
    child: 'subChild', imageUrl: 'image', iconCss: 'icon', hasChildren: 'hasChild'
  },
  allowDragAndDrop: true
  });  

  //Render initialized TreeView
  this.toolBoxTree.appendTo("#tab-toolbox");
  
  // Bind the OnClick Event and parent class (TreeViewComponent) to the callback.
  this.toolBoxTree.nodeClicked=this.OnTBTreeNodeClick.bind(this);
  this.toolBoxTree.nodeDragStop=this.OnTBTreeNodeDragStart.bind(this);
  this.toolBoxTree.nodeDragStop=this.OnTBTreeNodeDragStop.bind(this);
}

DestroyPropGrid_Tree()
{
  // Destroy the tree poroperty grid.
  if( this.propGrid_Tree != null )
  {
    this.propGrid_Tree.dataSource = [];
    this.propGrid_Tree.destroy();
    this.propGrid_Tree = null;
  }
}

// private DestroyPropGridDialog()
// {
//   if( this.propertyGrid != null )
//   {
//     // Destroy the Property Grid Dialog/Grid.
//     this.propertyGrid.Destroy();
//     this.propertyGrid = null;
//   }
// }

private DestroyConfigDialog()
{
  //debugger
  if( this.configDialog != null )
  {
    // Destroy the Property Grid Dialog/Grid.
    this.configDialog.Destroy();
    this.configDialog = null;
  }
}

private DestroySOEDialog()
{
  if( this.soeDialog != null )
  {
    // Destroy the Property Grid Dialog/Grid.
    this.soeDialog.Destroy();
    this.soeDialog = null;
  }
}

private DestroyFilesDialog()
{
  if( this.filesDialog != null )
  {
    // Destroy the Property Grid Dialog/Grid.
    this.filesDialog.Destroy();
    this.filesDialog = null;
  }
}

private DestroySaveDialog()
{
  if( this.saveDialog != null )
  {
    // Destroy the Save Dialog.
    this.saveDialog.Destroy();
    this.saveDialog = null;
  }
}

private DestroyPropGridDialog()
{
  //this.propertyGrid.dialog.destroy();
  //debugger
  if( this.propertyGrid != null )
  {
    if( this.propertyGrid.dialog != null )
    {
      // Destroy the Property Grid Dialog/Grid.
      this.propertyGrid.dialog.destroy();
    }
    
    this.propertyGrid = null;
  }
}


CreatePropGrid_Tree()
{
    this.propdata_tree = [];

    this.propGrid_Tree = new Grid({
      dataSource: this.propdata_tree,
      editSettings: { allowEditing: true,  mode: 'Normal'},
      allowSorting: false,
      allowSelection: true,
      gridLines: 'Both',
      enableHover: true,
      selectionSettings: {type: 'Single', mode: 'Row'},
      enableVirtualization: false,
      allowPaging: false,
      toolbar: ['Edit', 'Update', 'Cancel'],
      actionBegin: this.propGridTree_actionBegin.bind(this),
      rowHeight: 13,
      columns: [
          { field: 'name', headerText: 'Property', textAlign: 'Right', width: 125, isPrimaryKey: true, isIdentity: true },
          {
            field: 'value', headerText: 'Value', width: 125, edit: 
            {
                create: () => 
                {
                    this.elem = document.createElement('input');
                    return this.elem;
                },
                read: (args: any) => 
                {
                  if(!isNullOrUndefined(this.colorPickerObj)) 
                  {
                    return this.colorPickerObj.value;
                  } 
                  else 
                  {
                    return args.value;
                  }
                },
                destroy: () => 
                {
                  if(!isNullOrUndefined(this.colorPickerObj)) 
                  {
                      this.colorPickerObj.destroy();
                      this.colorPickerObj = null;
                  }
                },
                write: (args: { rowData: object, column: Column, element: HTMLElement }) => 
                {
                  this.rowData = args.rowData;
                  //debugger
                  if ( args.rowData["name"] == "bordercolor" || 
                       args.rowData["name"] == "oncolor" || 
                       args.rowData["name"] == "offcolor" ||
                       args.rowData["name"] == "normal color" ||
                       args.rowData["name"] == "high color" ||
                       args.rowData["name"] == "low color" ) 
                  {
                    //debugger
                    this.colorPickerObj = new ColorPicker({
                      value: args.rowData["value"],
                      mode: 'Palette',
                      modeSwitcher: false
                    });
                    this.colorPickerObj.appendTo(this.elem);                    
                  } 
                  else 
                  {
                    args.element["value"] = args.rowData["value"];
                  }
                }
            },
          }
      ],
      //width: '100%',
      //height: '100%'
    });
    this.propGrid_Tree.appendTo('#tab-tree');

}

propGridTree_actionBegin(args: any): void {
  console.log("Executing propGridTree_actionBegin callback.");
  if (args.requestType === 'save') {
    console.log("propGridTree_actionBegin requestType = save.");

    // Save changed propdata to data in appropriate component.
    if( this.selectedDevicePoint != null)
    {
      // Save changed property to the device point.      
      let prop:any = args.data;
      let name:string = prop.name;
      let value: string = prop.value;
      this.selectedDevicePoint.saveProperty(name, value);
      this.invalid = true;
    }
  }
}

resetPropData_Tree()
{
  console.log("Executing resetPropData().");
  this.propdata_tree = [];
  this.propGrid_Tree.dataSource = this.propdata_tree;
}

resetPropGrid_Tree()
{
  console.log("Executing resetPropGrid().");
  this.propGrid_Tree.dataSource = [];
  this.propGrid_Tree.dataSource = this.propdata_tree;
}

LoadDevicePointProperties_PropDialog()
{
  //debugger
  console.log("Executing DrawingBoardComponent.LoadDevicePointProperties_PropDialog().");

  if( this.selectedDevicePoint != null )
  {
    this.propertyGrid.propdata_toolbox = [];
    this.selectedDevicePoint.LoadProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
    this.propertyGrid.dialog.visible = true;
  }
}



LoadSymbolProperties()
{
  console.log("Executing DrawingBoardComponent.LoadSymbolProperties().");

  //debugger
  // Load properties of selected symbol.
  if( this.selectedShape != null)
  {
    this.propertyGrid.propdata_toolbox = [];
    this.selectedShape.LoadProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();

    if( this.selectedShape.getDevicePoint() != null)
    {
      // Display in device tree's property grid.
      this.propGrid_Tree.dataSource = [];
      this.propGrid_Tree.dataSource = this.propertyGrid.propdata_toolbox;
      //this.propGrid_Tree.dataSource = this.propdata_tree;

      // Highlight the device point id in the device tree.
      //debugger
      //this.treeViewInstance.selectedNodes = [this.selectedShape.getDevicePoint().getPointId()];
      //this.treeViewInstance.ensureVisible(this.selectedShape.getDevicePoint().getPointId());
      //this.treeViewInstance.ensureVisible(this.selectedShape.getDevicePoint().getFullPointId());
      this.selectedDevicePoint = this.selectedShape.getDevicePoint();    
    }
  }
}


LoadDevicePointProperties()
{
  console.log("Executing DrawingBoardComponent.LoadDevicePointProperties().");

  // Expose the property grid.
  document.getElementById("propgrid-tree").style.display = "block";
  this.propdata_tree = [];
  this.selectedDevicePoint.LoadProperties(this.propdata_tree);
  this.resetPropGrid_Tree();        
}

// Callback when dropping symbol entry onto drawing board.
OnTBTreeNodeDragStart(args: DragAndDropEventArgs)

{
    console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStart() - id: " + args.draggedNodeData.id);
    console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStart() - text: " + args.draggedNodeData.text);
    console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStart() - parentID: " + args.draggedNodeData.parentID);
    console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStart() - expanded: " + args.draggedNodeData.expanded);

    console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStart() - x: " + args.event.x);
    console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStart() - y: " + args.event.y);

    // Clear the tool box property grid.
    this.propertyGrid.resetPropGrid_Toolbox();

    //this.selectedShape = null;
}


// Callback when dropping symbol entry onto drawing board.
OnTBTreeNodeDragStop(args: DragAndDropEventArgs)
{
    // console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStop() - id: " + args.draggedNodeData.id);
    // console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStop() - text: " + args.draggedNodeData.text);
    // console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStop() - parentID: " + args.draggedNodeData.parentID);
    // console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStop() - expanded: " + args.draggedNodeData.expanded);

    // console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStop() - x: " + args.event.x);
    // console.log("Executing DrawingBoardComponent.OnTBTreeNodeDragStop() - y: " + args.event.y);

    args.cancel= true;

    const currentPos = {
      // x: args.event.x,
      // y: args.event.y
      x: args.event.offsetX,
      y: args.event.offsetY
    };

    this.propertyGrid.resetPropData_Toolbox();

    if( args.draggedNodeData.id == "rectangle")
    {
      debugger
      this.addRectangle(currentPos);
      this.LoadSymbolProperties();
      this.InitStates();
      this.toolBoxTree.selectedNodes = [args.draggedNodeData.id.toString()];
      this.treeViewInstance.ensureVisible(args.draggedNodeData.id.toString());
    }
    else if( args.draggedNodeData.id == "circle")
    {
      this.addCircle(currentPos);  
      //this.LoadSymbolProperties();
      this.InitStates();
      //this.toolBoxTree.selectedNodes = [args.draggedNodeData.id.toString()];
      this.treeViewInstance.ensureVisible(args.draggedNodeData.id.toString());
    }
    else if( args.draggedNodeData.id == "line")
    {
      this.addLine(currentPos);  
      //this.LoadSymbolProperties();
      this.InitStates();
      //this.toolBoxTree.selectedNodes = [args.draggedNodeData.id.toString()];
      this.treeViewInstance.ensureVisible(args.draggedNodeData.id.toString());
    }
    else if( args.draggedNodeData.id == "text")
    {
      this.addText(currentPos, true);  
      //this.LoadSymbolProperties();
      this.InitStates();
      //this.toolBoxTree.selectedNodes = [args.draggedNodeData.id.toString()];
      this.treeViewInstance.ensureVisible(args.draggedNodeData.id.toString());
    }
    else if( args.draggedNodeData.id.toString().startsWith("img"))
    {
      let nodedata: any[] = this.toolBoxTree.getTreeData(args.draggedNodeData.id.toString());
      this.addImage(currentPos, nodedata[0].image);
      //this.LoadSymbolProperties();
      this.InitStates();
      //this.toolBoxTree.selectedNodes = [args.draggedNodeData.id.toString()];
      this.treeViewInstance.ensureVisible(args.draggedNodeData.id.toString());
    }
    else
    {
      //this.selectedShape = null;
      console.log("ID Not Recognized: " + args.draggedNodeData.id)
    }
}

OnDeviceTreeNodeDragStart(args: DragAndDropEventArgs)
{
  // console.log("Executing TreeView OnNodeDragStart() - id: " + args.draggedNodeData.id);
  // console.log("Executing TreeView OnNodeDragStart() - text: " + args.draggedNodeData.text);
  // console.log("Executing TreeView OnNodeDragStart() - parentID: " + args.draggedNodeData.parentID);
  // console.log("Executing TreeView OnNodeDragStart() - expanded: " + args.draggedNodeData.expanded);

  // console.log("Executing TreeView OnNodeDragStart() - x: " + args.event.x);
  // console.log("Executing TreeView OnNodeDragStart() - y: " + args.event.y);

  //debugger

  // Clear the Tree Property Grid.
  this.resetPropGrid_Tree();  
}


OnDeviceTreeNodeDragStop(args: DragAndDropEventArgs)
{
  console.log("Executing TreeView OnNodeDragStop() - id: " + args.draggedNodeData.id);
  // console.log("Executing TreeView OnNodeDragStop() - text: " + args.draggedNodeData.text);
  // console.log("Executing TreeView OnNodeDragStop() - parentID: " + args.draggedNodeData.parentID);
  // console.log("Executing TreeView OnNodeDragStop() - expanded: " + args.draggedNodeData.expanded);

  // console.log("Executing TreeView OnNodeDragStop() - x: " + args.event.x);
  // console.log("Executing TreeView OnNodeDragStop() - y: " + args.event.y);

  args.cancel= true;

  const currentPos = {
    //x: args.event.x,
    //y: args.event.y
    x: args.event.offsetX,      
    y: args.event.offsetY
  };

  //debugger
  // Dropping a device point onto a symbol so do not exclude images.
  let targetShape: ShapeComponent = this.FindSymbol(currentPos, false);

  if( targetShape == null )
  {
    console.log("DrawingBoardComponent.OnNodeDragStop() - NULL Target Shape.");
    return;
  }

  if( targetShape.getType() == ShapeComponent.SYMBOL_TYPE_LINE ||
      targetShape.getType() == ShapeComponent.SYMBOL_TYPE_TEXT)
  {
    console.log("DrawingBoardComponent.OnNodeDragStop() - Target Shape Type Invalid for Drag Event:  " + targetShape.getType());
    return;
  }

  if( targetShape != null )
  {
    //let arr: Array<string> = args.draggedNodeData.id.toString().split('-');
    //let id:string = arr[1];    
    //console.log("DrawingBoardComponent.OnNodeDragStop() - id: " + id);

    // Find the Device Point.
    //let dp: DevicePointComponent = this.FindDevicePoint(id);
    let dp: DevicePointComponent = this.FindDevicePoint(args.draggedNodeData.id.toString());

    //debugger

    if( dp != null)
    {
      // Map the dp to the symbol.
      targetShape.addDevicePoint(dp);

      if( targetShape.getDevicePoint() != null )
      {
        //debugger
        targetShape.getDevicePoint().Init(Config.configdata);

        // Adjust properties for analog/accum point.
        targetShape.AdjustProperties();      
        targetShape.getDevicePoint().AdjustProperties();
        targetShape.getDevicePoint().setTextColor();
      }

      this.invalid = true;
      this.selectedDevicePoint = dp;

      //debugger
      this.treeViewInstance.ensureVisible(args.draggedNodeData.id.toString());
    }
    this.selectedShape = targetShape;
    this.ClearBRSymbols();
    this.selectedShape.drawBR = true;
    this.invalid = true;
    this.DirtyBit = true;
  }
}

// Tree View Node Expanded Callback.
OnDeviceTreeNodeExpanded(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardComponent.OnDeviceTreeNodeExpanded().");
    this.nodeExpanding = false;
    this.nodeExpanded = true;
    this.nodeCollapsing = false;
    this.nodeCollapsed= false;
}

// Tree View Node Expanding Callback.
OnDeviceTreeNodeExpanding(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardComponent.OnDeviceTreeNodeExpanding().");
    this.nodeExpanding = true;
    this.nodeExpanded = false;
    this.nodeCollapsing = false
    this.nodeCollapsed= false;
}


// Tree View Node Collapsed Callback.
OnDeviceTreeNodeCollapsed(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardCompoent.OnDeviceTreeNodeCollapsed()");
    this.nodeExpanding = false;
    this.nodeExpanded = false;
    this.nodeCollapsing = false
    this.nodeCollapsed= true;
  }

// Tree View Node Collapsing Callback.
OnDeviceTreeNodeCollapsing(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardComponent.OnDeviceTreeNodeCollapsing()");
    this.nodeExpanding = false;
    this.nodeExpanded = false;
    this.nodeCollapsing = true;
    this.nodeCollapsed= false;
}

// LoadPointTypes(): boolean
// {
//   let nodedata: any[] = this.treeViewInstance.getTreeData(this.id);
//   if( nodedata == null )
//   {
//     console.log("DrawingBoardComponent.LoadPointTypes() - NULL TreeData Returned For: " + this.id);
//     return false;
//   } 
//   else if( nodedata[0].subChild == null)
//   {
//     console.log("DrawingBoardComponent.LoadPointTypes() - NULL TreeData Subchild Returned For: " + this.id);
//     return false;
//   }
//   else if( nodedata[0].subChild.length > 0)
//   {
//     console.log("DrawingBoardComponent.LoadPointTypes() - Node Already Populated For: " + this.id);
//     return false;
//   }

//   let pointTypesToDisplay: { [key: string]: Object }[] = [];
//   for( let i:number=0;i<this.pointTypes.length; ++i )
//   {
//     let type = this.pointTypes[i];
//     let id = type.id + "-" + this.id;
//     var pttype = {
//       id: id,
//       label: type.label,
//       image: type.image,
//       expanded: false,  
//       subChild: []      
//     };

//     pointTypesToDisplay.push(pttype);
//   } 

//   this.treeViewInstance.addNodes(pointTypesToDisplay, this.id);
//   console.log("DrawingBoardComponent.LoadPointTypes() - Point Types Added to Parent Node: " + this.id);
  
//   return true;
// }

// startStream(id:string)
// {
//   this.StopStream();

//   this.id = id;
//   this.streamId++;
//   console.log("streamId: " + this.streamId);

//   // Subscribe to the point data for the selected key (server, client, or client/ied).

//   // TEST ONLY:
//   //this.id = "1632:1";
//   //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
//   var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;
//   console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - cmd: " + cmd);

//   this.wsSubscription = this.wsServiceComm.createObservableSocket(
//     this.url_commServer, cmd).subscribe(
//       data=>this.handleMessage(data),
//       // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
//       err=>this.Cleanup(),
//       ()=>
//       { }
//   );
// }

// RemoveTreeNodes()
// {
//   console.log("DrawingBoardComponent.RemoveTreeNodes()");

//   let nodedata: any[] = this.treeViewInstance.getTreeData(this.id.toString());
//   {
//     if( nodedata == null)
//     {
//       console.log("DrawingBoardComponent.RemoveTreeNodes() - NULL TreeData Returned For: " +this.id.toString());
//       return;
//     }
//     else if( nodedata.length == 0)
//     {
//       console.log("DrawingBoardComponent.RemoveTreeNodes() - Zero Length TreeData Returned For: " +this.id.toString());
//       return;
//     }

//     let items: any[] = nodedata[0].subChild;
//     if( items != null && items.length > 0)
//     {
//       this.treeViewInstance.removeNodes(items);
//     }
//   }
// }

// NOT USED.
// LoadNodePoints(argId: string)
// {
//   let nodedata: any[] = this.treeViewInstance.getTreeData(argId);
//   if( nodedata == null )
//   {
//     return false;
//   } 
//   else if( nodedata[0].subChild == null)
//   {
//     console.log("DrawingBoardComponent.LoadNodePoints() - NULL TreeData Subchild Returned For: " + argId);
//     return false;
//   }
//   else if( nodedata[0].subChild.length > 0)
//   {
//     console.log("DrawingBoardComponent.LoadNodePoints() - Node Already Populated For: " + argId);
//     return false;
//   }

//   let node: Object = this.treeViewInstance.getTreeData(argId);

//   let arr: Array<string> = argId.split('-');
//   let type = arr[0];

//   let pointsToDisplay: { [key: string]: Object }[] = []; 
//   for( let i:number=0; i<this.pointdata.length; ++i )
//   {
//     let pt:any = this.pointdata[i];
//     if( pt.pointid.startsWith(type))
//     {
//       var point = {
//         id: pt.pointid,
//         label: pt.ptname,
//         image: this.imgComponent,
//         expanded: false,
//         subChild: []      
//       };
//       pointsToDisplay.push(point);
//     }
//   }
//   this.treeViewInstance.addNodes(pointsToDisplay, argId);
// }

// Tree View Entry Click Callback.
OnDeviceTreeNodeClick(args: NodeClickEventArgs)
{
  console.log("Executing DrawingBoardComponent.OnDeivceTreeNodeClick()");

  //debugger

  if( this.nodeExpanding || this.nodeCollapsing )
  {
    console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - Node Expanding or Collapsing.");
    return;
  }

  //let argId: string = args.node.getAttribute("data-uid");
  //console.log("argId: " + argId);

  let data_uid: string = args.node.getAttribute("data-uid");
  console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - data_uid: " + data_uid);

  //debugger
  
  // Reset the property grid.
  this.resetPropData_Tree();
  
  //if( ! argId )
  if( ! data_uid )
  { 
    console.log("DrawingBoardComponent.OnDeviceTreeNodeClick() - Undefined nodeid retrieved from NodeClickEventsArgs.")
    return;
  }

  let arr: Array<string> = data_uid.split('-');
  if( arr == null )
  {
    console.log("DrawingBoardComponent.OnDeviceTreeNodeClick() - NULL data_uid arg.")
    return
  }

  //debugger
  if( arr.length == 2 )
  {
    let argId = arr[1];
    console.log("OnDevicePointNodeClick() - argId: " + argId);

    // Device Point Node Selection Logic
    if( argId.startsWith("st") || 
        argId.startsWith("an") || 
        argId.startsWith("ac") || 
        argId.startsWith("co") || 
        argId.startsWith("se") )
    {
      // Selected a specific device point node.
      console.log("OnDevicePointNodeClick() - argId: " + argId);

      // Get the point's id for lookup.
      // Retrieve the device point.
      // Display the selected point's properties.
      //let dp:DevicePointComponent = this.FindDevicePoint(argId);
      //debugger
      //this.selectedDevicePoint = this.FindDevicePoint(argId);
      this.selectedDevicePoint = this.FindDevicePoint(data_uid);
      if( this.selectedDevicePoint != null )
      {
        console.log("OnDevicePointNodeClick() - Deivce Point Selected for argId: " + argId);

        // Display the device point properties in the device tree's property grid.
        // TESTING:
        this.LoadDevicePointProperties();
        // // Expose the property grid.
        // document.getElementById("propgrid-tree").style.display = "block";
        // this.propdata_tree = [];
        // this.selectedDevicePoint.LoadProperties(this.propdata_tree);
        // this.resetPropGrid_Tree();   

        this.LoadDevicePointProperties_PropDialog();

        //this.selectedShape = this.FindMappedSymbol(argId)
        this.selectedShape = this.FindMappedSymbol(data_uid)
        if( this.selectedShape != null)
        {
          this.ClearBRSymbols();
          this.selectedShape.drawBR = true;
          this.invalid = true;
        }
      }
      return;
    }
  }
  else
  {
    alert("OnDevicePointNodeClick() - Invalid arr.length: " + arr.length)
  }
  // else if( arr.length == 1 )
  // {
  //   let argId = arr[0];
  //   // Determine if node selected is a parent node (clients, servers, components).
  //   let node:any = this.xmlData.getElementById(argId);
  //   console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - node: " + node);

  //   if( ! node)
  //   {
  //     // Return if node selected is a parent node (clients, servers, components).
  //     console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - Undefined node retrieved from xmlData for id: ", this.id)
  //     return;
  //   }

  //   // Node is a valid device type node (client, server, ied):
  //   // Proceed with getting points from the server.

  //   // Stop existing stream (if any).
  //   //debugger
  //   this.StopStream();

  //   this.id = argId;
  //   console.log("node id: " + this.id);

  //   this.RemoveTreeNodes();

  //   this.streamId++;
  //   console.log("streamId: " + this.streamId);

  //   // Subscribe to the point data for the selected key (server, client, or client/ied).

  //   // TEST ONLY:
  //   //this.id = "1632:1";
  //   //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
  //   var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;
  //   console.log("DrawingBoardComponent.OnDeviceTreeNodeClick() - cmd: " + cmd);

  //   //this.loadStaticPointData = true;

  //   this.wsSubscription = this.wsServiceComm.createObservableSocket(
  //     this.url_commServer, cmd).subscribe(
  //       data=>this.handleMessage(data),
  //       // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
  //       err=>this.Cleanup(),
  //       ()=>
  //       { }
  //   );
  // }
}

// Device treeview node click callback.
// OnDeviceTreeNodeClick(args: NodeClickEventArgs)
// {
//   console.log("Executing DrawingBoardComponent.OnDeivceTreeNodeClick()");

//   if( this.nodeExpanding || this.nodeCollapsing )
//   {
//     alert("DrawingBoardComponent.OnDeivceTreeNodeClick() - Node Expanding or Collapsing.");
//     return;
//   }

//   let argId: string = args.node.getAttribute("data-uid");
//   console.log("argId: " + argId);
  
//   // Reset the property grid.
//   this.resetPropData_Tree();
  
//   //if( ! argId )
//   { 
//     console.log("DrawingBoardComponent.OnDeviceTreeNodeClick() - Undefined nodeid retrieved from NodeClickEventsArgs.")
//     return;
//   }

//   // Device Point Node Selection Logic
//   if( argId.startsWith("st") || 
//       argId.startsWith("an") || 
//       argId.startsWith("ac") || 
//       argId.startsWith("co") || 
//       argId.startsWith("se") )
//   {
//     // Selected a specific device point node.
//     console.log("OnDevicePointNodeClick() - argId: " + argId);

//     debugger

//     // Get the point's id for lookup.
//     // Retrieve the device point.
//     // Display the selected point's properties.
//     //let dp:DevicePointComponent = this.FindDevicePoint(argId);
//     this.selectedDevicePoint = this.FindDevicePoint(argId);
//     if( this.selectedDevicePoint != null )
//     {
//       alert("OnDevicePointNodeClick() - Deivce Point Selected for argId: " + argId);

//       // Display the device point properties in the device tree's property grid.
//       // TESTING:
//       this.LoadDevicePointProperties();
//       // // Expose the property grid.
//       // document.getElementById("propgrid-tree").style.display = "block";
//       // this.propdata_tree = [];
//       // this.selectedDevicePoint.LoadProperties(this.propdata_tree);
//       // this.resetPropGrid_Tree();

//       this.selectedShape = this.FindMappedSymbol(argId)
//       if( this.selectedShape != null)
//       {
//         this.ClearBRSymbols();
//         this.selectedShape.drawBR = true;
//         this.invalid = true;
//       }
//     }
//     return;
//   }

//   // Determine if node selected is a parent node (clients, servers, components).
//   let node:any = this.xmlData.getElementById(argId);
//   console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - node: " + node);

//   if( ! node)
//   {
//     // Return if node selected is a parent node (clients, servers, components).
//     console.log("DrawingBoardComponent.OnDeivceTreeNodeClick() - Undefined node retrieved from xmlData for id: ", this.id)
//     return;
//   }

//   // Node is a valid device type node (client, server, ied):
//   // Proceed with getting points from the server.

//   // Stop existing stream (if any).
//   this.StopStream();

//   this.id = argId;
//   console.log("node id: " + this.id);

//   this.RemoveTreeNodes();

//   this.streamId++;
//   console.log("streamId: " + this.streamId);

//   // Subscribe to the point data for the selected key (server, client, or client/ied).

//   // TEST ONLY:
//   //this.id = "1632:1";
//   //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
//   var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;
//   console.log("DrawingBoardComponent.OnDeviceTreeNodeClick() - cmd: " + cmd);

//   //this.loadStaticPointData = true;

//   this.wsSubscription = this.wsServiceComm.createObservableSocket(
//     this.url_commServer, cmd).subscribe(
//       data=>this.handleMessage(data),
//       // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
//       err=>this.Cleanup(),
//       ()=>
//       { }
//   );
// }


// Requst all client points
RequestAllClientPoints()
{
  console.log("Executing RequestPoints()");

    this.streamId++;
    console.log("streamId: " + this.streamId);

    // Subscribe to the point data for the selected key (server, client, or client/ied).

    // TEST ONLY:
    //this.id = "1632:1";
    this.id = "all";
    var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

    console.log("DrawingBoardComponent.OnDeviceTreeNodeClick() - cmd: " + cmd);

    this.wsSubscription = this.wsServiceComm.createObservableSocket(
      this.url_commServer, cmd).subscribe(
        data=>this.handleMessage(data),
        // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
        err=>this.Cleanup(),
        ()=>
        { }
    );  
}


// Tool Box TreeView Entry Click Callback.
OnTBTreeNodeClick(args: NodeClickEventArgs)
{
  console.log("Executing DrawingBoardComponet.OnTBTreeNodeClick()");

  let argId: string = args.node.getAttribute("data-uid");
  console.log("argId: " + argId);

  // Hide the property grid.
  document.getElementById("propgrid-toolbox").style.display = "none";

  // We just clicked on the tool box node so clear symbol and device tree selections.
  this.selectedShape = null;
  this.selectedDevicePoint = null;

  if( ! argId )
  {
    console.log("DrawingBoardComponet.OnTBTreeNodeClick() - Undefined nodeid retrieved from NodeClickEventsArgs.")
    return;
  }

  this.id = argId;

  // Load/Display Default Symbol Properties.
  if( argId == "rectangle")
  {
    this.propertyGrid.propdata_toolbox = [];
    RectangleComponent.LoadDefaultProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
  }
  else if( argId == "circle")
  {
    this.propertyGrid.propdata_toolbox = [];
    CircleComponent.LoadDefaultProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
  }
  else if( argId == "line")
  {
    this.propertyGrid.propdata_toolbox = [];
    LineComponent.LoadDefaultProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
  }
  else if( argId == "text")
  {
    this.propertyGrid.propdata_toolbox = [];
    TextComponent.LoadDefaultProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
  }
  else if( argId.startsWith("img"))
  {
    this.propertyGrid.propdata_toolbox = [];
    ImageComponent.LoadDefaultProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
  }
  else
  {
    this.propertyGrid.propdata_toolbox = [];  
    ShapeComponent.LoadDefaultProperties(this.propertyGrid.propdata_toolbox);
    this.propertyGrid.resetPropGrid_Toolbox();
  }

  // Expose the property grid.
  document.getElementById("propgrid-toolbox").style.display = "block";
}

// Reads diagram file from server.
// ReadDiagramFileFromServer(isRemote: boolean)
ReadDiagramFileFromServer(val:string)
{
  // debugger
  console.log("Executing DrawingBoardComponent.ReadDiagramFile().")

  //debugger

  //let file: string = this.diagramFile;
  //let file: string = this.soeFile;
  let file = this.diagramPath + val;
  
  var contents: string;
  this.treeviewService.getTextFile(file)
  .subscribe((result:string) => 
  {
    if( result)
    contents = result;
    console.log("Set Contents: ", contents);

    let arr: Array<string> = contents.split('\r\n');
    this.serialData = [];
    //debugger
    for( let i=0; i<arr.length; ++i)
    {
      let line:string = arr[i];
      this.serialData.push(line);
    }  
    this.Deserialize();
  });
}


// Reads SOE file from server.
ReadSOEFileFromServer(val: string)
{
  //debugger
  console.log("Executing DrawingBoardComponent.ReadSOEFileFromServer() for:  " + this.soeFile);

  //let file: string = this.soeFile;
  let file = this.soePath + val;
  
  var contents: string;
  this.treeviewService.getTextFile(file)
  .subscribe((result:string) => 
  {
    if( result)
    contents = result;
    //console.log("Contents: ", contents);

    let arr: Array<string> = contents.split('\r\n');
    this.soeData = [];
    for( let i=0; i<arr.length; ++i)
    {
      let line:string = arr[i];
      //console.log("soe line: " + line);

      if( line.startsWith("Id,") == false)
      {
        let tokens: Array<string> = line.split(',');
        let inx:number = 0;
        let item =  { id: tokens[inx++],
                      date: tokens[inx++],
                      time: tokens[inx++], 
                      ms: tokens[inx++],
                      point: tokens[inx++],
                      name: tokens[inx++],
                      desc: tokens[inx++],
                      state: tokens[inx++],
                      value: tokens[inx++],
                      class: tokens[inx++],
                      tag1: tokens[inx++],
                      tag2: tokens[inx++],
                    };
        this.soeData.push(item);
      }
    }
    
    //debugger
    // Populate and expose the SOE Dialog.
    if( this.soeDialog != null )
    {
      this.soeDialog.CopySOEData(this.soeData);
      this.soeDialog.Reset();
      this.soeDialog.dialog.visible = true;
    }
  });
}


  //================== Retrieval and Parsing of RTU XML ======================================================
  /*
   * Download the XML (RTU) file.
   * Parse the contents into an XML document.  
   * Parse the XML document into Tree View items (json format).
   * Load the Tree View items into the tree view data store.
   * Load/Display the Tree View from the tree view data store.
  */
 processXML()
 {
   console.log("Executing processXML().");
   if( this.xmlData != null )
   {
     console.log("RTU-XML already loaded.");
     return;
   }

   var contents: string;
   this.treeviewService.getTextFile(this.rtuFile)
       .subscribe((result:string) => 
       {
         if( result)
         contents = result;
         console.log("Set Contents: ", contents);

         this.parser = new DOMParser();
         this.xmlData = this.parser.parseFromString(contents, "application/xml");
         console.log("xmlData:  ", this.xmlData ); 
         //var datanodes = this.xmlData.getElementsByTagName('data');
         var treenodes = this.xmlData.getElementsByTagName('tree');
         //var icons = this.xmlData.getElementsByTagName('icon');
         var items = this.xmlData.getElementsByTagName('item');

         // Parse and display the XML header items.
         //this.processXMLDataTags(this.xmlData);  
         
         // Only one tree node.
         for (var i = 0; i < treenodes.length; i++) 
         {
           // Build the tree view items.
           this.buildTreeViewItems(this.xmlData, items, this.treedata);
         }

         //this.CreateTabs();
         
         // Display the tree view
         //this.CreateTreeView();

         // TODO: Remove this.
         //this.CreateToolBoxTree();

         //this.CreatePropGrid_Tree();

         //this.CreateDialogs();
         this.propertyGrid = new PropGridComponent(this);
         if( this.propertyGrid )
         {
           // Display property grid but in invisible state.
           this.propertyGrid.CreatePropGridDialog(false);
         }

        //  debugger
         this.configDialog = new ConfigDialog(this, Config.PARENT_TYPE_DBC);
         if( this.configDialog )
         {
           // Display Configuration Dialog but in invisible state.
           this.configDialog.CreateDialog(false);
         }

         console.log("ProcessXML() - Dialogs Created.");

         //this.CreatePropGrid_ToolBox();
        });
 }


 /*
  *  Build the tree view items from the XML Document.
 */
 buildTreeViewItems(xmlData, items, treedata) 
 {
     var itemStoreItems = [];
     for (var i = 0; i < items.length; i++) 
     {
         var item = items[i];
         var itemrep = this.buildItem(xmlData, item);
         if( itemrep != null )
         {
           if( itemrep.label == "Servers" ||
              itemrep.label == "Clients" ||
              itemrep.label == "Components" )
          {
            treedata.push(itemrep);
          }
         }
     }

     console.log("ItemStoreItems: " + treedata);
 }


 /* 
  * Recursively build each tree view item.
 */
 buildItem(xmlData, item)
 {
   var id = item.getAttribute("id");
   if( id == undefined )
   {
     this.ID ++;
     id = this.ID;
   }

   var label = item.getAttribute("label");
   if( label == undefined)
   {
     label = id;
   }

   let kind: string = item.getAttribute("kind");
   
   let img: string = "";
   var icon = item.getAttribute("icon");

   if( icon == "Servers" )
   {
     img = this.imgServers;
   }
   if( icon == "Server" )
   {
     img = this.imgServer;
   }    
   else if( icon == "Clients" )
   {
     img = this.imgClients;
   }
   else if( icon == "Client" )
   {
     img = this.imgClient;
   }
   else if( icon == "Port" )
   {
     img = this.imgPort;
   }
   else if( icon == "IED" )
   {
     img = this.imgIed;
   }
   else if( icon == "Components" )
   {
     img = this.imgComponents;
   }
   else if( icon == "Comp" )
   {
     img = this.imgComponent;
   }
   else if( icon == "blank" )
   {
     img = this.imgBlank;
   }
   else if( icon == "unknown" )
   {
     img = this.imgUnknown;
   }

   var itemRep = {
                   id: id,
                   label: label,
                   image: img,
                   kind: kind,
                   expanded: true,
                   subChild: []
           };

   var children = item.childNodes;
   for (var j = 0; j < children.length; j++) 
   {
     if( children[j].nodeName == 'item')
     {
       // Create the child (aka subChild) item.
       //itemRep.subChild.push(this.buildItem(xmlData, children[j]));
       let item:any = this.buildItem(xmlData, children[j]);
       if( item.kind.toLowerCase() != "port" && item.kind.toLowerCase() != "time")
       {
         // Exclude non-point components.
         itemRep.subChild.push(item);
       }
     }
   }

   return itemRep;
 }


 tabSelect() 
{ 
  //debugger; 
  let tabObj: HTMLElement = document.getElementById('tabs'); 
  [].slice.call(tabObj.querySelectorAll('.e-toolbar-item')).forEach((item: HTMLElement, index: number): void => { 
    if (item.classList.contains('e-active')) 
    { 
      item.setAttribute('style', 'background: None'); 
    } 
    else 
    { 
      item.setAttribute('style', 'background: grey'); 
    } 
  }); 
}

 CreateTabs()
 {
   this.tabs = new Tab({
     cssClass: 'e-fill e-accent',
     created: this.tabSelect,
     selected: this.tabSelect,
     items: 
      [
         {
             header: { 'text': 'Device Tree' },
             //content: '#treeview'
             content: '#tab-tree'
         },
        //  {          
        //      header: { 'text': 'Tool Box' },
        //      //content: '#toolbox'
        //      content: '#tab-toolbox'
        //  },
      ]
   });
   this.tabs.appendTo('#tabs');
 }

 closeWindow()
 {
    //this.StopStream();

    // Destroy controls
    //this.DestroyControls();

    // Close current tab.
    window.close();
 }






// NOT USED CODE - REMOVE EVENTUALLY.

 // Traversal for XML Data Tags.
//  processXMLDataTags(xmlData)
//  {
//    console.log("Executing processXMLDataTags()");

//    if( xmlData == null )
//    {
//      console.log("processXMLDataTags - Invalid xmlData.")
//      return;
//    }
//    var nodes = xmlData.getElementsByTagName('data');
//    for (var i = 0; i < nodes.length; i++) 
//    {
//      // alert(nodes[i].nodeName + ' = ' + 
//      //       "name: " + nodes[i].getAttribute("name") + "  " + 
//      //       "  value: " + nodes[i].getAttribute("value"));    
//      try
//      {
//        var key = nodes[i].getAttribute("name");
//        var val = nodes[i].getAttribute("value");

//        if( key == "model")
//        {
//          this.rtuModel = val.toString();
//          //alert("Model: " + this.rtuModel);
//          //this.DisplayAccordion_Model(this.rtuModel);
//          //this.DisplayModel();
//          this.xmltabs.items[0].content = this.rtuModel;
//        }
//        else if( key == "name")
//        {
//          this.rtuName = val.toString();
//          //alert("RTU Name: " + this.rtuName);
//          //this.DisplayAccordion_Device(this.rtuName);
//          //this.DisplayRtuName();
//          this.xmltabs.items[1].content = this.rtuName;
//        }
//        else if( key == "license")
//        {
//          this.rtuLicense = val.toString();
//          //alert("RTU License: " + this.rtuLicense);
//        }
//        else if( key == "version")
//        {
//          this.rtuVersion = val.toString();
//          //alert("RTU Version: " + this.rtuVersion);
//        }        
//      }
//      catch(ex)
//      {
//        console.log("DownloaderComponent.processXML Data Exception:  " + ex);
//      }
//    }
//  }
//================== END Retrieval and Parsing of RTU XML ==================================================

// pointTypes: { [key: string]: Object }[] =  
//   [
//   { id: '01', label: 'Status Points', expanded: false, image: this.imgServers,
//   },
//   {
//       id: '02', label: 'Analog Points', image: this.imgClients, expanded: true,
//   },
//   {
//       id: '03', label: 'Accumulator Points', icon: 'folder', image: this.imgComponents, expanded: true,
//   },
//   {
//     id: '04', label: 'Control Points', image: this.imgClients, expanded: true,
//   },
//   {
//     id: '05', label: 'Setpoints', image: this.imgClients, expanded: true,
//   }
// ];

    // //this.pb_toggle = new Button({iconCss: 'e-icons burg-icon', isToggle: true, content:'&#9776'}, '#toggle');
    // this.pb_toggle = new Button({iconCss: 'e-icons burg-icon', isToggle: true, content:'Toggle Tool Box'}, '#toggle');
    // this.pb_toggle.element.onclick = (): void => 
    // {
    //   this.sidebar.toggle();
    // }

    // this.pb_logout = new Button({iconCss: 'e-icons e-logout-icon'}, '#logout');
    // this.pb_logout.element.setAttribute("title", "Logout");
    // this.pb_logout.element.onclick = (): void => 
    // {
    //   console.log("Executing pb_logout.onclick()");
    //   this.sendMessageToServer(this.cmd_sessionClose);
    //   this.router.navigateByUrl('/app');
    // }
    
    // this.rb_left = new RadioButton({ label: 'Tool Box Left', name: 'state', checked: true });
    // this.rb_left.appendTo('#left');

    // this.rb_left.change= (): void => 
    // {
    //   this.sidebar.position = "Left";
    //   document.getElementById("logout").style.setProperty('float', 'right');
    // };  

    // this.rb_right = new RadioButton({ label: 'Tool BoxRight', name: 'state', checked: false });
    // this.rb_right.appendTo('#right');

    // this.rb_right.change= (): void => 
    // {
    //   this.sidebar.position = "Right";
    //   document.getElementById("logout").style.setProperty('float', 'left');
    // };  


    // Retrieve the html symbol elements.
    // this.draggableRect = document.getElementById('symbol-rectangle');
    // this.draggableCircle = document.getElementById('symbol-circle');
    // this.draggableLine = document.getElementById('symbol-line');
    // this.draggableText = document.getElementById('symbol-text');

    // // Listen for the drag start event for each symbol.
    // this.draggableRect.addEventListener('dragstart', this.onDrag, false);
    // this.draggableCircle.addEventListener('dragstart', this.onDrag, false);
    // this.draggableLine.addEventListener('dragstart', this.onDrag, false);
    // this.draggableText.addEventListener('dragstart', this.onDrag, false);

    // // Drag End event listener for the Rectangle symbol.
    // this.draggableRect.addEventListener('dragend', (e) => {
    //   console.log("Executing Rectangle Drag End subscription logic.")
    //   const currentPos = {
    //     x: e.x,
    //     y: e.y
    //   };
    //   this.addRectangle(currentPos);  
    //   this.InitStates();
    // });

    // // Drag End event listener for the Circle symbol.
    // this.draggableCircle.addEventListener('dragend', (e) => {
    //   console.log("Executing Circle Drag End subscription logic.")
    //   const currentPos = {
    //     x: e.x,
    //     y: e.y
    //   };
    //   this.addCircle(currentPos);
    //   this.InitStates();  
    // });

    // // Drag End event listener for the Line symbol.
    // this.draggableLine.addEventListener('dragend', (e) => {
    //   console.log("Executing Line Drag End subscription logic.")
    //   const currentPos = {
    //     x: e.x,
    //     y: e.y
    //   };
    //   this.addLine(currentPos);
    //   this.InitStates();  
    // });

    // // Drag End event listener for the Text symbol.
    // this.draggableText.addEventListener('dragend', (e) => {
    //   console.log("Executing Line Drag End subscription logic.")
    //   const currentPos = {
    //     x: e.x,
    //     y: e.y
    //   };
    //   this.addText(currentPos, false);
    //   this.InitStates();  
    // });

  // onToggleClick()
  // {
  //   this.sidebar.toggle();
  // }

  // onImagesClick()
  // {
  //   // TODO:
  // }


  // onSymbolsClick()
  // {
  //   // TODO:
  // }

  // onRectangleClick()
  // {
  //   // Note Used.
  //   const currentPos = {
  //     x: 300,
  //     y: 100
  //   };
  //   this.addRectangle(currentPos);
  //   this.InitStates();
  // }

  // onCircleClick()
  // {
  //   // Note Used.
  //   const currentPos = {
  //     x: 300,
  //     y: 400
  //   };
  //   this.addCircle(currentPos);
  //   this.InitStates();
  // }

  // onLineClick()
  // {
  //   // Note Used.
  //   const currentPos = {
  //     x: 500,
  //     y: 375
  //   };
  //   this.addLine(currentPos);
  //   this.InitStates();
  // }

  // onTextClick()
  // {
  //   // Note Used.
  //   const currentPos = {
  //     x: 300,
  //     y: 75
  //   };
  //   this.addText(currentPos, false);
  //   this.InitStates();
  // }

// public GetSOEData(): Array<any>
// {
//   return this.soeData;
// }


}
