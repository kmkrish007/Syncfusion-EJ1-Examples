import { Grid, Edit, Sort, VirtualScroll, Scroll, RowDataBoundEventArgs, Page, QueryCellInfoEventArgs } from '@syncfusion/ej2-grids';
import { Dialog } from '@syncfusion/ej2-popups';
import { TextBox} from  '@syncfusion/ej2-inputs';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
import { Button, RadioButton } from '@syncfusion/ej2-buttons';
import {TreeViewComponent} from './treeview.component';
import { TreeView, NodeClickEventArgs } from '@syncfusion/ej2-navigations'
import { Toolbar as NavigationToolBar } from '@syncfusion/ej2-navigations';
import {DashboardLayout} from '@syncfusion/ej2-layouts';
import { TreeviewService } from './treeview.service';
import { Subscription } from 'rxjs';
//import {webSocket} from 'rxjs/webSocket';
import { WebsocketService } from '../websocket/websocket.service';

import {AuthDialogComponent} from './authdialog.component';


export class TreeViewDialog 
{

    //private treeViewComponent: TreeViewComponent;
    public dialog: Dialog = null;
    private wsSubscription: Subscription = null;
    private wsServiceComm: WebsocketService;
    private url_commServer = "ws://10.210.6.147:1113"
    private cmd_userState: string = "get userstate";
    private cmd_sessionClose: string = "session close";
    private sessionId: string = "";

    private static view_DATA = "data";
    private static view_COMM = "comm";  

    // subject = webSocket("ws://localhost:8081");
    //subject = webSocket(this.url_commServer);
  
    view: string;
    id: string;
    streamId: number = 0;

    last_comm_ms: number;

    SERVER_IP: string = "";
    //SERVER_IP: string = "10.210.6.147";
  
    //localIP: string = "10.210.3.63";

    private authDialog: AuthDialogComponent = null;

    rtuFile: string = "";
    //rtuFile: string = "http://" + this.SERVER_IP + "/wtp/rtu.xml/";
    private diagramPath: string = "http://" + this.SERVER_IP + "/wtp/diagrams/";

    private newTreeButton: Button = null;
    private newTerminalButton: Button = null;
    private logoutButton: Button = null;
    private saveButton: Button = null;
    private hmiButton: Button = null;
    private configButton: Button = null;
  
    private rb_status: RadioButton = null;
    private rb_analog: RadioButton = null;
    private rb_accum: RadioButton = null;
    private rb_control: RadioButton = null;
    private rb_setpoint: RadioButton = null;
    private rb_alarms: RadioButton = null;
    private rb_all: RadioButton = null;
  
    private toolbar: NavigationToolBar = null;

    private userList: string[] = [];
    private users: string[] = ['Users'];
    private ddUserList: string[] = [];
    //private toolbar: NavigationToolBar = null;
    private ddUsers: DropDownList = null;
  
    private ddModel: DropDownList = null;
    private ddModelList: string[] = ['Model'];
  
    private ddDevice: DropDownList = null;
    private ddDeviceList: string[] = ['Device'];
  
  
    public rtuLicense: string;
    public rtuVersion: string;
    public rtuModel: string;
    public rtuName: string;
    public ID: number = 0;


    private griddata: { [key: string]: Object }[] = [];
    private commdata: { [key: string]: Object }[] = [];
  
    public gridFilteredData: { [key: string]: Object }[] = [];  
  
    imgpath: string = "";
    imgServers: string = "";
    imgServer: string = "";
    imgClients: string = "";
    imgClient: string = "";
    imgIed: string = "";
    imgPort: string = "";
    imgComponents: string = "";
    imgComponent: string = "";
    imgBlank: string = "";
    imgUnknown: string = "";

    treeviewService: TreeviewService;
    public parser: DOMParser;

    status: any;
    private sub: any;
  
  // Displays rtu.xml file.
  treeViewInstance: TreeView = null;

  // Displays data view (point updates) or comm view (protocol data).
  gridInstance: Grid = null;

  dashboard: DashboardLayout = null;

  // The Pulse Timeline chart.
  //chartInstance: Chart = null;

  ddList: DropDownList = null;  

  private treedata: { [key: string]: Object }[] = []; 

  private doCharting = false;

  private isManualScroll: boolean = false; 

    private txColor: string = "crimson";
    private rxColor: string = "#16A085";    
    private selColor: string = "gold";
  
    private static COLOR_FORCED: string = '#85C1E9';
    private static COLOR_FAILED: string = "red";
    private static COLOR_ALARMED_STATUS: string = "yellowgreen";
    private static COLOR_ALARMED_LOW: string = "teal";
    private static COLOR_ALARMED_HIGH: string = "mediumvioletred";
  
    private static COL_ACKED:number = 15;
    
    private static permissions_NONE: number = 0;
    private static permissions_ALLOWED: number = 1;
    private static permissions_ENABLED: number = 2;
    private static permissions_FORBIDDEN: number = 3;
    private static permissions_CONFLICT: number = 4;
  
    private permissions_force: number = TreeViewDialog.permissions_NONE;
    private permissions_exec: number = TreeViewDialog.permissions_NONE;
  
    private permissonsSet: boolean = false;

    private static FILE_DELIMITER: string = "^";    
    private static ENG_UNITS: number = 1;
  
    private fbutton: Button = null;
    private cbutton: Button = null;
    private ebutton: Button = null;
  
    private forcedKey: Button = null;
    private failedKey: Button = null;
    private alarmedKeyStatus: Button = null;
    private alarmedKeyLow: Button = null;
    private alarmedKeyHigh: Button = null;
    private alarmedKeyNormal: Button = null;
    private btn_ackAll: Button = null;

    // ws_open()
    // {
    //   this.subject.subscribe();
    // }

    // ws_listen()
    // {
    //   this.subject.subscribe(
    //     msg => console.log('message received: ' + msg), // Called whenever there is a message from the server.
    //     err => console.log(err), // Called if at any point WebSocket API signals some kind of error.
    //     () => console.log('complete') // Called when connection is closed (for whatever reason).
    //   );      
    // }

    // ws_send(msg:string)
    // {
    //   //this.subject.subscribe();
    //   // Note that at least one consumer has to subscribe to the created subject - otherwise "nexted" values will be just buffered and not sent,
    //   // since no connection was established!
       
    //   //this.subject.next({message: 'some message'});
    //   this.subject.next(msg);
    //   // This will send a message to the server once a connection is made. Remember value is serialized with JSON.stringify by default!
       
    //   //subject.complete(); // Closes the connection.
       
    //   //this.subject.error({code: 4000, reason: 'I think our app just broke!'});
    //   // Also closes the connection, but let's the server know that this closing is caused by some error.      
    // }

    // ws_close()
    // {
    //   this.subject.complete();
    // }

    // ws_error()
    // {
    //   this.subject.error({code: 4000, reason: 'I think our app just broke!'})
    // }
  
  
    constructor(public TVC: TreeViewComponent)
    {
        console.log("Executing PropGridComponent.CreateGrid()");

        if(TVC)
        {
          this.sessionId = TVC.GetSessionID();
        }

        this.wsServiceComm = new WebsocketService();
    }


    // Creates the dialog.
    public CreateTreeViewDialog(show:boolean)
    {
        console.log("Executing PropGridComponent.ShowTBPropGridDialog()");

        //debugger
        let dialogContent: string = `<form id='TreeViewForm'>
            <div id="dlg-toolbar"></div> 
            <div id="dlg-dashboard"></div>
        </form>` 

        //debugger
        if( this.dialog != null)
        {
          this.DestroyTreeViewDialog();
          this.dialog = null;
        }

        if( this.dialog == null)
        {        
          this.dialog = new Dialog(
          { 
              header: 'Device Tree Window', 
              target: document.getElementById('target'), 
              content: dialogContent,
              allowDragging: true,
              visible: show, 
              animationSettings: 
              { 
                  effect: 'None' 
              }, 
              showCloseIcon: false,
              closeOnEscape: false, 
              width: '1400px',
              height: '700px', 
              open: this.onDialogOpen,
              enableResize: true,
              position: {X: "center", Y:"center"},
              close: this.onDialogClose, 
              created: this.onDialogCreate.bind(this),
              buttons:  
              [
                  {
                      // Click the footer buttons to hide the Dialog
                      'click': () => {
                          this.DestroyTreeViewDialog();
                      },
                      // Accessing button component properties by buttonModel property
                      buttonModel: {
                          isPrimary: true,
                          content: 'CLOSE',
                      }
                  },                
              ]
          }); 
          this.dialog.appendTo('#outerdialog'); 
        }
    }  


    // Dialog created Event callback.
    private onDialogCreate(args:any) 
    {
        //debugger
        console.log("Executing PropGridComponent.onDialogCreate()");
        this.OnInit();           
    } 

    // Dialog opened event callback
    private onDialogOpen()
    {
        //debugger;
        console.log("Executing PropGridComponent.onDialogOpen()");
    }

    // Dialog closed event callback.
    private onDialogClose()
    {
        //debugger;
        console.log("Executing PropGridComponent.onDialogClose()");
        this.DestroyTreeViewDialog();
    }

    // Destroy Dialog and child controls.
    public DestroyTreeViewDialog()
    {
        //debugger;
        console.log("Executing PropGridComponent.Destroy()");

        // if( this.propgrid != null )
        // {
        //     this.propgrid.destroy();
        // }

        if( this.dashboard != null )
        {
          this.dashboard.destroy();
          this.dashboard = null;
        }

        this.dialog.destroy();
        this.dialog = null;  
    }

    OnInit() 
    {
        console.log("Executing TreeViewDialog.OnInit().");
  
        // Create the main dashboard.
        this.dashboard = new DashboardLayout({
          cellSpacing: [5, 5],
          showGridLines: true,
          columns: 5,
          cellAspectRatio: 100/15,
          allowResizing: false,
          allowFloating: false,
          allowDragging: false,
          panels: [
            {'id':'dash-Panel2', 'sizeX': 1, 'sizeY': 13,'row': 0,  'col': 0, header: '<div style="max-width:100%;min-width:100%;color:black;font-size:20px;font-weight:bold;background-color:silver"> <b>DEVICE TREE </b></div>', content:'<div id="dash-treeview" style="max-height:100%;max-width:100%;min-width:100%;min-height:100%;overflow-y:scroll;background-color:rgb(163, 205, 248);border:solid darkgray 1px;"></div>'},
            {'id':'dash-Panel3', 'sizeX': 4, 'sizeY': 13,'row': 0,  'col': 1, content:'<div id="dash-grid" style="border:solid darkgray 1px;background-color:bisque"></div><div id="dash-authdialog"></div><router-outlet></router-outlet>' },
            {'id':'dash-Panel4', 'sizeX': 5, 'sizeY': 2, 'row': 13, 'col': 0, content:'<div id="dash-footer" style="max-width:100%;min-width:100%;height:100px;border:solid darkgray 1px;background-color:#154360"><div id ="dash-container" align="center" style="display:none"></div><div class="btn-group" id=dash-grp1 style="height:100%; width:100%;padding-top:10px;border:solid darkgray 1px;"><div class=button id="dash-buttonDiv" style="display:none;padding-left:30%;padding-top: 10px"><button class="divdash-tag1" id=dash-tag1 style="background-color:#3ADF00"></button><button class="divdash-tag2" id=dash-tag2 style="background-color:#F4D03F"></button><button class="divdash-tag3" id=dash-tag3 style="background-color:#FE2E2E"></button><button class="divdash-ackall" id=dash-ackall style="background-color:#47CC04"></button>  </div> </div> <div id ="dash-container1" align="center" style="display:none"></div> <div class="btn-group" id=dash-grp2 style="width:100%;padding-bottom:5px;border:solid darkgray 1px;"> <div class=button id="dash-keyDiv" style="display:none;padding-left:20%;padding-top: 10px"> <button class="divdash-key1" id=dash-key1 style="background-color:#85C1E9"></button><button class="divdash-key2" id=dash-key2 style="background-color:red"></button><button class="divdash-key3" id=dash-key3 style="background-color:greenyellow"></button><button class="divdash-key4" id=dash-key4 style="background-color:teal;"></button><button class="divdash-key5" id=dash-key5 style="background-color:mediumvioletred"></button><button class="divdash-key6" id=dash-key6 style="background-color:lightsalmon"></button> </div>   </div>    </div>' }  
          ]
        });        
        // render initialized dashboardlayout
        this.dashboard.appendTo('#dlg-dashboard');
  
        this.CreateToolbar();
  
        if( ! this.wsServiceComm )
        {
          alert("TreeViewDialog.OnInt() - ERROR: WebSocket Subscription is NULL.")
          return;
        }
  
        this.wsSubscription = this.wsServiceComm.createObservableSocket(
          this.url_commServer, this.cmd_userState + " " + this.sessionId) 
          //this.cmd_sessionOpen)
          .subscribe(
          data=>this.handleCommMessage(data),
          err=>alert('err: TreeViewDialog Subscribe'),
          ()=>
          { console.log('The TreeViewDialog Subscription Is Complete'); }
          );
  
        this.setPaths();
  
        this.Populate();
    }

    private CopyTreeData()
    {   
      //debugger     
      this.treedata = Array.from(this.TVC.GetTreeData());
    }

    Populate()
    {
      //alert("Executing Populate()");
  
      // Not until deployment.
      //this.getServerIP();    
      //this.setPaths();
  
      //this.processXML();
      // TODO:  Copy treedata from parent to this instance.
      this.CopyTreeData();
      this.CreateTreeView();
      //this.CreateHeaderButtons();
      //this.CreateXMLTabs();
      this.processXMLDataTags();
      document.getElementById("dash-buttonDiv").style.display = "none";
      //this.items = new DataManager(this.griddata).executeLocal(new Query());
      document.getElementById("dash-keyDiv").style.display = "none";

      //this.CreateAuthDialog();
  
    }

    // CreateAuthDialog()
    // {
    //   //debugger
    //   this.authDialog = new AuthDialogComponent(this);
    //   if( this.authDialog )
    //   {
    //     // Display property grid but in invisible state.
    //     this.authDialog.CreateAuthDialog(false);
    //   }
    // }

    getServerIP()
    {
      // TODO:  Comment out next two lines for production version.
      //var url = "http://10.210.6.147/index.html";
      var url = "http://10.210.6.147";
  
      // Get the server ip from user entered url.
      //var url = window.location.href;
      var pos1 = url.indexOf('//');
      var tok = url.slice(pos1+2);
      var pos2 = tok.indexOf('/');
      if( pos2 >= 0 )
      {    
        this.SERVER_IP = tok.slice(0,pos2);
      }
      else
      {
        this.SERVER_IP = tok;
      }
  
      //alert("SERVER_IP: " + this.SERVER_IP);
    }
  

    setPaths()
    {
      //debugger
      this.getServerIP();
  
      this.rtuFile = "http://" + this.SERVER_IP + "/wtp/rtu.xml/";
  
      this.diagramPath = "http://" + this.SERVER_IP + "/wtp/diagrams/";
  
      this.imgpath = "http://" + this.SERVER_IP + "/wtp/images/";
      this.imgServers = this.imgpath + "serversIcon.gif";
      this.imgServer = this.imgpath + "serverIcon.gif";
      this.imgClients = this.imgpath + "clientsIcon.gif";
      this.imgClient = this.imgpath + "clientIcon.gif";
      this.imgIed = this.imgpath + "componentIcon.gif";
      this.imgPort = this.imgpath + "portIcon.gif";
      this.imgComponents = this.imgpath + "componentsIcon.gif";
      this.imgComponent = this.imgpath + "componentIcon.gif";
      this.imgBlank = this.imgpath + "blankIcon.gif";
      this.imgUnknown = this.imgpath + "unknownIcon.gif";
    }
  

    handleCommMessage(msg: string)
    {
      //alert("handleCommMessage: " + msg);
      //console.log("handleCommMessage: " + msg);
      if( msg == "ping")
      {
        // Ignore.
        return;
      }
      else if( msg == "pong")
      {
        // Ignore.
        return;
      }
    //   if( msg.startsWith("DIAG:" ) )
    //   {
    //     //debugger
    //     if( this.configDialog )
    //     {
    //       this.configDialog.DisplayMsg(msg);
    //     }
    //   }
      if( msg.startsWith("-S") )
      {
        this.sessionId = msg.slice(1);
        alert("session id: " + this.sessionId);
  
        return;
      }
      else if( msg.startsWith("??"))
      {
        // Display the error.
        var err = msg.slice(2);
        alert("ERROR: " + err);
        return;
      }
      if( msg.startsWith("-[{") )
      {
          console.log('User List: ', msg);
          //alert("Received User List: " + msg);
          this.buildUserList(msg);
      }
      else
      {
        //debugger
        let arr: Array<string> = msg.split(' ');
        let streamid: string = arr[0];
        if( arr[1] == 'forcing')
        {
          // Disable until data is received.
          this.fbutton.disabled = true;
          this.cbutton.disabled = true;
  
          let arg: string = arr[2];
          if( arg == 'allowed' )
          {
            alert("Received forcing allowed.");
            this.fbutton.content = "Enable Forcing";
            this.permissions_force = TreeViewDialog.permissions_ALLOWED;

            // TODO: Temporary until dashboard buttons work!
            //debugger
            let cmd = "forcing enable root root";
            this.sendMessageToServer(cmd);
          }
          else if( arg == 'enabled')
          {
            alert("Received forcing enabled.");
            this.fbutton.content = "Disable Forcing";
            this.permissions_force = TreeViewDialog.permissions_ENABLED;
          }
          else if( arg == 'forbidden')
          {
            // TODO:  Implement This.
            this.fbutton.content = "Enable Forcing";
            this.permissions_force = TreeViewDialog.permissions_FORBIDDEN;  
          }
          else if( arg == 'conflict')
          {
            // TODO:  Implement This.
            this.fbutton.content = "Enable Forcing";
            this.fbutton.disabled = true;
            this.cbutton.disabled = true;
            this.permissions_force = TreeViewDialog.permissions_CONFLICT;
          }
  
          this.setDataViewPermissions();
  
          return;
        }
        else if( arr[1] == 'executing')
        {
          // Disable until data is received.
          this.ebutton.disabled = true;
          var arg = arr[2];
          if( arg == "allowed" )
          {
              alert("Received executing allowed.");
              this.ebutton.content = "Enable Executing";
              this.permissions_exec = TreeViewDialog.permissions_ALLOWED;

              let cmd = "executing enable root root";
              this.sendMessageToServer(cmd);
          }
          else if( arg == "enabled" )
          {
              alert("Received executing enabled.");
              this.ebutton.content = "Disable Executing";
              this.permissions_exec = TreeViewDialog.permissions_ENABLED;
          }
          else if( arg == "forbidden" )
          {
              this.ebutton.content = "Enable Executing";
              this.permissions_exec = TreeViewDialog.permissions_FORBIDDEN;
          }
          else if( arg == "conflict" )
          {
              this.ebutton.content = "Enable Executing";
              this.permissions_exec = TreeViewDialog.permissions_CONFLICT;
          }
  
          this.setDataViewPermissions();
  
          return;
        }
    
        let viewtype: string = arr[1];
        if( viewtype == "data" )
        {
            this.ProcessPointData(msg, arr);
            return;
        }
        else if( viewtype == "comm" )
        {
            this.ProcessCommData(msg, arr);
            return;
        }
        // else if( viewtype == "pulse" )
        // {
        //     this.ProcessPulseData(msg, arr);
        //     return;
        // }
        else
        {
            console.log('Invalid View Type: ', viewtype);
            return;
        }
      }
    }

    ProcessPointData(msg: string, arr: Array<string>)
    {
      var datatype = arr[2];
  
      // Static Data
      if( datatype == 's' )
      {
          this.ProcessStaticData(msg, arr);
      }
      // Dynamic Data
      else if( datatype == 'd' )
      {
          this.ProcessDynamicData(msg, arr);
      }
    }
  
    ProcessStaticData(msg: string, arr: Array<string>)
    {
        console.log("ProcessStaticData(): " + msg);
  
        //debugger
        var first = msg.indexOf('"');
        var last = msg.indexOf('"', first+1);
        var remaining = msg.slice(last+2);
        var toks = remaining.split(' ');
  
        // Client ID and ied num are sent as hex string so convert to decimal numeric.
        let clientid:number = parseInt(arr[3], 16);
        let iedNum:number = parseInt(arr[4], 16);
        let iedName:string = arr[5];
  
        // Add to data store.
        let item: any;
        let id: string = arr[6];
  
        if( id.startsWith("an") )
        {
          //debugger
          // TODO: Need engineering units.  
            item =  { clientid: clientid,
                      ied: iedNum,
                      iedname: iedName,
                      pointid: arr[6],
                      ptname: msg.slice(first+1, last),
                      scale: toks[0],
                      offset: toks[1],
                      highlimit: toks[2],
                      lowlimit: toks[3],
                      raw: 0,
                      units: TreeViewDialog.ENG_UNITS,
                      forced: 0,
                      failed: 0,
                      alarmed: 0,
                      timestamp: new Date(8364186e5),
                      acked: ""        
                    };
        }
        else if( id.startsWith("st") || id.startsWith("co") )
        { 
          var first_0 = msg.indexOf('"', last+1); 
          var last_0 = msg.indexOf('"', first_0+1);
  
          var first_1 = msg.indexOf('"', last_0+1);
          var last_1 = msg.indexOf('"', first_1+1);
  
          item =  { clientid: clientid,
                    ied: iedNum,
                    iedname: iedName,
                    pointid: arr[6],
                    ptname: msg.slice(first+1, last),
                    scale: msg.slice(first_0+1, last_0),
                    offset: msg.slice(first_1+1, last_1),
                    highlimit: 0,
                    lowlimit: 0,
                    raw: 0,
                    units: TreeViewDialog.ENG_UNITS,
                    forced: 0,
                    failed: 0,
                    alarmed: 0,
                    timestamp: new Date(8364186e5),
                    acked: ""
                   };
        }
        else if( id.startsWith("ac") )
        {
            item =  { clientid: clientid,
                      ied: iedNum,
                      iedname: iedName,
                      pointid: arr[6],
                      ptname: msg.slice(first+1, last),
                      scale: toks[0],
                      offset: 0,
                      highlimit: 0,
                      lowlimit: 0,
                      raw: 0,
                      units: TreeViewDialog.ENG_UNITS,
                      forced: 0,
                      failed: 0,
                      alarmed: 0,
                      timestamp: new Date(8364186e5),
                      acked: ""
                    };
        }
        else if( id.startsWith("se") )
        {
            item =  { clientid: clientid,
                      ied: iedNum,
                      iedname: iedName,
                      pointid: arr[6],
                      ptname: msg.slice(first+1, last),
                      scale: 0,
                      offset: 0,
                      highlimit: 0,
                      lowlimit: 0,
                      raw: 0,
                      units: TreeViewDialog.ENG_UNITS,
                      forced: 0,
                      failed: 0,
                      alarmed: 0,
                      timestamp: new Date(8364186e5),
                      acked: ""
                    };
        }
  
        this.AddToGrid(item);
    }
  
    ProcessDynamicData(msg: string, arr: Array<string>)
    {
      console.log('dynamic data: ', msg);
  
      //debugger
      let toks: Array<string> = msg.split(' ');
  
      // Client ID and ied num are sent as decimal string.
      let clientid:number = parseInt(arr[3], 10);
      let iedNum:number = parseInt(arr[4], 10);
      //let iedName:string = arr[5];
  
      let id: string = arr[5].trim();
      var pt = this.griddata.find(x=>x.pointid == id && x.clientid == clientid && x.ied == iedNum);
  
      if( pt == null )
      {
          console.log('ProcessDynamicData - Point Not Found for ID: ', id);
          return;
      }
  
      //debugger
      pt.raw = arr[6];
      pt.forced = arr[7];
      pt.failed = arr[8];
      pt.alarmed = arr[9];
      pt.acked = arr[10];
  
      let alarmed:number = parseInt(pt.alarmed.toString());
  
      if( alarmed > 0 )
      {
        //debugger
        if( pt.acked == "0")
        {
          pt.acked = "UNACKED";
        }
        else
        {
          pt.acked = "ACKED";
        }
      }
      else
      {
        pt.acked = "";
      }
  
  
      var first = msg.indexOf('"');
      var last = msg.indexOf('"', first+1);
      pt.timestamp = msg.slice(first+1, last);
  
      // TODO:  Commented out until radio buttons added.
      this.FilterPoints();
      
      let numForced = this.QueryGrid_ForcedPoints();
      if( numForced == 0)
      {
        // Disable Clear Forcing Button
        this.cbutton.disabled = true;
      }
      else
      {
        // Enable Clear Forcing Button.
        this.cbutton.disabled = false;
        //alert("ProcessDynamicData - Clear Forcing Button Enabled.");
      }
    }
  
ProcessCommData(msg: string, arr: Array<string>)
{  
if( arr.length < 5 )
{
      console.log('ProcessCommData - Invalid comm data length: ', arr.length);
      return;
}

let cdata: string = " ";
let rdata: string = " ";

// ProcessProcess the cooked data.
if( arr[4] == "c" )
{
    this.last_comm_ms = parseInt(arr[2]);

    // Build the cooked data string from the remaining tokens.
    for(var i=5; i<arr.length; ++i )
    {
        cdata += arr[i];
        cdata += " ";
    }

    //console.log('cdata: ' + cdata);

    var isheader = false;
    if( cdata.includes("Application Header"))
    {
        // Mark header entry.
        isheader = true;
    }

    let uid: string = arr[2].trim();
    //var dt = new Date(new Date(parseInt(uid)));
    let dt: Date = new Date(parseInt(uid));

    let dirtag: string = " ";
    let dir: string = arr[3].trim();
    if( dir == "r" )
    {
        dirtag = "recv";
    }
    else if( dir == "s" )
    {
        dirtag = "send";
    }

    let item: any =  { id_ts: uid,
          ts_ext: dt.toISOString(),
          dir: dirtag,
          data_raw: rdata,
          data_cooked:  cdata,                   
          type: arr[4].trim(),
          isHeader: isheader,
          isSelected: 'N' };

    this.AddToGrid(item);
}
// // Process the raw data.
else if( arr[4] == "r" )
{
  //console.log("ProcessCommData for RawData");

  let tdata: string = "";
  for(var i=5; i<arr.length; ++i )
  {
      // Build the raw data string from the remaining tokens.
      tdata += arr[i];
  }
  // Group the raw hex digits into groups of four.
  for(var i=0; i<tdata.length; ++i )
  {
      var remainder = -1;
      if( i > 0 )
      {
          // Separate into groups of 4 chars.
          var remainder = i%4;
      }
      if( remainder == 0 )
      {
        // Insert a space.
        rdata += " ";
      }
      rdata += tdata[i];
      //console.log("ProcessCommData rdata: " + rdata);
  }

  // Query for the raw data's corresponding cooked header.
  // If found, update the header entry's raw data column.
  // The raw data's corresponding cooked header has the most recent
  // timestamp < the raw data's timestamp and must be the same dir
  // (send or receive) and type = "c".

  // Retrieve all prior cooked header entries of the same dir (send or receive).
  let param_dir: string = arr[3].trim();
  let dir: string = arr[3].trim();
  if( dir == "r" )
  {
      param_dir = "recv";
  }
  else if( dir == "s" )
  {
      param_dir = "send";
  }
  
  let param_type: string = "c";
  //console.log("ProcessCommData - param_type: ", param_type);
  let param_ts: string = arr[2].trim();
  //console.log("ProcessCommData - param_ts: ", param_ts);

  //var pts = this.griddata.find(x=>x.type == param_type);
  let results: Array<any> = [];
  for( var i=0; i<this.griddata.length; ++i)
  {
    let ts: any = this.griddata[i].id_ts;

    if( this.griddata[i].id_ts < parseInt(param_ts) &&
        this.griddata[i].isHeader == true &&
        this.griddata[i].type == param_type &&
        this.griddata[i].dir == param_dir )
    {
      results.push(this.griddata[i]);
      //console.log("Point Match inx: ", i);             
    }
  }
  //console.log("Points Found: "+ results);

  let sresults: Array<any> = results.sort((n1,n2) => {
    if (n1.id_ts > n2.id_ts) {
        return -1;
    }

    if (n1 < n2) {
        return 1;
    }

    return 0;
  });

  if( sresults != null && sresults.length > 0 ) 
  { 
      var item = sresults[0]; 
      if( item != null ) 
      { 
        item.data_raw += rdata; 
        if(this.isManualScroll == false && this.doCharting == true) 
        //if(this.isManualScroll == false) 
        { 
          // Auto scrolling.
          this.gridInstance.dataSource = [];  
          this.gridInstance.dataSource = this.griddata;
          if( this.doCharting == true )
          { 
            // Charting so Scroll to bottom.
            (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight;
          } 
          this.isManualScroll = false; 
        } 
        else 
        {
          // Manual Scrolling. 
          if(this.gridInstance.getContent().firstElementChild.clientHeight + this.gridInstance.getContent().firstElementChild.scrollTop >= this.gridInstance.getContent().firstElementChild.scrollHeight) 
          {
            // At the bottom. 
            //this.gridInstance.dataSource = this.griddata; 
            //(this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
            this.isManualScroll = false; 
          } 
          else 
          { 
            //this.HandlePageFault();
            return; 
          } 
        }  
      } 
  } 



  // Sncfusion DataManager predicate way does not work for me.
  //let predicate: Predicate = new Predicate('type', 'equal', "c");
  //predicate = predicate.and('dir', 'equal', param_dir);
  //predicate = predicate.and('isHeader', 'equal', "true");
  //predicate = predicate.and('id_ts', 'lessthan', param_ts);

  // new DataManager(this.griddata)
  // //.executeQuery(new Query().where(predicate))
  // .executeQuery(new Query().where('type', 'equal', "c"))
  // .then((e: ReturnOption) => this.items = <{[key: string]: Object}[]>e.result).catch((e) => true);
  
  //this.items = new DataManager(this.griddata).executeLocal(new Query());

  // OLD DOJO 1.7 / JS way before Angular:
  // var param_type = "c";
  // var param_ts = arr[2].trim();
  // var uresults = this.griddata.query
  // (
  //         function(element)
  //         {
  //             return element.type == param_type &&
  //             element.dir == param_dir &&
  //             element.isHeader == true &&
  //             element.id_ts < param_ts;
  //         }
  // );
  // // Sort the results in descending order in order to grab the most recent.
  // var sresults = uresults.sort
  // (
  //         function(a, b)
  //         {
  //                 return a.id_ts > b.id_ts ? -1:1;
  //         }
  // );
  // if( sresults != null && sresults.length > 0 )
  // {
  //     // Retrieve the corresponding (most recent) cooked header.
  //     var item = sresults[0];
  //     if( item != null )
  //     {
  //         // Update the cooked header with the raw data.
  //         item.data_raw += rdata;
  //     }
  // }
  }
  return;
}


AddToGrid(item: any)
{ 
  if( item == null )
  {
    return;
  }
  
  this.griddata.push(item);

  if( this.doCharting == true)
  {
    this.gridInstance.getContent().querySelector('.e-content').addEventListener('mousedown', function(e)
    { 
      this.isManualScroll = true; 
    }.bind(this)) 
    this.gridInstance.getContent().querySelector('.e-content').addEventListener('wheel', function(e)
    { 
      this.isManualScroll = true; 
    }.bind(this)) 

    // console.log("Current Page: " + this.gridInstance.pageSettings.currentPage);
    // console.log("Page Count: " + this.gridInstance.pageSettings.pageCount);
    // console.log("Page Size: " + this.gridInstance.pageSettings.pageSize);
    // console.log("Total Records Count: " + this.gridInstance.pageSettings.totalRecordsCount);
    // console.log("Grid Data Records: " + this.griddata.length);

    if(this.isManualScroll == false) 
    { 
      // Auto Scrolling.
      // this.gridInstance.dataSource = [];  
      // this.gridInstance.dataSource = this.griddata; 
      // (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight;       
      this.isManualScroll = false; 
    } 
    else 
    {
      //Manual Scroll.
      if(this.gridInstance.getContent().firstElementChild.clientHeight + this.gridInstance.getContent().firstElementChild.scrollTop >= 
        this.gridInstance.getContent().firstElementChild.scrollHeight) 
        { 
          // Manual Scrolling but at bottom. 
          //this.gridInstance.dataSource = this.griddata;
          //(this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
          this.isManualScroll = false; 
        } 
        else 
        {
          // Manual Scrolling but not at bottom.
          return; 
        } 
    }     
  } 
}


setDataViewPermissions()
{
  console.log("Executing setDataViewPermissions.")

  if( this.view != TreeViewDialog.view_DATA)
  {
    alert("setDataViewPermissions - Not Data View - Returning.")
    return;
  }

  if( this.griddata.length == 0 )
  {
    return;
  }


  if( this.permissions_force == TreeViewDialog.permissions_ALLOWED )
  {
    this.fbutton.content = "Enable Forcing";
    this.fbutton.disabled = false;
    this.cbutton.disabled = true;
    console.log("setDataViewPermissions - Set Forcing to ALLOWED");
  }
  else if( this.permissions_force == TreeViewDialog.permissions_ENABLED )
  {
    this.fbutton.content = "Disable Forcing";
    this.fbutton.disabled = false;
    this.cbutton.disabled = true;
    console.log("setDataViewPermissions - Set Forcing to ENABLED");
  }
  else if( this.permissions_force == TreeViewDialog.permissions_FORBIDDEN )
  {
    this.fbutton.content = "Enable Forcing";
    this.fbutton.disabled = true;
    this.cbutton.disabled = true;
    console.log("setDataViewPermissions - Set Forcing to FORBIDDEN");
  }
  else if( this.permissions_force == TreeViewDialog.permissions_CONFLICT )
  {
    this.fbutton.content = "Enable Forcing";
    this.fbutton.disabled = true;
    this.cbutton.disabled = true;
    console.log("setDataViewPermissions - Set Forcing to CONFLICT");
  }

  if( this.permissions_exec == TreeViewDialog.permissions_ALLOWED )
  {
      this.ebutton.content = "Enable Executing";
      this.ebutton.disabled = false;
      this.permissions_exec = TreeViewDialog.permissions_ALLOWED;
      console.log("setDataViewPermissions - Set Executinging to ALLOWED"); 
  }
  if( this.permissions_exec == TreeViewDialog.permissions_ENABLED )
  {
      this.ebutton.content = "Disable Executing";
      this.ebutton.disabled = false;
      this.permissions_exec = TreeViewDialog.permissions_ENABLED;
      console.log("setDataViewPermissions - Set Executinging to ENABLED"); 
  }
  if( this.permissions_exec == TreeViewDialog.permissions_FORBIDDEN )
  {
      this.ebutton.content = "Enable Executing";
      this.ebutton.disabled = true;
      this.permissions_exec = TreeViewDialog.permissions_FORBIDDEN;
      console.log("setDataViewPermissions - Set Executinging to FORBIDDEN");        
  }
  if( this.permissions_exec == TreeViewDialog.permissions_CONFLICT )
  {
      this.ebutton.content = "Enable Executing";
      this.ebutton.disabled = true;
      this.permissions_exec = TreeViewDialog.permissions_CONFLICT;
      console.log("setDataViewPermissions - Set Executinging to CONFLICT"); 
  }

  this.permissonsSet = true;
}


processXMLDataTags()
{
  debugger
  console.log("Executing processXMLDataTags()");

  if( this.TVC.xmlData == null )
  {
    console.log("processXMLDataTags - Invalid xmlData.")
    return;
  }
  var nodes = this.TVC.xmlData.getElementsByTagName('data');
  for (var i = 0; i < nodes.length; i++) 
  {
    // alert(nodes[i].nodeName + ' = ' + 
    //       "name: " + nodes[i].getAttribute("name") + "  " + 
    //       "  value: " + nodes[i].getAttribute("value"));    
    try
    {
      var key = nodes[i].getAttribute("name");
      var val = nodes[i].getAttribute("value");

      if( key == "model")
      {
        this.rtuModel = val.toString();
        this.ddModelList.push(this.rtuModel);
        this.ddModel.dataSource = this.ddModelList;
        this.ddModel.index = 0;
      }
      else if( key == "name")
      {
        this.rtuName = val.toString();
        this.ddDeviceList.push(this.rtuName);
        this.ddDevice.dataSource = [];
        this.ddDevice.dataSource = this.ddDeviceList;
        this.ddDevice.index = 0;
        //debugger
      }
      else if( key == "license")
      {
        this.rtuLicense = val.toString();
        //alert("RTU License: " + this.rtuLicense);
      }
      else if( key == "version")
      {
        this.rtuVersion = val.toString();
        //alert("RTU Version: " + this.rtuVersion);
      }        
    }
    catch(ex)
    {
      console.log("DownloaderComponent.processXML Data Exception:  " + ex);
    }
  }
}


  


buildUserList(msg: string)
{
  //return;
  //debugger
  console.log('Executing buildUserList()');
  if (msg != "error")
  {
    var start = 0;
    //let len:number = 1;
    // TODO: Need to test with multiple users using ConfigAdmin2.
    // TODO: TEST DATA for MULTIPLE USERS
    msg = "-[{\"name\":\"root\", \"address\":\"10.210.3.63\", \"forcing\":\"false\", \"executing\":\"false\"} {\"name\":\"renee\", \"address\":\"10.210.3.63\", \"forcing\":\"false\", \"executing\":\"false\"} {\"name\":\"owl\", \"address\":\"10.210.3.63\", \"forcing\":\"false\", \"executing\":\"false\"}]";
    
    //for (var i = 0; i < len; i++)
    let i=0;
    while(1)
    {
      i++;                  
      var lpos = msg.indexOf("{", start);
      var rpos = msg.indexOf("}", start);
      if( lpos == -1 || rpos == -1 )
      {
          break;
      }
      start = rpos+1;

      var entry = msg.slice(lpos+1, rpos);
      var tokens = entry.split(",");

      this.userList[i] = "user " + tokens[0] + " at " + tokens[1];

      let forcing: boolean = (tokens[2] == "true");
      let executing: boolean = (tokens[3] == "true");

      // TEST ONLY
      forcing = true;
      executing = true;
      if (forcing)
      {
              if (executing)
              {
                      this.userList[i] += " (forcing and executing)";
              }
              else
              {
                      this.userList[i] += " (forcing)";
              }
      }
      else
      {
              if (executing)
              {
                      this.userList[i] += " (executing)";
              }
      }
      //this.userList += '</li>';
    }
  } 
  else
  {
      this.userList[1] += "<h3>Error fetching users</h3>";
  }

  //debugger
  this.ddUserList = this.users.concat(this.userList);
  //this.ddUsers.dataSource = [];
  this.ddUsers.dataSource = this.ddUserList;
  this.ddUsers.index = 0;
}
  


  DestroyGrid()
{
  if( this.gridInstance != null)
  {
    this.gridInstance.dataSource = [];
    this.gridInstance.destroy();
    this.gridInstance = null;
  }
}

CreateGrid()
{  
  //if( this.view == "data")
  if( this.view == TreeViewDialog.view_DATA)
  {
    this.griddata = [];

    this.gridInstance = new Grid({
      dataSource: this.griddata,
      //editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, newRowPosition: 'Bottom' },
      allowSorting: true,
      allowSelection: true,
      pageSettings: { pageSize: 100 },
      gridLines: 'Both',
      enableHover: true,
      selectionSettings: {type: 'Single', mode: 'Both'},
      enableVirtualization: true,
      allowPaging: false,
      cellSelected: this.OnGridRowCellSelected.bind(this),
      rowSelected: this.OnGridRowSelected.bind(this),
      rowDataBound: this.OnGridRowDataBound.bind(this), 
      rowHeight: 15,
      // dataStateChange: this.OnDataStateChange.bind(this),
      columns: [
          { field: 'clientid', headerText: 'Client ID', textAlign: 'Right', width: 25, isPrimaryKey: true, visible: false },
          { field: 'ied', headerText: 'IED', textAlign: 'Right', width: 25, isPrimaryKey: true, visible: false },
          { field: 'iedname', headerText: 'IED Name', textAlign: 'Right', width: 50, isPrimaryKey: false },
          { field: 'pointid', headerText: 'Point ID', textAlign: 'Right', width: 25, isPrimaryKey: true },
          { field: 'ptname', headerText: 'Point Name', width: 100 },
          { field: 'scale', headerText: 'scale', width: 25, visible: false},
          { field: 'offset', headerText: 'offset', width: 25, visible: false},
          { field: 'highlimit', headerText: 'high', width: 25, visible: false},
          { field: 'lowlimit', headerText: 'low', width: 25, visible: false},
          { field: 'raw', headerText: 'Raw', textAlign: 'Right', width: 25 },
          { field: 'units', headerText: 'units', width: 25, visible: false},
          { field: 'forced', headerText: 'Forced', textAlign: 'Right', width: 25, visible: false },
          { field: 'failed', headerText: 'Failed', textAlign: 'Right', width: 25, visible: false },
          { field: 'alarmed', headerText: 'Alarmed', textAlign: 'Right', width: 25, visible: true },
          { field: 'timestamp', headerText: 'Timestamp', textAlign:'Left', format: 'M/d/y hh:mm' , width: 40 },
          { field: 'acked', headerText: 'Acked', textAlign: 'Right', width: 25, visible: true },
      ],
      width: '100%',    
      height: '100%'
    });
    this.gridInstance.appendTo('#dash-grid');
  }
  //else if( this.view == "comm")
  else if( this.view == TreeViewDialog.view_COMM)
  {
    //Create subscription (observer) to comm data observable.
    // this.commSubscription = this.CreateCommDataObservable().subscribe(data=>this.HandleCommSubscription(data),
    //     err=>alert("ERROR: CommData Subscribe"),
    //     ()=>{console.log("The Comm Data Subscription Is Complete.")} );

    this.griddata = [];

    this.gridInstance = new Grid({
      dataSource: this.griddata,
      //dataSource: this.data,
      //editSettings: { allowEditing: false, allowAdding: false, allowDeleting: false, newRowPosition: 'Bottom' },
      allowSorting: true,
      gridLines: 'Both',
      enableHover: true,
      allowPaging: false,
      pageSettings: { pageSize: 1000 },
      enableVirtualization: true,
      rowHeight: 15,
      rowDataBound: this.OnGridRowDataBound.bind(this),
      //dataStateChange: this.OnDataStateChange.bind(this),
      columns: [
        { field: 'id_ts', headerText: 'Timestamp', width: 0, textAlign: 'Right', isPrimaryKey: true  },
        { field: 'ts_ext', headerText: 'Date/Time', width: 210 },
        { field: 'dir', headerText: '', width: 0},
        { field: 'type', headerText: '', width: 0 },
        { field: 'data_raw', headerText: 'Raw Data', width: 450 },
        { field: 'data_cooked', headerText: 'Analyzed Data', width: 500 },
        { field: 'isHeader', headerText: '', width: 0 },
        { field: 'isSelected', headerText: '', width: 0 }
      ],
      //height: 575
      //height: 715
      height: '100%',
      width: '100%'
    });
    this.gridInstance.appendTo('#dash-grid');
  }
}

OnGridRowCellSelected(args: any)
{
  //debugger
  console.log('Executing OnGridRowCellSelected().');
  if(args.cellIndex.cellIndex == TreeViewDialog.COL_ACKED)
  {
    if( args.data.alarmed != "0" )
    {
      if( args.data.acked == "UNACKED")
      {
        let rowinx = this.GetPointIndex(args.data.pointid);
        if( rowinx >= 0 )
        {
          // Send ack command to server.
          let cmd:string = "ack " + args.data.pointid;
          this.sendMessageToServer(cmd);
        }
      }
    }
  }
}

GetPointIndex(id:string): number
{ 
  for( let i:number=0; i<this.griddata.length; ++i)
  {
    let item = this.griddata[i];
    if( item.pointid == id )
    {
      return i;
    }    
  }

  return -1;
}


OnAckAll()
{ 
  for( let i:number=0; i<this.griddata.length; ++i)
  {
    let item = this.griddata[i];
    if( item.acked == "UNACKED" )
    {
      // Send ack command to server.
      let cmd:string = "ack " + item.pointid;
      this.sendMessageToServer(cmd);
    }    
  }

  this.gridInstance.dataSource = [];
  this.gridInstance.dataSource = this.griddata;
}


OnGridRowSelected(args: any )
{
  //alert("OnGridRowSelected() for: " + args.data.pointid);
  //debugger

  if( args.target.cellIndex == TreeViewDialog.COL_ACKED)
  {
    console.log("Ack Column Selected");
    return;
  }

  console.log('Executing OnGridRowSelected().');
  if( args.data.pointid.startsWith("st") ||
      args.data.pointid.startsWith("an") ||
      args.data.pointid.startsWith("ac") )
  {
      console.log("Found st/an/ac type point.");
      if( this.IsForcingEnabled() == true )
      {
          console.log("Forcing is Enabled.");
          this.ShowForceDialog(args.data);
      }
      else
      {
          alert("Forcing Must Be Enabled.");
      }
  }
  else if( args.data.pointid.startsWith("co") ||
            args.data.pointid.startsWith("se") )
  {
      console.log("Found co/se type point.");
      if( this.IsExecutingEnabled() == true )
      {
          console.log("Executing is Enabled.");
          this.ShowExecuteDialog(args.data);
          //this.ShowConfirmExecuteDialog(args.data)
      }
      else
      {
          alert("Executing Must Be Enabled.");
      }
  }
}


CreateDataViewButtons()
{
  debugger
  document.getElementById("dash-buttonDiv").style.display = "block";

  if( this.fbutton == null )
  {
    this.fbutton = new Button( {cssClass: 'e-outline'} );
    this.fbutton.appendTo('#dash-tag1');
    this.fbutton.disabled = true;
    this.fbutton.content = "Disable Forcing";

    this.fbutton.element.onclick = (): void => 
    {
      if( this.fbutton.content.startsWith("Enable") )
      {
        // if( this.authDialog )
        // {
        //   // this.authDialog.cmd = "forcing enable ";
        //   // this.authDialog.arg = "You must authenticate to enable forcing:";
        //   this.authDialog.dialog.visible = true;
        //   return;
        // }

        //debugger
        //let cmd = "forcing enable root root";
        //this.sendMessageToServer(cmd);
  
      }
      else if( this.fbutton.content.startsWith("Disable") )
      {
          let cmd: string = "forcing disable";
          this.sendMessageToServer(cmd);
          console.log('fbutton OnClick() - Cmd Sent: ', cmd);
      }
    };
  }

  if( this.cbutton == null )
  {
    this.cbutton = new Button( {cssClass: 'e-outline'});
    this.cbutton.appendTo('#dash-tag2');
    this.cbutton.disabled = true;
    this.cbutton.content = "Clear Forcing";

    this.cbutton.element.onclick = (): void => 
    {
      //alert("cbutton Click Callback.");
      let cmd: string = "clear";
      this.sendMessageToServer(cmd);
      console.log('cbutton OnClick() - Cmd Sent: ', cmd);  
    };
  }

  if( this.ebutton == null )
  {
    this.ebutton = new Button( {cssClass: 'e-outline'} );
    this.ebutton.appendTo('#dash-tag3');
    this.ebutton.disabled = true;
    this.ebutton.content = "Disable Executing";

    this.ebutton.element.onclick = (): void => 
    {
      if( this.ebutton.content.startsWith("Enable") )
      {
        if( this.authDialog )
        {
          // this.authDialog.cmd = "executing enable ";
          // this.authDialog.arg = "You must authenticate to enable executing:";
          this.authDialog.dialog.visible = true;
          return;
        }
      }
      if( this.ebutton.content.startsWith("Disable") )
      {
          let cmd: string = "executing disable";
          this.sendMessageToServer(cmd);
          console.log('ebutton OnClick() - Cmd Sent: ', cmd);
      }  
    };        
  }

  if( this.btn_ackAll == null )
  {
    this.btn_ackAll = new Button( {cssClass: 'e-outline'} );
    this.btn_ackAll.appendTo('#dash-ackall');
    this.btn_ackAll.disabled = false;
    this.btn_ackAll.content = "ACK ALL ALARMS";

    this.btn_ackAll.element.onclick = (): void => 
    {
      this.OnAckAll();
    };        
  }

}

CreateKeyButtons()
{
  document.getElementById("dash-keyDiv").style.display = "inline";  
  if( this.forcedKey == null )
  {
    this.forcedKey = new Button( {cssClass: 'e-outline'} );
    this.forcedKey.appendTo('#dash-key1');
    this.forcedKey.disabled = false;
    this.forcedKey.isToggle = false;
    this.forcedKey.content = "FORCED COLOR";
  }

  if( this.failedKey == null )
  {
    this.failedKey = new Button( {cssClass: 'e-outline'} );
    this.failedKey.appendTo('#dash-key2');
    this.failedKey.disabled = false;
    this.failedKey.isToggle = false;
    this.failedKey.content = "FAILED COLOR";
  }

  if( this.alarmedKeyStatus == null )
  {
    this.alarmedKeyStatus = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyStatus.appendTo('#dash-key3');
    this.alarmedKeyStatus.disabled = false;
    this.alarmedKeyStatus.isToggle = false;
    this.alarmedKeyStatus.content = "ALARM STATUS COLOR";
  }
  if( this.alarmedKeyLow == null )
  {
    this.alarmedKeyLow = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyLow.appendTo('#dash-key4');
    this.alarmedKeyLow.disabled = false;
    this.alarmedKeyLow.isToggle = false;
    this.alarmedKeyLow.content = "ALARM LOW COLOR";
  }
  if( this.alarmedKeyHigh == null )
  {
    this.alarmedKeyHigh = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyHigh.appendTo('#dash-key5');
    this.alarmedKeyHigh.disabled = false;
    this.alarmedKeyHigh.isToggle = false;
    this.alarmedKeyHigh.content = "ALARM HIGH COLOR";
  }
  if( this.alarmedKeyNormal == null )
  {
    this.alarmedKeyNormal = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyNormal.appendTo('#dash-key6');
    this.alarmedKeyNormal.disabled = false;
    this.alarmedKeyNormal.isToggle = false;
    this.alarmedKeyNormal.content = "NORMAL COLOR";
  }
  if( this.btn_ackAll == null )
  {
    this.btn_ackAll = new Button( {cssClass: 'e-outline'} );
    this.btn_ackAll.appendTo('#ackall');
    this.btn_ackAll.disabled = false;
    this.btn_ackAll.isToggle = true;
    this.btn_ackAll.content = "ACK ALL";
  }

}


private DisableRadioButtons(disable: boolean)
{
  this.rb_all.disabled = disable;
  this.rb_status.disabled = disable;
  this.rb_analog.disabled = disable;
  this.rb_accum.disabled = disable;
  this.rb_control.disabled = disable;
  this.rb_setpoint.disabled = disable;
  this.rb_alarms.disabled = disable;

  if( disable )
  {
    this.rb_all.checked = false;
    this.rb_status.checked = false;
    this.rb_analog.checked = false;
    this.rb_accum.checked = false;
    this.rb_control.checked = false;
    this.rb_setpoint.checked = false;
    this.rb_alarms.checked = false;

    document.getElementById("rb-group").style.display = "none";
  }
  else
  {
    document.getElementById("rb-group").style.display = "block";
    this.rb_all.checked = true;
    this.rb_status.checked = false;
    this.rb_analog.checked = false;
    this.rb_accum.checked = false;
    this.rb_control.checked = false;
    this.rb_setpoint.checked = false;
    this.rb_alarms.checked = false;  
  }
}

private CreateRadioButtons()
{
    debugger
    this.rb_all = new RadioButton({ label: 'All', name: 'state', checked: true });
    this.rb_all.appendTo('#rb-all');
    this.rb_all.disabled = true;

    this.rb_all.change= (): void => 
    {
      //document.getElementById("rb-status").style.setProperty('float', 'left');
      console.log("All Radio Button Change Fired");
      this.FilterPoints("all");
    };

    this.rb_status = new RadioButton({ label: 'Status', name: 'state', checked: false });
    this.rb_status.appendTo('#rb-status');
    this.rb_status.disabled = true;

    this.rb_status.change= (): void => 
    {
      //document.getElementById("rb-status").style.setProperty('float', 'left');
      console.log("Status Radio Button Change Fired");
      this.FilterPoints("st");
    };

    this.rb_analog = new RadioButton({ label: 'Analog', name: 'state', checked: false });
    this.rb_analog.appendTo('#rb-analog');
    this.rb_analog.disabled = true;

    this.rb_analog.change= (): void => 
    {
      //document.getElementById("logout").style.setProperty('float', 'right');
      console.log("Analog Radio Button Change Fired");
      this.FilterPoints("an");
    };

    this.rb_accum = new RadioButton({ label: 'Accum', name: 'state', checked: false });
    this.rb_accum.appendTo('#rb-accum');
    this.rb_accum.disabled = true;

    this.rb_accum.change= (): void => 
    {
      //document.getElementById("logout").style.setProperty('float', 'right');
      console.log("Accumulator Radio Button Change Fired");
      this.FilterPoints("ac");
    };  

    this.rb_control = new RadioButton({ label: 'Control', name: 'state', checked: false });
    this.rb_control.appendTo('#rb-control');
    this.rb_control.disabled = true;

    this.rb_control.change= (): void => 
    {
      //document.getElementById("logout").style.setProperty('float', 'right');
      console.log("Control Radio Button Change Fired");
      this.FilterPoints("co");
    };

    this.rb_setpoint = new RadioButton({ label: 'Setpoint', name: 'state', checked: false });
    this.rb_setpoint.appendTo('#rb-setpoint');
    this.rb_setpoint.disabled = true;

    this.rb_setpoint.change= (): void => 
    {
      //document.getElementById("logout").style.setProperty('float', 'right');
      console.log("Setpoint Radio Button Change Fired");
      this.FilterPoints("se");
    };

    this.rb_alarms = new RadioButton({ label: 'Alarms', name: 'state', checked: false });
    this.rb_alarms.appendTo('#rb-alarms');
    this.rb_alarms.disabled = true;

    this.rb_alarms.change= (): void => 
    {
      //document.getElementById("logout").style.setProperty('float', 'right');
      console.log("Alarms Radio Button Change Fired");
      this.FilterPoints("alarms");
    };  

    this.DisableRadioButtons(true);
}


// private GetFilterKey(): string
// {
//   if( this.rb_all.checked )
//   {
//     return "all";
//   }
//   else if( this.rb_status.checked )
//   {
//     return "st";
//   }
//   else if( this.rb_analog.checked )
//   {
//     return "an";
//   }
//   else if( this.rb_accum.checked )
//   {
//     return "ac";
//   }
//   else if( this.rb_control.checked )
//   {
//     return "co";
//   }
//   else if( this.rb_setpoint.checked )
//   {
//     return "se";
//   }
//   else if( this.rb_alarms.checked )
//   {
//     return "alarms";
//   }

//   return "all";

// }

FilterPoints(type:string = null)
{
  //debugger
  this.gridFilteredData = [];

  if( type == null )
  {
    // TODO: Uncommented out until radio buttons added.
    //type = this.GetFilterKey();
    type = "all";
  }

  console.log("FilterPoints() - type: " + type);

  if( type == "all")
  {
    this.gridInstance.dataSource = [];
    this.gridInstance.dataSource = this.griddata;
    return;  
  }

  if( type == "alarms")
  {
    for( let i:number=0; i<this.griddata.length; ++i)
    {
      let item: any = this.griddata[i];
      if( item)
      {
        let ival = parseInt(item.alarmed.toString());
        if( ival > 0 )
        {
          this.gridFilteredData.push(item);
        }
      }
    }
  
    this.gridInstance.dataSource = [];
    this.gridInstance.dataSource = this.gridFilteredData;
    // this.gridInstance.dataSource = this.griddata;

    return;  
  }


  for( let i:number=0; i<this.griddata.length; ++i)
  {
    let item: any = this.griddata[i];
    if( item)
    {
      if( item.pointid.startsWith(type.trim().toLowerCase()))
      {
        this.gridFilteredData.push(item);
      }
    }
  }

  this.gridInstance.dataSource = [];
  this.gridInstance.dataSource = this.gridFilteredData;
}


IsForcingEnabled(): boolean
{
    if( this.fbutton == null )
    {
      return false;
    }

    if( this.fbutton.content.startsWith("Disable") )
    {
      return true;
    }

    return false;
}


IsExecutingEnabled(): boolean
{
    if( this.ebutton == null )
    {
      return false;
    }

    if( this.ebutton.content.startsWith("Disable"))
    {
      return true;
    }

    return false;
}

ShowForceDialog(row: any)
{
  let tb_Value: TextBox;
  let tb_PointId: TextBox;
  let tb_PointName: TextBox;
  let tb_PointType: TextBox;
  let tb_PointStatus: TextBox;


  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='dash-forceForm'> 
  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointId" name="PT ID: " />
        <div id="ptidError" class="error"></div> 
    </div>

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointName" name="PT NAME: " /> 
        <div id="ptnameError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointType" name="TYPE: " /> 
        <div id="pttypeError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointStatus" name="STATUS: " /> 
        <div id="ptstatusError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="forceValue" name="Force Value" /> 
        <div id="userError" class="error"></div> 
    </div> 
  </div> 


  </form> 
  </div> 
  </div>` 

  let dialog: Dialog = new Dialog({ 
    header: 'Forcing Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {
          var cmd = "force " + tb_PointId.value + " " + tb_Value.value;
        
          this.sendMessageToServer(cmd);
          console.log('ForceDialog() - Cmd Sent: ', cmd);

          dialog.destroy();
        },

        buttonModel: 
        { 
            content: 'Force To Raw', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }

    },
    { 
      'click': () => 
      {
        var cmd = "clear " + tb_PointId.value;
        this.sendMessageToServer(cmd);
        console.log('ForceDialog() - Cmd Sent: ', cmd);

        dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Clear Force', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }

  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#authdialog'); 

  function onDialogCreate(args) 
  {
    //alert("Executing onDialogCreate()");

    tb_Value = new TextBox({ 
       
      
      placeholder: 'Force Value', 
        floatLabelType: 'Always' 
    }); 
    tb_Value.appendTo('#forceValue'); 

    tb_PointId = new TextBox({ 
        placeholder: 'Point Id', 
        floatLabelType: 'Always', 
    });     
    tb_PointId.appendTo('#pointId');  
    tb_PointId.readonly = true;  

    tb_PointName = new TextBox({ 
      placeholder: 'Point Name', 
      floatLabelType: 'Always', 
    });     
    tb_PointName.appendTo('#pointName');
    tb_PointName.readonly = true;    

    tb_PointType = new TextBox({ 
      placeholder: 'Point Type', 
      floatLabelType: 'Always', 
    });     
    tb_PointType.appendTo('#pointType');
    tb_PointType.readonly = true;    

    tb_PointStatus = new TextBox({ 
      placeholder: 'Point Status', 
      floatLabelType: 'Always', 
    });     
    tb_PointStatus.appendTo('#pointStatus');
    tb_PointStatus.readonly = true;    

    var display = " ";
    var pttype = " ";
    var flstatus = "";

    if( row.pointid.startsWith("an") )
    {
        pttype = "Analog";
    }
    else if( row.pointid.startsWith("st") )
    {
        pttype = "Status";
    }
    else if( row.pointid.startsWith("co") )
    {
        pttype = "Control";
    }
    else if( row.pointid.startsWith("se") )
    {
        pttype = "Setpoint";
    }
    else if( row.pointid.startsWith("ac") )
    {
        pttype = "Accumulator";
    }

    if( row.forced == "1" )
    {
        flstatus = "forced";
    }
    else if( row.forced == "0" )
    {
        flstatus = "unforced";
    }

    tb_PointType.value = pttype;
    tb_PointId.value = row.pointid;
    tb_PointName.value = row.ptname;
    tb_PointStatus.value = flstatus;
    tb_Value.value = row.raw;
  } 

  function onDialogOpen()
  {
    //alert("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    //alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


ShowExecuteDialog(row: any)
{
  let tb_Value: TextBox;
  let tb_PointId: TextBox;
  let tb_PointName: TextBox;
  let tb_PointType: TextBox;

  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='forceForm'> 
  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointId" name="PT ID: " />
        <div id="ptidError" class="error"></div> 
    </div>

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointName" name="PT NAME: " /> 
        <div id="ptnameError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointType" name="TYPE: " /> 
        <div id="pttypeError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="executeValue" name="Execute Value" /> 
        <div id="userError" class="error"></div> 
    </div> 
  </div> 


  </form> 
  </div> 
  </div>` 

  let dialog: Dialog = new Dialog({ 
    header: 'Execute Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {
          let value: string = tb_Value.value; 
          //alert('Execute Value: ' + value); 
          console.log('Execute Value: ' + value); 

          // Destory first execute dialog.
          dialog.destroy();

          // Show Confirm Execute Dialog.
          this.ShowConfirmExecuteDialog(tb_PointId.value, tb_Value.value);
        },

        buttonModel: 
        { 
            content: 'Execute Value', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }

    },
    { 
      'click': () => 
      {
          dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Cancel', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }
  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#dash-authdialog'); 

  function onDialogCreate(args) 
  {
    //debugger
    // alert("Executing onDialogCreate()");

    tb_Value = new TextBox({ 
        placeholder: 'Execute Value', 
        floatLabelType: 'Always' 
    }); 
    tb_Value.appendTo('#executeValue'); 

    tb_PointId = new TextBox({ 
        placeholder: 'Point Id', 
        floatLabelType: 'Always', 
    });     
    tb_PointId.appendTo('#pointId');  
    tb_PointId.readonly = true;  

    tb_PointName = new TextBox({ 
      placeholder: 'Point Name', 
      floatLabelType: 'Always', 
    });     
    tb_PointName.appendTo('#pointName');
    tb_PointName.readonly = true;    

    tb_PointType = new TextBox({ 
      placeholder: 'Point Type', 
      floatLabelType: 'Always', 
    });     
    tb_PointType.appendTo('#pointType');
    tb_PointType.readonly = true;
    
    var display = " ";
    var pttype = " ";
    var flstatus = "";

    if( row.pointid.startsWith("an") )
    {
        pttype = "Analog";
    }
    else if( row.pointid.startsWith("st") )
    {
        pttype = "Status";
    }
    else if( row.pointid.startsWith("co") )
    {
        pttype = "Control";
    }
    else if( row.pointid.startsWith("se") )
    {
        pttype = "Setpoint";
    }
    else if( row.pointid.startsWith("ac") )
    {
        pttype = "Accumulator";
    }

    if( row.forced == "1" )
    {
        flstatus = "forced";
    }
    else if( row.forced == "0" )
    {
        flstatus = "unforced";
    }

    // Populate the text box fields.
    tb_PointType.value = pttype;
    tb_PointId.value = row.pointid;
    tb_PointName.value = row.ptname;
    tb_Value.value = row.raw;    
  } 

  function onDialogOpen()
  {
    //alert("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    // alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


ShowConfirmExecuteDialog(id: string, value: string)
{
  let dialogContent: string = "Are You Sure?";

  let dialog: Dialog = new Dialog({ 
    header: 'Execute Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {
          let cmd: string = "execute " + id + " " + value;
        
          this.sendMessageToServer(cmd);
          console.log('ShowAuthDialog() - Cmd Sent: ', cmd);
          dialog.destroy();
        },

        buttonModel: 
        { 
            content: 'Execute', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }
    },
    { 
      'click': () => 
      {
          dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Cancel', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }
  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#dash-authdialog'); 

  function onDialogCreate(args) 
  {
    console.log("Executing onDialogCreate()");
  } 

  function onDialogOpen()
  {
    console.log("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    // alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


// ShowAuthDialog(cmd: string, arg: string)
// {
//   debugger
//   console.log("Executing ShowAuthDialog.");

//   let tb_UserName: TextBox;
//   let tb_PassWord: TextBox;
//   let title: string = "Authentication Dialog";

//   let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='myForm'> 
//   <div class="row"> 
//   <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
//   <input id="dlg-username" name="UserName" /> 
//   <div id="dlg-userError" class="error"></div> 
//   </div> 
//   </div> 
//   <div class="row"> 
//   <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
//   <input id="dlg-password" name="Password" /> 
//   <div id="dlg-passwordError" class="error"></div> 
//   </div> 
//   </div> 
//   </form> 
//   </div> 
//   </div>` 

//   this.authDialog = new Dialog({
//     header: title, 
//     target: document.getElementById('newdialog'), 
//     //target: document.getElementById('target'), 
//     content: arg + dialogContent,
//     //isModal: true, 
//     animationSettings: { 
//         effect: 'None' 
//     }, 
//     buttons: [{ 
//         'click': () => 
//         {
//           alert('ShowAuthDialog() - Click Event Fired: ' + cmd);

//           let user: string = tb_UserName.value; 
//           let pswd: string = tb_PassWord.value; 
//           console.log('UserName: ' + user + ' Password: ' + pswd); 

//           cmd += user;
//           cmd += " ";
//           cmd += pswd;
//           //dialog.validate();
        
//           debugger
//           this.sendMessageToServer(cmd);

//           this.authDialog.destroy();
//           console.log('ShowAuthDialog() - Cmd Sent: ', cmd);
//         },

//         buttonModel: 
//         { 
//             content: 'Authenticate', 
//             isPrimary: true, 
//             cssClass: 'e-outline'

//         } 
//     }], 
//     showCloseIcon: true, 
//     width: '500px', 
//     open: onAuthDialogOpen, 
//     close: onAuthDialogClose, 
//     created: onAuthDialogCreated
//   });
//   this.authDialog.appendTo('#dlg-authdialog'); 
//   //this.authDialog.appendTo('#dash-treeview');
//   //this.authDialog.show(); 

//   function onAuthDialogCreated(args) 
//   {
//     console.log("Executing onDialogCreated()");

//     tb_UserName = new TextBox({ 
//         placeholder: 'User Name', 
//         floatLabelType: 'Always' 
//     }); 
//     tb_UserName.appendTo('#dlg-username'); 

//     tb_PassWord = new TextBox({ 
//         placeholder: 'Password', 
//         floatLabelType: 'Always', 
//         type: 'password' 
//     });     
//     tb_PassWord.appendTo('#dlg-password');
//   } 

//   function onAuthDialogOpen()
//   {
//     console.log("Executing onAuthDialogOpen()");
//   }

//   function onAuthDialogClose()
//   {
//     alert("Executing onAuthDialogClose()");
//     this.authDialog.destroy();  
//   }
// }

CreateTreeView()
{
  //debugger
  //alert("Executing CreateTreeView()");
  this.treeViewInstance = new TreeView({
    fields: { dataSource: this.treedata, id: 'id', text: 'label', 
    child: 'subChild', imageUrl: 'image', iconCss: 'icon', hasChildren: 'hasChild'}
  });  

  //Render initialized TreeView
  this.treeViewInstance.appendTo("#dash-treeview");
  
  // Bind the OnClick Event and parent class (TreeViewComponent) to the callback.
  this.treeViewInstance.nodeClicked=this.OnTreeNodeClick.bind(this);
  //this.treeViewInstance.setProperties({'height': 900})
}

sendMessageToServer(msg: string)
{
  // Append session id to message.
      msg += " " + this.sessionId;
      this.status = this.wsServiceComm.sendMessage(msg);
}

closeSocket()
{
      this.wsSubscription.unsubscribe();
      this.wsServiceComm.ws.close();
      this.status = "The Socket Is Closed.";
      //alert("Socket Closed.")
      //alert("Treeview.closeSocket() - Socket Closed.");
}

  ngOnDestroy()
  {
    //alert("TreeView.ngOnDestroy()");
    this.StopStream();

    // this.closeSocket();
    // this.sub.unsubscribe();
  }

  StopStream()
  {
    if( this.wsSubscription != null )
    {
      // Send stream stop message to the server.
      // let cmd: string = "stream" + " " + this.streamId + " " + "stop" + " " + this.sessionId;    
      let cmd: string = "stream" + " " + this.streamId + " " + "stop";    

      this.sendMessageToServer(cmd);

      // Close the socket.
      this.closeSocket();
      this.wsSubscription = null;
    }    
  }


  OnGridRowDataBound(args: RowDataBoundEventArgs)
  {
    //if( this.view == "data")
    if( this.view == TreeViewDialog.view_DATA)
    {
      if( args.data['forced'] == "1")
      {
        // Forced Point.
        args.row.setAttribute("bgcolor", TreeViewDialog.COLOR_FORCED);
      }
      else if( args.data['failed'] == "1")
      {
        // Failed Point.
        args.row.setAttribute("bgcolor", TreeViewDialog.COLOR_FAILED);
      }
      else if( args.data['alarmed'] == "1")
      {
        // Alarmed Status Point.
        args.row.setAttribute("bgcolor", TreeViewDialog.COLOR_ALARMED_STATUS);
      }
      else if( args.data['alarmed'] == "2")
      {
        // Alarmed Anlog Low Point.
        args.row.setAttribute("bgcolor", TreeViewDialog.COLOR_ALARMED_LOW);
      }
      else if( args.data['alarmed'] == "3")
      {
        // Alarmed Analog High Point.
        args.row.setAttribute("bgcolor", TreeViewDialog.COLOR_ALARMED_HIGH);
      }
      else
      {
        // Normal Point.
        //args.row.setAttribute("bgcolor", '#E59866');
        args.row.setAttribute("bgcolor", 'lightsalmon');
      }
    }
    //else if( this.view == "comm")
    else if( this.view == TreeViewDialog.view_COMM)
    {
      if( args.data['isSelected'] == 'Y')
      {
        args.row.setAttribute("bgcolor", this.selColor);
        //alert("OnGridRowDataBound Event Fired: " + args.data['isSelected']);
      }
      else if( args.data['dir'] == 'send')
      {
        // Send Request: Color is red.
        args.row.setAttribute("bgcolor", this.txColor);
      }
      else if( args.data['dir'] == 'recv')
      {
          // Receive Response: Color is green.
        args.row.setAttribute("bgcolor", this.rxColor);
      }

      if(this.isManualScroll == false && this.doCharting == true) 
      {
        (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight;  
      }
    }
  }


OnTreeNodeClick(args: NodeClickEventArgs)
{
  //debugger

    //alert("Executing OnClick()");
    this.StopStream();
    this.DestroyDataViewButtons();
    this.DestroyGrid();
    //this.DestroyChart();

    //debugger
    this.id = args.node.getAttribute("data-uid");
    if( ! this.id )
    {
      console.log("TreeViewDialog.OnTreeNodeClick() - Undefined nodeid retrieved from NodeClickEventsArgs.")
      return;
    }

    console.log("node id" + this.id);

    if( this.id == "2")
    {
      this.id = "all";
      this.view = TreeViewDialog.view_DATA;
      this.streamId ++;

      // TEST ONLY:
      //this.id = "1632:1";
      //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
      var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

      this.CreateGrid();
      
      // Create the forcing/clear forcing/executing toggle buttons.
      this.CreateDataViewButtons();
      this.CreateKeyButtons();

      // Enable the radio buttons
      //this.DisableRadioButtons(false);

      if( this.wsServiceComm == null )
      {
          alert("TreeViewDialog.OnTreeNodeClick() - NULL Subscription - Unable to send stream request: " + cmd);
          return;
      }
  
      this.wsSubscription = this.wsServiceComm.createObservableSocket(
        this.url_commServer, cmd).subscribe(
          data=>this.handleCommMessage(data),
          // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
          err=>this.Cleanup(),
          ()=>
          { }
      );
    }


    if( ! this.TVC )
    {
      console.log("TreeViewDialog.OnTreeNodeClick() - Error retrieving xmlData for id: " + this.id + " - NULL parent TreeViewComponent.")
      return;
    }
    var node = this.TVC.xmlData.getElementById(this.id);
    console.log("TreeViewDialog.OnTreeNodeClick() - node: " + node);

    if( ! node)
    {
      console.log("TreeViewDialog.OnTreeNodeClick() - Undefined node retrieved from xmlData for id: ", this.id)
      return;
    }
    
    this.view = node.getAttribute("view");
    if( ! this.view )
    {
      console.log("TreeViewDialog.OnTreeNodeClick() - Undefined view attribute retrieved from xmlData node for id: ", this.id)
      return;
    }
    console.log("Node View Type: " + this.view);

    this.streamId ++;

    if( this.view == TreeViewDialog.view_DATA)
    {    
      // TEST ONLY:
      //this.id = "1632:1";
      //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
      var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

      this.CreateGrid();
     
      // Create the forcing/clear forcing/executing toggle buttons.
      this.CreateDataViewButtons();
      this.CreateKeyButtons();

      // Enable the radio buttons
      //this.DisableRadioButtons(false);
    }
    else if( this.view == TreeViewDialog.view_COMM)
    {
      //this.id = "6:0";    
      //var cmd = "stream " + this.streamId.toString() + " " + "comm" + " " + this.id;
      let pos:number = this.id.indexOf(':');
      if( pos < 0 )
      {
        this.id += ":0";
      }
      var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

      this.CreateGrid();

      // this.DestroyDataViewButtons(); 

      //this.CreateChart();

      // Hide or disable the radio buttons.
      //this.DisableRadioButtons(true);
    }

    if( this.wsServiceComm == null )
    {
        alert("TreeViewDialog.OnTreeNodeClick() - NULL Subscription - Unable to send stream request: " + cmd);
        return;
    }

    this.wsSubscription = this.wsServiceComm.createObservableSocket(
      this.url_commServer, cmd).subscribe(
        data=>this.handleCommMessage(data),
        // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
        err=>this.Cleanup(),
        ()=>
        { }
    );
}


QueryGrid_ForcedPoints()
{
  if( this.view != TreeViewDialog.view_DATA)
  {
    console.log("QueryGrid_ForcedPoints - Not Data View Returning.")
    return;
  }

  let cnt: number = 0;

  for( var i=0; i<this.griddata.length; ++i)
  {
    let item: any = this.griddata[i];
    if( item != null )
    { 
      if( item.forced == '1' )
      {     
        cnt++;
      }
    }
  }
  //alert("QueryGrid_ForcedPoints() - # Forced Points: "+ cnt);

  return cnt;
}


DestroyDataViewButtons()
{
  document.getElementById("dash-buttonDiv").style.display = "none";

  if( this.fbutton != null )
  {
    this.fbutton.destroy();
    this.fbutton = null;
    console.log("DestroyDataViewButtsons - fbutton destroyed");
  }
  if( this.cbutton != null )
  {
    this.cbutton.destroy();
    this.cbutton = null;
    console.log("DestroyDataViewButtsons - cbutton destroyed");
  }
  if( this.ebutton != null )
  {
    this.ebutton.destroy();
    this.ebutton = null;
    console.log("DestroyDataViewButtsons - ebutton destroyed");
  }

}

Cleanup()
{
      alert("Executing TreeView.Cleanup()");

      // Destroy the grid.
      if( this.gridInstance != null )
      {
        this.gridInstance.dataSource = [];
        this.gridInstance.destroy();
        this.gridInstance = null;
      }

      // Destroy the tree view.
      this.DestroyTreeView();

      // Destroy the chart.
      //this.DestroyChart();
      //this.DestroyGrid();

      // Destroy Buttons.
      this.DestroyDataViewButtons();
      //this.DestroyHeaderButtons();

      //this.router.navigateByUrl('/app');
}

DestroyTreeView()
{
  if( this.treeViewInstance != null)
  {
    this.treeViewInstance.destroy();    
    this.treeViewInstance = null;
  }
}



DestroyHeaderButtons()
{
  if( this.newTreeButton != null )
  {
    this.newTreeButton.destroy;
    this.newTreeButton = null;
  }
  if( this.newTerminalButton != null )
  {
    this.newTerminalButton.destroy;
    this.newTerminalButton = null;
  }
  if( this.logoutButton != null )
  {
    this.logoutButton.destroy;
    this.logoutButton = null;
  }
}


CreateToolbar()
{
  //let symbolTypes: string[] = ['Symbols', 'Rectangle', 'Circle', 'Line', 'Text'];
  let model: string[] = ['Model'];
  let device: string[] = ['Device'];
  //users: string[] = ['Users'];

  this.toolbar = new NavigationToolBar({
  created: this.CreateToolBarButtons.bind(this),
      items: [
        { template: '<div id="rb-group" style="background-color:yellowgreen"> <input id="rb-all" type="radio"/> <input id="rb-status" type="radio"/> <input id="rb-analog" type="radio"/> <input id="rb-accum" type="radio"/> <input id="rb-control" type="radio"/> <input id="rb-setpoint" type="radio"/> <input id="rb-alarms" type="radio"/> </div>'},
        { type: "Separator" },
        { type: 'Input', template: this.ddModel = new DropDownList({ dataSource: model, width: 120, index: 0, cssClass:"custom1"}) },
        { type: "Separator" },
        { type: 'Input', template: this.ddDevice = new DropDownList({ dataSource: device, width: 150, index: 0, cssClass:"custom2"}) },
        { type: "Separator" },
        { type: 'Input', template: this.ddUsers = new DropDownList({ dataSource: this.users, width: 500, index: 0, cssClass:"custom3" }) },
        { type: "Separator" },
        { template: '<button class="e-btn" id="dlg-newTree_btn" style="background-color:yellowgreen;padding:0px"></button>' },
        { template: '<button class="e-btn" id="dlg-newTerminal_btn" style="background-color:magenta;padding:0px"></button>' },
        { template: '<button class="e-btn" id="dlg-save_btn" style="background-color:aqua;padding:0px"></button>' },
        { template: '<button class="e-btn" id="dlg-hmi_btn" style="background-color:violet;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="dlg-config_btn" style="background-color:yellow;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="dlg-logout_btn" style="background-color:red"></button>' },
    ]
  });
  this.toolbar.appendTo('#dlg-toolbar');  
  //debugger
}

CreateToolBarButtons()
{
  this.CreateRadioButtons();

  this.newTreeButton = new Button({ cssClass: `e-flat`, iconCss: 'e-tree-icon e-icons', isToggle: false });
  this.newTreeButton.appendTo('#dlg-newTree_btn');
  this.newTreeButton.element.setAttribute("title", "Tree View");
  this.newTreeButton.disabled = true;
  // this.newTreeButton.element.onclick = (): void => 
  // {
  //     console.log("Executing newTreeButton.onclick()");

  //     if( this.treeViewDialog != null)
  //     {
  //       this.treeViewDialog = null;
  //     }

  //     if( this.treeViewDialog == null )
  //     {
  //       this.treeViewDialog = new TreeViewDialog(this);
  //       if( this.treeViewDialog )
  //       {
  //         // Display property grid but in invisible state.
  //         this.treeViewDialog.CreateTreeViewDialog(true);
  //       }
  //     }      
  //     this.router.navigate(['/treeview', this.sessionId]);
  // }

  this.newTerminalButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-terminal-icon', isToggle: false });
  this.newTerminalButton.appendTo('#dlg-newTerminal_btn');
  this.newTerminalButton.element.setAttribute("title", "Terminal View");
  this.newTerminalButton.element.onclick = (): void => 
  {
      console.log("Executing newTerminalButton.onclick()");
      this.StopStream();

      // Destroy the grid.
      if( this.gridInstance != null )
      {
        this.gridInstance.dataSource = [];
        this.gridInstance.destroy();
        this.gridInstance = null;
      }

      // Destroy the tree view.
      this.DestroyTreeView();

      // Destroy Buttons.
      this.DestroyDataViewButtons();
      this.DestroyHeaderButtons();
      //this.DestroyConfigDialog();
      //this.router.navigate(['/terminal', this.sessionId]);
      //window.open("./terminal.html", '_blank');
  };  


  this.saveButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-save-icon', isToggle: false });
  this.saveButton.appendTo('#dlg-save_btn');
  this.saveButton.element.setAttribute("title", "Save");
  this.saveButton.element.onclick = (): void => 
  {
      console.log("Executing hmiButton.onclick()");
      // Save to local file.
      //this.OnSave();
  }

  this.hmiButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-clear-icon', isToggle: true });
  this.hmiButton.appendTo('#dlg-hmi_btn');
  this.hmiButton.element.setAttribute("title", "HMI View");
  this.hmiButton.disabled = true;
  // this.hmiButton.element.onclick = (): void => 
  // {
  //     console.log("Executing hmiButton.onclick()");
  //     this.StopStream();

  //     // Destroy the grid.
  //     if( this.gridInstance != null )
  //     {
  //       this.gridInstance.dataSource = [];
  //       this.gridInstance.destroy();
  //       this.gridInstance = null;
  //     }

  //     // Destroy the tree view.
  //     this.DestroyTreeView();

  //     // Destroy Buttons.
  //     this.DestroyDataViewButtons();
  //     this.DestroyHeaderButtons();
  //     this.DestroyConfigDialog();
  //     this.router.navigate(['/hmi', this.sessionId]);
  // }


  this.configButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.configButton.appendTo('#dlg-config_btn');
  this.configButton.element.setAttribute("title", "config");
  this.configButton.disabled =true;
  // this.configButton.element.onclick = (): void => 
  // {
  //   debugger
  //   console.log("Executing configBtn.onclick()");

  //   if( this.configDialog != null )
  //   {
  //     this.configDialog.dialog.visible = true;
  //   }
  // }  

  this.logoutButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-logout-icon', isToggle: true });
  this.logoutButton.appendTo('#dlg-logout_btn');
  this.logoutButton.element.setAttribute("title", "Logout");
  this.logoutButton.disabled = true;
  // this.logoutButton.element.onclick = (): void => 
  // {
  //     console.log("Executing logoutButton.onclick()");
  //     this.sendMessageToServer(this.cmd_sessionClose);
  //     // Destroy the grid.
  //     if( this.gridInstance != null )
  //     {
  //       this.gridInstance.dataSource = [];
  //       this.gridInstance.destroy();
  //       this.gridInstance = null;
  //     }
  //     this.DestroyDataViewButtons();
  //     this.DestroyHeaderButtons();
  //     this.DestroyConfigDialog();
  //     this.router.navigateByUrl('/app');
  // }
}

// Callback method to save data to the user's local file.
  OnSave()
  {
      console.log('Executing OnSave()');

      var textToSave = this.FormatCommData();
      var textToSaveAsBlob = new Blob([textToSave], {type:"text/plain"});
      var textToSaveAsURL = window.URL.createObjectURL(textToSaveAsBlob);
      var fileNameToSaveAs = "protocol.txt";

      var downloadLink = document.createElement("a");
      downloadLink.download = fileNameToSaveAs;
      downloadLink.innerHTML = "Download File";
      downloadLink.href = textToSaveAsURL;
      downloadLink.onclick = this.destroyClickedElement;
      downloadLink.style.display = "none";
      document.body.appendChild(downloadLink);

      downloadLink.click();
  }

  destroyClickedElement(event)
  {
      document.body.removeChild(event.target);
  }


  FormatCommData()
  {
      var lines = "<START of REPORT>\r\n";

      // Retrieve the last hour of grid (comm and pulse) data.
      let ts_to: number = this.last_comm_ms;
      let ts_from: number = ts_to - 3600000;

      let results: Array<any> = [];
      for( var i=0; i<this.griddata.length; ++i)
      {
        if( this.griddata[i].id_ts >= ts_from &&
            this.griddata[i].id_ts <= ts_to )
        {
          results.push(this.griddata[i]);
          console.log("QueryGrid_SaveRecords() - Point Is Selected: ", i);  
        }
      }
  
      // Sort results in ascending order.
      let sresults: Array<any> = results.sort((n1,n2) => {
        return n1.id_ts > n2.id_ts ? 1:-1;
      });
  
      if( sresults != null && sresults.length > 0 )
      {
          for( var i=0; i<sresults.length; ++i )
          {
              var item = sresults[i];
              if( item != null )
              {
                  // Format the data.
                  var line = item.id_ts + TreeViewDialog.FILE_DELIMITER +
                            item.dir + TreeViewDialog.FILE_DELIMITER +
                            item.type + TreeViewDialog.FILE_DELIMITER +
                            item.data_raw + TreeViewDialog.FILE_DELIMITER +
                            item.data_cooked + "\r\n";
                  lines += line;
            }
          }
      }

      lines += "<END OF REPORT>\r\n";

      return lines;
  }

}






  
  
    

  


    

