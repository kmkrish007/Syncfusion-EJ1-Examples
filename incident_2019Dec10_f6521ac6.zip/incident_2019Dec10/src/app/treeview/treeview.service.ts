import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { MessageService } from '../message.service';
import {Observable } from 'rxjs';
//import {RTU} from './rtu';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'blob' as 'text',
  })
};

interface ApiUploadResult {
  url: string;
}

export interface UploadResult {
  name: string;
  type: string;
  size: number;
  url: string;
}

@Injectable({
  providedIn: 'root'
})
export class TreeviewService {
  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  getTextFile(filename: string): Observable<string> {
    // The Observable returned by get() is of type Observable<string>
    // because a text response was specified.
    // There's no need to pass a <string> type parameter to get().
    return this.http.get(filename, {responseType: 'text'})
      .pipe(
        tap( // Log the result or error
          data => this.log(filename, data),
          error => this.logError(filename, error)
        )
      );
  }

  getIpAddress() {
    return this.http
          //.get('https://api.ipify.org/?format=json')
          //.get('ENV.REMOTE_ADDR')
          .get('https:///?format=json')
          .pipe(
            //catchError(this.handleError)
            tap( // Log the result or error
              //data => this.log(filename, data),
              //error => this.logError(filename, error)
            )
    
          );
  } 

  // public downloadReport(url, file): Observable<any> {
  //   // Create url
  //   //let url = "http://wtp/diagram/diagram.txt";
  //   var body = { filename: file };

  //   return this.http.post(url, body, {
  //     responseType: "blob",
  //     headers: new HttpHeaders().append("Content-Type", "application/json")
  //   });
  // }

  postMethod(url:string, file: File) {
    console.log("Executing TreeViewService.postMethod for url: " + url);
    //let fileToUpload:File = files.item(0); 
    let formData = new FormData(); 
    formData.append("file", file, file.name); 
    this.http.post(url, formData)
        .subscribe(
          val => {
            console.log("Post Method: " + val)
          }
    );
    //return false; 
    }


  putTextFile(filename: string, payload:File) {
    //let path:string = "http://10.210.6.147/wtp/diagrams/";
    //putTextFile(filename: string, payload:Blob) {
    //const headers = new HttpHeaders().set("Content-Type", "text");
    //payload = "Hello World";
    this.http.post(filename, payload)
    //this.http.post(filename, payload, httpOptions)
    //this.http.put(filename, {name: 'diagram.txt', content: payload})
    .subscribe(
      val => {
          alert("PUT call successful value returned in body" + val);
      },
      response => {
          alert("PUT call in error" +  response);
          console.log("PUT call in error" + response);
      },
      () => {
          alert("The PUT observable is now completed.");
      }
    );

      // .pipe(
      //   tap( // Log the result or error
      //     //data => this.log(filename, data),
      //     error => this.logError(filename, error)
      //   )
      // );
  }

  


  // putexample()
  // {
  //   this.http.put("/courses/-KgVwECOnlc-LHb_B0cQ.json",
  //   {
  //       "courseListIcon": ".../main-page-logo-small-hat.png",
  //       "description": "Angular Tutorial For Beginners TEST",
  //       "iconUrl": ".../angular2-for-beginners.jpg",
  //       "longDescription": "...",
  //       "url": "new-value-for-url"
  //   },
  //   {headers})
  //   .subscribe(
  //       val => {
  //           console.log("PUT call successful value returned in body", 
  //                       val);
  //       },
  //       response => {
  //           console.log("PUT call in error", response);
  //       },
  //       () => {
  //           console.log("The PUT observable is now completed.");
  //       }
  //   );

  // }



  // public getImage(filename: string): Observable<Blob> {
  //   return this.http
  //     // .get(`${this.URL}/image/${hero._id}`, 
  //     .get(`filename`, 
  //     {
  //       responseType: "blob"
  //     });
  // }


  // I upload the given file to the remote server. Returns a Promise.
    public async uploadFile( path: string, file: File ) : Promise<UploadResult> {
 
        var result = await this.http
            .post<ApiUploadResult>(
                //"./api/upload.cfm",
                path,
                file, // Send the File Blob as the POST body.
                {
                    // NOTE: Because we are posting a Blob (File is a specialized Blob
                    // object) as the POST body, we have to include the Content-Type
                    // header. If we don't, the server will try to parse the body as
                    // plain text.
                    headers: {
                        "Content-Type": file.type
                    },
                    params: {
                        clientFilename: file.name,
                        mimeType: file.type
                    }
                }
            )
            .toPromise()
        ;
 
        return({
            name: file.name,
            type: file.type,
            size: file.size,
            url: result.url
        });
 
    }
 


  


  private log(filename: string, data: string) {
    const message = `TreeViewService downloaded "${filename}" and got "${data}".`;
    this.messageService.add(message);
  }

  private logError(filename: string, error: any) {
    const message = `TreeViewService failed to download "${filename}"; got error "${error.message}".`;
    console.error(message);
    this.messageService.add(message);
  }
}

