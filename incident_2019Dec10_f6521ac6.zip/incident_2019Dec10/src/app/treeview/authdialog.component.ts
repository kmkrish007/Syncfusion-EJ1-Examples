import { Dialog } from '@syncfusion/ej2-popups';
import { TextBox} from  '@syncfusion/ej2-inputs';
import {TreeViewDialog} from './TreeViewDialog';

export class AuthDialogComponent 
{
  public dialog: Dialog = null;
  private tb_UserName: TextBox;
  private tb_Password: TextBox;
  private title:string = "Authentication Dialog";
  private parent: TreeViewDialog = null;
  private cmd = "forcing enable ";
  private arg = "You must authenticate to enable forcing:";

  //public cmd: string;
  //public arg: string;

  dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='myForm'> 
  <div class="row"> 
  <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
  <input id="dlg-username" name="UserName" /> 
  <div id="dlg-userError" class="error"></div> 
  </div> 
  </div> 
  <div class="row"> 
  <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
  <input id="dlg-password" name="Password" /> 
  <div id="dlg-passwordError" class="error"></div> 
  </div> 
  </div> 
  </form> 
  </div> 
  </div>` 

  constructor(tvd: TreeViewDialog)
  {
      //console.log("Executing AuthDialogComponent constructor.");
      this.parent = tvd;
  }



  CreateAuthDialog(show: boolean)
  {
    debugger
    console.log("Executing ShowAuthDialog.");


    this.dialog = new Dialog({
      header: this.title, 
      target: document.getElementById('outerdialog'), 
      //target: document.getElementById('dlg-authdialog'), 
      //target: document.getElementById('target'), 
      //target: null,
      content: this.arg + this.dialogContent,
      //isModal: true,
      visible: show, 
      closeOnEscape: false,
      animationSettings: { 
          effect: 'None' 
      }, 
      buttons: [{ 
          'click': () => 
          {
            alert('ShowAuthDialog() - Click Event Fired: ' + this.cmd);

            let user: string = this.tb_UserName.value; 
            let pswd: string = this.tb_Password.value;
            console.log('UserName: ' + user + ' Password: ' + pswd); 

            this.cmd += user;
            this.cmd += " ";
            this.cmd += pswd;
            //dialog.validate();
          
            debugger
            //this.parent.sendMessageToServer(this.cmd);

            //this.dialog.destroy();
            //console.log('CreateAuthDialog() - Cmd Sent: ', this.cmd);
          },

          buttonModel: 
          { 
              content: 'Authenticate', 
              isPrimary: true, 
              cssClass: 'e-outline'

          } 
      }], 
      showCloseIcon: true, 
      width: '500px', 
      open: this.onAuthDialogOpen, 
      close: this.onAuthDialogClose, 
      created: this.onAuthDialogCreated
    });
    //this.dialog.appendTo('#dlg-authdialog'); 
    this.dialog.appendTo('#innerdialog');
    //this.authDialog.show(); 

  }

  private onAuthDialogCreated(args) 
  {
    console.log("Executing onDialogCreated()");

    this.tb_UserName = new TextBox({ 
        placeholder: 'User Name', 
        floatLabelType: 'Always' 
    }); 
    this.tb_UserName.appendTo('#dlg-username'); 

    this.tb_Password = new TextBox({ 
        placeholder: 'Password', 
        floatLabelType: 'Always', 
        type: 'password' 
    });     
    this.tb_Password.appendTo('#dlg-password');
  } 

  private onAuthDialogOpen()
  {
    console.log("Executing onAuthDialogOpen()");
  }

  private onAuthDialogClose()
  {
    alert("Executing onAuthDialogClose()");
    this.dialog.destroy();  
  }

}
