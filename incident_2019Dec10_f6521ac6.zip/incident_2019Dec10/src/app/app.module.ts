import { NgModule }         from '@angular/core';
import { BrowserModule }    from '@angular/platform-browser';
import { FormsModule }      from '@angular/forms';
//import { HttpModule, JsonpModule, } from '@angular/http';
//import { FileManagerAllModule } from '@syncfusion/ej2-angular-filemanager';
//import { FileManagerModule, NavigationPaneService, BreadCrumbBarService, DetailsViewService, LargeIconsViewService, ContextMenuService } from '@syncfusion/ej2-angular-filemanager';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientXsrfModule } from '@angular/common/http';
//import { PageService, SortService } from '@syncfusion/ej2-angular-grids';
//import { ToolbarService } from '@syncfusion/ej2-angular-grids';
//import { AccordionModule } from '@syncfusion/ej2-angular-navigations';
import { AppComponent }         from './app.component';
import { MessageService }       from './message.service';
//import { SharedService }       from './shared.service';
import { TreeViewComponent } from './treeview/treeview.component';
import { TerminalComponent } from './terminal/terminal.component';
import { DrawingBoardComponent} from './hmi/drawingboard.component';
import { RichTextEditorAllModule } from '@syncfusion/ej2-angular-richtexteditor';
import { AppRoutingModule } from './app-routing/app-routing.module';

//import { SelectionService } from '@syncfusion/ej2-angular-charts';
//import { DashboardLayoutModule } from '@syncfusion/ej2-angular-layouts';
//import { ChartAllModule, AccumulationChartAllModule, RangeNavigatorAllModule } from '@syncfusion/ej2-angular-charts';
// import { DateTimeService, LineSeriesService, DateTimeCategoryService, StripLineService, 
//          CandleSeriesService} from '@syncfusion/ej2-angular-charts';

//import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
//import { InMemoryDataService }  from './in-memory-data.service';
//import { RequestCache, RequestCacheWithMap } from './request-cache.service';
//import { AuthService }          from './auth.service';
//import { ConfigComponent }      from './config/config.component';
//import { DownloaderComponent }  from './downloader/downloader.component';
//import { HeroesComponent }      from './heroes/heroes.component';
//import { HttpErrorHandler }     from './http-error-handler.service';
//import { MessagesComponent }    from './messages/messages.component';
//import { PackageSearchComponent } from './package-search/package-search.component';
//import { UploaderComponent }    from './uploader/uploader.component';
//import { httpInterceptorProviders } from './http-interceptors/index';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { LoginComponent } from './login/login.component';

declare var require: any;

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    RichTextEditorAllModule,
    //DashboardLayoutModule,
    //AccordionModule,
    //GridModule,
    //ChartAllModule,
    //AccumulationChartAllModule,
    //RangeNavigatorAllModule,
    //BrowserAnimationsModule,
    FormsModule,
  //  FileManagerModule,
  //  HttpModule,
  //  JsonpModule,
    HttpClientModule,
    HttpClientXsrfModule.withOptions({
      cookieName: 'My-Xsrf-Cookie',
      headerName: 'My-Xsrf-Header',
    }),

    // The HttpClientInMemoryWebApiModule module intercepts HTTP requests
    // and returns simulated server responses.
    // Remove it when a real server is ready to receive requests.
    // HttpClientInMemoryWebApiModule.forRoot(
    //   InMemoryDataService, {
    //     dataEncapsulation: false,
    //     passThruUnknownUrl: true,
    //     put204: false // return entity after PUT/update
    //   }
    // )
  ],
  declarations: [
    AppComponent,
    TreeViewComponent,
    TerminalComponent,
    DrawingBoardComponent,
    //ConfigComponent,
    //DownloaderComponent,
    //HeroesComponent,
    //MessagesComponent,
    // UploaderComponent,
    // PackageSearchComponent,
    //LoginComponent
  ],
  providers: [
    //AuthService,3
    //HttpErrorHandler,
    //{ provide: RequestCache, useClass: RequestCacheWithMap },
    //httpInterceptorProviders,
    //DateTimeService, 
    //TooltipService, 
    //LineSeriesService, 
    //DateTimeCategoryService, 
    //StripLineService,
    //CandleSeriesService,
    MessageService,
    //SharedService,
    //SortService,
    //SelectionService,
    //PageService,
    //ToolbarService,
  //  NavigationPaneService, 
  //  BreadCrumbBarService, 
  //  DetailsViewService, 
  //  LargeIconsViewService
  ],
  bootstrap: [ AppComponent]
})
export class AppModule {}
