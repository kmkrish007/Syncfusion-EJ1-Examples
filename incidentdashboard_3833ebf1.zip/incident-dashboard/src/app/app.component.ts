import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import {WebsocketService} from './websocket/websocket.service';
//import { Dialog } from '@syncfusion/ej2-popups';
import { ActivatedRoute } from '@angular/router';
import {Router} from '@angular/router';
import {Login} from './login';
//import {SharedService} from './shared.service';
//import {TreeViewComponent} from './treeview/treeview.component';
import {Config} from './config/config';


@Component({
  selector: 'app-root',
  //template: '<app-treeview [sessionId]="app_sessionId"></app-treeview>',
  templateUrl: './app.component.html',
  // providers: [WebsocketService, SharedService],
  providers: [WebsocketService],
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit 
{
  //private ipAddress: string = "10.210.6.147";
  //private localIP: string = "10.210.3.63";
  private wsSubscription: Subscription = null;

  //private url_commServer = "ws://10.210.6.147:1113";
  private url_commServer = "";

  private cmd_userState: string = "get userstate";
  //cmd_sessionOpen: string = "session open root root 10.210.3.63";
  private cmd_sessionOpen: string = "session open";
  private ipaddress = "10.210.3.63";
  private SERVER_IP: string = "";

  private cmd_sessionClose: string = "session close";

  //sessionId: string = "S383886777";
  public static app_sessionId: string = "";

  //private dialog: Dialog = null;
  private status;
l
  streamId: number = 0;

  public login = new Login("", "");

  constructor( private wsServiceComm: WebsocketService, 
               private route: ActivatedRoute,
               private router: Router) 
              //  private sharedService: SharedService)
  {
    console.log("Executing AppComponent Constructor.");
  }

  ngOnInit() 
  {
    console.log("Executing AppComponent OnInit.");
    //this.ipaddress = window.location.hostname;
    //this.ipaddress = ClientIP;
    //alert("Local IP Address: " + this.ipaddress);
    //this.ShowLoginDialog();
    
    this.setPaths();
  }

  onSubmit()
  {
    console.log("Executing OnSubmit");
    // alert("User Name: " + this.login.user);
    // alert("Password: " + this.login.pswd);

    let cmd:string = this.cmd_sessionOpen + " " + this.login.user + " " + this.login.pswd + " " + this.ipaddress;
    // alert("Cmd: " + cmd);

    // this.wsSubscription = this.wsServiceComm.createObservableSocket(this.url_commServer, this.cmd_sessionOpen)
    this.wsSubscription = this.wsServiceComm.createObservableSocket(this.url_commServer, cmd)
    .subscribe(
        data=>this.handleCommMessage(data),
        err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
      ()=>
      {                
        console.log('The Login Subscription Is Complete'); }
    );  
  }

  getServerIP()
  {
    // Get the server ip from user entered url.
    var url = window.location.href;

    if( Config.MODE_DEV )
    {
      // For development mode, use the next line to set the url.
      //url = "http://10.210.6.147";
      url = Config.SERVERIP_TEST;
    }

    var pos1 = url.indexOf('//');
    var tok = url.slice(pos1+2);
    var pos2 = tok.indexOf('/');
    if( pos2 >= 0 )
    {    
      this.SERVER_IP = tok.slice(0,pos2);
    }
    else
    {
      this.SERVER_IP = tok;
    }

    localStorage.setItem("serverIP", this.SERVER_IP);

    console.log("AppComponent - SERVER_IP: " + this.SERVER_IP);
  }

  setPaths()
  {
    debugger
    this.getServerIP();

    this.url_commServer = "ws://" + this.SERVER_IP + ":" + Config.PORT_COMMSERVER.toString();

  }


private RequestConfig()
{
  //debugger
  let cmd:string = "get config";
  this.sendMessageToServer(cmd);
}

sendMessageToServer(msg: string)
{
  //debugger
  // Append session id to message.
      msg += " " + AppComponent.app_sessionId;
      this.status = this.wsServiceComm.sendMessage(msg);
}


  handleCommMessage(msg: string)
  {
    console.log(msg)
    if( msg == "ping")
    {
      // Ignore.
      return;
    }
    else if( msg == "pong")
    {
      // Ignore.
      return;
    }
    else if( msg.startsWith("CFG:"))
    {
      //debugger
      console.log(msg);
      let entry:any = msg.slice(4)
      Config.Add(entry);
    }
    else if( msg.startsWith("CFG START") )
    {
      //debugger
      Config.configdata = [];
    }
    else if( msg.startsWith("CFG END:") )
    {
      if( msg.indexOf("FAIL") > 0)
      {
        // Display error.
        alert(msg);
      }

      //debugger
      document.getElementById("id-login").style.display = 'none';      
      document.getElementById("id-panel-main").style.display =  'none';
      //this.router.navigate(['/treeview', AppComponent.app_sessionId]);

      //this.closeSocket();
      this.StopStream();
      this.router.navigate(['/treeview']);
    }
    else if( msg.startsWith("-S") )
    {
      AppComponent.app_sessionId = msg.slice(1);
      console.log("AppComponent.handleCommMessage() - this.sessionId: " + AppComponent.app_sessionId);

      localStorage.setItem("sessionid", AppComponent.app_sessionId);
      localStorage.setItem("numTreeView", "0");
      localStorage.setItem("numTermView", "0");
      localStorage.setItem("numSLDView", "0");
      //localStorage.setItem("serverIP", "");

      this.RequestConfig();

      // this.closeSocket();
      // document.getElementById("id-login").style.display = 'none';      
      // document.getElementById("id-panel-main").style.display =  'none';

      // TODO:
      // Navigate to TreeView here.
      //this.router.navigateByUrl('/terminal');

      // DEBUG - COMMENTED OUT.
      //this.router.navigate(['/treeview', this.app_sessionId]);
      //window.open("./treeview/treeview.component.html", '_blank');

      //this.router.navigate(['/sidebarmenu', this.sessionId]);
      //var win = window.open("/treeview/neswtreeview.html", '_blank');
      //var win = window.open("/newtreeview.html", '_blank');
      //win.focus();
      return;
    }
    else if( msg.startsWith("??"))
    {
      // Display the error.
      var err = msg.slice(2);
      alert("ERROR: " + err);
      return;
    }  
  }

  // set sessionid(val: string)
  // {
  //   this.sharedService.sessionId = val;
  // }

  StopStream()
  {
    if( this.wsSubscription != null )
    {
      // Send stream stop message to the server.
      // let cmd: string = "stream" + " " + this.streamId + " " + "stop" + " " + this.sessionId;    
      let cmd: string = "stream" + " " + this.streamId + " " + "stop";    

      this.sendMessageToServer(cmd);

      // Close the socket.
      this.closeSocket();
    }    
  }



  closeSocket()
  {
        this.wsSubscription.unsubscribe();
        this.status = "The Socket Is Closed.";
        this.wsServiceComm.ws.close();
        console.log("Socket Closed.");
  }

  ngOnDestroy()
  {
    console.log("AppComponent.ngOnDestroy()");
    this.closeSocket();
  }

  public static OpenInNewTab(url: string): void {
    // open link in new tab
    const newTab = window.open(url, '_blank');
  
    // set opener to null so that no one can references it
    newTab.opener = null;
  }

  // ShowLoginDialog()
  // {
  //   //alert("Executing AppComponent ShowLoginDialog.");

  //   let tb_UserName: TextBox;
  //   let tb_PassWord: TextBox;
  //   let title: string = "Login Dialog";


  //   let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='myForm'> 
  //   <div class="row"> 
  //   <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
  //   <input id="username" name="UserName" /> 
  //   <div id="userError" class="error"></div> 
  //   </div> 
  //   </div> 
  //   <div class="row"> 
  //   <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
  //   <input id="password" name="Password" /> 
  //   <div id="passwordError" class="error"></div> 
  //   </div> 
  //   </div> 
  //   </form> 
  //   </div> 
  //   </div>` 
 
  //   // let dialog: Dialog = new Dialog({
  //   this.dialog = new Dialog({

  //     header: title, 
  //     target: document.getElementById('target'), 
  //     content: dialogContent, 
  //     animationSettings: { 
  //         effect: 'None' 
  //     }, 
  //     buttons: [{ 
  //         'click': () => 
  //         {
  //           let user: string = tb_UserName.value; 
  //           let pswd: string = tb_PassWord.value; 
  //           //console.log('UserName: ' + user + ' Password: ' + pswd); 

  //           this.wsSubscription = this.wsServiceComm.createObservableSocket(this.url_commServer, this.cmd_sessionOpen)
  //           .subscribe(
  //               data=>this.handleCommMessage(data),
  //               err=>alert('err: LoginDialog Subscribe'),
  //             ()=>
  //             {                
  //               console.log('The Login Subscription Is Complete'); }
  //           );
          
  //           this.dialog.destroy();
  //         },

  //         buttonModel: 
  //         { 
  //             content: 'Login', 
  //             isPrimary: true, 
  //             cssClass: 'e-outline'

  //         } 
  //     }], 
  //     showCloseIcon: true, 
  //     width: '500px', 
  //     open: onDialogOpen, 
  //     close: onDialogClose, 
  //     created: onDialogCreate
  //   }); 
  //   this.dialog.appendTo('#dialog'); 
  
  //   function onDialogCreate(args) 
  //   {
  //     //alert("Executing onDialogCreate()");
  
  //     tb_UserName = new TextBox({ 
  //         placeholder: 'User Name', 
  //         floatLabelType: 'Always' 
  //     }); 
  //     tb_UserName.appendTo('#username'); 
  
  //     tb_PassWord = new TextBox({ 
  //         placeholder: 'Password', 
  //         floatLabelType: 'Always', 
  //         type: 'password' 
  //     });     
  //     tb_PassWord.appendTo('#password');    
  //   } 

  //   function onDialogOpen()
  //   {
  //     //alert("Executing onDialogOpen()");
  //   }

  //   function onDialogClose()
  //   {
  //     //alert("Executing onDialogClose()");
  //     this.dialog.destroy();  
  //   }
  // }

  // handleCommMessage(msg: string)
  // {
  //   //alert("handleCommMessage: " + msg);
  //   console.log(msg)
  //   if( msg == "ping")
  //   {
  //     // Ignore.
  //     return;
  //   }
  //   else if( msg == "pong")
  //   {
  //     // Ignore.
  //     return;
  //   }
  //   else if( msg.startsWith("-S") )
  //   {
  //     this.sessionId = msg.slice(1);
  //     //alert("this.sessionId: " + this.sessionId);

  //     this.closeSocket();

  //     // TODO:
  //     // Navigate to TreeView here.
  //     //this.router.navigateByUrl('/terminal');
  //     this.router.navigate(['/treeview', this.sessionId]);

  //     return;
  //   }
  //   else if( msg.startsWith("??"))
  //   {
  //     // Display the error.
  //     var err = msg.slice(2);
  //     alert("ERROR: " + err);
  //     return;
  //   }  
  // }



}
