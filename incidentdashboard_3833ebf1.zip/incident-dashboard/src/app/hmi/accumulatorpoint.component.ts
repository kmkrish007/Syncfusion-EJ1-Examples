import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';
import { Config } from '../config/config';


export class AccumulatorPointComponent extends DevicePointComponent{

    private text_type = AccumulatorPointComponent.POINT_TYPE_ACCUMULATOR;

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_COLOR_NORMAL: string = "darkmagenta";

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_FILLCOLOR: string = "black";
    public static DEFAULT_BORDERCOLOR: string = "red";
    public static DEFAULT_TEXTCOLOR: string = "black";
    public static DEFAULT_DISPLAYTEXT: string = "";
    public static DEFAULT_FONTFAMILY: string = "Arial";
    public static DEFAULT_FONTSIZE: number = 50;
    public static DEFAULT_PRECISION: number = 0;

    // Configurable when point mapped to symbol on map.
    protected normalColor: string = AccumulatorPointComponent.DEFAULT_COLOR_NORMAL;

    //protected borderColor: string = AccumulatorPointComponent.DEFAULT_BORDERCOLOR;
    //protected fillColor: string = AccumulatorPointComponent.DEFAULT_FILLCOLOR;
    //protected displayText: string = AccumulatorPointComponent.DEFAULT_DISPLAYTEXT;
    //protected fontFamily: string = AccumulatorPointComponent.DEFAULT_FONTFAMILY;
    //protected fontSize: number = AccumulatorPointComponent.DEFAULT_FONTSIZE;
    //protected textColor: string = AccumulatorPointComponent.DEFAULT_TEXTCOLOR;

    //protected failedColor: string = DevicePointComponent.DEFAULT_COLOR_FAILED;
    //protected forcedColor: string = DevicePointComponent.DEFAULT_COLOR_FORCED;

    protected precision: number = AccumulatorPointComponent.DEFAULT_PRECISION;
    protected forced: number = 0;

    constructor(
        protected deviceType: string,
        protected deviceName: string,
        protected sn: number,
        protected ied: number,
        protected pointid: string,
        protected pointname: string,
        protected units: number
    ) 
    {
        super(deviceType, deviceName, sn, ied, pointid, pointname, units);

        this.borderColor = AccumulatorPointComponent.DEFAULT_BORDERCOLOR;
        this.fillColor = AccumulatorPointComponent.DEFAULT_FILLCOLOR;
        this.displayText = AccumulatorPointComponent.DEFAULT_DISPLAYTEXT;
        this.fontFamily = AccumulatorPointComponent.DEFAULT_FONTFAMILY;
        this.fontSize = AccumulatorPointComponent.DEFAULT_FONTSIZE;
        this.textColor = AccumulatorPointComponent.DEFAULT_TEXTCOLOR;

        this.Init(Config.configdata);
    }

    public Init(config: Array <any>)
    {
        this.ApplyConfig(config);
    }

    protected ApplyConfig(config: Array <any>)
    {
      if( ! config )
      {
          return;
      }

      super.ApplyConfig(config);

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_ACCUM)
        {
          if( item.name == "normal text color")
          {
              this.normalColor = item.value;
          }          
          else if( item.name == "precision")
          {
              this.precision = parseInt(item.value);
          }
          else if( item.name == "font size")
          {
              this.fontSize = parseInt(item.value);
          }
          else if( item.name == "font family")
          {
              this.fontFamily = item.value;
          }          
          else if( item.name == "border color")
          {
              this.borderColor = item.value;
          }          
        }
      }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_ACCUM)
        {
          if( item.name == "normal text color")
          {
              AccumulatorPointComponent.DEFAULT_COLOR_NORMAL = item.default;
          }
          else if( item.name == "precision")
          {
              AccumulatorPointComponent.DEFAULT_PRECISION = parseInt(item.default);
          }
          else if( item.name == "font size")
          {
            AccumulatorPointComponent.DEFAULT_FONTSIZE = parseInt(item.default);
          }
          else if( item.name == "font family")
          {
            AccumulatorPointComponent.DEFAULT_FONTFAMILY = item.default;
          }          
          else if( item.name == "border color")
          {
              AccumulatorPointComponent.DEFAULT_BORDERCOLOR = item.default;
          }          
        }
      }
    }
  

      public deserialize(obj:any)
      {
          //debugger
          this.borderColor = obj.devicePoint.borderColor;
          this.fillColor = obj.devicePoint.fillColor;
          this.displayText = obj.devicePoint.displayText;
          this.fontFamily = obj.devicePoint.fontFamily;
          this.fontSize = obj.devicePoint.fontSize;
          this.textColor = obj.devicePoint.textColor;
          this.normalColor = obj.devicePoint.normalColor;
          this.setTextColor();
      }

      // public GetFontString(): string
      // {
      //     return this.fontSize + "px" + this.fontFamily;
      // }

      public setForced(val: number)
      {
          console.log("AccumulatorPointComponent.setForced() for val: " + val);
          this.forced = val;
      }

      public getForced(): number
      {
          console.log("AccumulatorPointComponent.getForced() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
          return this.forced;
      }

      // public getTextColor(): string
      // {
      // //console.log("DevicePointComponent.getTextColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
      // return this.textColor;
      // }
  

      public setTextColor()
      {
        //debugger

        // TODO: TEST ONLY.
        //this.setFailed(1);
        //this.setForced(1);

        // console.log("AnalogPointComponent.getFillColor() for: " + 
        //               this.getSN() + ":" + 
        //               this.getIed() + "-" + 
        //               this.getPointId());
        if( this.getFailed() )
        {
          // Failed Point.
          //console.log("Returning LOW LIMIT COLOR.");
          this.textColor = this.failedColor;
        }
        else if( this.getForced() )
        {
          // Forced Point.
          console.log("Returning FORCED COLOR: " + this.forcedColor + " For Pt: " + this.getExtName());
          this.textColor = this.forcedColor;
        }
        else
        {
          // Normal Limit.
          //console.log("Returning NORMAL LIMIT COLOR.");
          this.textColor = this.normalColor;
        }
      }


      public getFillColor(): string
      {
          // Normal.
          //return AccumulatorPointComponent.COLOR_NORMAL;
          return this.fillColor;
      }

      public getDisplayText(): string
      {
        //console.log("AccumulatorPointComponent.getDisplayText() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
       //return this.value.toString();

       let tag:string = "";

       if( this.getFailed() )
       {
           tag = "Failed";
       }
       if( this.getForced() )
       {
           tag = "Forced";
       }

       let txt = this.value.toString();

       if( tag.length > 0 )
       {
           txt += " " + tag;
       }

       return txt;        

      }


      public LoadProperties(propdata: { [key: string]: Object }[])
      {
        //debugger
        console.log("Executing AnalogPointComponent.LoadProperties().");

        // Load the property array with point properties.
        let item:any = {name: "type", value: this.getPointType()};
        propdata.push(item);

        item = {name: "ext name", value: this.getExtName()};
        propdata.push(item);
        item = {name: "sn", value: this.getSN()};
        propdata.push(item);
        item = {name: "ied", value: this.getIed()};
        propdata.push(item);
        item = {name: "pt", value: this.getPointId()};
        propdata.push(item);
        item = {name: "pid", value: this.getPid()};
        propdata.push(item);

        item = {name: "units", value: this.getUnits()};
        propdata.push(item);
        // item = {name: "scale", value: this.getScale()};
        // propdata.push(item);
        // item = {name: "offset", value: this.getOffset()};
        // propdata.push(item);
        // item = {name: "high", value: this.getHighLimit()};
        // propdata.push(item);
        // item = {name: "low", value: this.getLowLimit()};
        // propdata.push(item);

        item = {name: "normal color", value: this.normalColor};
        propdata.push(item);
        item = {name: "failed color", value: this.failedColor};
        propdata.push(item);
        item = {name: "forced color", value: this.forcedColor};
        propdata.push(item);

        item = {name: "bordercolor", value: this.borderColor};
        propdata.push(item);
        item = {name: "fontfamily", value: this.fontFamily};
        propdata.push(item);
        item = {name: "fontsize", value: this.fontSize};
        propdata.push(item);
        item = {name: "text color", value: this.textColor};
        propdata.push(item);
      }


      public saveProperty(name: string, value: string): boolean
      {
          console.log("Executing AccumulatorPointComponent.SaveProperty().");

          //debugger
          if( name == "normal color")
          {
              //debugger
              this.normalColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "failed color")
          {
              //debugger
              this.failedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "forced color")
          {
              //debugger
              this.forcedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "bordercolor")
          {
              this.borderColor = value;
              return true;
          }
          // else if( name == "fillcolor")
          // {
          //     this.fillColor = value;
          //     return true;
          // }
          else if( name == "fontsize")
          {
              this.fontSize = parseInt(value);
              return true;
          }
          else if( name == "fontfamily")
          {
              this.fontFamily = value;
              return true;
          }
          // else if( name == "text color")
          // {
          //     this.textColor = value;
          //     return true;
          // }
  
          //super.saveProperty(name, value);
          return false;
      } 

      public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
      {
        console.log("Executing AccumulatorPointComponent.LoadDefaultProperties().");

        let item:any = {name: "type", value: AccumulatorPointComponent.POINT_TYPE_ACCUMULATOR};
        propdata.push(item);

        // Load the property array with point properties.
        item = {name: "bordercolor", value: AccumulatorPointComponent.DEFAULT_BORDERCOLOR};
        propdata.push(item);
        item = {name: "fillcolor", value: AccumulatorPointComponent.DEFAULT_FILLCOLOR};
        propdata.push(item);
        item = {name: "displayText", value: AccumulatorPointComponent.DEFAULT_DISPLAYTEXT};
        propdata.push(item);
        item = {name: "fontFamily", value: AccumulatorPointComponent.DEFAULT_FONTFAMILY};
        propdata.push(item);
        item = {name: "fontSize", value: AccumulatorPointComponent.DEFAULT_FONTSIZE};
        propdata.push(item);
        item = {name: "text color", value: AccumulatorPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        
        //super.LoadDefaultProperties(propdata);
      }

      
      public static saveDefaultProperty(name: string, value: string)
      {
          console.log("Executing AccumulatorPointComponent.SaveDefaultProperty().");
      
          if( name == "bordercolor")
          {
              AccumulatorPointComponent.DEFAULT_BORDERCOLOR = value;
          }
          else if( name == "fillcolor")
          {
            AccumulatorPointComponent.DEFAULT_FILLCOLOR = value;
          }
          else if( name == "displayText")
          {
            AccumulatorPointComponent.DEFAULT_DISPLAYTEXT = value;
          }
          else if( name == "fontFamily")
          {
            AccumulatorPointComponent.DEFAULT_FONTFAMILY = value;
          }
          else if( name == "fontSize")
          {
            AccumulatorPointComponent.DEFAULT_FONTSIZE = parseInt(value);
          }
          else if( name == "text color")
          {
            AccumulatorPointComponent.DEFAULT_TEXTCOLOR = value;
          }
      }

      public AdjustProperties(): boolean
      {
        //debugger
        //console.log("Executing AccumulatorPointComponent.AdjustProperties() for: " + this.getExtName())
          //this.fontSize = 20;
          this.borderColor = "black";
          this.fillColor = "black";
          this.setTextColor();

          return true;
      }

  
  


  


  

 
 
}