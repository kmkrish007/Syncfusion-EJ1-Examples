import { Grid, Edit, Column, Toolbar} from '@syncfusion/ej2-grids';
import { ColorPicker, ColorPickerEventArgs} from '@syncfusion/ej2-inputs';
import { Dialog } from '@syncfusion/ej2-popups';
import {isNullOrUndefined } from 'util';

import {ShapeComponent} from './shape.component';
import {RectangleComponent} from './rectangle.component';
import {CircleComponent} from './circle.component';
import {LineComponent} from './line.component';
import {TextComponent} from './text.component';
import {DrawingBoardComponent} from './drawingboard.component';

export class PropGridComponent 
{

    private propgrid: Grid = null;
    public dialog: Dialog = null;

    public propdata_toolbox: { [key: string]: Object }[] = []; 

    private elem: HTMLElement = null;
    private colorPickerObj: ColorPicker = null;
    private rowData: object = null;

    private parent: DrawingBoardComponent = null; 
  
    constructor(dbc: DrawingBoardComponent)
    {
        console.log("Executing PropGridComponent.CreateGrid()");

        this.parent = dbc;
        this.CreateGrid();
    }

    private CreateGrid()
    {
        console.log("Executing PropGridComponent.CreateGrid()");

        this.propgrid = new Grid({
            dataSource: this.propdata_toolbox,
            editSettings: { allowEditing: true,  mode: 'Normal'},
            allowSorting: false,
            allowSelection: true,
            gridLines: 'Both',
            enableHover: true,
            selectionSettings: {type: 'Single', mode: 'Row'},
            enableVirtualization: false,
            allowPaging: false,
            toolbar: ['Edit', 'Update', 'Cancel'],
            actionBegin: this.propGridToolbox_actionBegin.bind(this),
            rowHeight: 13,
            columns: [
                { field: 'name', headerText: 'Property', textAlign: 'Right', width: 125, isPrimaryKey: true, isIdentity: true },
                {
                    field: 'value', headerText: 'Value', width: 125, edit: 
                    {
                        create: () => 
                        {
                            this.elem = document.createElement('input');
                            return this.elem;
                        },
                        read: (args: any) => 
                        {
                        if(!isNullOrUndefined(this.colorPickerObj)) 
                        {
                            return this.colorPickerObj.value;
                        } 
                        else 
                        {
                            return args.value;
                        }
                        },
                        destroy: () => 
                        {
                        if(!isNullOrUndefined(this.colorPickerObj)) 
                        {
                            this.colorPickerObj.destroy();
                            this.colorPickerObj = null;
                        }
                        },
                        write: (args: { rowData: object, column: Column, element: HTMLElement }) => 
                        {
                            this.rowData = args.rowData;
                            if ( args.rowData["name"] == "bordercolor" || 
                                args.rowData["name"] == "fillcolor" ||
                                args.rowData["name"] == "oncolor"  ||
                                args.rowData["name"] == "offcolor" ||
                                args.rowData["name"] == "failed color" ||
                                args.rowData["name"] == "forced color" ||
                                //args.rowData["name"] == "text color" ||
                                args.rowData["name"] == "high color" ||
                                args.rowData["name"] == "normal color" ||
                                args.rowData["name"] == "low color" ||
                                args.rowData["name"] == "on text color" ||
                                args.rowData["name"] == "off text color" ) 
                            {
                                this.colorPickerObj = new ColorPicker({
                                value: args.rowData["value"],
                                mode: 'Palette',
                                modeSwitcher: false
                                });
                                this.colorPickerObj.appendTo(this.elem);                    
                            } 
                            else 
                            {
                                args.element["value"] = args.rowData["value"];
                            }
                        }
                    },
                }
                ],
            });
    
    }

    // Creates the dialog.
    public CreatePropGridDialog(show:boolean)
    {
        console.log("Executing PropGridComponent.ShowTBPropGridDialog()");

        //debugger
        let dialogContent: string = `<form id='PropGridForm'> 
            <div id="gridelement"></div>
        </form>` 

        this.dialog = new Dialog(
        { 
            header: 'HMI Property Grid Dialog', 
            target: document.getElementById('target'), 
            content: dialogContent,
            allowDragging: true,
            visible: show, 
            animationSettings: 
            { 
                effect: 'None' 
            }, 
            showCloseIcon: true, 
            width: '300px',
            height: '500px', 
            open: this.onDialogOpen,
            enableResize: true,
            position: {X: "right", Y:"bottom"},
            close: this.onDialogClose, 
            created: this.onDialogCreate.bind(this)
        }); 
        this.dialog.appendTo('#propdialog'); 
    }  


    // Dialog created Event callback.
    private onDialogCreate(args:any) 
    {
        //debugger
        console.log("Executing PropGridComponent.onDialogCreate()");
        this.propgrid.appendTo('#gridelement');            
    } 

    // Dialog opened event callback
    private onDialogOpen()
    {
        //debugger;
        console.log("Executing PropGridComponent.onDialogOpen()");
    
    }

    // Dialog closed event callback.
    private onDialogClose()
    {
        //debugger;
        console.log("Executing PropGridComponent.onDialogClose()");

        // if( this.propgrid != null )
        // {
        //     this.propgrid.destroy();
        // }

        // alert("Executing onDialogClose()");
        //this.tbdialog.destroy();  
    }

    // Destroy (called when drawing board exits).
    public Destroy()
    {
        //debugger;
        console.log("Executing PropGridComponent.Destroy()");

        if( this.propgrid != null )
        {
            this.propgrid.destroy();
        }

        this.dialog.destroy();  
    }
    

    // Callback when some property grid action begins.
    private propGridToolbox_actionBegin(args: any): void 
    {
        
        console.log("Executing PropGridComponent.propGridToolbox_actionBegin callback.");
        if( args.requestType == 'beginEdit' )
        {
            debugger
            if( args.rowData.name == "type" ||
                args.rowData.name == "ext name"||
                args.rowData.name == "sn"||
                args.rowData.name == "ied"||
                args.rowData.name == "pt"||
                args.rowData.name == "pid"||
                args.rowData.name == "on text"||
                args.rowData.name == "off text" ||
                args.rowData.name == "units"||
                args.rowData.name == "scale"||
                args.rowData.name == "offset"||
                args.rowData.name == "high"||
                args.rowData.name == "low" ||
                args.rowData.name == "start angle"||
                args.rowData.name == "end angle"||
                args.rowData.name == "counter clockwise" ||
                args.rowData.name == "startpoint x"||
                args.rowData.name == "startpoint y"||
                args.rowData.name == "endpoint x"||
                args.rowData.name == "endpoint y"||
                args.rowData.name == "font string" ||
                args.rowData.name == "text color" )
                
            {
                args.cancel = true;
                return;
            }
        }
        else if (args.requestType === 'save') 
        {
            //debugger
            console.log("propGridToolbox_actionBegin requestType = save.");
        
            let prop:any = args.data;
            let name:string = prop.name;
            let value: string = prop.value;


            if( this.parent == null )
            {
                console.log("PropGridComponent.propGridToolbox_actionBegin() - NULL Parent Object.");
                return;
            }
        
            // Save changed propdata to data in appropriate component.
            if( this.parent.selectedShape != null)
            {
                // Save changed property to the device point.      
                // let prop:any = args.data;
                // let name:string = prop.name;
                // let value: string = prop.value;
                this.parent.selectedShape.saveProperty(name, value);
                this.parent.selectedShape.drawBR = true;
                //this.parent.invalid = true;
        
                // Save changed propdata to data in appropriate component.
                //debugger
                if( this.parent.selectedDevicePoint != null)
                {
                    // Save changed property to the device point.      
                    let prop:any = args.data;
                    let name:string = prop.name;
                    let value: string = prop.value;
                    this.parent.selectedDevicePoint.saveProperty(name, value);
                }
                this.parent.invalid = true;
            }
            else if( this.parent.id == "rectangle")
            {
                // Save Default Property.
                RectangleComponent.saveDefaultProperty(name, value);
            }
            else if( this.parent.id == "circle")
            {
                // Save Default Property.
                CircleComponent.saveDefaultProperty(name, value);
            }
            else if( this.parent.id == "line")
            {
                // Save Default Property.
                LineComponent.saveDefaultProperty(name, value);
            }
            else if( this.parent.id == "text")
            {
                // Save Default Property.
                TextComponent.saveDefaultProperty(name, value);
            }
            else
            {
                ShapeComponent.saveDefaultProperty(name, value);
            }    
        }
    }
  

    // Called to update or clear the property grid data store.
    public resetPropData_Toolbox()
    {
        console.log("Executing PropGridComponent.resetPropData_Toolbox().");

        if( this.propgrid == null )
        {
            console.log("PropGridComponent.resetPropData_Toolbox() - NULL propgrid - returning.")
            return;
        }

        this.propgrid.dataSource = [];
        this.propgrid.dataSource = this.propdata_toolbox;
    }

    // Called to update or clear the property grid data store.
    public resetPropGrid_Toolbox()
    {
        console.log("Executing PropGridComponent.resetPropGrid_Toolbox().");

        if( this.propgrid == null )
        {
            console.log("PropGridComponent.resetPropGrod_Toolbox() - NULL propgrid - returning.")
            return;
        }

        this.propgrid.dataSource = [];
        this.propgrid.dataSource = this.propdata_toolbox;
    }

    // public getPropGrid(): Grid
    // {
    //     return this.propgrid;
    // }

    // public setPropGrid(pg: Grid)
    // {
    //     this.propgrid = pg
    // }
}
