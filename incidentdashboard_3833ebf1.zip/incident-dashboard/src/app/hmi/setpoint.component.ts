import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';
import { Config } from '../config/config';

export class SetpointComponent extends DevicePointComponent{

    private text_type = DevicePointComponent.POINT_TYPE_SETPOINT;

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_COLOR_NORMAL: string = "darkmagenta";

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_FILLCOLOR: string = "black";
    public static DEFAULT_BORDERCOLOR: string = "red";
    public static DEFAULT_TEXTCOLOR: string = "black";
    public static DEFAULT_DISPLAYTEXT: string = "";
    public static DEFAULT_FONTFAMILY: string = "Arial";
    public static DEFAULT_FONTSIZE: number = 50;

    // Configurable when point mapped to symbol on map.
    protected normalColor: string = SetpointComponent.DEFAULT_COLOR_NORMAL;

    //protected borderColor: string = SetpointComponent.DEFAULT_BORDERCOLOR;
    //protected fillColor: string = SetpointComponent.DEFAULT_FILLCOLOR;
    //protected displayText: string = SetpointComponent.DEFAULT_DISPLAYTEXT;
    //protected fontFamily: string = SetpointComponent.DEFAULT_FONTFAMILY;
    //protected fontSize: number = SetpointComponent.DEFAULT_FONTSIZE;
    //protected textColor: string = SetpointComponent.DEFAULT_TEXTCOLOR;

    //protected failedColor: string = DevicePointComponent.DEFAULT_COLOR_FAILED;
    
    constructor(
        protected deviceType: string,
        protected deviceName: string,
        protected sn: number,
        protected ied: number,
        protected pointid: string,
        protected pointname: string,
        protected units: number
    ) 
    {
        super(deviceType, deviceName, sn, ied, pointid, pointname, units);

        this.borderColor = SetpointComponent.DEFAULT_BORDERCOLOR;
        this.fillColor = SetpointComponent.DEFAULT_FILLCOLOR;
        this.displayText = SetpointComponent.DEFAULT_DISPLAYTEXT;
        this.fontFamily = SetpointComponent.DEFAULT_FONTFAMILY;
        this.fontSize = SetpointComponent.DEFAULT_FONTSIZE;
        this.textColor = SetpointComponent.DEFAULT_TEXTCOLOR;

        this.Init(Config.configdata);
    }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
    }

    protected ApplyConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      super.ApplyConfig(config);

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SETPOINT)
        {
          if( item.name == "normal text color")
          {
              this.normalColor = item.value;
          }
          else if( item.name == "font size")
          {
              this.fontSize = parseInt(item.value);
          }
          else if( item.name == "font family")
          {
              this.fontFamily = item.value;
          }          
          else if( item.name == "border color")
          {
              this.borderColor = item.value;
          }          
        }
      }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_ACCUM)
        {
          if( item.name == "normal text color")
          {
            SetpointComponent.DEFAULT_COLOR_NORMAL = item.default;
          }
          else if( item.name == "font size")
          {
            SetpointComponent.DEFAULT_FONTSIZE = parseInt(item.default);
          }
          else if( item.name == "font family")
          {
            SetpointComponent.DEFAULT_FONTFAMILY = item.default;
          }          
          else if( item.name == "border color")
          {
            SetpointComponent.DEFAULT_BORDERCOLOR = item.default;
          }          
        }
      }
    }
        

    public deserialize(obj:any)
    {
        //debugger
        this.borderColor = obj.devicePoint.borderColor;
        this.fillColor = obj.devicePoint.fillColor;
        this.displayText = obj.devicePoint.displayText;
        this.fontFamily = obj.devicePoint.fontFamily;
        this.fontSize = obj.devicePoint.fontSize;
        this.textColor = obj.devicePoint.textColor;
        this.normalColor = obj.devicePoint.normalColor;
        this.setTextColor();
    }

    // public GetFontString(): string
    // {
    //     return this.fontSize + "px" + this.fontFamily;
    // }

    public setTextColor()
    {
      //debugger
      // TODO: TEST ONLY.
      //this.setFailed(1);

      //debugger
      // console.log("AnalogPointComponent.setTextColor() for: " + 
      //               this.getSN() + ":" + 
      //               this.getIed() + "-" + 
      //               this.getPointId());
      if( this.getFailed() )
      {
        // Failed Point.
        //console.log("Returning LOW FAILED COLOR.");
        this.textColor = this.failedColor;
      }
      else
      {
        // Normal.
        //console.log("Returning NORMAL COLOR.");
        this.textColor = this.normalColor;
      }
    }



    public getFillColor(): string
    {
        return this.fillColor;
    }

    public getDisplayText(): string
    {
      //console.log("SetpointComponent.getDisplayText() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
      //return this.value.toString();

      let tag:string = "";

      if( this.getFailed() )
      {
          tag = "Failed";
      }
      if( this.getForced() )
      {
          tag = "Forced";
      }

      let txt = this.value.toString();

      if( tag.length > 0 )
      {
          txt += " " + tag;
      }

      return txt;        
      //return this.value.toString();
    }

    public LoadProperties(propdata: { [key: string]: Object }[])
    {
      //debugger
      console.log("Executing AnalogPointComponent.LoadProperties().");

      // Load the property array with point properties.
      let item:any = {name: "type", value: this.getPointType()};
      propdata.push(item);

      item = {name: "ext name", value: this.getExtName()};
      propdata.push(item);
      item = {name: "sn", value: this.getSN()};
      propdata.push(item);
      item = {name: "ied", value: this.getIed()};
      propdata.push(item);
      item = {name: "pt", value: this.getPointId()};
      propdata.push(item);
      item = {name: "pid", value: this.getPid()};
      propdata.push(item);

      item = {name: "units", value: this.getUnits()};
      propdata.push(item);
      // item = {name: "scale", value: this.getScale()};
      // propdata.push(item);
      // item = {name: "offset", value: this.getOffset()};
      // propdata.push(item);
      // item = {name: "high", value: this.getHighLimit()};
      // propdata.push(item);
      // item = {name: "low", value: this.getLowLimit()};
      // propdata.push(item);

      item = {name: "normal color", value: this.normalColor};
      propdata.push(item);
      item = {name: "failed color", value: this.failedColor};
      propdata.push(item);

      item = {name: "bordercolor", value: this.borderColor};
      propdata.push(item);
      item = {name: "fontfamily", value: this.fontFamily};
      propdata.push(item);
      item = {name: "fontsize", value: this.fontSize};
      propdata.push(item);
      item = {name: "text color", value: this.textColor};
      propdata.push(item);
    }
    
    public saveProperty(name: string, value: string): boolean
    {
        console.log("Executing AnalogPointComponent.SaveProperty().");

        if( name == "normal color")
        {
            //debugger
            this.normalColor = value;
            this.setTextColor();
            return true;
        }
        else if( name == "failed color")
        {
            //debugger
            this.failedColor = value;
            this.setTextColor();
            return true;
        }
        else if( name == "fontsize")
        {
            this.fontSize = parseInt(value);
            return true;
        }
        else if( name == "fontfamily")
        {
            this.fontFamily = value;
            return true;
        }

        return false;
    }


    public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
    {
      console.log("Executing SetpointComponent.LoadDefaultProperties().");

      let item:any = {name: "type", value: SetpointComponent.POINT_TYPE_SETPOINT};
      propdata.push(item);

      // Load the property array with point properties.
      item = {name: "bordercolor", value: SetpointComponent.DEFAULT_BORDERCOLOR};
      propdata.push(item);
      item = {name: "fillcolor", value: SetpointComponent.DEFAULT_FILLCOLOR};
      propdata.push(item);
      item = {name: "displayText", value: SetpointComponent.DEFAULT_DISPLAYTEXT};
      propdata.push(item);
      item = {name: "fontFamily", value: SetpointComponent.DEFAULT_FONTFAMILY};
      propdata.push(item);
      item = {name: "fontSize", value: SetpointComponent.DEFAULT_FONTSIZE};
      propdata.push(item);
      item = {name: "text color", value: SetpointComponent.DEFAULT_TEXTCOLOR};
      propdata.push(item);    

      //super.LoadDefaultProperties(propdata);
    }


    public static saveDefaultProperty(name: string, value: string)
    {
        console.log("Executing SetpointComponent.SaveDefaultProperty().");
    
        if( name == "bordercolor")
        {
          SetpointComponent.DEFAULT_BORDERCOLOR = value;
        }
        else if( name == "fillcolor")
        {
          SetpointComponent.DEFAULT_FILLCOLOR = value;
        }
        else if( name == "displayText")
        {
          SetpointComponent.DEFAULT_DISPLAYTEXT = value;
        }
        else if( name == "fontFamily")
        {
          SetpointComponent.DEFAULT_FONTFAMILY = value;
        }
        else if( name == "fontSize")
        {
          SetpointComponent.DEFAULT_FONTSIZE = parseInt(value);
        }
        else if( name == "text color")
        {
          SetpointComponent.DEFAULT_TEXTCOLOR = value;
        }
    }

    public AdjustProperties(): boolean
    {
        //this.fontSize = 20;
        this.borderColor = "black";
        this.fillColor = "black";
        this.setTextColor();

        return true;
    }

 
}