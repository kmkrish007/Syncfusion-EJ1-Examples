import {ShapeComponent} from './shape.component';
import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';

export class RectangleComponent extends ShapeComponent{

  protected type = ShapeComponent.SYMBOL_TYPE_RECTANGLE;

  // Default fields.
  public static DEFAULT_COLOR_BORDER: string = "red";
  public static DEFAULT_COLOR_FILL: string = "green";
  public static DEFAULT_HEIGHT = 25;
  public static DEFAULT_WIDTH = 25;

  private static MIN_HEIGHT = 25;
  private static MIN_WIDTH = 25;

  // Override fields.
  protected borderColor:string = RectangleComponent.DEFAULT_COLOR_BORDER;
  protected fillColor:string = RectangleComponent.DEFAULT_COLOR_FILL;

  protected width:number = RectangleComponent.DEFAULT_WIDTH;
  protected height:number = RectangleComponent.DEFAULT_HEIGHT;

  constructor(
      protected x: number,
      protected y: number
  ) 
  { 
    super(x,y);
  }

  public Init(config: Array<any>)
  {
      this.ApplyConfig(config);
  }
    
  protected ApplyConfig(config: Array<any>)
  {
    //debugger

    if( ! config )
    {
        return;
    }
    
    super.ApplyConfig(config);

    for( let i:number=0;i<config.length; ++i )
    {
      let item: any = config[i];
      if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_RECT)
      {
        if( item.name == "border color")
        {
          this.setBorderColor(item.value);
        }
        else if( item.name == "fill color")
        {
          this.setFillColor(item.value);
        }
        else if( item.name == "height")
        {
          this.height = parseInt(item.value);
        }
        else if( item.name == "width")
        {
          this.width = parseInt(item.value);
        }
      }
    }

    if( this.devicePoint )
    {
         this.devicePoint.Init(config);
    }

  }

  public static ApplyDefaultConfig(config: Array<any>)
  {
    if( ! config )
    {
        return;
    }

    for( let i:number=0;i>config.length; ++i )
    {
      let item: any = config[i];
      if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_RECT)
      {
        if( item.name == "border color")
        {
          RectangleComponent.DEFAULT_COLOR_BORDER = item.default;
        }
        else if( item.name == "fill color")
        {
          RectangleComponent.DEFAULT_COLOR_FILL = item.default;
        }
        else if( item.name == "height")
        {
          RectangleComponent.DEFAULT_HEIGHT = parseInt(item.default);
        }
        else if( item.name == "width")
        {
          RectangleComponent.DEFAULT_WIDTH = parseInt(item.default);
        }
      }
    }
  }

  public setHeight(val:number)
  {
    this.height = val;
  }

  public setWidth(val:number)
  {
    this.width = val;
  }



  public getType(): string
  {
        return this.type;
  }
 
  public deserialize(obj:any)
  {
    //debugger
    this.dragging = obj.dragging;
    this.dragTL = obj.dragTL;
    this.dragTR = obj.dragTR;
    this.dragBL = obj.dragBL;
    this.dragBR = obj.dragBR;
    this.closeEnough = obj.closeEnough;
    this.displayText = obj.displayText;
    this.borderColor = obj.borderColor;
    this.fillColor = obj.fillColor;
  }

  protected GetDefaultConfig()
  {

  }

  protected GetConfig()
  {

  }
      
  public draw( ctx: CanvasRenderingContext2D )
  {
    console.log("Executing RectangleComponent.draw()");

    if( this.height < RectangleComponent.MIN_HEIGHT )
    {
      this.height = RectangleComponent.MIN_HEIGHT;
    }
    if( this.width < RectangleComponent.MIN_WIDTH )
    {
      this.width = RectangleComponent.MIN_WIDTH;
    }

    ctx.beginPath();

    // Draw Border.
    ctx.lineWidth = 3;
    ctx.strokeStyle = this.getBorderColor();
    ctx.rect( this.x, this.y, this.width, this.height);
    ctx.stroke();

    // Draw Fill
    ctx.fillStyle = this.getFillColor();
    ctx.fill();

    // Draw Display Text (e.g. value).
    //ctx.font = "50px Arial";
    ctx.font = this.getFontString();
    let txt: string = this.getDisplayText();
    //ctx.fillStyle = "black";
    ctx.fillStyle = this.getTextColor();
    let x:number = this.x + this.width/2 - ctx.measureText(txt).width/2;
    let y:number = this.y + this.height/2;
    ctx.fillText(this.getDisplayText(), x, y);

    ctx.closePath();

  }


  public drawBoundedRect( ctx: CanvasRenderingContext2D )
  {
    ctx.beginPath();
    // Draw Border.
    ctx.strokeStyle = "pink";
    ctx.lineWidth = 1;
    ctx.setLineDash([1, 2]);
    ctx.rect( this.x-10, this.y-10, this.width+20, this.height+20);
    ctx.stroke();
    ctx.closePath();
  }

   public isSelected(pos_x: number, pos_y: number): boolean
   {
      //  console.log("Executing RectangleComponent.isSelected() for x: " + pos_x + "  y:" + pos_y);
       console.log("RectangleComponent.isSelected() for x: " + this.x + "  y: " + this.y + " pos_x: " + pos_x + "  + pos_y: " + pos_y );

        // Make sure the given position's [x,y] coordinates 
        // fall within this shape's bounding rectangle.
        if ( (this.x <= pos_x) && 
             (this.x + this.width >= pos_x) &&
             (this.y <= pos_y) && 
             (this.y + this.height >= pos_y))
        {
          console.log("Rectangle Selected.");
          this.checkForResizing(pos_x, pos_y);
          return true;
        }

        return false;
   }

   checkForResizing(pos_x: number, pos_y: number) 
   {
     console.log("Executing RectangleComponent.checkForResizing() for x: " + pos_x + "  y:" + pos_y);

     this.initDraggingStates();

     if( this.devicePoint )
     {
        if( this.devicePoint.getPointType() == DevicePointComponent.POINT_TYPE_ANALOG || 
            this.devicePoint.getPointType() == DevicePointComponent.POINT_TYPE_ACCUMULATOR ||
            this.devicePoint.getPointType() == DevicePointComponent.POINT_TYPE_SETPOINT )
        {
          this.dragging = true;
          console.log("Rectangle.checkForResizing() - Disable resizing/dragging enabled for point type: " + this.devicePoint.getPointType());
          return;
        }
      }

     if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Left corner.
          this.dragTL = true;
          console.log("dragTL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.width) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Right corner.
          this.dragTR = true;
          console.log("dragTR = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y + this.height) )
     {
          // Dragging Bottom-Left corner.
          this.dragBL = true;
          console.log("dragBL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.width) && this.isCloseEnough(pos_y, this.y + this.height) )
     {
          // Dragging Bottom-Right corner.
          this.dragBR = true;
          console.log("dragBR = true");
     }
     else
     {
          // Dragging entire symbol.
          this.dragging = true;
          console.log("dragging = true");
     }
   }


   public resizeTL(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeTL() for x: " + pos_x + "  y: " + pos_y);

     if( pos_y < this.y)
     {
       this.height += (this.y - pos_y);
       this.y = pos_y;
     }
     else if( pos_y > this.y )
     {
       this.height -= (pos_y - this.y);
       this.y = pos_y;
     }

     if( pos_x < this.x)
     {
       this.width += (this.x - pos_x);
       this.x = pos_x;
     }
     else if( pos_x > this.x )
     {
       this.width -= (pos_x - this.x);
       this.x = pos_x;
     }
   }

   public resizeTR(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeTR() for x: " + pos_x + "  y: " + pos_y);

     if( pos_y < this.y )
     {
       this.height += (this.y - pos_y);
       this.y = pos_y;
     }
     else if( pos_y > this.y )
     {
       this.height -= (pos_y - this.y);
       this.y = pos_y;
     }

     if( pos_x < this.x + this.width)
     {
       this.width -= ((this.x + this.width) - pos_x);
     }
     else if( pos_x > this.x + this.width)
     {
       this.width += ((pos_x + this.width) - this.x);
     }
   }

   public resizeBL(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeBL() for x: " + pos_x + "  y: " + pos_y);

    if( pos_y > this.y + this.height)
    {
      this.height += (pos_y - (this.y + this.height));
    }
    else if( pos_y < this.y + this.height )
    {
      this.height -= ((this.y + this.height) - pos_y);
    }

    if( pos_x < this.x)
    {
      this.width += (this.x - pos_x);
      this.x = pos_x;
    }
    else if( pos_x > this.x )
    {
      this.width -= (pos_x - this.x);
      this.x = pos_x;
    }
   }

   public resizeBR(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeBR() for x: " + pos_x + "  y: " + pos_y);

    if( pos_y > this.y + this.height)
    {
      this.height += (pos_y - (this.y + this.height));
    }
    else if( pos_y < this.y + this.height )
    {
      this.height -= ((this.y + this.height) - pos_y);
    }

    if( pos_x < this.x + this.width)
    {
      this.width -= ((this.x + this.width) - pos_x);
    }
    else if( pos_x > this.x + this.width)
    {
      this.width += (pos_x - (this.x + this.width));
    }
   }

   public calcXY(x:number, y:number)
   {
     let offsetX = x-this.x;
     let offsetY = y-this.y;
     this.updateXY(x-offsetX, y-offsetY);
    //  let x:number = x-offsetX;
    //  let y:number = y-offsetY;
   }

   protected getFillColor(): string
   {
     if( this.devicePoint == null)
     {
         return this.fillColor;
     }
     return this.devicePoint.getFillColor();
   }

   protected getBorderColor(): string
   {
     if( this.devicePoint == null )
     {
         return this.borderColor;
     }
     else
     {
         return this.devicePoint.getBorderColor();
     }
   }

   protected setBorderColor(val: string)
   {
     this.borderColor = val;
   }

   protected setFillColor(val: string)
   {
     this.fillColor = val;
   }

   protected getFontString(): string
   {
     debugger
     if( this.devicePoint == null )
     {
       console.log("ShapeComponent.getFontString(): " + DevicePointComponent.GetFontString());
       return DevicePointComponent.GetFontString();
     }
     else
     {
       console.log("ShapeComponent.getFontString(): " + this.devicePoint.getFontString());
       return this.devicePoint.getFontString();
     }
   }



public LoadProperties(propdata: { [key: string]: Object }[])
{
  console.log("Executing RectangleComponent.LoadProperties().");

  // Load the property array with symbol properties.

  // TODO:  Make this property non-editable in grid.
  let item:any = {name: "type", value: this.type};
  propdata.push(item);

  item = {name: "x", value: this.x};
  propdata.push(item);
  item = {name: "y", value: this.y};
  propdata.push(item);
  item = {name: "width", value: this.width};
  propdata.push(item);
  item = {name: "height", value: this.height};
  propdata.push(item);

  
  if( this.devicePoint != null )
  {
    //item = {name: "", value: ""};
    //propdata.push(item);

    this.devicePoint.LoadProperties(propdata);
  }
  else
  {
    // Load the property array with symbol properties.
    //let item:any = {name: "bordercolor", value: this.borderColor};
    //propdata.push(item);
    item = {name: "fillcolor", value: this.fillColor};
    propdata.push(item);
    item = {name: "bordercolor", value: this.borderColor};
    propdata.push(item);
  }
}

public saveProperty(name: string, value: string): boolean
{
    console.log("Executing RectangleComponent.SaveProperty().");
    
    if( name == "bordercolor")
    {
        this.borderColor = value;
        return true;
    }
    else if( name == "fillcolor")
    {
        this.fillColor = value;
        return true;
    }
    else if( name == "x")
    {
        this.x = parseInt(value);
        return true;
    }
    else if( name == "y")
    {
        this.y = parseInt(value);
        return true;
    }
    else if( name == "width")
    {
        this.width = parseInt(value);
        return true;
    }
    else if( name == "height")
    {
        this.height = parseInt(value);
        return true;
    }

    //super.saveProperty(name, value);

    return false;
} 


public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
{
  console.log("Executing RectangleComponent.LoadDefaultProperties().");

  let item:any = {name: "type", value: ShapeComponent.SYMBOL_TYPE_RECTANGLE};
  propdata.push(item);

  item = {name: "bordercolor", value: RectangleComponent.DEFAULT_COLOR_BORDER};
  propdata.push(item);
  item = {name: "fillcolor", value: RectangleComponent.DEFAULT_COLOR_FILL};
  propdata.push(item);
  item = {name: "width", value: RectangleComponent.DEFAULT_WIDTH};
  propdata.push(item);
  item = {name: "height", value: RectangleComponent.DEFAULT_HEIGHT};
  propdata.push(item);

  //super.LoadDefaultProperties(propdata);
}


public static saveDefaultProperty(name: string, value: string)
{
     console.log("Executing RectangleComponent.SaveDefaultProperty().");

     if( name == "bordercolor")
     {
         RectangleComponent.DEFAULT_COLOR_BORDER = value;
     }
     else if( name == "fillcolor")
     {
         RectangleComponent.DEFAULT_COLOR_FILL = value;
     }
     else if( name == "width")
     {
         RectangleComponent.DEFAULT_WIDTH = parseInt(value);
     }
     else if( name == "height")
     {
         RectangleComponent.DEFAULT_HEIGHT = parseInt(value);
     }
      
     //super.saveDefaultProperty(name, value);
}


public AdjustProperties(): boolean
{
  this.height = RectangleComponent.DEFAULT_HEIGHT;
  this.width = RectangleComponent.DEFAULT_WIDTH;

  return true;
}



 
}