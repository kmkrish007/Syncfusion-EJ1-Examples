import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';
import { Config } from '../config/config';

export class ControlPointComponent extends DevicePointComponent{

    private text_type = ControlPointComponent.POINT_TYPE_CONTROL;

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_COLOR_ON: string = "red";
    public static DEFAULT_COLOR_OFF: string = "yellowgreen";
    public static DEFAULT_BORDERCOLOR: string = "red";
    public static DEFAULT_TEXTCOLOR: string = "black";
    public static DEFAULT_DISPLAYTEXT: string = "";
    public static DEFAULT_FONTFAMILY: string = "Arial";
    public static DEFAULT_FONTSIZE: number = 50;

    // Configurable when point mapped to symbol on map.
    protected onColor: string = ControlPointComponent.DEFAULT_COLOR_ON;
    protected offColor: string = ControlPointComponent.DEFAULT_COLOR_OFF;

    // Configurable when point mapped to symbol on map
    //protected borderColor: string = ControlPointComponent.DEFAULT_BORDERCOLOR;    
    //protected displayText: string = ControlPointComponent.DEFAULT_DISPLAYTEXT;
    //protected fontFamily: string = ControlPointComponent.DEFAULT_FONTFAMILY;
    //protected fontSize: number = ControlPointComponent.DEFAULT_FONTSIZE;
    //protected textColor: string = ControlPointComponent.DEFAULT_TEXTCOLOR;

    //protected failedColor: string = DevicePointComponent.DEFAULT_COLOR_FAILED;

    // Not used except in deserialize.
    //protected fillColor: string = DevicePointComponent.FILLCOLOR_DEFAULT;
    
    constructor(
        protected deviceType: string,
        protected deviceName: string,
        protected sn: number,
        protected ied: number,
        protected pointid: string,
        protected pointname: string,
        protected units: number,
        private ts: number,
        private offText: string,
        private onText: string
    ) {
        super(deviceType, deviceName, sn, ied, pointid, pointname, units);

        this.borderColor = ControlPointComponent.DEFAULT_BORDERCOLOR;    
        this.displayText = ControlPointComponent.DEFAULT_DISPLAYTEXT;
        this.fontFamily = ControlPointComponent.DEFAULT_FONTFAMILY;
        this.fontSize = ControlPointComponent.DEFAULT_FONTSIZE;
        this.textColor = ControlPointComponent.DEFAULT_TEXTCOLOR;

        this.Init(Config.configdata);
      }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
    }

    protected ApplyConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      super.ApplyConfig(config);

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_CONTROL)
        {
          if( item.name == "on fill color")
          {
              this.onColor = item.value;
          }
          else if( item.name == "off fill color")
          {
              this.offColor = item.value;
          }
          else if( item.name == "font size")
          {
              this.fontSize = parseInt(item.value);
          }
          else if( item.name == "font family")
          {
              this.fontFamily = item.value;
          }          
          else if( item.name == "border color")
          {
              this.borderColor = item.value;
          }
        }
      }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_ACCUM)
        {
          if( item.name == "on fill color")
          {
              ControlPointComponent.DEFAULT_COLOR_ON = item.default;
          }
          else if( item.name == "off fill color")
          {
              ControlPointComponent.DEFAULT_COLOR_OFF = item.default;
          }
          else if( item.name == "font size")
          {
            ControlPointComponent.DEFAULT_FONTSIZE = parseInt(item.default);
          }
          else if( item.name == "font family")
          {
            ControlPointComponent.DEFAULT_FONTFAMILY = item.default;
          }          
          else if( item.name == "border color")
          {
            ControlPointComponent.DEFAULT_BORDERCOLOR = item.default;
          }          
        }
      }
    }


      public deserialize(obj:any)
      {
          //debugger
          this.borderColor = obj.devicePoint.borderColor;
          this.fillColor = obj.devicePoint.fillColor;
          this.displayText = obj.devicePoint.displayText;
          this.fontFamily = obj.devicePoint.fontFamily;
          this.fontSize = obj.devicePoint.fontSize;
          this.textColor = obj.devicePoint.textColor;
          this.onColor = obj.devicePoint.onColor;
          this.offColor = obj.devicePoint.offColor;
          this.setTextColor();
      }

      // public GetFontString(): string
      // {
      //     //return DevicePointComponent.FONTSIZE_DEFAULT + "px " + DevicePointComponent.FONTFAMILY_DEFAULT;
      //     return this.fontSize + "px" + this.fontFamily;
      // }

      setTimestamp(val: number)
      {
          this.ts = val;
      }
  
      getTimestamp()
      {
          return this.ts;
      }

      public getFillColor(): string
      {
        // TODO: TEST ONLY.
        //this.setFailed(1);

        // if( this.getFailed()  )
        // {
        //     console.log("Returning FAILED COLOR.");
        //     return this.failedColor;
        // }
        if( this.value == this.onValue )
        {
            console.log("Returning ON COLOR.");
            return this.onColor;
        }
        else
        {
            console.log("Returning OFF COLOR.");
            return this.offColor;
        }

        // if( this.value == this.onValue )
        // {
        //   return ControlPointComponent.COLOR_ON;
        // }
        // else
        // {
        //   return ControlPointComponent.COLOR_OFF;
        // }
      }

      public getDisplayText(): string
      {
        console.log("ControlPointComponent.getDisplayText() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        //return this.displayText;

        let txt:string = "";

        if( this.getFailed() )
        {
            txt = "Failed";
        }
        // if( this.getForced() )
        // {
        //     txt = "Forced";
        // }

        return txt;        
      }

      public getOnColor(): string
      {
        console.log("ControlPointComponent.getOnColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return this.onColor;
      }
  
      public getOffColor(): string
      {
        console.log("ControlPointComponent.getOnColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return this.offColor;
      }
  

      public LoadProperties(propdata: { [key: string]: Object }[])
      {
        console.log("Executing ControlPointComponent.LoadProperties().");

        // Load the property array with point properties.
        let item:any = {name: "type", value: this.getPointType()};
        propdata.push(item);

        item = {name: "ext name", value: this.getExtName()};
        propdata.push(item);
        item = {name: "sn", value: this.getSN()};
        propdata.push(item);
        item = {name: "ied", value: this.getIed()};
        propdata.push(item);
        item = {name: "pt", value: this.getPointId()};
        propdata.push(item);
        item = {name: "pid", value: this.getPid()};
        propdata.push(item);
        
        item = {name: "on text", value: this.onText};
        propdata.push(item);
        item = {name: "off text", value: this.offText};
        propdata.push(item);

        item = {name: "oncolor", value: this.onColor};
        propdata.push(item);
        item = {name: "offcolor", value: this.offColor};
        propdata.push(item);
        item = {name: "failed color", value: this.failedColor};
        propdata.push(item);

        item = {name: "bordercolor", value: this.borderColor};
        propdata.push(item);
        item = {name: "fontFamily", value: this.fontFamily};
        propdata.push(item);
        item = {name: "fontSize", value: this.fontSize};
        propdata.push(item);
        item = {name: "text color", value: this.textColor};
        propdata.push(item);            
      }

      public saveProperty(name: string, value: string): boolean
      {
          console.log("Executing ControlPointComponent.SaveProperty().");
  
          if( name == "bordercolor")
          {
              this.borderColor = value;
              return true;
          }
          else if( name == "oncolor")
          {
              this.onColor = value;
              return true;
          }
          else if( name == "offcolor")
          {
              this.offColor = value;
              return true;
          }
          else if( name == "failed color")
          {
              this.failedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "fontsize")
          {
              this.fontSize = parseInt(value);
              return true;
          }
          else if( name == "fontfamily")
          {
              this.fontFamily = value;
              return true;
          }
          // else if( name == "text color")
          // {
          //     this.textColor = value;
          //     return true;
          // }

          return false;
      }
  
      public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
      {
        console.log("Executing ControlPointComponent.LoadDefaultProperties().");

        let item:any = {name: "type", value: ControlPointComponent.POINT_TYPE_CONTROL};
        propdata.push(item);

        // Load the property array with point properties.
        item = {name: "bordercolor", value: ControlPointComponent.DEFAULT_BORDERCOLOR};
        propdata.push(item);
        item = {name: "displayText", value: ControlPointComponent.DEFAULT_DISPLAYTEXT};
        propdata.push(item);
        item = {name: "fontFamily", value: ControlPointComponent.DEFAULT_FONTFAMILY};
        propdata.push(item);
        item = {name: "fontSize", value: ControlPointComponent.DEFAULT_FONTSIZE};
        propdata.push(item);
        item = {name: "text color", value: ControlPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "on color", value: ControlPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "off color", value: ControlPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        
        //super.LoadDefaultProperties(propdata);
      }

      public static saveDefaultProperty(name: string, value: string)
      {
          console.log("Executing ControlPointComponent.SaveProperty().");
  
          if( name == "bordercolor")
          {
            ControlPointComponent.DEFAULT_BORDERCOLOR = value;
          }
          else if( name == "oncolor")
          {
            ControlPointComponent.DEFAULT_COLOR_ON = value;
          }
          else if( name == "offcolor")
          {
            ControlPointComponent.DEFAULT_COLOR_OFF = value;
          }
          else if( name == "fontsize")
          {
            ControlPointComponent.DEFAULT_FONTSIZE = parseInt(value);
          }
          else if( name == "fontfamily")
          {
            ControlPointComponent.DEFAULT_FONTFAMILY = value;
          }
          else if( name == "text color")
          {
            ControlPointComponent.DEFAULT_TEXTCOLOR = value;
          }
      }

      public setTextColor()
      {
        // TODO: TEST ONLY.
        //this.setFailed(1);

        //debugger
        // console.log("AnalogPointComponent.setTextColor() for: " + 
        //               this.getSN() + ":" + 
        //               this.getIed() + "-" + 
        //               this.getPointId());
        if( this.getFailed() )
        {
          // Failed Point.
          this.textColor = this.failedColor;
        }
        // TODO:  Missing piece here!!!
        // else if( this.value == this.onValue )
        // {
        //     this.textColor = this.onTextColor;
        // }
        // else if( this.value == this.offValue )
        // {
        //     this.textColor = this.offTextColor;            
        // }

      }


      public AdjustProperties(): boolean
      {
        //this.fontSize = 20;
        this.setTextColor();
        return true;
      }
}