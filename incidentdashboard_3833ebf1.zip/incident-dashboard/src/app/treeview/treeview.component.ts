/* tslint:disable */
import { Component, OnInit, ViewEncapsulation, OnDestroy, HostListener} from '@angular/core';
import { enableRipple, EmitType } from '@syncfusion/ej2-base';
import { TreeView, NodeClickEventArgs } from '@syncfusion/ej2-navigations'
import { TreeviewService } from './treeview.service';
import { Subscription } from 'rxjs';
import { WebsocketService } from '../websocket/websocket.service';
import { Grid, Edit, Sort, VirtualScroll, Scroll, RowDataBoundEventArgs, Selection as GridSelection} from '@syncfusion/ej2-grids';
import { VirtualInfo, IRenderer } from '@syncfusion/ej2-grids';
//import { ComboBox } from '@syncfusion/ej2-dropdowns';
// import { VirtualScrollService } from '@syncfusion/ej2-angular-grids';
// import { PageSettingsModel } from '@syncfusion/ej2-angular-grids';
//import { DataManager, Query, ReturnOption, Predicate } from '@syncfusion/ej2-data';
import { Button, RadioButton } from '@syncfusion/ej2-buttons';
import { Dialog } from '@syncfusion/ej2-popups';
import { TextBox} from  '@syncfusion/ej2-inputs';
import { ActivatedRoute } from '@angular/router';
import { Router} from '@angular/router';
import { Toolbar as NavigationToolBar } from '@syncfusion/ej2-navigations';
import { Series, IAxisLabelRenderEventArgs, ILegendRenderEventArgs, ITooltipRenderEventArgs, ILoadedEventArgs, IPointEventArgs, ChartTheme, Chart, DateTime, Tooltip, Crosshair, Zoom, Legend, Selection, ScrollBar, IScrollEventArgs} from '@syncfusion/ej2-charts';
import { Browser } from '@syncfusion/ej2-base';
import { ColumnSeries, RangeColumnSeries } from '@syncfusion/ej2-charts';
import { DashboardLayout } from '@syncfusion/ej2-layouts';
import { DropDownList } from '@syncfusion/ej2-dropdowns';
//import { DropDownButton, ItemModel } from '@syncfusion/ej2-splitbuttons';
//import { inject } from '@angular/core/testing';
//import {StreamWriter} from '@syncfusion/ej2-file-utils';
//import {SharedService} from '../shared.service';
//import {TreeViewDialog} from './TreeViewDialog';
import {ConfigDialog} from '../dialogs/configdialog';
import {AppComponent} from '../app.component';
import {Config} from '../config/config';
import { SOEDialog } from '../dialogs/soedialog';
import { ServerFilesDialog } from '../dialogs/serverfilesdialog';


Chart.Inject(ColumnSeries, DateTime, Tooltip, Crosshair, Zoom, Legend, Selection, RangeColumnSeries, ScrollBar);

enableRipple(false);

Grid.Inject(Edit, Sort, Selection, VirtualScroll, Scroll);

interface virtualScrollInfo extends IRenderer 
{ 
    currentInfo: VirtualInfo; 
}



@Component({
  selector: 'app-treeview',
  templateUrl: './treeview.component.html',
  providers: [ TreeviewService ],
  styleUrls: ['./treeview.component.css'],
  encapsulation: ViewEncapsulation.None 
})

export class TreeViewComponent implements OnInit
{
  //showTree: boolean = true;

  private SERVER_IP: string = "";
  //SERVER_IP: string = "10.210.6.147";

  // Need to obtain these:
  //localIP: string = "10.210.3.63";

  imgpath: string = "";
  imgServers: string = "";
  imgServer: string = "";
  imgClients: string = "";
  imgClient: string = "";
  imgIed: string = "";
  imgPort: string = "";
  imgComponents: string = "";
  imgComponent: string = "";
  imgBlank: string = "";
  imgUnknown: string = "";

  private selIndex: any = [];


  // imgpath: string = "http://" + this.SERVER_IP + "/wtp/images/";
  // imgServers: string = this.imgpath + "serversIcon.gif";
  // imgServer: string = this.imgpath + "serverIcon.gif";
  // imgClients: string = this.imgpath + "clientsIcon.gif";
  // imgClient: string = this.imgpath + "clientIcon.gif";
  // imgIed: string = this.imgpath + "componentIcon.gif";
  // imgPort: string = this.imgpath + "portIcon.gif";
  // imgComponents: string = this.imgpath + "componentsIcon.gif";
  // imgComponent: string = this.imgpath + "componentIcon.gif";
  // imgBlank: string = this.imgpath + "blankIcon.gif";
  // imgUnknown: string = this.imgpath + "unknownIcon.gif";

  // Displays rtu.xml file.
  private treeViewInstance: TreeView = null;

  // Displays data view (point updates) or comm view (protocol data).
  private gridInstance: Grid = null;

  // The Pulse Timeline chart.
  private chartInstance: Chart = null;

  private dashboard:DashboardLayout = null;

  //private ddList: DropDownList = null;

  // Dialog to display/edit master config data.
  public configDialog: ConfigDialog = null;

  // Dialog to display the selected SOE log.
  public soeDialog: SOEDialog;

  public filesDialog: ServerFilesDialog;

  // Container to store the master configuration once it
  // downloads from the epaq or is applied from the 
  // master configuration dialog.
  private configdata: { [key: string]: Object }[] = []; 

  // Used for local config file load.
  //private fileReader:FileReader = null;

  // Temporary data store for serialized string data.
  //private serialData: string[] = [];
    
  // Temp data store for serialized string data.
  private soeData: { [key: string]: Object }[] = [];



  private static view_DATA = "data";
  private static view_COMM = "comm";  

  view: string;
  id: string;
  streamId: number = 0;
  last_comm_ms: number;
  //defaultsessionid = "S383886777";
  //sessionId: string = "S383886777";
  //@Input()
  private sessionId: string = "";

  contents: string = "";
  rtuFile: string = "";
  //rtuFile: string = "http://" + this.SERVER_IP + "/wtp/rtu.xml/";

  private diagramPath: string = "http://" + this.SERVER_IP + "/wtp/diagrams/";

  private soeFile:string = "";
  private soePath: string = "http://" + this.SERVER_IP + "/Soe/";

  private static FILE_TYPE_NONE = 0;
  private static FILE_TYPE_DIAG = 1;
  private static FILE_TYPE_SOE = 2;
  
  //private treeViewDialog: TreeViewDialog = null;

  // TODO: REMOVE THIS.
  //rtuFile: string = 'assets/rtu.xml';
  //txtFile: string = 'assets/test.txt';
  //xmltabs: Tab = null;

  public parser: DOMParser;
  public xmlData: Document = null;

  wsSubscription: Subscription = null;

  commSubscription: Subscription = null;

  status: any;
  private sub: any;

  //private url_commServer:string = "ws://10.210.6.147:1113";
  private url_commServer:string = "";
  //private static PORT_commServer:string = "1113";

  cmd_userState: string = "get userstate";
  cmd_sessionClose: string = "session close";
  //cmd_sessionOpen: string = "session open root root 10.210.3.63";

  private griddata: { [key: string]: Object }[] = [];
  //private commdata: { [key: string]: Object }[] = [];

  private updateGrid:boolean = true;

  public gridFilteredData: { [key: string]: Object }[] = [];

  // timeline datastore.
  //public pulsedata: Object[] = [];
  
  public primaryXAxis: Object;
  public primaryYAxis: Object;
  public chart1Data: Object[] = [];
  public chart2Data: Object[] = [];
  public rxData: Object[] = [];
  public txData: Object[] = [];

  public ddArray:string[] = [];

  public title: string;

    // Pink/Purple
  //private txColor: string = "#E033FF";
  //private txColor: string = "#C733FF";
  //private txColor: string = "#FF7133";
  // Pink
  //private txColor: string = "#FE2EC8";

  // Red
  //private txColor: string = "#E74C3C";
  //private txColor: string = "#E59866";
  //private txColor: string = "#CB4335";
  //private txColor: string = "#DF01A5";
  private txColor: string = "crimson";
  // Green
  //private rxColor: string = "#2ecd71";
  private rxColor: string = "#16A085";
  
  // bright yellow
  //private selColor: string = "#FFFF00";
  private selColor: string = "yellowgreen";

  private static COLOR_FORCED: string = '#85C1E9';
  private static COLOR_FAILED: string = "red";
  private static COLOR_ALARMED_STATUS: string = "yellowgreen";
  private static COLOR_ALARMED_LOW: string = "teal";
  private static COLOR_ALARMED_HIGH: string = "mediumvioletred";

  private static COL_ACKED:number = 15;


  // private txColor: string = "#FA58AC";
  // //private txColor: string = "#FF3333";
  // //private rxColor: string = "#04B404";
  // private rxColor: string = "#04B431";
  // private selColor: string = "#FF0000";
  // //private selColor: string = "";

  private static permissions_NONE: number = 0;
  private static permissions_ALLOWED: number = 1;
  private static permissions_ENABLED: number = 2;
  private static permissions_FORBIDDEN: number = 3;
  private static permissions_CONFLICT: number = 4;

  private static DIRTYPE_SEND = "send";
  private static DIRTYPE_RECV = "receive";

  private permissions_force: number = TreeViewComponent.permissions_NONE;
  private permissions_exec: number = TreeViewComponent.permissions_NONE;

  private permissonsSet: boolean = false;

  private fbutton: Button = null;
  private cbutton: Button = null;
  private ebutton: Button = null;

  private forcedKey: Button = null;
  private failedKey: Button = null;
  private alarmedKeyStatus: Button = null;
  private alarmedKeyLow: Button = null;
  private alarmedKeyHigh: Button = null;
  private alarmedKeyNormal: Button = null;
  private btn_ackAll: Button = null;
  //private alarmedKey5: Button = null;

  private newTreeButton: Button = null;
  private newTerminalButton: Button = null;
  private logoutButton: Button = null;
  private saveButton: Button = null;
  private hmiButton: Button = null;
  private configButton: Button = null;
  private soeButton: Button = null;
  private resizeButton: Button = null;

  private rb_status: RadioButton = null;
  private rb_analog: RadioButton = null;
  private rb_accum: RadioButton = null;
  private rb_control: RadioButton = null;
  private rb_setpoint: RadioButton = null;
  private rb_alarms: RadioButton = null;
  private rb_all: RadioButton = null;

  private rb_auto: RadioButton = null;
  private rb_manual: RadioButton = null;


  // private keyBtn1: Button = null;
  // private keyBtn2: Button = null;
  // private keyBtn3: Button = null;
  // private keyBtn4: Button = null;

  //userList: string = "name: (unknown), address: (unknown), forcing: true, executing: true";
  private userList: string[] = [];
  private users: string[] = ['Users'];
  private ddUserList: string[] = [];
  private toolbar: NavigationToolBar = null;
  private ddUsers: DropDownList = null;

  private ddModel: DropDownList = null;
  private ddModelList: string[] = ['Model'];

  private ddDevice: DropDownList = null;
  private ddDeviceList: string[] = ['Device'];


  public rtuLicense: string;
  public rtuVersion: string;
  public rtuModel: string;
  public rtuName: string;
  public ID: number = 0;

  private ts_first_tx: number = 0;
  private ts_first_rx: number = 0;

  private ts_last_tx: number = 0;
  private ts_last_rx: number =0;

// The max min/ms to display on the chart at any give time.
private max_chart_min: number = 2;
private max_chart_ms: number = this.max_chart_min * 1000 * 60;

// True=live pulse timeline and grid live updating.
// False=Pulse timeline and grid live updating stops.
// (false when scrolling back historically in chart or grid or 
//  selecting chart pulse point).
private doCharting = true;
//private doCharting = false;

private isManualScroll: boolean = false; 
//private lastPage: number = 0;

// True-live grid updating (default).
// False-live grid updating stops.
// [when selecting a pulse point or scrolling back (historically) in grid].
//updateGrid = true;

// Data store for tree view items.
private treedata: { [key: string]: Object }[] = []; 

nodeExpanding: boolean = false;
nodeExpanded: boolean = false;
nodeCollapsing: boolean = false;
nodeCollapsed: boolean = false;

private static FILE_DELIMITER: string = "^";
private static ENG_UNITS: number = 1;


public chartArea: Object = {
  border: {
      width: 0
  }
};
public width: string = Browser.isDevice ? '100%' : '60%';
public marker: Object = 
{
  visible: true,
  height: 10,
  width: 10
};
public tooltip: Object;
public crosshair: Object;


public load(args: ILoadedEventArgs): void {
  let selectedTheme: string = location.hash.split('/')[1];
  selectedTheme = selectedTheme ? selectedTheme : 'Material';
  args.chart.theme = <ChartTheme>(selectedTheme.charAt(0).toUpperCase() + selectedTheme.slice(1)).replace(/-dark/i, "Dark");
};


  constructor(public treeviewService: TreeviewService, 
              private wsServiceComm: WebsocketService,
              //private sharedService: SharedService,
              private route: ActivatedRoute,
              private router: Router
              )
  {  
    console.log("Executing TreeView constructor."); 
    //this.data = wsServiceComm;
  }

  // get sessionid(): string
  // {
  //   return this.sharedService.sessionId;
  // }

  public GetSessionID(): string
  {
    return this.sessionId;
  }


  GetLabelTime(ts:number, inx:number)
  {
    let ms:number = inx*2;
    let tm:Date = new Date(new Date(ts).getTime() + (ms*1000));
    let dt:Date = new Date(tm.getFullYear(), tm.getMonth(), tm.getDay(), tm.getHours(), tm.getMinutes(), tm.getSeconds())
    return dt;
  }

  getServerIP()
  {
    // // Get the server ip from user entered url.
    // var url = window.location.href;

    // if( Config.MODE_DEV )
    // {
    //   // For development mode, use the next line to set the url.
    //   //url = "http://10.210.6.147";
    //   url = Config.SERVERIP_TEST;
    // }

    // var pos1 = url.indexOf('//');
    // var tok = url.slice(pos1+2);
    // var pos2 = tok.indexOf('/');
    // if( pos2 >= 0 )
    // {    
    //   this.SERVER_IP = tok.slice(0,pos2);
    // }
    // else
    // {
    //   this.SERVER_IP = tok;
    // }
    // localStorage.setItem("serverIP", this.SERVER_IP);

    this.SERVER_IP = localStorage.getItem("serverIP");
    console.log("SERVER_IP: " + this.SERVER_IP);
  }

  setPaths()
  {
    debugger
    this.getServerIP();

    this.url_commServer = "ws://" + this.SERVER_IP + ":" + Config.PORT_COMMSERVER.toString();

    this.rtuFile = "http://" + this.SERVER_IP + "/wtp/rtu.xml/";

    this.diagramPath = "http://" + this.SERVER_IP + "/wtp/diagrams/";
    this.soePath = "http://" + this.SERVER_IP + "/Soe/";

    this.imgpath = "http://" + this.SERVER_IP + "/wtp/images/";
    this.imgServers = this.imgpath + "serversIcon.gif";
    this.imgServer = this.imgpath + "serverIcon.gif";
    this.imgClients = this.imgpath + "clientsIcon.gif";
    this.imgClient = this.imgpath + "clientIcon.gif";
    this.imgIed = this.imgpath + "componentIcon.gif";
    this.imgPort = this.imgpath + "portIcon.gif";
    this.imgComponents = this.imgpath + "componentsIcon.gif";
    this.imgComponent = this.imgpath + "componentIcon.gif";
    this.imgBlank = this.imgpath + "blankIcon.gif";
    this.imgUnknown = this.imgpath + "unknownIcon.gif";
  }

  // getSessionId(): void {
  //   return this.sharedService.sessionId;
  //   // this.sharedService.getSessionID()
  //   //     .subscribe(sessionid => this.sessionId = sessionid);
  // }

  ngOnInit() 
  {
      console.log("Executing TreeViewComponent.ngOnInit().");

      let dashboardContent:string = 
      `{'id':'Panel2', 'sizeX': 1, 'sizeY': 13,'row': 0,  'col': 0, header: '<div style="max-width:100%;min-width:100%;color:black;font-size:20px;font-weight:bold;background-color:silver"> <b>DEVICE TREE </b></div>', content:'<div id="treeview" style="max-height:100%;max-width:100%;min-width:100%;min-height:100%;overflow:inherit;background-color:rgb(163, 205, 248);border:solid darkgray 1px;"></div>'},
      {'id':'Panel3', 'sizeX': 4, 'sizeY': 13,'row': 0,  'col': 1, content:'<div id="grid" style="overflow:inherit;border:solid darkgray 1px;background-color:bisque"></div><div id="authdialog"></div><router-outlet></router-outlet>' },
      {'id':'Panel4', 'sizeX': 5, 'sizeY': 2, 'row': 13, 'col': 0, content:
    <div id="footer" style="max-width:100%;min-width:100%;height:100px;border:solid darkgray 1px;background-color:#154360">
      <div id ="container" align="center" style="display:none">'
        <div class="btn-group" id=grp1 style="height:50%;width:100%;padding-top:5px;border:solid darkgray 1px;">
          <div class=button id="buttonDiv" style="display:none;padding-left:30%;padding-top: 1px">
            <button class="div-tag1" id=tag1 style="background-color:#3ADF00"></button>
            <button class="div-tag2" id=tag2 style="background-color:#F4D03F"></button>
            <button class="div-tag3" id=tag3 style="background-color:#FE2E2E"></button>
            <button class="div-ackall" id=ackall style="background-color:#47CC04"></button>  
          </div> 
        </div>
      </div>
      <div id ="container1" align="center" style="display:none"> 
        <div class="btn-group" id=grp2 style="width:100%;height:50%;padding-top:5px;border:solid darkgray 1px"> 
          <div class=button id="keyDiv" style="display:none;padding-left:20%"> 
            <button class="div-key1" id=key1 style="background-color:#85C1E9"></button>
            <button class="div-key2" id=key2 style="background-color:red"></button>
            <button class="div-key3" id=key3 style="background-color:greenyellow"></button>
            <button class="div-key4" id=key4 style="background-color:teal;"></button>
            <button class="div-key5" id=key5 style="background-color:mediumvioletred"></button>
            <button class="div-key6" id=key6 style="background-color:lightsalmon"></button> 
          </div>   
        </div>   
      </div> 
    </div>' }`; 


      // Create the main dashboard.
      this.dashboard = new DashboardLayout({
        cellSpacing: [5, 5],
        showGridLines: true,
        columns: 5,
        cellAspectRatio: 100/15,
        allowResizing: false,
        allowFloating: false,
        allowDragging: false,
        panels: [
         {'id':'Panel2', 'sizeX': 1, 'sizeY': 13,'row': 0,  'col': 0, header: '<div style="max-width:100%;min-width:100%;color:black;font-size:20px;font-weight:bold;background-color:silver"> <b>DEVICE TREE </b></div>', content:'<div id="treeview" style="max-height:100%;max-width:100%;min-width:100%;min-height:100%;overflow:inherit;background-color:rgb(163, 205, 248);border:solid darkgray 1px;"></div>'},
         {'id':'Panel3', 'sizeX': 4, 'sizeY': 13,'row': 0,  'col': 1, content:'<div id="grid" style="overflow:auto;border:solid darkgray 1px;background-color:bisque"></div><div id="authdialog"></div><router-outlet></router-outlet>' },
         {'id':'Panel4', 'sizeX': 5, 'sizeY': 2, 'row': 13, 'col': 0, content:'<div id="footer" style="max-width:100%;min-width:100%;height:auto;border:solid darkgray 1px;background-color:#154360"><div id ="container" align="center" style="height:50%;display:none"></div><div class="btn-group" id=grp1 style="display:none;height:50%;width:100%;padding-top:5px;border:solid darkgray 1px;"><div class=button id="buttonDiv" style="display:none;padding-left:30%;padding-top: 1px"><button class="div-tag1" id=tag1 style="background-color:#3ADF00"></button><button class="div-tag2" id=tag2 style="background-color:#F4D03F"></button><button class="div-tag3" id=tag3 style="background-color:#FE2E2E"></button><button class="div-ackall" id=ackall style="background-color:#47CC04"></button>  </div> </div> <div id ="container1" align="center" style="height:50%;display:none"></div> <div class="btn-group" id=grp2 style="display:none;width:100%;height:50%;padding-top:5px;border:solid darkgray 1px"> <div class=button id="keyDiv" style="display:none;padding-left:20%"> <button class="div-key1" id=key1 style="background-color:#85C1E9"></button><button class="div-key2" id=key2 style="background-color:red"></button><button class="div-key3" id=key3 style="background-color:greenyellow"></button><button class="div-key4" id=key4 style="background-color:teal;"></button><button class="div-key5" id=key5 style="background-color:mediumvioletred"></button><button class="div-key6" id=key6 style="background-color:lightsalmon"></button> </div>   </div>    </div>' }  
        ]
      });        
      // render initialized dashboardlayout
      this.dashboard.appendTo('#dashboard');

      this.CreateToolbar();

      this.sessionId = localStorage.getItem("sessionid");
      console.log("TreeViewComponent.ngOnInit() - Session ID: " + this.sessionId);

      this.setPaths();

      this.wsSubscription = this.wsServiceComm.createObservableSocket(
        this.url_commServer, this.cmd_userState + " " + this.sessionId) 
        //this.cmd_sessionOpen)
        .subscribe(
        data=>this.handleCommMessage(data),
        err=>alert('err: TreeViewComponent Subscribe'),
        ()=>
        { console.log('The TreeViewComponent Subscription Is Complete'); }
        );

      this.Populate();

      this.IncrementView();

      //this.getClientIP();
  }

private IncrementView()
{
  let num:number = parseInt(localStorage.getItem("numTreeView"));
  console.log("IncrementView() - numTreeView read: " + num);
  num += 1;
  localStorage.setItem("numTreeView", num.toString() );      
  console.log("IncrementView() - numTreeView written: " + num);
}

  // call this event handler before browser refresh/close tab.
  @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) 
  {
    console.log("Processing beforeunload...");
    this.StopStream();
    //this.Cleanup();
    this.DestroyControls();
    this.router.navigateByUrl('/app');  
    this.DecrementView();
  }

  // execute this function before browser refresh
  DecrementView(){
    let num:number = parseInt(localStorage.getItem("numTreeView"));
    console.log("DecrementView() - numTreeView read: " + num);
    num -= 1;
    localStorage.setItem("numTreeView", num.toString() );      
    console.log("DecrementView() - numTreeView written: " + num);
  }

private CreateToolbar()
{
  //let symbolTypes: string[] = ['Symbols', 'Rectangle', 'Circle', 'Line', 'Text'];
  let model: string[] = ['Model'];
  let device: string[] = ['Device'];
  //users: string[] = ['Users'];

  this.toolbar = new NavigationToolBar({
  created: this.CreateToolBarButtons.bind(this),
      items: [
        { template: '<div id="rb-group" style="background-color:yellowgreen"> <input id="rb-all" type="radio"/> <input id="rb-status" type="radio"/> <input id="rb-analog" type="radio"/> <input id="rb-accum" type="radio"/> <input id="rb-control" type="radio"/> <input id="rb-setpoint" type="radio"/> <input id="rb-alarms" type="radio"/> </div>'},
        { type: "Separator" },
        { type: 'Input', template: this.ddModel = new DropDownList({ dataSource: model, width: 120, index: 0, cssClass:"custom1"}) },
        { type: "Separator" },
        { type: 'Input', template: this.ddDevice = new DropDownList({ dataSource: device, width: 150, index: 0, cssClass:"custom2"}) },
        { type: "Separator" },
        { type: 'Input', template: this.ddUsers = new DropDownList({ dataSource: this.users, width: 500, index: 0, cssClass:"custom3" }) },
        { type: "Separator" },
        { template: '<button class="e-btn" id="newTree_btn" style="background-color:yellowgreen;padding:0px"></button>' },
        { template: '<button class="e-btn" id="newTerminal_btn" style="background-color:magenta;padding:0px"></button>' },
        { template: '<button class="e-btn" id="hmi_btn" style="background-color:violet;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="config_btn" style="background-color:yellow;padding:0px"></button>' },
        { template: '<button class="e-btn" id="soe_btn" style="background-color:aqua;padding:0px"></button>' },
        { template: '<button class="e-btn" id="save_btn" style="background-color:violet;padding:0px"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="logout_btn" style="background-color:red"></button>' },
        { type: "Separator" },
        { template: '<button class="e-btn" id="resize_btn" style="background-color:magenta"></button>' },
        { type: "Separator" },
        { template: '<div id="rb-group-scroll" style="background-color:violet;float-right:10%"> <input id="rb-auto" type="radio"/> <input id="rb-manual" type="radio"/>  </div>'},
    ]
  });
  this.toolbar.appendTo('#toolbar');  
}

private CreateToolBarButtons()
{
  this.CreateRadioButtons();
  this.CreateRadioButtons_Scroll();

  this.newTreeButton = new Button({ cssClass: `e-flat`, iconCss: 'e-tree-icon e-icons', isToggle: false });
  this.newTreeButton.appendTo('#newTree_btn');
  this.newTreeButton.element.setAttribute("title", "Tree View");
  this.newTreeButton.element.onclick = (): void => 
  {
    console.log("Executing newTreeButton.onclick()");

    //if( Config.MODE_DEV )
    if( Config.MODE_MULTITABS )
    {      
      let num:number = parseInt(localStorage.getItem("numTreeView"));
      console.log("Num Tree Views Read: " + num);
      if( num < Config.MAX_TREEVIEWS)
      {
        //AppComponent.OpenInNewTab('/treeview');
        this.OpenInNewTab('/treeview');
      }
      else
      {
        alert("Maximum Tree Views Reached: Only " + Config.MAX_TREEVIEWS + " Allowed.");
      }
    }
    else
    {
      // Test for prod mode
      this.StopStream();
      this.DestroyControls();
      this.router.navigateByUrl('/treeview'); 
    }
  }

  this.newTerminalButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-terminal-icon', isToggle: false });
  this.newTerminalButton.appendTo('#newTerminal_btn');
  this.newTerminalButton.element.setAttribute("title", "Terminal View");
  this.newTerminalButton.element.onclick = (): void => 
  {
    console.log("Executing newTerminalButton.onclick()");
    //if( Config.MODE_DEV )
    if( Config.MODE_MULTITABS )
    {
      let num:number = parseInt(localStorage.getItem("numTermView"));
      //alert("Num Term Views Read: " + num);
      if( num < Config.MAX_TERMVIEWS)
      {
        AppComponent.OpenInNewTab('/terminal');
      }
      else
      {
        alert("Maximum Terminal Views Reached: Only " + Config.MAX_TERMVIEWS + " Allowed.");
      }
    }
    else
    {
      // Test for prod mode
      this.StopStream();
      this.DestroyControls();
      this.router.navigateByUrl('/terminal'); 
    }
  };  


  this.saveButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-save-icon', isToggle: false });
  this.saveButton.appendTo('#save_btn');
  this.saveButton.element.setAttribute("title", "Save");
  this.saveButton.element.onclick = (): void => 
  {
      console.log("Executing saveButton.onclick()");
      // Save to local file.
      this.OnSave();
  }

  this.hmiButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-clear-icon', isToggle: true });
  this.hmiButton.appendTo('#hmi_btn');
  this.hmiButton.element.setAttribute("title", "HMI View");
  this.hmiButton.element.onclick = (): void => 
  {
    //if( Config.MODE_DEV )
    if( Config.MODE_MULTITABS)
    {
      let num:number = parseInt(localStorage.getItem("numSLDView"));
      console.log("Num SLD Views Read: " + num);
      if( num < Config.MAX_SLDVIEWS)
      {
        console.log("Executing hmiButton.onclick()");
        //AppComponent.OpenInNewTab('/hmi');
        this.OpenInNewTab('/hmi');
      }
      else
      {
        alert("Maximum SLD Views Reached: Only " + Config.MAX_SLDVIEWS + " Allowed.");
      }
    }
    else
    {
      // Test for prod mode
      this.StopStream();
      this.DestroyControls();
      this.router.navigateByUrl('/hmi'); 
    }
  }


  this.configButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-tree-icon', isToggle: true });
  this.configButton.appendTo('#config_btn');
  this.configButton.element.setAttribute("title", "config");
  this.configButton.disabled =false;
  this.configButton.element.onclick = (): void => 
  {
    debugger
    console.log("Executing configBtn.onclick()");

    if( this.configDialog != null )
    {
      this.configDialog.dialog.visible = true;
    }
  }
  
  this.soeButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-save-icon', isToggle: false });
  this.soeButton.appendTo('#soe_btn');
  this.soeButton.element.setAttribute("title", "View SOE");
  this.soeButton.element.onclick = (): void => 
  {
      console.log("Executing soeButton.onclick()");
      // Request to view soe files.
      this.RequestSOEFiles();
  }

  this.resizeButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-save-icon', isToggle: false });
  this.resizeButton.appendTo('#resize_btn');
  this.resizeButton.element.setAttribute("title", "Resize Dashboard");
  this.resizeButton.element.onclick = (): void => 
  {
      console.log("Executing resizeButton.onclick()");
      // Request to resize dashboard.
      this.ResizeDashboard();
  }


  this.logoutButton = new Button({ cssClass: `e-flat`, iconCss: 'e-icons e-logout-icon', isToggle: true });
  this.logoutButton.appendTo('#logout_btn');
  this.logoutButton.element.setAttribute("title", "Logout");
  this.logoutButton.element.onclick = (): void => 
  {
      console.log("Executing logoutButton.onclick()");
      // Send session close message - don't need to stop the stream.
      this.sendMessageToServer(this.cmd_sessionClose);
      this.Cleanup();
      //this.router.navigateByUrl('/app'); 
  }
}

private ResizeDashboard()
{
  let panelContent: HTMLElement = document.getElementById("panelContent");
  let panelHeight: number  = panelContent.offsetHeight;
  let panelWidth: number = panelContent.offsetWidth;
  let diff: number = Math.round(panelHeight/panelWidth);
  this.dashboard.resizePanel('panel0', 1, diff);
  this.dashboard.resizePanel('panel1', 1, diff);
  this.dashboard.resizePanel('panel2', 1, diff);  
}

private DestroyToolBarButtons()
{
  this.DestroyRadioButtons();
  this.DestroyRadioButtons_Scroll();

  if( this.newTreeButton != null )
  {
    this.newTreeButton.destroy();
    this.newTreeButton = null;
  }
 
  if( this.newTerminalButton != null )
  {
    this.newTerminalButton.destroy();
    this.newTerminalButton = null;
  }
 
  if( this.saveButton != null )
  {
    this.saveButton.destroy();
    this.saveButton = null;
  }
 
  if( this.hmiButton != null )
  {
    this.hmiButton.destroy();
    this.hmiButton = null;
  }

  if( this.configButton != null )
  {
    this.configButton.destroy();
    this.configButton = null;
  }

  if( this.logoutButton != null )
  {  
    this.logoutButton.destroy();
    this.logoutButton = null;
  }
}

private DisableRadioButtons(disable: boolean)
{
  this.rb_all.disabled = disable;
  this.rb_status.disabled = disable;
  this.rb_analog.disabled = disable;
  this.rb_accum.disabled = disable;
  this.rb_control.disabled = disable;
  this.rb_setpoint.disabled = disable;
  this.rb_alarms.disabled = disable;

  if( disable )
  {
    this.rb_all.checked = false;
    this.rb_status.checked = false;
    this.rb_analog.checked = false;
    this.rb_accum.checked = false;
    this.rb_control.checked = false;
    this.rb_setpoint.checked = false;
    this.rb_alarms.checked = false;

    document.getElementById("rb-group").style.display = "none";
  }
  else
  {
    document.getElementById("rb-group").style.display = "block";
    this.rb_all.checked = true;
    this.rb_status.checked = false;
    this.rb_analog.checked = false;
    this.rb_accum.checked = false;
    this.rb_control.checked = false;
    this.rb_setpoint.checked = false;
    this.rb_alarms.checked = false;  
  }
}

private CreateRadioButtons()
{
    debugger
    this.rb_all = new RadioButton({ label: 'All', name: 'state', checked: true });
    this.rb_all.appendTo('#rb-all');
    this.rb_all.disabled = true;

    this.rb_all.change= (): void => 
    {
      console.log("All Radio Button Change Fired");
      this.FilterPoints("all");
    };

    this.rb_status = new RadioButton({ label: 'Status', name: 'state', checked: false });
    this.rb_status.appendTo('#rb-status');
    this.rb_status.disabled = true;

    this.rb_status.change= (): void => 
    {
      console.log("Status Radio Button Change Fired");
      this.FilterPoints("st");
    };

    this.rb_analog = new RadioButton({ label: 'Analog', name: 'state', checked: false });
    this.rb_analog.appendTo('#rb-analog');
    this.rb_analog.disabled = true;

    this.rb_analog.change= (): void => 
    {
      console.log("Analog Radio Button Change Fired");
      this.FilterPoints("an");
    };

    this.rb_accum = new RadioButton({ label: 'Accum', name: 'state', checked: false });
    this.rb_accum.appendTo('#rb-accum');
    this.rb_accum.disabled = true;

    this.rb_accum.change= (): void => 
    {
      console.log("Accumulator Radio Button Change Fired");
      this.FilterPoints("ac");
    };  

    this.rb_control = new RadioButton({ label: 'Control', name: 'state', checked: false });
    this.rb_control.appendTo('#rb-control');
    this.rb_control.disabled = true;

    this.rb_control.change= (): void => 
    {
      console.log("Control Radio Button Change Fired");
      this.FilterPoints("co");
    };

    this.rb_setpoint = new RadioButton({ label: 'Setpoint', name: 'state', checked: false });
    this.rb_setpoint.appendTo('#rb-setpoint');
    this.rb_setpoint.disabled = true;

    this.rb_setpoint.change= (): void => 
    {
      console.log("Setpoint Radio Button Change Fired");
      this.FilterPoints("se");
    };

    this.rb_alarms = new RadioButton({ label: 'Alarms', name: 'state', checked: false });
    this.rb_alarms.appendTo('#rb-alarms');
    this.rb_alarms.disabled = true;

    this.rb_alarms.change= (): void => 
    {
      console.log("Alarms Radio Button Change Fired");
      this.FilterPoints("alarms");
    };  

    this.DisableRadioButtons(true);
}

private DestroyRadioButtons()
{
    //debugger
    if( this.rb_all != null)
    {
      this.rb_all.destroy();
      this.rb_all = null;
    }

    if( this.rb_status != null)
    {
      this.rb_status.destroy();
      this.rb_status = null;
    }

    if( this.rb_analog != null )
    {
      this.rb_analog.destroy();
      this.rb_analog = null;
    }

    if( this.rb_accum != null )
    {
      this.rb_accum.destroy();
      this.rb_accum = null;
    }

    if( this.rb_control != null )
    {
      this.rb_control.destroy();
      this.rb_control = null;
    }

    if( this.rb_setpoint != null )
    {
      this.rb_setpoint.destroy();
      this.rb_setpoint = null;
    }

    if( this.rb_alarms != null )
    {
      this.rb_alarms.destroy();
      this.rb_alarms = null;
    }
}


private CreateRadioButtons_Scroll()
{
    debugger
    this.rb_auto = new RadioButton({ label: 'auto scroll', name: 'state', checked: true });
    this.rb_auto.appendTo('#rb-auto');
    this.rb_auto.disabled = true;

    this.rb_auto.change= (): void => 
    {
      //document.getElementById("rb-status").style.setProperty('float', 'left');
      console.log("Auto Radio Button Change Fired");
      this.updateGrid = true;
      this.doCharting = true;
      this.QueryGrid_ClearSelected();
      this.chartInstance.series[0].opacity = 1;
      this.chartInstance.series[1].opacity = 1;
    };

    this.rb_manual = new RadioButton({ label: 'manual scroll', name: 'state', checked: false });
    this.rb_manual.appendTo('#rb-manual');
    this.rb_manual.disabled = true;

    this.rb_manual.change= (): void => 
    {
      //document.getElementById("rb-status").style.setProperty('float', 'left');
      console.log("Manual Radio Button Change Fired");
      this.updateGrid = false;
      this.doCharting = false;
      (this.gridInstance.getContent().firstChild as Element).scrollTop = 0;
    };

    this.DisableRadioButtons_Scroll(true);
}

private DisableRadioButtons_Scroll(disable: boolean)
{
  this.rb_auto.disabled = disable;
  this.rb_manual.disabled = disable;

  if( disable )
  {
    this.rb_auto.checked = false;
    this.rb_manual.checked = false;

    document.getElementById("rb-group-scroll").style.display = "none";
  }
  else
  {
    document.getElementById("rb-group-scroll").style.display = "block";
    this.rb_auto.checked = true;
    this.rb_manual.checked = false;
  }
}


private DestroyRadioButtons_Scroll()
{
    //debugger
    if( this.rb_auto != null)
    {
      this.rb_auto.destroy();
      this.rb_auto = null;
    }

    if( this.rb_manual != null)
    {
      this.rb_manual.destroy();
      this.rb_manual = null;
    }
}





private GetFilterKey(): string
{
  if( this.rb_all.checked )
  {
    return "all";
  }
  else if( this.rb_status.checked )
  {
    return "st";
  }
  else if( this.rb_analog.checked )
  {
    return "an";
  }
  else if( this.rb_accum.checked )
  {
    return "ac";
  }
  else if( this.rb_control.checked )
  {
    return "co";
  }
  else if( this.rb_setpoint.checked )
  {
    return "se";
  }
  else if( this.rb_alarms.checked )
  {
    return "alarms";
  }

  return "all";

}

private FilterPoints(type:string = null)
{
  //debugger
  this.gridFilteredData = [];

  if( type == null )
  {
    type = this.GetFilterKey();
  }

  console.log("FilterPoints() - type: " + type);

  if( type == "all")
  {
    this.gridInstance.dataSource = [];
    this.gridInstance.dataSource = this.griddata;
    return;  
  }

  if( type == "alarms")
  {
    for( let i:number=0; i<this.griddata.length; ++i)
    {
      let item: any = this.griddata[i];
      if( item)
      {
        let ival = parseInt(item.alarmed.toString());
        if( ival > 0 )
        {
          this.gridFilteredData.push(item);
        }
      }
    }
  
    this.gridInstance.dataSource = [];
    this.gridInstance.dataSource = this.gridFilteredData;
    // this.gridInstance.dataSource = this.griddata;

    return;  
  }


  for( let i:number=0; i<this.griddata.length; ++i)
  {
    let item: any = this.griddata[i];
    if( item)
    {
      if( item.pointid.startsWith(type.trim().toLowerCase()))
      {
        this.gridFilteredData.push(item);
      }
    }
  }

  this.gridInstance.dataSource = [];
  this.gridInstance.dataSource = this.gridFilteredData;
}

public ClearConfigDialog()
{
  if( this.configDialog != null )
  {
    this.configDialog = null;
  }
}

private DestroyConfigDialog()
{
  if( this.configDialog != null )
  {
    // Destroy the Property Grid Dialog/Grid.
    this.configDialog.Destroy();
    this.configDialog = null;
  }
}

private DestroyFilesDialog()
{
  if( this.filesDialog != null )
  {
    // Destroy the Property Grid Dialog/Grid.
    this.filesDialog.Destroy();
    this.filesDialog = null;
  }
}


private DestroySOEDialog()
{
  if( this.soeDialog != null )
  {
    // Destroy the Property Grid Dialog/Grid.
    this.soeDialog.Destroy();
    this.soeDialog = null;
  }
}




OnLoadLocalDiagram(files: FileList)
{
  console.log('Executing DrawingBoardComponent.OnLoadLocalDiagram().');

  if( this.configDialog != null && this.configDialog.GetLoadLocal() )
  {
    this.configDialog.OnLoadLocalConfig(files);
  }

  // let file:File = files[0];
  // this.fileReader = new FileReader();
  // this.fileReader.onload = this.OnDiagramLoaded.bind(this);

  // var blob = file.slice(0, file.size);
  // this.fileReader.readAsText(blob);    

  document.getElementById("loadfile").style.display = "none"; 
}

 
  Populate()
  {
    //alert("Executing Populate()");

    // Not until deployment.
    //this.getServerIP();    
    //this.setPaths();

    this.processXML(); 
    //this.CreateHeaderButtons();
    //this.CreateXMLTabs();
    document.getElementById("buttonDiv").style.display = "none";
    //this.items = new DataManager(this.griddata).executeLocal(new Query());
    document.getElementById("keyDiv").style.display = "none";
  }


  handleCommMessage(msg: string)
  {
    //alert("handleCommMessage: " + msg);
    console.log("handleCommMessage: " + msg);
    if( msg == "ping")
    {
      // Ignore.
      return;
    }
    else if( msg == "pong")
    {
      // Ignore.
      return;
    }
    else if( msg.startsWith("logout"))
    {
      console.log("TreeViewComponent.handleCommMessage() - Received logout message: " + msg);
      this.StopStream();
      this.DestroyControls();
      this.router.navigateByUrl('/app');      
      return;
    }
    else if( msg.startsWith("DIAG:" ) )
    {
      //debugger
      if( this.configDialog )
      {
        this.configDialog.DisplayMsg(msg);
      }
    }
    else if( msg.startsWith("show soe files:"))
    {
      // Display the message for now.
      //alert("Msg: " + msg);
      this.processSOEFiles(msg);
      return;
    }  
    else if( msg.startsWith("-S") )
    {
      this.sessionId = msg.slice(1);

      return;
    }
    else if( msg.startsWith("??"))
    {
      // Display the error.
      var err = msg.slice(2);
      alert("ERROR: " + err);
      return;
    }
    if( msg.startsWith("-[{") )
    {
        console.log('User List: ', msg);
        //alert("Received User List: " + msg);
        this.buildUserList(msg);
    }
    else
    {
      //debugger
      let arr: Array<string> = msg.split(' ');
      let streamid: string = arr[0];
      if( arr[1] == 'forcing')
      {
        // Disable until data is received.
        this.fbutton.disabled = true;
        this.cbutton.disabled = true;

        let arg: string = arr[2];
        if( arg == 'allowed' )
        {
          //alert("Received forcing allowed.");
          this.fbutton.content = "Enable Forcing";
          this.permissions_force = TreeViewComponent.permissions_ALLOWED;
        }
        else if( arg == 'enabled')
        {
          //alert("Received forcing enabled.");
          this.fbutton.content = "Disable Forcing";
          this.permissions_force = TreeViewComponent.permissions_ENABLED;
        }
        else if( arg == 'forbidden')
        {
          // TODO:  Implement This.
          this.fbutton.content = "Enable Forcing";
          this.permissions_force = TreeViewComponent.permissions_FORBIDDEN;

        }
        else if( arg == 'conflict')
        {
          // TODO:  Implement This.
          this.fbutton.content = "Enable Forcing";
          this.fbutton.disabled = true;
          this.cbutton.disabled = true;
          this.permissions_force = TreeViewComponent.permissions_CONFLICT;
        }

        this.setDataViewPermissions();

        return;
      }
      else if( arr[1] == 'executing')
      {
        // Disable until data is received.
        this.ebutton.disabled = true;
        var arg = arr[2];
        if( arg == "allowed" )
        {
            //alert("Received executing allowed.");
            this.ebutton.content = "Enable Executing";
            this.permissions_exec = TreeViewComponent.permissions_ALLOWED;
        }
        else if( arg == "enabled" )
        {
            //alert("Received executing enabled.");
            this.ebutton.content = "Disable Executing";
            this.permissions_exec = TreeViewComponent.permissions_ENABLED;
        }
        else if( arg == "forbidden" )
        {
            this.ebutton.content = "Enable Executing";
            this.permissions_exec = TreeViewComponent.permissions_FORBIDDEN;
        }
        else if( arg == "conflict" )
        {
            this.ebutton.content = "Enable Executing";
            this.permissions_exec = TreeViewComponent.permissions_CONFLICT;
        }

        this.setDataViewPermissions();

        return;
      }
  
      let viewtype: string = arr[1];
      if( viewtype == "data" )
      {
          this.ProcessPointData(msg, arr);
          return;
      }
      else if( viewtype == "comm" )
      {
          this.ProcessCommData(msg, arr);
          return;
      }
      else if( viewtype == "pulse" )
      {
          this.ProcessPulseData(msg, arr);
          return;
      }
      else
      {
          console.log('Invalid View Type: ', viewtype);
          return;
      }
    }
  }


  setDataViewPermissions()
  {
    //alert("Executing setDataViewPermissions.")

    if( this.view != TreeViewComponent.view_DATA)
    {
      //alert("setDataViewPermissions - Not Data View - Returning.")
      return;
    }

    if( this.griddata.length == 0 )
    {
      return;
    }


    if( this.permissions_force == TreeViewComponent.permissions_ALLOWED )
    {
      this.fbutton.content = "Enable Forcing";
      this.fbutton.disabled = false;
      this.cbutton.disabled = true;
      //alert("setDataViewPermissions - Set Forcing to ALLOWED");
    }
    else if( this.permissions_force == TreeViewComponent.permissions_ENABLED )
    {
      this.fbutton.content = "Disable Forcing";
      this.fbutton.disabled = false;
      this.cbutton.disabled = true;
      //alert("setDataViewPermissions - Set Forcing to ENABLED");
    }
    else if( this.permissions_force == TreeViewComponent.permissions_FORBIDDEN )
    {
      this.fbutton.content = "Enable Forcing";
      this.fbutton.disabled = true;
      this.cbutton.disabled = true;
      //alert("setDataViewPermissions - Set Forcing to FORBIDDEN");
    }
    else if( this.permissions_force == TreeViewComponent.permissions_CONFLICT )
    {
      this.fbutton.content = "Enable Forcing";
      this.fbutton.disabled = true;
      this.cbutton.disabled = true;
      //alert("setDataViewPermissions - Set Forcing to CONFLICT");
    }

    if( this.permissions_exec == TreeViewComponent.permissions_ALLOWED )
    {
        this.ebutton.content = "Enable Executing";
        this.ebutton.disabled = false;
        this.permissions_exec = TreeViewComponent.permissions_ALLOWED;
        //alert("setDataViewPermissions - Set Executinging to ALLOWED"); 
    }
    if( this.permissions_exec == TreeViewComponent.permissions_ENABLED )
    {
        this.ebutton.content = "Disable Executing";
        this.ebutton.disabled = false;
        this.permissions_exec = TreeViewComponent.permissions_ENABLED;
        //alert("setDataViewPermissions - Set Executinging to ENABLED"); 
    }
    if( this.permissions_exec == TreeViewComponent.permissions_FORBIDDEN )
    {
        this.ebutton.content = "Enable Executing";
        this.ebutton.disabled = true;
        this.permissions_exec = TreeViewComponent.permissions_FORBIDDEN;
        //alert("setDataViewPermissions - Set Executinging to FORBIDDEN");        
    }
    if( this.permissions_exec == TreeViewComponent.permissions_CONFLICT )
    {
        this.ebutton.content = "Enable Executing";
        this.ebutton.disabled = true;
        this.permissions_exec = TreeViewComponent.permissions_CONFLICT;
        //alert("setDataViewPermissions - Set Executinging to CONFLICT"); 
    }

    this.permissonsSet = true;
  }

  buildUserList(msg: string)
  {
    //debugger
    console.log('Executing buildUserList()');
    if (msg != "error")
    {
      var start = 0;
      //let len:number = 1;
              // TODO: Need to test with multiple users using ConfigAdmin2.
              // TODO: TEST DATA for MULTIPLE USERS
              msg = "-[{\"name\":\"root\", \"address\":\"10.210.3.63\", \"forcing\":\"false\", \"executing\":\"false\"} {\"name\":\"renee\", \"address\":\"10.210.3.63\", \"forcing\":\"false\", \"executing\":\"false\"} {\"name\":\"owl\", \"address\":\"10.210.3.63\", \"forcing\":\"false\", \"executing\":\"false\"}]";
              
              //for (var i = 0; i < len; i++)
              let i=0;
              while(1)
              {
                  i++;                  
                  var lpos = msg.indexOf("{", start);
                  var rpos = msg.indexOf("}", start);
                  if( lpos == -1 || rpos == -1 )
                  {
                      break;
                  }
                  start = rpos+1;

                  var entry = msg.slice(lpos+1, rpos);
                  var tokens = entry.split(",");

                  this.userList[i] = "user " + tokens[0] + " at " + tokens[1];

                  let forcing: boolean = (tokens[2] == "true");
                  let executing: boolean = (tokens[3] == "true");
  
                  // TEST ONLY
                  forcing = true;
                  executing = true;
                  if (forcing)
                  {
                          if (executing)
                          {
                                  this.userList[i] += " (forcing and executing)";
                          }
                          else
                          {
                                  this.userList[i] += " (forcing)";
                          }
                  }
                  else
                  {
                          if (executing)
                          {
                                  this.userList[i] += " (executing)";
                          }
                  }
                  //this.userList += '</li>';
              }
    } 
    else
    {
        this.userList[1] += "<h3>Error fetching users</h3>";
    }

    //debugger
    this.ddUserList = this.users.concat(this.userList);
    //this.ddUsers.dataSource = [];
    this.ddUsers.dataSource = this.ddUserList;
    this.ddUsers.index = 0;
  }


  ProcessPointData(msg: string, arr: Array<string>)
  {
    var datatype = arr[2];

    // Static Data
    if( datatype == 's' )
    {
        this.ProcessStaticData(msg, arr);
    }
    // Dynamic Data
    else if( datatype == 'd' )
    {
        this.ProcessDynamicData(msg, arr);
    }
  }

  ProcessStaticData(msg: string, arr: Array<string>)
  {
      //console.log("ProcessStaticData(): " + msg);

      //debugger
      var first = msg.indexOf('"');
      var last = msg.indexOf('"', first+1);
      var remaining = msg.slice(last+2);
      var toks = remaining.split(' ');

      // Client ID and ied num are sent as hex string so convert to decimal numeric.
      let clientid:number = parseInt(arr[3], 16);
      let iedNum:number = parseInt(arr[4], 16);
      let iedName:string = arr[5];

      // Add to data store.
      let item: any;
      let id: string = arr[6];

      if( id.startsWith("an") )
      {
        //debugger
        // TODO: Need engineering units.  
          item =  { clientid: clientid,
                    ied: iedNum,
                    iedname: iedName,
                    pointid: arr[6],
                    ptname: msg.slice(first+1, last),
                    scale: toks[0],
                    offset: toks[1],
                    highlimit: toks[2],
                    lowlimit: toks[3],
                    raw: 0,
                    units: TreeViewComponent.ENG_UNITS,
                    forced: 0,
                    failed: 0,
                    alarmed: 0,
                    timestamp: new Date(8364186e5),
                    acked: ""        
                  };
      }
      else if( id.startsWith("st") || id.startsWith("co") )
      { 
        var first_0 = msg.indexOf('"', last+1); 
        var last_0 = msg.indexOf('"', first_0+1);

        var first_1 = msg.indexOf('"', last_0+1);
        var last_1 = msg.indexOf('"', first_1+1);

        item =  { clientid: clientid,
                  ied: iedNum,
                  iedname: iedName,
                  pointid: arr[6],
                  ptname: msg.slice(first+1, last),
                  scale: msg.slice(first_0+1, last_0),
                  offset: msg.slice(first_1+1, last_1),
                  highlimit: 0,
                  lowlimit: 0,
                  raw: 0,
                  units: TreeViewComponent.ENG_UNITS,
                  forced: 0,
                  failed: 0,
                  alarmed: 0,
                  timestamp: new Date(8364186e5),
                  acked: ""
                 };
      }
      else if( id.startsWith("ac") )
      {
          item =  { clientid: clientid,
                    ied: iedNum,
                    iedname: iedName,
                    pointid: arr[6],
                    ptname: msg.slice(first+1, last),
                    scale: toks[0],
                    offset: 0,
                    highlimit: 0,
                    lowlimit: 0,
                    raw: 0,
                    units: TreeViewComponent.ENG_UNITS,
                    forced: 0,
                    failed: 0,
                    alarmed: 0,
                    timestamp: new Date(8364186e5),
                    acked: ""
                  };
      }
      else if( id.startsWith("se") )
      {
          item =  { clientid: clientid,
                    ied: iedNum,
                    iedname: iedName,
                    pointid: arr[6],
                    ptname: msg.slice(first+1, last),
                    scale: 0,
                    offset: 0,
                    highlimit: 0,
                    lowlimit: 0,
                    raw: 0,
                    units: TreeViewComponent.ENG_UNITS,
                    forced: 0,
                    failed: 0,
                    alarmed: 0,
                    timestamp: new Date(8364186e5),
                    acked: ""
                  };
      }

      this.AddToGrid(item);
  }

  ProcessDynamicData(msg: string, arr: Array<string>)
  {
    //console.log('dynamic data: ', msg);

    //debugger
    let toks: Array<string> = msg.split(' ');

    // Client ID and ied num are sent as decimal string.
    let clientid:number = parseInt(arr[3], 10);
    let iedNum:number = parseInt(arr[4], 10);
    //let iedName:string = arr[5];

    let id: string = arr[5].trim();
    var pt = this.griddata.find(x=>x.pointid == id && x.clientid == clientid && x.ied == iedNum);

    if( pt == null )
    {
        console.log('ProcessDynamicData - Point Not Found for ID: ', id);
        return;
    }

    //debugger
    pt.raw = arr[6];
    pt.forced = arr[7];
    pt.failed = arr[8];
    pt.alarmed = arr[9];
    pt.acked = arr[10];

    let alarmed:number = parseInt(pt.alarmed.toString());

    if( alarmed > 0 )
    {
      debugger
      if( pt.acked == "0")
      {
        pt.acked = "UNACKED";
      }
      else
      {
        pt.acked = "ACKED";
      }
    }
    else
    {
      pt.acked = "";
    }

    // if( id.startsWith("st") || id.startsWith("co") )
    // {
    //   debugger
    //     var first = msg.indexOf('"');
    //     var last = msg.indexOf('"', first+1);
    //     pt.timestamp = msg.slice(first+1, last);
    // }
    // else
    // {
    //   pt.timestamp  = " ";
    // }

    var first = msg.indexOf('"');
    var last = msg.indexOf('"', first+1);
    pt.timestamp = msg.slice(first+1, last);

    // if( id.startsWith("st"))
    // {
    //   if( pt.forced.toString() != "1")
    //   {
    //     if( pt.raw.toString() == "1" )
    //     {
    //       debugger
    //       pt.alarmed = "1";
    //       if( pt.acked == "" || pt.acked == "1" )
    //       {
    //         pt.acked = "";
    //       }
    //     }
    //   }
    // }
    // if( id.startsWith("an"))
    // {
    //   if( pt.forced.toString() != "1")
    //   {
    //     if( parseInt(pt.raw.toString()) < parseInt(pt.lowlimit.toString()) )
    //     {
    //       pt.alarmed = "2";
    //       if( pt.acked == "")
    //       {
    //         pt.acked = "UNACKED";
    //       }
    //     }
    //     else if( parseInt(pt.raw.toString()) > parseInt(pt.highlimit.toString()) )
    //     {
    //       pt.alarmed = "3";
    //       if( pt.acked == "")
    //       {
    //         pt.acked = "UNACKED";
    //       }
    //     }
    //   }
    // }

    // Reset then update the grid.
    // this.gridInstance.dataSource = [];
    // this.gridInstance.dataSource = this.griddata;
    this.FilterPoints();
    
    let numForced = this.QueryGrid_ForcedPoints();
    if( numForced == 0)
    {
      // Disable Clear Forcing Button
      this.cbutton.disabled = true;
    }
    else
    {
      // Enable Clear Forcing Button.
      this.cbutton.disabled = false;
      //alert("ProcessDynamicData - Clear Forcing Button Enabled.");
    }
  }

  ProcessCommData(msg: string, arr: Array<string>)
  {  
      if( arr.length < 5 )
      {
           console.log('ProcessCommData - Invalid comm data length: ', arr.length);
           return;
      }
  
      let cdata: string = " ";
      let rdata: string = " ";
   
      // Process the cooked data.
      if( arr[4] == "c" )
      {
          this.last_comm_ms = parseInt(arr[2]);
  
          // Build the cooked data string from the remaining tokens.
          for(var i=5; i<arr.length; ++i )
          {
              cdata += arr[i];
              cdata += " ";
          }
  
          //console.log('cdata: ' + cdata);
  
          var isheader = false;
          if( cdata.includes("Application Header"))
          {
             // Mark header entry.
             isheader = true;
          }
  
          let uid: string = arr[2].trim();
          //var dt = new Date(new Date(parseInt(uid)));
          let dt: Date = new Date(parseInt(uid));
  
          let dirtag: string = " ";
          let dir: string = arr[3].trim();
          if( dir == "r" )
          {
              dirtag = TreeViewComponent.DIRTYPE_RECV;
          }
          else if( dir == "s" )
          {
              dirtag = TreeViewComponent.DIRTYPE_SEND;
          }
  
          let item: any =  { id_ts: uid,
                ts_ext: dt.toISOString(),
                dir: dirtag,
                data_raw: rdata,
                data_cooked:  cdata,                   
                type: arr[4].trim(),
                isHeader: isheader,
                isSelected: 'N' };
  
          this.AddToGrid(item, false);
      }
      // // Process the raw data.
      else if( arr[4] == "r" )
      {
        //console.log("ProcessCommData for RawData");

        let tdata: string = "";
        for(var i=5; i<arr.length; ++i )
        {
            // Build the raw data string from the remaining tokens.
            tdata += arr[i];
        }
        // Group the raw hex digits into groups of four.
        for(var i=0; i<tdata.length; ++i )
        {
            var remainder = -1;
            if( i > 0 )
            {
                // Separate into groups of 4 chars.
                var remainder = i%4;
            }
            if( remainder == 0 )
            {
              // Insert a space.
              rdata += " ";
            }
            rdata += tdata[i];
            this.UpdateGrid(true);
            // this.gridInstance.dataSource = [];
            // this.gridInstance.dataSource = this.griddata;
            //console.log("ProcessCommData rdata: " + rdata);
        }

        // Query for the raw data's corresponding cooked header.
        // If found, update the header entry's raw data column.
        // The raw data's corresponding cooked header has the most recent
        // timestamp < the raw data's timestamp and must be the same dir
        // (send or receive) and type = "c".

        // Retrieve all prior cooked header entries of the same dir (send or receive).
        let param_dir: string = arr[3].trim();
        let dir: string = arr[3].trim();
        if( dir == "r" )
        {
            param_dir = TreeViewComponent.DIRTYPE_RECV;
        }
        else if( dir == "s" )
        {
            param_dir = TreeViewComponent.DIRTYPE_SEND;
        }
        
        let param_type: string = "c";
        //console.log("ProcessCommData - param_type: ", param_type);
        let param_ts: string = arr[2].trim();
        //console.log("ProcessCommData - param_ts: ", param_ts);

        //var pts = this.griddata.find(x=>x.type == param_type);
        let results: Array<any> = [];
        for( var i=0; i<this.griddata.length; ++i)
        {
          let ts: any = this.griddata[i].id_ts;

          if( this.griddata[i].id_ts < parseInt(param_ts) &&
              this.griddata[i].isHeader == true &&
              this.griddata[i].type == param_type &&
              this.griddata[i].dir == param_dir )
          {
            results.push(this.griddata[i]);
            //console.log("Point Match inx: ", i);             
          }
        }
        //console.log("Points Found: "+ results);

        let sresults: Array<any> = results.sort((n1,n2) => {
          if (n1.id_ts > n2.id_ts) {
              return -1;
          }
      
          if (n1 < n2) {
              return 1;
          }
      
          return 0;
        });

        // OLD 
        // if( sresults != null && sresults.length > 0 )
        // {
        //     // Retrieve the corresponding (most recent) cooked header.
        //     var item = sresults[0];
        //     if( item != null )
        //     {
        //         // Update the cooked header with the raw data.
        //         item.data_raw += rdata
        //         //console.log("item.data_raw: ", item.data_raw);
              
        //         this.gridInstance.dataSource = [];
        //         this.gridInstance.dataSource = this.griddata;
        //         //console.log("Raw Data Updated for Item: ", item.id_ts);                 
        //     }
        // }

        // Last working 2019-Nov-14:
        // if( sresults != null && sresults.length > 0 ) 
        // { 
        //    var item = sresults[0]; 
        //     if( item != null ) 
        //     { 
        //       item.data_raw += rdata; 
        //       if(this.isManualScroll == false && this.doCharting == true) 
        //       //if(this.isManualScroll == false) 
        //       { 
        //         // Auto scrolling.
        //         this.gridInstance.dataSource = [];  
        //         this.gridInstance.dataSource = this.griddata;
        //         if( this.doCharting == true )
        //         { 
        //           // Charting so Scroll to bottom.
        //           (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight;
        //         } 
        //         this.isManualScroll = false; 
        //       } 
        //       else 
        //       {
        //         // Manual Scrolling. 
        //         if(this.gridInstance.getContent().firstElementChild.clientHeight + this.gridInstance.getContent().firstElementChild.scrollTop >= this.gridInstance.getContent().firstElementChild.scrollHeight) 
        //         {
        //           // At the bottom. 
        //           //this.gridInstance.dataSource = this.griddata; 
        //           //(this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
        //           this.isManualScroll = false; 
        //         } 
        //         else 
        //         { 
        //           //this.HandlePageFault();
        //           return; 
        //         } 
        //       }  
        //     } 
        // }
        

        // Syncfusion recommendation - ticket# 233199
        if( sresults != null && sresults.length > 0 ) 
        { 
           var item = sresults[0]; 
            if( item != null ) 
            { 
              item.data_raw += rdata; 
              this.AddToGrid(item);

              // this.gridInstance.dataSource = [];  
              // this.gridInstance.dataSource = this.griddata; 

              // GRID-PERF-TEST:  
              //  if(!this.isManualScroll) { 
              //     this.gridInstance.dataSource = [];  
              //     this.gridInstance.dataSource = this.griddata; 
              //     (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
              //     this.isManualScroll = false; 
              //   } else { 
              //     if(this.gridInstance.getContent().firstElementChild.clientHeight + this.gridInstance.getContent().firstElementChild.scrollTop >= this.gridInstance.getContent().firstElementChild.scrollHeight) { 
              //       this.gridInstance.dataSource = this.griddata; 
              //       (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
              //       this.isManualScroll = false; 
              //     } else { 
              //       return; 
              //     } 
              //   }  
            } 
        }         



        // Sncfusion DataManager predicate way does not work for me.
        //let predicate: Predicate = new Predicate('type', 'equal', "c");
        //predicate = predicate.and('dir', 'equal', param_dir);
        //predicate = predicate.and('isHeader', 'equal', "true");
        //predicate = predicate.and('id_ts', 'lessthan', param_ts);

        // new DataManager(this.griddata)
        // //.executeQuery(new Query().where(predicate))
        // .executeQuery(new Query().where('type', 'equal', "c"))
        // .then((e: ReturnOption) => this.items = <{[key: string]: Object}[]>e.result).catch((e) => true);
        
        //this.items = new DataManager(this.griddata).executeLocal(new Query());

        // OLD DOJO 1.7 / JS way before Angular:
        // var param_type = "c";
        // var param_ts = arr[2].trim();
        // var uresults = this.griddata.query
        // (
        //         function(element)
        //         {
        //             return element.type == param_type &&
        //             element.dir == param_dir &&
        //             element.isHeader == true &&
        //             element.id_ts < param_ts;
        //         }
        // );
        // // Sort the results in descending order in order to grab the most recent.
        // var sresults = uresults.sort
        // (
        //         function(a, b)
        //         {
        //                 return a.id_ts > b.id_ts ? -1:1;
        //         }
        // );
        // if( sresults != null && sresults.length > 0 )
        // {
        //     // Retrieve the corresponding (most recent) cooked header.
        //     var item = sresults[0];
        //     if( item != null )
        //     {
        //         // Update the cooked header with the raw data.
        //         item.data_raw += rdata;
        //     }
        // }
    }
    return;
  }


ProcessPulseData(msg: string, arr: Array<string>)
{
    //console.log('ProcessPulseData msg: ', msg);
    //alert('ProcessPulseData msg: '+ msg);    

    if( arr.length != 3 )
    {
         console.log('ProcessPulseData - Invalid pulse data length: ', arr.length);
         return;
    }

    let streamId: string = arr[0].trim();
    //console.log('ProcessPulseData - streamId: ', streamId);

    let viewtype: string = arr[1].trim();
    //console.log('ProcessPulseData - viewtype: ', viewtype);

    let nybbles: string = arr[2].trim();
    //console.log('ProcessPulseData - nybbles: ', nybbles);

    let hex_ts: string = nybbles.slice(2, 14);
    //console.log('ProcessPulseData - hex_ts: ', hex_ts);

    let dec_ts: number = parseInt(hex_ts, 16);
    //console.log('ProcessPulseData - dec_ts: ', dec_ts);

    let hex_channel: string = nybbles.slice(0,2);
    //console.log('ProcessPulseData - hex_channel: ', hex_channel);

    let nchannel: number = parseInt(hex_channel, 16);
    //console.log('ProcessPulseData - nchannel: ', nchannel);

    let receive: boolean = false;
    let transmit: boolean = false;

    let dirtag: string;
    if( nchannel == 0 )
    {
        receive = true;
        dirtag = "RX";
    }
    else if( nchannel == 1 )
    {
        transmit = true;
        dirtag = "TX";
    }
    else
    {
        console.log('ProcessPulseData - Invalid nchannel: ', nchannel);
    }

    let hex_state: string = nybbles.slice(14, 16);
    //console.log('ProcessPulseData - hex_state: ', hex_state);

    let nstate: number = parseInt(hex_state, 16);
    //console.log('ProcessPulseData - nstate: ', nstate);

    let pulsestate: string;
    if( nstate == 0 )
    {
        pulsestate = "OFF";
    }
    else if( nstate == 1 )
    {
        pulsestate = "ON";
    }
    else
    {
        console.log('ProcessPulseData - Invalid nstate: ', nstate);
    }
    //console.log('ProcessPulseData - pulsestate: ', pulsestate);

    if( transmit == true )
    {
      if( this.ts_first_tx == 0)
      {
        this.ts_first_tx = dec_ts;
      }
      this.ts_last_tx = dec_ts;

      let pitem:any = { x: new Date(dec_ts), low: 0, high:50 };

      // Update the data grid with the new item.
      this.txData.push(pitem);
      if( this.doCharting )
      {
        this.chartInstance.series[0].dataSource = [];
        this.chartInstance.series[0].dataSource = this.txData;
      }
    } 
    else if( receive == true )
    {
      if( this.ts_first_rx == 0)
      {
        this.ts_first_rx = dec_ts;
      }
      this.ts_last_rx = dec_ts;

      let pitem:any = { x: new Date(dec_ts), low: 50, high:100 };

      // Update the data grid with the new item.
      this.rxData.push(pitem);
      if( this.doCharting == true)
      {  
        this.chartInstance.series[1].dataSource = [];
        this.chartInstance.series[1].dataSource = this.rxData;
      }  
    } 

    // if( this.doCharting == true)
    // {
    //   // Load current chart based on most recent tx/rx pulses.
    //   this.LoadChart_Current();
    //   this.chartInstance.dataBind();
    // }

    return;
}

// Currently running
// AddToGrid(item: any)
// { 
//   if( item == null )
//   {
//     return;
//   }
  
//   this.griddata.push(item);

//   if( this.doCharting == true)
//   {
//     this.gridInstance.getContent().querySelector('.e-content').addEventListener('mousedown', function(e)
//     { 
//       this.isManualScroll = true; 
//     }.bind(this)) 
//     this.gridInstance.getContent().querySelector('.e-content').addEventListener('wheel', function(e)
//     { 
//       this.isManualScroll = true; 
//     }.bind(this)) 

//     // console.log("Current Page: " + this.gridInstance.pageSettings.currentPage);
//     // console.log("Page Count: " + this.gridInstance.pageSettings.pageCount);
//     // console.log("Page Size: " + this.gridInstance.pageSettings.pageSize);
//     // console.log("Total Records Count: " + this.gridInstance.pageSettings.totalRecordsCount);
//     // console.log("Grid Data Records: " + this.griddata.length);

//     if(this.isManualScroll == false) 
//     { 
//       // Auto Scrolling.
//       // this.gridInstance.dataSource = [];  
//       // this.gridInstance.dataSource = this.griddata; 
//       // (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight;       
//       this.isManualScroll = false; 
//     } 
//     else 
//     {
//       //Manual Scroll.
//       if(this.gridInstance.getContent().firstElementChild.clientHeight + this.gridInstance.getContent().firstElementChild.scrollTop >= 
//         this.gridInstance.getContent().firstElementChild.scrollHeight) 
//         { 
//           // Manual Scrolling but at bottom. 
//           //this.gridInstance.dataSource = this.griddata;
//           //(this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
//           this.isManualScroll = false; 
//         } 
//         else 
//         {
//           // Manual Scrolling but not at bottom.
//           return; 
//         } 
//     }     
//   } 
// }

private UpdateGrid(update: boolean)
{
  if( ! update )
  {
    return;
  }

  if( this.view == TreeViewComponent.view_DATA)
  {
    this.gridInstance.dataSource = [];  
    this.gridInstance.dataSource = this.griddata; 
    return;
  }

  // Comm View.
  let scrollTop:number = (this.gridInstance.getContent().firstChild as Element).scrollTop;

  if( this.updateGrid )
  {
    this.gridInstance.dataSource = [];  
    this.gridInstance.dataSource = this.griddata; 
    (this.gridInstance.getContent().firstChild as Element).scrollTop = 
        (this.gridInstance.getContent().firstChild as Element).scrollHeight;
  }
  else
  {
    //debugger
    (this.gridInstance.getContent().firstChild as Element).scrollTop = scrollTop;
  }
}


private AddToGrid(item: any, update=true) 
{ 
  this.griddata.push(item); 
  this.UpdateGrid(update);

  // From Ticket#23319
  // GRID-PERF-TEST:
  // if( this.doCharting == true) 
  // { 
  //   this.griddata.push(item); 
  //     this.gridInstance.getContent().querySelector('.e-content').addEventListener('mousedown', function(e){ 
  //       this.isManualScroll = true; 
  //     }.bind(this)) 
  //     this.gridInstance.getContent().querySelector('.e-content').addEventListener('wheel', function(e){ 
  //       this.isManualScroll = true; 
  //     }.bind(this)) 
 
  //     if(!this.isManualScroll) { 
  //       this.gridInstance.dataSource = [];  
  //       this.gridInstance.dataSource = this.griddata; 
  //       (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
  //       this.isManualScroll = false; 
  //     } else { 
  //       if(this.gridInstance.getContent().firstElementChild.clientHeight + this.gridInstance.getContent().firstElementChild.scrollTop >= this.gridInstance.getContent().firstElementChild.scrollHeight) { 
  //         this.gridInstance.dataSource = this.griddata; 
  //         (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight; 
  //         this.isManualScroll = false; 
  //       } else { 
  //         return; 
  //       } 
  //     } 
  // }  
  // else 
  // { 
  //   this.griddata.push(item); 
  // } 
} 


sendMessageToServer(msg: string)
{
  // Append session id to message.
      msg += " " + this.sessionId;
      this.status = this.wsServiceComm.sendMessage(msg);
}

closeSocket()
{
      this.wsSubscription.unsubscribe();
      this.wsServiceComm.ws.close();
      this.status = "The Socket Is Closed.";
      //alert("Treeview.closeSocket() - Socket Closed.");
}

  ngOnDestroy()
  {
    console.log("Executing TreeView.ngOnDestroy()");
    this.StopStream();
  }


  StopStream()
  {
    if( this.wsSubscription != null )
    {
      // Send stream stop message to the server.
      // let cmd: string = "stream" + " " + this.streamId + " " + "stop" + " " + this.sessionId;    
      let cmd: string = "stream" + " " + this.streamId + " " + "stop";    

      this.sendMessageToServer(cmd);

      // Close the socket.
      this.closeSocket();
    }    
  }


  private OnGridDataBound(args: RowDataBoundEventArgs)
  {
    debugger
    if (this.selIndex.length) 
    {
      this.gridInstance.selectRows(this.selIndex);
      this.selIndex = [];
    }
  }


  private OnGridRowDataBound(args: RowDataBoundEventArgs)
  {
    if( this.view == TreeViewComponent.view_DATA)
    {
      if( args.data['forced'] == "1")
      {
        // Forced Point.
        args.row.setAttribute("bgcolor", TreeViewComponent.COLOR_FORCED);
      }
      else if( args.data['failed'] == "1")
      {
        // Failed Point.
        args.row.setAttribute("bgcolor", TreeViewComponent.COLOR_FAILED);
      }
      else if( args.data['alarmed'] == "1")
      {
        // Alarmed Status Point.
        args.row.setAttribute("bgcolor", TreeViewComponent.COLOR_ALARMED_STATUS);
      }
      else if( args.data['alarmed'] == "2")
      {
        // Alarmed Anlog Low Point.
        args.row.setAttribute("bgcolor", TreeViewComponent.COLOR_ALARMED_LOW);
      }
      else if( args.data['alarmed'] == "3")
      {
        // Alarmed Analog High Point.
        args.row.setAttribute("bgcolor", TreeViewComponent.COLOR_ALARMED_HIGH);
      }
      else
      {
        // Normal Point.
        //args.row.setAttribute("bgcolor", '#E59866');
        args.row.setAttribute("bgcolor", 'lightsalmon');
      }
    }
    //else if( this.view == "comm")
    else if( this.view == TreeViewComponent.view_COMM)
    {
      // GRID-PERF-TEST:
      if( args.data["isSelected"] == 'Y')
      {
        if( args.data["dir"] == TreeViewComponent.DIRTYPE_SEND)
        {
          args.row.setAttribute("bgcolor", this.txColor);
        }
        else if( args.data["dir"] == TreeViewComponent.DIRTYPE_RECV)
        {
          args.row.setAttribute("bgcolor", this.rxColor);
        }

        // debugger
        // args.row.setAttribute("bgcolor", this.selColor);
        // console.log("OnGridRowDataBound Event Fired: " + args.data['isSelected']);
      }
      // if( args.data['dir'] == TreeViewComponent.DIRTYPE_SEND)
      // {
      //   // Send Request: Color is red.
      //   args.row.setAttribute("bgcolor", this.txColor);
      // }
      // else if( args.data['dir'] == TreeViewComponent.DIRTYPE_RECV)
      // {
      //     // Receive Response: Color is green.
      //   args.row.setAttribute("bgcolor", this.rxColor);
      // }

      // GRID-PERF-TEST:
      // if(this.isManualScroll == false && this.doCharting == true) 
      // {
      //   (this.gridInstance.getContent().firstChild as Element).scrollTop = (this.gridInstance.getContent().firstChild as Element).scrollHeight;  
      // }
    }
  }
      
  private OnTreeNodeClick(args: NodeClickEventArgs)
  {
    debugger

      if( this.nodeExpanding || this.nodeCollapsing )
      {
        console.log("TreeViewComponent.OnDeivceTreeNodeClick() - Node Expanding or Collapsing.");
        return;
      }
  
      //alert("Executing OnClick()");
      this.StopStream();
      this.DestroyDataViewButtons();
      this.DestroyKeyButtons();
      this.DestroyGrid();
      this.DestroyChart();

      //debugger
      this.id = args.node.getAttribute("data-uid");
      if( ! this.id )
      {
        console.log("TreeViewComponent.OnClick() - Undefined nodeid retrieved from NodeClickEventsArgs.")
        return;
      }

      console.log("node id" + this.id);

      if( this.id == "2")
      {
        this.id = "all";
        this.view = TreeViewComponent.view_DATA;
        this.streamId ++;

        // TEST ONLY:
        //this.id = "1632:1";
        //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
        var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;
        console.log("OnTreeNoveClick() - cmd: " + cmd)

        this.CreateGrid();
        
        // Create the forcing/clear forcing/executing toggle buttons.
        this.CreateDataViewButtons();
        this.CreateKeyButtons();

        // Enable the radio buttons
        this.DisableRadioButtons(false);

        // Disable/hide the scroll radio buttons
        this.DisableRadioButtons_Scroll(true);

        this.wsSubscription = this.wsServiceComm.createObservableSocket(
          this.url_commServer, cmd).subscribe(
            data=>this.handleCommMessage(data),
            // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
            err=>this.Cleanup(),
            // err=>{this.DestroyControls();
            //       this.router.navigateByUrl('/app');
            //     }, 
            ()=>
            { }
        );

        return; 
      }
  
      var node = this.xmlData.getElementById(this.id);
      console.log("OnClick() - node: " + node);

      if( ! node)
      {
        console.log("TreeViewComponent.OnClick() - Undefined node retrieved from xmlData for id: ", this.id)
        return;
      }
      
      this.view = node.getAttribute("view");
      if( ! this.view )
      {
        console.log("TreeViewComponent.OnClick() - Undefined view attribute retrieved from xmlData node for id: ", this.id)
        return;
      }
      console.log("Node View Type: " + this.view);
  
      this.streamId ++;

      if( this.view == TreeViewComponent.view_DATA)
      {    
        // TEST ONLY:
        //this.id = "1632:1";
        //var cmd = "stream " + this.streamId.toString() + " " + "data" + " " + this.id;
        var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

        this.CreateGrid();
       
        // Create the forcing/clear forcing/executing toggle buttons.
        this.CreateDataViewButtons();
        this.CreateKeyButtons();

        // Enable the radio buttons
        this.DisableRadioButtons(false);

        // Disable/hide the scroll radio buttons
        this.DisableRadioButtons_Scroll(true);
      }
      else if( this.view == TreeViewComponent.view_COMM)
      {
        //this.id = "6:0";    
        //var cmd = "stream " + this.streamId.toString() + " " + "comm" + " " + this.id;
        let pos:number = this.id.indexOf(':');
        if( pos < 0 )
        {
          this.id += ":0";
        }
        var cmd = "stream " + this.streamId.toString() + " " + this.view + " " + this.id + " " + this.sessionId;

        this.CreateGrid();

        // this.DestroyDataViewButtons(); 

        this.CreateChart();

        // Hide/disable the radio buttons.
        this.DisableRadioButtons(true);

        // Enable the scroll radio buttons
        this.DisableRadioButtons_Scroll(false);
      }
  
      this.wsSubscription = this.wsServiceComm.createObservableSocket(
        this.url_commServer, cmd).subscribe(
          data=>this.handleCommMessage(data),
          // err=>alert('ERROR: Unable to Connect to server: ' + this.url_commServer),
          err=>this.Cleanup(),
          // err=>{this.DestroyControls();
          //   this.router.navigateByUrl('/app');
          // }, 
          ()=>
          { }
      );
}


private OnGridRowCellSelected(args: any)
{
  debugger
  console.log('Executing OnGridRowCellSelected().');
  if(args.cellIndex.cellIndex == TreeViewComponent.COL_ACKED)
  {
    if( args.data.alarmed != "0" )
    {
      if( args.data.acked == "UNACKED")
      {
        let rowinx = this.GetPointIndex(args.data.pointid);
        if( rowinx >= 0 )
        {
          // Send ack command to server.
          let cmd:string = "ack " + args.data.pointid;
          this.sendMessageToServer(cmd);
        }
      }
    }
  }
}

private GetPointIndex(id:string): number
{ 
  for( let i:number=0; i<this.griddata.length; ++i)
  {
    let item = this.griddata[i];
    if( item.pointid == id )
    {
      return i;
    }    
  }

  return -1;
}


private OnAckAll()
{ 
  for( let i:number=0; i<this.griddata.length; ++i)
  {
    let item = this.griddata[i];
    if( item.acked == "UNACKED" )
    {
      // Send ack command to server.
      let cmd:string = "ack " + item.pointid;
      this.sendMessageToServer(cmd);
    }    
  }

  this.gridInstance.dataSource = [];
  this.gridInstance.dataSource = this.griddata;
}


private OnGridRowSelected(args: any )
{
  //alert("OnGridRowSelected() for: " + args.data.pointid);
  //debugger

  if( args.target.cellIndex == TreeViewComponent.COL_ACKED)
  {
    console.log("Ack Column Selected");
    return;
  }

  console.log('Executing OnGridRowSelected().');
  if( args.data.pointid.startsWith("st") ||
      args.data.pointid.startsWith("an") ||
      args.data.pointid.startsWith("ac") )
  {
      console.log("Found st/an/ac type point.");
      if( this.IsForcingEnabled() == true )
      {
          console.log("Forcing is Enabled.");
          this.ShowForceDialog(args.data);
      }
      else
      {
          alert("Forcing Must Be Enabled.");
      }
  }
  else if( args.data.pointid.startsWith("co") ||
            args.data.pointid.startsWith("se") )
  {
      console.log("Found co/se type point.");
      if( this.IsExecutingEnabled() == true )
      {
          console.log("Executing is Enabled.");
          this.ShowExecuteDialog(args.data);
          //this.ShowConfirmExecuteDialog(args.data)
      }
      else
      {
          alert("Executing Must Be Enabled.");
      }
  }
}

private IsForcingEnabled(): boolean
{
    if( this.fbutton == null )
    {
      return false;
    }

    if( this.fbutton.content.startsWith("Disable") )
    {
      return true;
    }

    return false;
}


private IsExecutingEnabled(): boolean
{
    if( this.ebutton == null )
    {
      return false;
    }

    if( this.ebutton.content.startsWith("Disable"))
    {
      return true;
    }

    return false;
}

private ShowForceDialog(row: any)
{
  let tb_Value: TextBox;
  let tb_PointId: TextBox;
  let tb_PointName: TextBox;
  let tb_PointType: TextBox;
  let tb_PointStatus: TextBox;


  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='forceForm'> 
  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointId" name="PT ID: " />
        <div id="ptidError" class="error"></div> 
    </div>

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointName" name="PT NAME: " /> 
        <div id="ptnameError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointType" name="TYPE: " /> 
        <div id="pttypeError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointStatus" name="STATUS: " /> 
        <div id="ptstatusError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="forceValue" name="Force Value" /> 
        <div id="userError" class="error"></div> 
    </div> 
  </div> 


  </form> 
  </div> 
  </div>` 

  let dialog: Dialog = new Dialog({ 
    header: 'Forcing Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {
          var cmd = "force " + tb_PointId.value + " " + tb_Value.value;
        
          this.sendMessageToServer(cmd);
          console.log('ForceDialog() - Cmd Sent: ', cmd);

          dialog.destroy();
        },

        buttonModel: 
        { 
            content: 'Force To Raw', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }

    },
    { 
      'click': () => 
      {
        var cmd = "clear " + tb_PointId.value;
        this.sendMessageToServer(cmd);
        console.log('ForceDialog() - Cmd Sent: ', cmd);

        dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Clear Force', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }

  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#authdialog'); 

  function onDialogCreate(args) 
  {
    //alert("Executing onDialogCreate()");

    tb_Value = new TextBox({ 
       
      
      placeholder: 'Force Value', 
        floatLabelType: 'Always' 
    }); 
    tb_Value.appendTo('#forceValue'); 

    tb_PointId = new TextBox({ 
        placeholder: 'Point Id', 
        floatLabelType: 'Always', 
    });     
    tb_PointId.appendTo('#pointId');  
    tb_PointId.readonly = true;  

    tb_PointName = new TextBox({ 
      placeholder: 'Point Name', 
      floatLabelType: 'Always', 
    });     
    tb_PointName.appendTo('#pointName');
    tb_PointName.readonly = true;    

    tb_PointType = new TextBox({ 
      placeholder: 'Point Type', 
      floatLabelType: 'Always', 
    });     
    tb_PointType.appendTo('#pointType');
    tb_PointType.readonly = true;    

    tb_PointStatus = new TextBox({ 
      placeholder: 'Point Status', 
      floatLabelType: 'Always', 
    });     
    tb_PointStatus.appendTo('#pointStatus');
    tb_PointStatus.readonly = true;    

    var display = " ";
    var pttype = " ";
    var flstatus = "";

    if( row.pointid.startsWith("an") )
    {
        pttype = "Analog";
    }
    else if( row.pointid.startsWith("st") )
    {
        pttype = "Status";
    }
    else if( row.pointid.startsWith("co") )
    {
        pttype = "Control";
    }
    else if( row.pointid.startsWith("se") )
    {
        pttype = "Setpoint";
    }
    else if( row.pointid.startsWith("ac") )
    {
        pttype = "Accumulator";
    }

    if( row.forced == "1" )
    {
        flstatus = "forced";
    }
    else if( row.forced == "0" )
    {
        flstatus = "unforced";
    }

    tb_PointType.value = pttype;
    tb_PointId.value = row.pointid;
    tb_PointName.value = row.ptname;
    tb_PointStatus.value = flstatus;
    tb_Value.value = row.raw;
  } 

  function onDialogOpen()
  {
    //alert("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    //alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


private ShowExecuteDialog(row: any)
{
  let tb_Value: TextBox;
  let tb_PointId: TextBox;
  let tb_PointName: TextBox;
  let tb_PointType: TextBox;

  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='forceForm'> 
  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointId" name="PT ID: " />
        <div id="ptidError" class="error"></div> 
    </div>

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointName" name="PT NAME: " /> 
        <div id="ptnameError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="pointType" name="TYPE: " /> 
        <div id="pttypeError" class="error"></div> 
    </div> 
  </div> 

  <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="executeValue" name="Execute Value" /> 
        <div id="userError" class="error"></div> 
    </div> 
  </div> 


  </form> 
  </div> 
  </div>` 

  let dialog: Dialog = new Dialog({ 
    header: 'Execute Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {
          let value: string = tb_Value.value; 
          //alert('Execute Value: ' + value); 
          console.log('Execute Value: ' + value); 

          // Destory first execute dialog.
          dialog.destroy();

          // Show Confirm Execute Dialog.
          this.ShowConfirmExecuteDialog(tb_PointId.value, tb_Value.value);
        },

        buttonModel: 
        { 
            content: 'Execute Value', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }

    },
    { 
      'click': () => 
      {
          dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Cancel', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }
  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#authdialog'); 

  function onDialogCreate(args) 
  {
    // alert("Executing onDialogCreate()");

    tb_Value = new TextBox({ 
        placeholder: 'Execute Value', 
        floatLabelType: 'Always' 
    }); 
    tb_Value.appendTo('#executeValue'); 

    tb_PointId = new TextBox({ 
        placeholder: 'Point Id', 
        floatLabelType: 'Always', 
    });     
    tb_PointId.appendTo('#pointId');  
    tb_PointId.readonly = true;  

    tb_PointName = new TextBox({ 
      placeholder: 'Point Name', 
      floatLabelType: 'Always', 
    });     
    tb_PointName.appendTo('#pointName');
    tb_PointName.readonly = true;    

    tb_PointType = new TextBox({ 
      placeholder: 'Point Type', 
      floatLabelType: 'Always', 
    });     
    tb_PointType.appendTo('#pointType');
    tb_PointType.readonly = true;
    
    var display = " ";
    var pttype = " ";
    var flstatus = "";

    if( row.pointid.startsWith("an") )
    {
        pttype = "Analog";
    }
    else if( row.pointid.startsWith("st") )
    {
        pttype = "Status";
    }
    else if( row.pointid.startsWith("co") )
    {
        pttype = "Control";
    }
    else if( row.pointid.startsWith("se") )
    {
        pttype = "Setpoint";
    }
    else if( row.pointid.startsWith("ac") )
    {
        pttype = "Accumulator";
    }

    if( row.forced == "1" )
    {
        flstatus = "forced";
    }
    else if( row.forced == "0" )
    {
        flstatus = "unforced";
    }

    // Populate the text box fields.
    tb_PointType.value = pttype;
    tb_PointId.value = row.pointid;
    tb_PointName.value = row.ptname;
    tb_Value.value = row.raw;    
  } 

  function onDialogOpen()
  {
    //alert("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    // alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


private ShowConfirmExecuteDialog(id: string, value: string)
{
  let dialogContent: string = "Are You Sure?";

  let dialog: Dialog = new Dialog({ 
    header: 'Execute Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {
          let cmd: string = "execute " + id + " " + value;
        
          this.sendMessageToServer(cmd);
          console.log('ShowAuthDialog() - Cmd Sent: ', cmd);
          dialog.destroy();
        },

        buttonModel: 
        { 
            content: 'Execute', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }
    },
    { 
      'click': () => 
      {
          dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Cancel', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }
  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#authdialog'); 

  function onDialogCreate(args) 
  {
    console.log("Executing onDialogCreate()");
  } 

  function onDialogOpen()
  {
    console.log("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    // alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}

private DestroyTreeView()
{
  if( this.treeViewInstance != null)
  {
    this.treeViewInstance.destroy();    
    this.treeViewInstance = null;
  }
}

public GetTreeData(): Array<any>
{
  return this.treedata
}

private CreateTreeView()
{
  //alert("Executing CreateTreeView()");
  this.treeViewInstance = new TreeView({
    fields: { dataSource: this.treedata, id: 'id', text: 'label', 
    child: 'subChild', imageUrl: 'image', iconCss: 'icon', hasChildren: 'hasChild'}
  });  

  //Render initialized TreeView
  this.treeViewInstance.appendTo("#treeview");
  document.getElementById("treeview").style.overflow = "inherit";
  
  // Bind the OnClick Event and parent class (TreeViewComponent) to the callback.
  this.treeViewInstance.nodeClicked=this.OnTreeNodeClick.bind(this);
  this.treeViewInstance.nodeExpanded=this.OnDeviceTreeNodeExpanded.bind(this);
  this.treeViewInstance.nodeCollapsed=this.OnDeviceTreeNodeCollapsed.bind(this);
  this.treeViewInstance.nodeExpanding=this.OnDeviceTreeNodeExpanding.bind(this);
  this.treeViewInstance.nodeCollapsing=this.OnDeviceTreeNodeCollapsing.bind(this);
  //this.treeViewInstance.setProperties({'height': 900})
}

// Tree View Node Expanded Callback.
OnDeviceTreeNodeExpanded(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardComponent.OnDeviceTreeNodeExpanded().");
    this.nodeExpanding = false;
    this.nodeExpanded = true;
    this.nodeCollapsing = false;
    this.nodeCollapsed= false;
}

// Tree View Node Expanding Callback.
OnDeviceTreeNodeExpanding(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardComponent.OnDeviceTreeNodeExpanding().");
    this.nodeExpanding = true;
    this.nodeExpanded = false;
    this.nodeCollapsing = false
    this.nodeCollapsed= false;
}


// Tree View Node Collapsed Callback.
OnDeviceTreeNodeCollapsed(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardCompoent.OnDeviceTreeNodeCollapsed()");
    this.nodeExpanding = false;
    this.nodeExpanded = false;
    this.nodeCollapsing = false
    this.nodeCollapsed= true;
  }

// Tree View Node Collapsing Callback.
OnDeviceTreeNodeCollapsing(args: NodeClickEventArgs)
{
    console.log("Executing DrawingBoardComponent.OnDeviceTreeNodeCollapsing()");
    this.nodeExpanding = false;
    this.nodeExpanded = false;
    this.nodeCollapsing = true;
    this.nodeCollapsed= false;
}


private DestroyGrid()
{
  if( this.gridInstance != null)
  {
    this.gridInstance.dataSource = [];
    this.gridInstance.destroy();
    this.gridInstance = null;
  }
}

private DestroyChart()
{
  if( this.chartInstance != null)
  {
    this.chartInstance.series[0].dataSource = [];
    this.chartInstance.series[1].dataSource = [];
    this.chart1Data = [];
    this.chart2Data = [];
    this.txData = [];
    this.rxData = [];
    this.chartInstance.destroy();
    this.chartInstance = null;
  }
}


private CreateGrid()
{  
  //if( this.view == "data")
  if( this.view == TreeViewComponent.view_DATA)
  {
    this.griddata = [];

    this.gridInstance = new Grid({
      dataSource: this.griddata,
      //editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, newRowPosition: 'Bottom' },
      allowSorting: true,
      allowSelection: true,
      pageSettings: { pageSize: 100 },
      gridLines: 'Both',
      enableHover: true,
      selectionSettings: {type: 'Single', mode: 'Both'},
      enableVirtualization: true,
      allowPaging: false,
      cellSelected: this.OnGridRowCellSelected.bind(this),
      rowSelected: this.OnGridRowSelected.bind(this),
      rowDataBound: this.OnGridRowDataBound.bind(this), 
      rowHeight: 15,
      // dataStateChange: this.OnDataStateChange.bind(this),
      columns: [
          { field: 'clientid', headerText: 'Client ID', textAlign: 'Right', width: 25, isPrimaryKey: true, visible: false },
          { field: 'ied', headerText: 'IED', textAlign: 'Right', width: 25, isPrimaryKey: true, visible: false },
          { field: 'iedname', headerText: 'IED Name', textAlign: 'Right', width: 50, isPrimaryKey: false },
          { field: 'pointid', headerText: 'Point ID', textAlign: 'Right', width: 25, isPrimaryKey: true },
          { field: 'ptname', headerText: 'Point Name', width: 100 },
          { field: 'scale', headerText: 'scale', width: 25, visible: false},
          { field: 'offset', headerText: 'offset', width: 25, visible: false},
          { field: 'highlimit', headerText: 'high', width: 25, visible: false},
          { field: 'lowlimit', headerText: 'low', width: 25, visible: false},
          { field: 'raw', headerText: 'Raw', textAlign: 'Right', width: 25 },
          { field: 'units', headerText: 'units', width: 25, visible: false},
          { field: 'forced', headerText: 'Forced', textAlign: 'Right', width: 25, visible: false },
          { field: 'failed', headerText: 'Failed', textAlign: 'Right', width: 25, visible: false },
          { field: 'alarmed', headerText: 'Alarmed', textAlign: 'Right', width: 25, visible: true },
          { field: 'timestamp', headerText: 'Timestamp', textAlign:'Left', format: 'M/d/y hh:mm' , width: 40 },
          { field: 'acked', headerText: 'Acked', textAlign: 'Right', width: 25, visible: true },
      ],
      width: '100%',    
      height: '100%'
    });
    this.gridInstance.appendTo('#grid');
  }
  //else if( this.view == "comm")
  else if( this.view == TreeViewComponent.view_COMM)
  {
    this.griddata = [];
    this.gridInstance = new Grid({
      dataSource: this.griddata,
      allowSorting: false,
      gridLines: 'Both',
      enableHover: true,
      allowPaging: false,
      enableVirtualization: true,
      rowHeight: 15,
      //dataBound: this.OnGridDataBound.bind(this),
      rowDataBound: this.OnGridRowDataBound.bind(this),
      //dataStateChange: this.OnDataStateChange.bind(this),
      columns: [
        { field: 'id_ts', headerText: 'Timestamp', width: 0, textAlign: 'Right', isPrimaryKey: true, visible: false  },
        { field: 'ts_ext', headerText: 'Date/Time', width: 210 },
        { field: 'dir', headerText: '', width: 100},
        { field: 'type', headerText: '', width: 0, visible: false },
        { field: 'data_raw', headerText: 'Raw Data', width: 450 },
        { field: 'data_cooked', headerText: 'Analyzed Data', width: 500 },
        { field: 'isHeader', headerText: '', width: 0, visible: false },
        { field: 'isSelected', headerText: '', width: 0, visible: false }
      ],
      //height: 575
      //height: 715
      height: '100%',
      width: '100%'
    });
    this.gridInstance.appendTo('#grid');
  }
}

// CreateCommDataObservable()
// {
//     // Create Observable for comm data received.
//     return new Observable((observer) => {
//       // Observable execution.
//       observer.next(this.griddata.shift())
//       observer.complete()      
//     })
// }

// HandleCommSubscription(item: any)
// {
//   console.log("Executing HandleCommSubscription.")
//   // Returns the comm message that should be added to the grid.
// }

private CreateChart()
{
  let dt:Date = new Date();
  let ts:number = dt.getTime();
  let pointClick: EmitType<IPointEventArgs> = (args: IPointEventArgs) => {

  //alert("Series index: " + args.seriesIndex+'\n' + 'Point index: ' + args.pointIndex + '\n' + 'Point value: ' + args.point.xValue); 
  let pointElement = document.getElementById((args.series as Series).chart.element.id + '_Series_'+ args.seriesIndex+'_Point_' + args.pointIndex); 
  let className: string = pointElement.getAttribute('class'); 
  if ((className != null) && (className.indexOf('deselected')>=0))
  { 
    // Chart point deselected:
    console.log('point deselected: ' + args.pointIndex);

    // Set all chart points to full opacity.
    this.chartInstance.series[0].opacity = 1;
    this.chartInstance.series[1].opacity = 1;
    
    // Clear any selected grid rows. 
    this.QueryGrid_ClearSelected();
    // let scrollState: boolean = this.isManualScroll;
    // this.isManualScroll = false;
    // this.gridInstance.dataSource = [];
    // this.gridInstance.dataSource = this.griddata;
    // this.isManualScroll = scrollState;
    // Resume charting.
    // this.doCharting = true;

    // this.updateGrid = true;
    // this.rb_auto.checked = true;
    // this.rb_manual.checked = false;
    // this.DisableRadioButtons_Scroll(false);
  } 
  else 
  {
    console.log('point selected: ' + args.pointIndex);
    this.QueryGrid_ClearSelected();

    // Stop charting.
    // this.doCharting = false;
    // this.updateGrid = false;
    // this.rb_auto.checked = false;
    // this.rb_manual.checked = true;
    // this.DisableRadioButtons_Scroll(true);

    // Find the corresponding grid row(s) and hightlight them. 
    this.QueryGridData(args.point.xValue, args.seriesIndex); 
  } 
 }; 
  pointClick = pointClick.bind(this); 

  //this.doCharting = true;
  //console.log("CreateChart() - Set charting to true - initial.");
  
  this.chartInstance = new Chart({
    //title: "Pulse Timeline",
    //enableAutoIntervalOnZooming: true,
    tooltip: { enable: true },
        tooltipRender:(args: ITooltipRenderEventArgs) => {  
        //  Format the current point x value
        let toks = new Date(args.point.x.toString()).toISOString().split('T')[1];
        args.text=toks.split('.')[0];
        },
    crosshair: {enable: false, lineType: 'Vertical'},
    selectionMode: 'Point',
    background: '#D6DBDF',
    border: {color: "gray", width: 2},
    height: '150px',
    legendSettings: {
      visible: true,
      position: 'Left'
      //position:'Custom',
      //location: { x: 20, y: 100 } 
      },
    primaryXAxis:{
      //title: "timeline",
      valueType: 'DateTime',
      labelFormat: 'hh:mm:ss',
      intervalType: 'Seconds',
      edgeLabelPlacement: 'Shift',    
      crosshairTooltip: { enable: true },
      majorGridLines: { width: 0 },
      zoomFactor: 1.0,
       scrollbarSettings: { 
        enable: false
      }    
    },
    primaryYAxis:{
        //crosshairTooltip: { enable: true },
        labelFormat: '',
        rangePadding: 'None',
        minimum: 0,
        maximum: 100,
        lineStyle: { width: 0 },
        majorTickLines: { width: 0 },
        minorTickLines: { width: 0 },
    },
    series:[{
      dataSource: this.chart1Data,
      type: 'RangeColumn',
      columnWidth: 0.3,
      xName: 'x',
      yName:'y',
      low: 'low',
      high: 'high',
      name:'TX',
      fill: this.txColor,
      marker: { visible: false }
    },
    {
      dataSource: this.chart2Data,
      type: 'RangeColumn',
      columnWidth: 0.3,
      xName: 'x',
      yName:'y',
      low: 'low',
      high: 'high',
      name:'RX',
      fill: this.rxColor,
      marker: { visible: false }
    }],
    zoomSettings:
    {
        enableMouseWheelZooming: true,
        enableSelectionZooming: true,
        enablePan: true,
        enableScrollbar: true,
        mode: 'X'
    },
    // scrollChanged: (args: IScrollEventArgs) => 
    // {
    //     //this.doCharting = false;

    //     //console.log("Zoom Position: " + args.zoomPosition + "  Zoom Factor: " + args.zoomFactor);
    //     //alert("Zoom Position: " + args.zoomPosition + "\n" + "Zoom Factor: " + args.zoomFactor);

    //     if( args.zoomPosition >= 0.900)
    //     {
    //       // Load current chart based on most recent tx/rx pulses.
    //       this.LoadChart_Current();
    //       this.chartInstance.dataBind();

    //       //console.log("Page Count: " + this.gridInstance.pageSettings.pageCount);
    //       //this.gridInstance.goToPage(this.gridInstance.pageSettings.pageCount);
        
    //       // Resume charting.
    //       //this.doCharting = true;

    //       //this.updateGrid = true;
    //       //this.doCharting = true;

    //       //return;
    //     }

    //     // Load historical chart based on scroll position.
    //     this.LoadChart_Historical(args.zoomPosition);    
    //     this.chartInstance.dataBind();
    // },
    legendRender:(args: ILegendRenderEventArgs)=> {
      if (args.text == 'TX') {
        args.text = 'RX';
        args.fill = 'green';
      } 
      else {
        args.text = 'TX';
        args.fill = 'red';
      }
     },
    axisLabelRender:(args: IAxisLabelRenderEventArgs)=>{ 
        if(args.axis.orientation==="Horizontal")
        { 
          // Convert X-axis timestamps to ISO time.
          let toks = new Date(args.value).toISOString().split('T')[1];
          args.text=toks.split('.')[0];
        } 
        else if(args.axis.orientation==="Vertical")
        {
          // No labels for Y-axis. 
          args.text="";
        }  
      },
      pointClick: pointClick  
  });
  this.chartInstance.appendTo('#container');
  //this.chartInstance.appendTo('#grp1');
}

public legend: Object = { 
  position: 'Custom', 
  location: { x: 30, y: 200 } 
} 


// Load current chart based on most recent tx/rx pulses.
// private LoadChart_Current()
// {  
//   let max_ts_tx = this.ts_last_tx;
//   let min_ts_tx = max_ts_tx - this.max_chart_ms;
//   console.log("LoadChart_Current for min_ts_tx: " + min_ts_tx + "  max_ts_tx: " + max_ts_tx);

//   if(min_ts_tx < this.ts_first_tx)
//   {
//     // Reset to the earliest pulse time.
//     min_ts_tx = this.ts_first_tx;
//     max_ts_tx = min_ts_tx + this.max_chart_ms;
//     console.log("LoadChart_Current - min_ts_tx: " + min_ts_tx + "< max_ts_tx: " + max_ts_tx);
//   }
//   this.LoadTXData(min_ts_tx, max_ts_tx);

//   let max_ts_rx = this.ts_last_rx;
//   let min_ts_rx = max_ts_rx - this.max_chart_ms;
//   console.log("LoadChart_Current for min_ts_rx: " + min_ts_rx + "  max_ts_rx: " + max_ts_rx);

//   if(min_ts_rx < this.ts_first_rx)
//   {
//     // Reset to the earliest pulse time.
//     min_ts_rx = this.ts_first_rx;
//     max_ts_rx = min_ts_tx + this.max_chart_ms;
//     console.log("LoadChart_Current - min_ts_rx: " + min_ts_rx + "< max_ts_rx: " + max_ts_rx);
//   }
//   this.LoadRXData(min_ts_rx, max_ts_rx);
  
//   this.chartInstance.primaryXAxis.zoomFactor = this.max_chart_min / (this.txData as object[]).length;
//   this.chartInstance.primaryXAxis.zoomPosition = (1 / (this.txData as object[]).length) *
//     ((this.txData as object[]).length - this.max_chart_min); 
// }

// //Load grid data based on chart scroll position.
// private LoadGrid_ManualScroll(pct: number)
// {
//   console.log("Executing LoadGrid_ManualScroll() for pct: " + pct);

//   // Number of records to skip from begining of graddata store.
//   let ntot = this.griddata.length;
//   let nload = Math.floor(ntot * pct);
//   let nskip = ntot - nload;

//   this.commdata = [];
//   for( var i=0; i<this.griddata.length; ++i)
//   {
//     if( i > nskip )
//     {
//       this.commdata.push(this.griddata[i]);
//     }
//   }

//   console.log("# Comm Records Pushed: ", this.commdata.length);             

//   this.gridInstance.dataSource = [];
//   this.gridInstance.dataSource = this.commdata;
// }

// Load historical chart based on given scroll position.
// private LoadChart_Historical(scrollPct: number)
// {
//   let tot_ms_tx = this.ts_last_tx - this.ts_first_tx;
//   let span_ms_tx = Math.floor(tot_ms_tx * scrollPct);
//   let max_ts_tx = this.ts_first_tx + span_ms_tx;
//   let min_ts_tx: number = max_ts_tx - this.max_chart_ms;
//   console.log("LoadChart_Historical for min_ts_tx: " + min_ts_tx + "  max_ts_tx: " + max_ts_tx);

//   if(min_ts_tx < this.ts_first_tx)
//   {
//     // Reset to the earliest pulse time.
//     min_ts_tx = this.ts_first_tx;
//     max_ts_tx = min_ts_tx + this.max_chart_ms;
//     console.log("LoadChart_Historical - min_ts_tx: " + min_ts_tx + "< max_ts_tx: " + max_ts_tx);
//   }      
//   this.LoadTXData(min_ts_tx, max_ts_tx);

//   let tot_ms_rx = this.ts_last_rx - this.ts_first_rx;
//   let span_ms_rx = Math.floor(tot_ms_rx * scrollPct);
//   let max_ts_rx = this.ts_first_rx + span_ms_rx;
//   let min_ts_rx: number = max_ts_rx - this.max_chart_ms;
//   console.log("LoadChart_Historical for min_ts_rx: " + min_ts_rx + "  max_ts_rx: " + max_ts_rx);

//   if(min_ts_rx < this.ts_first_rx)
//   {
//     // Reset to the earliest pulse time.
//     min_ts_rx = this.ts_first_rx;
//     max_ts_rx = min_ts_rx + this.max_chart_ms;
//     console.log("LoadChart_Historical - ts_min: " + min_ts_rx + "< ts_earliest: " + max_ts_rx);
//   }      
//   this.LoadRXData(min_ts_rx, max_ts_rx);

//   this.chartInstance.primaryXAxis.zoomFactor = this.max_chart_min / (this.txData as object[]).length;
//   this.chartInstance.primaryXAxis.zoomPosition = (1 / (this.txData as object[]).length) *
//     ((this.txData as object[]).length - this.max_chart_min);    

//   //this.LoadGrid_ManualScroll();
// }

// Load transmit chart data based on min/max timestamps in ms.
// private LoadTXData(ts_min: number, ts_max: number)
// {
//   this.chart1Data = [];
//   for( var i=0; i<this.txData.length; ++i)
//   {
//     let element: any = this.txData[i]; 
//     let dt: Date = element.x;
//     let ts: number = dt.getTime();
//     console.log("QueryTXData ts: ", ts);

//     if( ts >= ts_min && ts <= ts_max )
//     {
//       this.chart1Data.push(this.txData[i]);
//       console.log("Pushed TX Pulse ts: ", ts);             
//     }
//   }
//   this.chartInstance.series[0].dataSource = [];
//   this.chartInstance.series[0].dataSource = this.chart1Data;
// }

// Load receive chart data based on min/max timestamps in ms.
// private LoadRXData(ts_min: number, ts_max: number)
// {
//   this.chart2Data = [];
//   for( var i=0; i<this.rxData.length; ++i)
//   {
//     let element: any = this.rxData[i]; 
//     let dt: Date = element.x;
//     let ts: number = dt.getTime();
//     console.log("QueryRXData ts: ", ts);

//     if( ts >= ts_min && ts <= ts_max )
//     {
//       this.chart2Data.push(this.rxData[i]);
//       console.log("Pushed RX Pulse ts: ", ts);             
//     }
//   }
//   this.chartInstance.series[1].dataSource = [];
//   this.chartInstance.series[1].dataSource = this.chart2Data;
// }


private QueryGridData(key_ts: number, ntype: number)
{
  let key_type: string = "";
  if( ntype == 0)
  {
    key_type = TreeViewComponent.DIRTYPE_SEND;
  }
  else if( ntype === 1)
  {
    key_type = TreeViewComponent.DIRTYPE_RECV;
  }
  else
  {
    console.log("QueryGridData() - Invaid xmit type: " + ntype);
    return;
  }

  if( ! this.QueryGrid_ExactRecords(key_ts, key_type))
  {
    let ts1: number = this.QueryGrid_PrevHeader(key_ts, key_type);
    let ts2: number = this.QueryGrid_NextHeader(key_ts, key_type);

    let diff1:number = 0;
    let diff2:number = 0;

    if( key_ts >= ts1 )
    {
      let diff1: number = key_ts - ts1;
    }
    if( ts2 >= key_ts )
    {
      let diff2: number = ts1 - key_ts;
    }

    this.QueryGrid_IntermediateRecords(ts1, ts2, key_type);
  }
}


private QueryGrid_ExactRecords(key_ts: number, key_type: string)
{
  let first: number = -1;

  console.log("QueryGrid_ExactRecords - Grid Length: " + this.griddata.length);


  for( var i=0; i<this.griddata.length; ++i)
  {
    if( this.griddata[i].dir == key_type &&
        this.griddata[i].id_ts == key_ts )
    {
      if( first < 0)
      {
        first = i; 
      }
      let item: any = this.griddata[i];
      item.isSelected = 'Y';
      this.selIndex.push(i);
      console.log("QueryGrid_ExactRecords() - Exact Point Is Selected: ", i);  
    }
  }

  if( first >= 0)
  {
    console.log("QueryGrid_ExactRecords - First: " + first);

    // Calculate scroll top in order to navigate to the selected row.
    let r_height = this.gridInstance.getRowHeight();  
    (this.gridInstance.getContent().firstChild as Element).scrollTop = (first+1) * r_height;
    
    // Exact matches found.
    console.log("Exact Match Found");
    return true;
  }

  //console.log("QueryGrid_IntermediateRecords() - # Intermediate Points Found: "+ results.length);

  // No exact matches.
  console.log("QueryGrid_ExactRecords - None Found: " + first);

  return false;
}


private QueryGrid_PrevHeader(key_ts: number, key_type: string)
{
  let results: Array<any> = [];
  for( var i=0; i<this.griddata.length; ++i)
  {
    if( this.griddata[i].isHeader == true &&
        this.griddata[i].dir == key_type && 
        this.griddata[i].id_ts < key_ts )
    {
      results.push(this.griddata[i]);
      //console.log("QueryGrid_PrevHeader() - Point Match inx: ", i);       
    }
  }

  //alert("QueryGridData_PrevHeader() - " + results.length + " matches found.");

  let sresults: Array<any> = results.sort((n1,n2) => {
    return n1.id_ts < n2.id_ts ? 1:-1;
  });

  if( sresults != null && sresults.length > 0 )
  {
      // Retrieve the header just prior to the timestamp.
      //alert("QueryGridData_PrevHeader() - " + results.length + " matches found.");
      return sresults[0].id_ts;
  }

  return 0;
}

private QueryGrid_NextHeader(key_ts: number, key_type: string)
{
  let results: Array<any> = [];
  for( var i=0; i<this.griddata.length; ++i)
  {
    if( this.griddata[i].dir == key_type &&
        this.griddata[i].isHeader == true &&
        this.griddata[i].id_ts > key_ts )
    {
      results.push(this.griddata[i]);
      //console.log("QueryGrid_LastHeader() - Point Match inx: ", i);       
    }
  }

  //alert("QueryGridData_NextHeader() - " + results.length + " matches found.")
  //console.log("Points Found: "+ results);

  let sresults: Array<any> = results.sort((n1,n2) => {
    return n1.id_ts > n2.id_ts ? 1:-1;
  });

  if( sresults != null && sresults.length > 0 )
  {
      // Retrieve the header just prior to the timestamp.
      //alert("QueryGridData_NextHeader() - " + results.length + " matches found.");
      return sresults[0].id_ts;
  }

  return key_ts;
}


private QueryGrid_IntermediateRecords(ts1: number, ts2: number, key_type: string)
{
  let first: number = -1;

  for( var i=0; i<this.griddata.length; ++i)
  {
    if( this.griddata[i].dir == key_type &&
        //this.griddata[i].isHeader == false &&
        this.griddata[i].id_ts >= ts1 &&
        this.griddata[i].id_ts <= ts2 )
    {
      if( first < 0 )
      {
        // Index of first intermediate record.
        first = i; 
      }
      let item: any = this.griddata[i];
      item.isSelected = 'Y';
      this.selIndex.push(i);
      console.log("QueryGrid_IntermediateRecords() - Point Is Selected: ", i);  
    }
  }

  if( first >= 0)
  {
    // Calculate scroll top in order to navigate to the selected row.
    console.log("QueryGrid_IntermediateRecords - First: " + first);
    let r_height = this.gridInstance.getRowHeight();    //getting the grid rowheight  
    (this.gridInstance.getContent().firstChild as Element).scrollTop = (first+1) * r_height; //calculate the value for scrollTop  
  }
  //alert("QueryGrid_IntermediateRecords() - # Intermediate Points Found: "+ results.length);
}

private QueryGrid_ClearSelected()
{
  for( var i=0; i<this.griddata.length; ++i)
  {
    let item: any = this.griddata[i];
    //item.isSelected = 'N';
 
    if( item.isSelected == 'Y' )
    {     
      item.isSelected = 'N';
    }
  }
}

private QueryGrid_ForcedPoints()
{
  if( this.view != TreeViewComponent.view_DATA)
  {
    console.log("QueryGrid_ForcedPoints - Not Data View Returning.")
    return;
  }

  let cnt: number = 0;

  for( var i=0; i<this.griddata.length; ++i)
  {
    let item: any = this.griddata[i];
    if( item != null )
    { 
      if( item.forced == '1' )
      {     
        cnt++;
      }
    }
  }
  //alert("QueryGrid_ForcedPoints() - # Forced Points: "+ cnt);

  return cnt;
}

private DestroyDataViewButtons()
{
  document.getElementById("buttonDiv").style.display = "none";

  if( this.fbutton != null )
  {
    this.fbutton.destroy();
    this.fbutton = null;
  }
  if( this.cbutton != null )
  {
    this.cbutton.destroy();
    this.cbutton = null;
  }
  if( this.ebutton != null )
  {
    this.ebutton.destroy();
    this.ebutton = null;
  }
  if( this.btn_ackAll != null )
  {
    this.btn_ackAll.destroy();
    this.btn_ackAll = null;
  }

}


public SaveConfig(config: Array<any>)
{
  this.configdata = [];

  for( let i:number=0; i < config.length; ++i )
  {
    let item:any = config[i];
    if( item )
    {
      this.configdata[i] = item;
    }
  }
}

// private closeWindow()
// {
//    this.StopStream();

//    // Destroy controls
//    this.DestroyControls();

//    // Close current tab.
//    window.close();
// }




private Cleanup()
{
  console.log("Executing TreeView.Cleanup()");
  this.DestroyControls();
  this.router.navigateByUrl('/app');  
}

private DestroyControls()
{
  // Destroy the grid.
  this.DestroyGrid();

  // Destroy the tree view.
  this.DestroyTreeView();

  // Destroy the chart.
  this.DestroyChart();

  // Destroy Buttons.
  this.DestroyDataViewButtons();
  this.DestroyToolBarButtons();
  this.DestroyKeyButtons();

  // Destroy Config Dialog.
  this.DestroyConfigDialog();

  // Destroy SOE Dialog.
  this.DestroySOEDialog();
  this.DestroyFilesDialog();
}

private CreateKeyButtons()
{
  // debugger
  document.getElementById("keyDiv").style.display = "inline";  
  document.getElementById("grp2").style.display = "inline";  

  if( this.forcedKey == null )
  {
    this.forcedKey = new Button( {cssClass: 'e-outline'} );
    this.forcedKey.appendTo('#key1');
    this.forcedKey.disabled = false;
    this.forcedKey.isToggle = false;
    this.forcedKey.content = "FORCED COLOR";
  }

  if( this.failedKey == null )
  {
    this.failedKey = new Button( {cssClass: 'e-outline'} );
    this.failedKey.appendTo('#key2');
    this.failedKey.disabled = false;
    this.failedKey.isToggle = false;
    this.failedKey.content = "FAILED COLOR";
  }

  if( this.alarmedKeyStatus == null )
  {
    this.alarmedKeyStatus = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyStatus.appendTo('#key3');
    this.alarmedKeyStatus.disabled = false;
    this.alarmedKeyStatus.isToggle = false;
    this.alarmedKeyStatus.content = "ALARM STATUS COLOR";
  }
  if( this.alarmedKeyLow == null )
  {
    this.alarmedKeyLow = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyLow.appendTo('#key4');
    this.alarmedKeyLow.disabled = false;
    this.alarmedKeyLow.isToggle = false;
    this.alarmedKeyLow.content = "ALARM LOW COLOR";
  }
  if( this.alarmedKeyHigh == null )
  {
    this.alarmedKeyHigh = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyHigh.appendTo('#key5');
    this.alarmedKeyHigh.disabled = false;
    this.alarmedKeyHigh.isToggle = false;
    this.alarmedKeyHigh.content = "ALARM HIGH COLOR";
  }
  if( this.alarmedKeyNormal == null )
  {
    this.alarmedKeyNormal = new Button( {cssClass: 'e-outline'} );
    this.alarmedKeyNormal.appendTo('#key6');
    this.alarmedKeyNormal.disabled = false;
    this.alarmedKeyNormal.isToggle = false;
    this.alarmedKeyNormal.content = "NORMAL COLOR";
  }
}

private DestroyKeyButtons()
{
  document.getElementById("keyDiv").style.display = "none";

  if( this.forcedKey != null )
  {
    this.forcedKey.destroy();
    this.forcedKey = null;
  }

  if( this.failedKey != null )
  {
    this.failedKey.destroy();
    this.failedKey = null;
  }

  if( this.alarmedKeyStatus != null )
  {
    this.alarmedKeyStatus.destroy();
    this.alarmedKeyStatus = null;
  }
  if( this.alarmedKeyLow != null )
  {
    this.alarmedKeyLow.destroy();
    this.alarmedKeyLow = null;
  }
  if( this.alarmedKeyHigh != null )
  {
    this.alarmedKeyHigh.destroy();
    this.alarmedKeyHigh = null;
  }
  if( this.alarmedKeyNormal != null )
  {
    this.alarmedKeyNormal.destroy();
    this.alarmedKeyNormal = null;
  }
}


private CreateDataViewButtons()
{
  //debugger
  document.getElementById("buttonDiv").style.display = "block";
  document.getElementById("grp1").style.display = "block";

  if( this.fbutton == null )
  {
    this.fbutton = new Button( {cssClass: 'e-outline'} );
    this.fbutton.appendTo('#tag1');
    this.fbutton.disabled = true;
    this.fbutton.content = "Disable Forcing";

    this.fbutton.element.onclick = (): void => 
    {
      if( this.fbutton.content.startsWith("Enable") )
      {
          let cmd: string = "forcing enable ";
          let arg: string = "You must authenticate to enable forcing:";
          this.ShowAuthDialog(cmd, arg);
          return;
      }
      if( this.fbutton.content.startsWith("Disable") )
      {
          let cmd: string = "forcing disable";
          this.sendMessageToServer(cmd);
          console.log('fbutton OnClick() - Cmd Sent: ', cmd);
      }  
    };
  }

  if( this.cbutton == null )
  {
    this.cbutton = new Button( {cssClass: 'e-outline'});
    this.cbutton.appendTo('#tag2');
    this.cbutton.disabled = true;
    this.cbutton.content = "Clear Forcing";

    this.cbutton.element.onclick = (): void => 
    {
      //alert("cbutton Click Callback.");
      let cmd: string = "clear";
      this.sendMessageToServer(cmd);
      console.log('cbutton OnClick() - Cmd Sent: ', cmd);  
    };
  }

  if( this.ebutton == null )
  {
    this.ebutton = new Button( {cssClass: 'e-outline'} );
    this.ebutton.appendTo('#tag3');
    this.ebutton.disabled = true;
    this.ebutton.content = "Disable Executing";

    this.ebutton.element.onclick = (): void => 
    {
      if( this.ebutton.content.startsWith("Enable") )
      {
          let cmd: string = "executing enable ";
          let arg: string = "You must authenticate to enable executing:";
          this.ShowAuthDialog(cmd, arg);
          return;
      }
      if( this.ebutton.content.startsWith("Disable") )
      {
          let cmd: string = "executing disable";
          this.sendMessageToServer(cmd);
          console.log('ebutton OnClick() - Cmd Sent: ', cmd);
      }  
    };        
  }

  if( this.btn_ackAll == null )
  {
    this.btn_ackAll = new Button( {cssClass: 'e-outline'} );
    this.btn_ackAll.appendTo('#ackall');
    this.btn_ackAll.disabled = false;
    this.btn_ackAll.content = "ACK ALL ALARMS";

    this.btn_ackAll.element.onclick = (): void => 
    {
      this.OnAckAll();
    };        
  }

}

ShowAuthDialog(cmd: string, arg: string)
{
  console.log("Executing ShowAuthDialog.");

  let tb_UserName: TextBox;
  let tb_PassWord: TextBox;
  let title: string = "Authentication Dialog";

  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='myForm'> 
  <div class="row"> 
  <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
  <input id="username" name="UserName" /> 
  <div id="userError" class="error"></div> 
  </div> 
  </div> 
  <div class="row"> 
  <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
  <input id="password" name="Password" /> 
  <div id="passwordError" class="error"></div> 
  </div> 
  </div> 
  </form> 
  </div> 
  </div>` 

  let dialog: Dialog = new Dialog({

    header: title, 
    target: document.getElementById('target'), 
    content: arg + dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [{ 
        'click': () => 
        {
          console.log('ShowAuthDialog() - Click Event Fired: ', cmd);

          let user: string = tb_UserName.value; 
          let pswd: string = tb_PassWord.value; 
          //console.log('UserName: ' + user + ' Password: ' + pswd); 

          cmd += user;
          cmd += " ";
          cmd += pswd;
          //dialog.validate();
        
          this.sendMessageToServer(cmd);

          dialog.destroy();
          console.log('ShowAuthDialog() - Cmd Sent: ', cmd);
        },

        buttonModel: 
        { 
            content: 'Authenticate', 
            isPrimary: true, 
            cssClass: 'e-outline'

        } 
    }], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  });
  dialog.appendTo('#authdialog'); 

  function onDialogCreate(args) 
  {
    console.log("Executing onDialogCreate()");

    tb_UserName = new TextBox({ 
        placeholder: 'User Name', 
        floatLabelType: 'Always' 
    }); 
    tb_UserName.appendTo('#username'); 

    tb_PassWord = new TextBox({ 
        placeholder: 'Password', 
        floatLabelType: 'Always', 
        type: 'password' 
    });     
    tb_PassWord.appendTo('#password');    
  } 

  function onDialogOpen()
  {
    console.log("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    //alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


// private getClientIP()
// {
//   // if( this.xmlData != null )
//   // {
//   //   console.log("RTU-XML already loaded.");
//   //   return;
//   // }

//   debugger
//   var contents: string;
//   this.treeviewService.getIpAddress()
//       .subscribe((result:string) => 
//       {
//         if( result)
//           contents = result;
//           console.log("Set Contents: ", contents);
//           this.SERVER_IP = contents;
//           console.log("IP: " + this.SERVER_IP);
//       });
// }


//================== Retrieval and Parsing of RTU XML ======================================================
  /*
   * Download the XML (RTU) file.
   * Parse the contents into an XML document.  
   * Parse the XML document into Tree View items (json format).
   * Load the Tree View items into the tree view data store.
   * Load/Display the Tree View from the tree view data store.
  */
  processXML()
  {
    if( this.xmlData != null )
    {
      console.log("RTU-XML already loaded.");
      return;
    }

    var contents: string;
    this.treeviewService.getTextFile(this.rtuFile)
        .subscribe((result:string) => 
        {
          if( result)
          contents = result;
          console.log("Set Contents: ", contents);

          this.parser = new DOMParser();
          this.xmlData = this.parser.parseFromString(contents, "application/xml");
          console.log("xmlData:  ", this.xmlData ); 
          var datanodes = this.xmlData.getElementsByTagName('data');
          var treenodes = this.xmlData.getElementsByTagName('tree');
          var icons = this.xmlData.getElementsByTagName('icon');
          var items = this.xmlData.getElementsByTagName('item');


          //alert("Start Debugger");
          debugger
          
          // Only one tree node.
          for (var i = 0; i < treenodes.length; i++) 
          {
            // Build the tree view items.
            this.buildTreeViewItems(this.xmlData, items, this.treedata);
          }
          
          // Diplay the tree view.
          this.CreateTreeView();

          // TODO:  Parse and display the XML header items.
          this.processXMLDataTags(this.xmlData);

          this.CreateDialogs();
                    
        });
  }

  private CreateDialogs()
  {
    this.configDialog = new ConfigDialog(this, Config.PARENT_TYPE_TREEVIEW);
    if( this.configDialog )
    {
      // Display Configuration Dialog but in invisible state.
      this.configDialog.CreateDialog(false);
    }

    this.soeDialog = new SOEDialog(this, Config.PARENT_TYPE_TREEVIEW);
    if( this.soeDialog )
    {
      // Display SOE Dialog but in invisible state.
      this.soeDialog.CreateDialog(false);
    }          

    this.filesDialog = new ServerFilesDialog(this, Config.PARENT_TYPE_TREEVIEW);
    if( this.filesDialog )
    {
      // Display SOE Dialog but in invisible state.
      this.filesDialog.CreateDialog(false);
    }          
  }


  /*
   *  Build the tree view items from the XML Document.
  */
  buildTreeViewItems(xmlData, items, treedata) 
  {
      var itemStoreItems = [];
      for (var i = 0; i < items.length; i++) 
      {
          var item = items[i];
          var itemrep = this.buildItem(xmlData, item);
          if( itemrep.label == "Servers" ||
              itemrep.label == "Clients" ||
              itemrep.label == "Components" )
          {
            treedata.push(itemrep);
          }
      }

      console.log("ItemStoreItems: " + treedata);
  }


  /* 
   * Recursively build each tree view item.
  */
  buildItem(xmlData, item) 
  {
    var id = item.getAttribute("id");
    if( id == undefined )
    {
      this.ID ++;
      id = this.ID;
    }

    var label = item.getAttribute("label");
    if( label == undefined)
    {
      label = id;
    }

    let img: string = "";
    var icon = item.getAttribute("icon");

    if( icon == "Servers" )
    {
      img = this.imgServers;
    }
    if( icon == "Server" )
    {
      img = this.imgServer;
    }    
    else if( icon == "Clients" )
    {
      img = this.imgClients;
    }
    else if( icon == "Client" )
    {
      img = this.imgClient;
    }
    else if( icon == "Port" )
    {
      img = this.imgPort;
    }
    else if( icon == "IED" )
    {
      img = this.imgIed;
    }
    else if( icon == "Components" )
    {
      img = this.imgComponents;
    }
    else if( icon == "Comp" )
    {
      img = this.imgComponent;
    }
    else if( icon == "blank" )
    {
      img = this.imgBlank;
    }
    else if( icon == "unknown" )
    {
      img = this.imgUnknown;
    }

    let expand:boolean = false;

    if( label == "Servers" ||
        label == "Clients"  ||
        label == "Components" )
    {
      expand = true;
    }

    var itemRep = {
                    id: id,
                    label: label,
                    image: img,
                    expanded: expand,
                    subChild: []
            };
  
    var children = item.childNodes;
    for (var j = 0; j < children.length; j++) 
    {
      if( children[j].nodeName == 'item')
      {
        // Create the child (aka subChild) item.
        itemRep.subChild.push(this.buildItem(xmlData, children[j]));
      }
    }

    return itemRep;
  }


  // Traversal for XML Data Tags.
  processXMLDataTags(xmlData)
  {
    console.log("Executing processXMLDataTags()");

    if( xmlData == null )
    {
      console.log("processXMLDataTags - Invalid xmlData.")
      return;
    }
    var nodes = xmlData.getElementsByTagName('data');
    for (var i = 0; i < nodes.length; i++) 
    {
      // alert(nodes[i].nodeName + ' = ' + 
      //       "name: " + nodes[i].getAttribute("name") + "  " + 
      //       "  value: " + nodes[i].getAttribute("value"));    
      try
      {
        var key = nodes[i].getAttribute("name");
        var val = nodes[i].getAttribute("value");

        if( key == "model")
        {
          this.rtuModel = val.toString();
          this.ddModelList.push(this.rtuModel);
          this.ddModel.dataSource = this.ddModelList;
          this.ddModel.index = 0;
        }
        else if( key == "name")
        {
          this.rtuName = val.toString();
          this.ddDeviceList.push(this.rtuName);
          this.ddDevice.dataSource = [];
          this.ddDevice.dataSource = this.ddDeviceList;
          this.ddDevice.index = 0;
        }
        else if( key == "license")
        {
          this.rtuLicense = val.toString();
        }
        else if( key == "version")
        {
          this.rtuVersion = val.toString();
        }        
      }
      catch(ex)
      {
        console.log("DownloaderComponent.processXML Data Exception:  " + ex);
      }
    }
  }
//================== END Retrieval and Parsing of RTU XML ==================================================

// Callback method to save data to the user's local file.
OnSave()
  {
      console.log('Executing OnSave()');

      var textToSave = this.FormatCommData();
      var textToSaveAsBlob = new Blob([textToSave], {type:"text/plain"});
      var textToSaveAsURL = window.URL.createObjectURL(textToSaveAsBlob);
      var fileNameToSaveAs = "protocol.txt";

      var downloadLink = document.createElement("a");
      downloadLink.download = fileNameToSaveAs;
      downloadLink.innerHTML = "Download File";
      downloadLink.href = textToSaveAsURL;
      downloadLink.onclick = this.destroyClickedElement;
      downloadLink.style.display = "none";
      document.body.appendChild(downloadLink);

      downloadLink.click();
  }

  FormatCommData()
  {
      var lines = "<START of REPORT>\r\n";

      // Retrieve the last hour of grid (comm and pulse) data.
      let ts_to: number = this.last_comm_ms;
      let ts_from: number = ts_to - 3600000;

      let results: Array<any> = [];
      for( var i=0; i<this.griddata.length; ++i)
      {
        if( this.griddata[i].id_ts >= ts_from &&
            this.griddata[i].id_ts <= ts_to )
        {
          results.push(this.griddata[i]);
          console.log("QueryGrid_SaveRecords() - Point Is Selected: ", i);  
        }
      }
  
      // Sort results in ascending order.
      let sresults: Array<any> = results.sort((n1,n2) => {
        return n1.id_ts > n2.id_ts ? 1:-1;
      });
  
      if( sresults != null && sresults.length > 0 )
      {
          for( var i=0; i<sresults.length; ++i )
          {
              var item = sresults[i];
              if( item != null )
              {
                  // Format the data.
                  var line = item.id_ts + TreeViewComponent.FILE_DELIMITER +
                            item.dir + TreeViewComponent.FILE_DELIMITER +
                            item.type + TreeViewComponent.FILE_DELIMITER +
                            item.data_raw + TreeViewComponent.FILE_DELIMITER +
                            item.data_cooked + "\r\n";
                  lines += line;
            }
          }
      }

      lines += "<END OF REPORT>\r\n";

      return lines;
  }

  destroyClickedElement(event)
  {
      document.body.removeChild(event.target);
  }

// ConfigData Save/Load Routines:

public GetDiagramPath(): string
{
  return this.diagramPath;
}

// Sends master configuration to the wtp server on the target device and
// saves the data to the given file on the target device.
public SendConfig(serialdata:Array<string>, filename:string)
{
  //let hdr:string = "put " + "diagram.sld" + "\r\n";
  let hdr:string = "put " + filename + " \r\n";
  console.log("SendConfig() - hdr: " + hdr);

  this.sendFileToServer(hdr);

  for( let i: number = 0; i<serialdata.length; ++i)
  {
    let rline: string = serialdata[i] + "\r\n";
   
    console.log("rline: " + rline + "  rline length: " + rline.length );
    //console.log("rline length: " + rline.length);
    this.sendFileToServer(rline);
  }

  let footer:string = "end put" + "\r\n";
  this.sendFileToServer(footer);
}

sendFileToServer(msg: string)
{
  // Append session id to message.
  if( this.wsServiceComm == null )
  {
    console.log("DrawingBoardComponent.sendFileToServer() - WS Subscription is null.");
    return;
  }

  //msg += " " + this.sessionId;
  this.status = this.wsServiceComm.sendMessage(msg);
}

// Request the list of soe files from server.
private RequestSOEFiles()
{
  //debugger
  let cmd:string = "get soe";
  this.sendMessageToServer(cmd);
}

processSOEFiles(msg: string)
{
  // Display the message for now.
  console.log("Msg: " + msg);
  let arr:Array<string> = msg.split(':');
  if( arr.length == 2)
  {
    let files:Array<string> = arr[1].split(';');
    //this.ShowServerFilesDialog(files, TreeViewComponent.FILE_TYPE_SOE);
    this.filesDialog.CopyData(files);
    this.filesDialog.Reset();
    this.filesDialog.SetFileType(ServerFilesDialog.FILE_TYPE_SOE);
    this.filesDialog.dialog.visible = true;
  }
  else
  {
    alert("Error Retrieving Diagram Files from Server.");
  }
}

private OpenInNewTab(url: string): void {
  // open link in new tab
  const newTab = window.open(url, '_blank');

  // set opener to null so that no one can references it
  newTab.opener = null;
}



// Reads SOE file from server.
public ReadSOEFileFromServer(val: string)
{
  //debugger
  console.log("Executing DrawingBoardComponent.ReadSOEFileFromServer() for:  " + this.soeFile);

  let file = this.soePath + val;
  
  var contents: string;
  this.treeviewService.getTextFile(file)
  .subscribe((result:string) => 
  {
    if( result)
    contents = result;
    console.log("Contents: ", contents);

    let arr: Array<string> = contents.split('\r\n');
    this.soeData = [];
    for( let i=0; i<arr.length; ++i)
    {
      let line:string = arr[i];
      console.log("soe line: " + line);

      if( line.startsWith("Id,") == false)
      {
        let tokens: Array<string> = line.split(',');
        let inx:number = 0;
        let item =  { id: tokens[inx++],
                      date: tokens[inx++],
                      time: tokens[inx++], 
                      ms: tokens[inx++],
                      point: tokens[inx++],
                      name: tokens[inx++],
                      desc: tokens[inx++],
                      state: tokens[inx++],
                      value: tokens[inx++],
                      class: tokens[inx++],
                      tag1: tokens[inx++],
                      tag2: tokens[inx++],
                    };
        this.soeData.push(item);
      }
    }    
    debugger
    // Populate and expose the SOE Dialog.
    if( this.soeDialog != null )
    {
      this.soeDialog.CopySOEData(this.soeData);
      this.soeDialog.Reset();
      this.soeDialog.dialog.visible = true;
    }
  });
}

}




// TODO - REMOVE:
// Temporary TreeView test data until the rtu.xml file is parsed into JSON format.
// treedata: { [key: string]: Object }[] = []; 
//   [
//   { id: '01', label: 'Servers', expanded: true, image: this.imgServers,
//       subChild: [
//           {
//               id: '33200:0', label: 'DNP3_Server#1:DNP3#1 ', image: this.imgServer, view: 'data', expanded: true,
//               subChild: [
//                   { id: '1001', label: 'Eth1001:X:20000:ST', image: this.imgPort, view: 'comm' }
//               ]
//           },
//           {
//               id: '33248:0', label: 'EventLogger_Server#1:EventLogger ', image: this.imgServer, expanded: true
//           },
//           {
//               id: '33264:0', label: 'WebAccess_Server#1:WebAccess ', image: this.imgServer, expanded: true
//           },
//       ]
//   },
//   {
//       id: '02', label: 'Clients', image: this.imgClients, expanded: true,
//       subChild: [
//           {
//               id: '1648:0', label: 'Local_Client:Local ', image: this.imgClient, expanded: true,
//               subChild: [
//                   { id: '10', label: 'Ser10:115200:Backbone', image: this.imgPort, expanded: true,
//                   subChild: [ 
//                       { id: '1648:1', label: 'Local#1:LocalAnalog#1 ', image: this.imgIed, expanded: false,
//                       subChild: [
//                         { id: '10:1', label: '10:1', image: this.imgPort}
//                       ]
//                       },
//                       { id: '1648:2', label: 'Local#1:LocalControl#2 ', image: this.imgIed, expanded: false,
//                       subChild: [
//                         { id: '10:2', label: '10:2', image: this.imgPort}
//                       ]
//                     },
//                     ] 
//                   },
//                   { 
//                     id: '9', label: 'Ser9:115200:Backbone', image: this.imgPort, expanded: true,
//                     subChild: [ 
//                       { id: '1648:3', label: 'Local#1:LocalAnalog#3 ', image: this.imgIed, expanded: false,
//                       subChild: [
//                         { id: '10:3', label: '10:3', image: this.imgPort}
//                       ]
//                     },
//                     ]
//                   },
//               ]
//           },
//           {
//               id: '1632:0', label: 'DNP3C_Client:DNP3C ', image: this.imgClient, expanded: true,
//               subChild: [
//                   { id: '6', label: 'Ser6:9600:485' , image: this.imgPort, expanded: true,
//                   subChild: [
//                       { id: '1632:1', label: 'DNP3C#1:DNP3C#1 ', image: this.imgIed, expanded: false,
//                       subChild: [
//                         { id: '6:1', label: '6:1', image: this.imgPort}
//                       ]
//                     },
//                     ]
//                   },
//                   { id: '20', label: 'Ser20:9600:Ecombo:232', image: this.imgPort, expanded: true,
//                     subChild: [
//                       { id: '1632:2', label: 'DNP3C#1:DNP3C#2 ', image: this.imgIed, expanded: false,
//                       subChild: [
//                         { id: '6:2', label: '6:2', image: this.imgPort}
//                       ]
//                     },
//                     ]
//                   }
//               ]
//           },
//       ]
//   },
//   {
//       id: '03', label: 'Components', icon: 'folder', image: this.imgComponents, expanded: true,
//       subChild: [
//           {id: '17408:0', label: 'Netconfig_Comp#1:Netconfig ', image: this.imgComponent },
//           {id: '4272:0', label: 'Time_Comp#1:Time ', image: this.imgComponent},
//           {id: '4256:0', label: 'ePaq9420x16_Comp#1:ePaq9420x16 ', image: this.imgComponent},
//       ]
//   }
// ];





