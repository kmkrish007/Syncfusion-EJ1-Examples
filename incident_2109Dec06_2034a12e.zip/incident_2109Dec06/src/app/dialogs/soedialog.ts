import { Grid} from '@syncfusion/ej2-grids';
import { Dialog } from '@syncfusion/ej2-popups';
import { Config } from '../config/config';

export class SOEDialog 
{

    private grid: Grid = null;
    public dialog: Dialog = null;

    private griddata: { [key: string]: Object }[] = [];

    private parent: any = null; 
    private parentType: number;
  
    constructor(parent: any, type:number)
    {
        console.log("Executing SOEDialog.constructor()");

        this.parent = parent;
        this.parentType = type;
        this.CreateGrid();
    }

    private CreateGrid()
    {
        //debugger
        console.log("Executing SOEDialog.CreateGrid()");

        this.grid = new Grid({
            dataSource: this.griddata,
            allowSorting: false,
            allowSelection: true,
            gridLines: 'Both',
            enableHover: true,
            enableVirtualization: false,
            allowPaging: false,
            rowHeight: 13,
            columns: 
            [
                //{ field: 'soe', headerText: 'Sequence of Events', textAlign: 'Left', width: 200, visible: true}
                { field: 'id', headerText: 'ID', textAlign: 'Right', width: 200, visible: true},
                { field: 'date', headerText: 'DATE', textAlign: 'Right', width: 200, visible: true},
                { field: 'time', headerText: 'TIME', textAlign: 'Right', width: 200, visible: true},
                { field: 'ms', headerText: 'MILLISECS', textAlign: 'Right', width: 150, visible: true},
                { field: 'point', headerText: 'POINT', textAlign: 'Right', width: 150, visible: true},
                { field: 'name', headerText: 'NAME', textAlign: 'Right', width: 150, visible: true},
                { field: 'desc', headerText: 'DESCRIPTION', textAlign: 'Right', width: 200, visible: true},
                { field: 'state', headerText: 'STATE', textAlign: 'Right', width: 100, visible: true},
                { field: 'value', headerText: 'VALUE', textAlign: 'Right', width: 100, visible: true},
                { field: 'class', headerText: 'CLASS', textAlign: 'Right', width: 50, visible: false},
                { field: 'tag1', headerText: 'TAG1', textAlign: 'Right', width: 50, visible: false},
                { field: 'tag2', headerText: 'TAG2', textAlign: 'Right', width: 50, visible: false}
            ]
            });
    }

    // Creates the dialog.
    public CreateDialog(show:boolean)
    {
        console.log("Executing SOEDialog.CreateSOEDialog()");

        //debugger
        let dialogContent: string = `<form id='SOEForm'> 
            <div id="soegrid"></div>
        </form>` 

        this.dialog = new Dialog(
        { 
            header: 'SOE (Sequence of Events) Dialog', 
            target: document.getElementById('target'), 
            content: dialogContent,
            allowDragging: true,
            visible: show,
            isModal: false, 
            animationSettings: 
            { 
                effect: 'None' 
            }, 
            showCloseIcon: false, 
            width: '1500px',
            height: '700px', 
            open: this.onDialogOpen,
            enableResize: true,
            position: {X: "center", Y:"center"},
            close: this.onDialogClose, 
            created: this.onDialogCreate.bind(this),
            buttons:  
            [
                {
                    'click': () => {
                        this.dialog.visible = false;
                    },
                    buttonModel: {
                        isPrimary: true,
                        content: 'CLOSE'
                    }
                },                
            ],            
        }); 
        if( this.parentType == Config.PARENT_TYPE_DBC)
        { 
            this.dialog.appendTo('#soedialog-dbc');
        }
        else if( this.parentType == Config.PARENT_TYPE_TREEVIEW)
        { 
            this.dialog.appendTo('#soedialog-tvc');
        }
    }  


    // Dialog created Event callback.
    private onDialogCreate(args:any) 
    {
        //debugger
        console.log("Executing SOEDialog.onDialogCreate()");
        if( this.grid != null )
        {
            this.grid.appendTo('#soegrid');
        }
            
    } 

    // Dialog opened event callback
    private onDialogOpen()
    {
        //debugger;
        console.log("Executing SOEDialog.onDialogOpen()");
    
    }

    // Dialog closed event callback.
    private onDialogClose()
    {
        //debugger;
        console.log("Executing SOEDialog.onDialogClose()");
    }

    // Destroy (called when drawing board exits).
    public Destroy()
    {
        //debugger;
        console.log("Executing SOEDialog.Destroy()");

        if( this.grid != null )
        {
            this.grid.destroy();
        }
        this.dialog.destroy();  
    }

    public CopySOEData(data: Array<any>)
    {   
      //debugger
      this.griddata = [];
      this.griddata = Array.from(data);
    }

    public Reset()
    {
        //debugger
        this.grid.dataSource = [];
        this.grid.dataSource = this.griddata;    
    }

    

}
