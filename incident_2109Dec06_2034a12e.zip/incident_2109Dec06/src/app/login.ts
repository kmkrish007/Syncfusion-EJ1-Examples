export class Login {
    constructor(
        public user: string,
        public pswd: string
      ) {  }    
}
