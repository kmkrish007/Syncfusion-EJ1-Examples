import { TestBed } from '@angular/core/testing';

import { WebsockettermService } from './websocketterm.service';

describe('WebsockettermService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WebsockettermService = TestBed.get(WebsockettermService);
    expect(service).toBeTruthy();
  });
});
