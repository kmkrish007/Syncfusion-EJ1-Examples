import { Component, ViewChild, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Subscription } from 'rxjs';
import {WebsocketServiceTerm} from './websocketterm.service';
import { RichTextEditor} from '@syncfusion/ej2-richtexteditor';
import { Button } from '@syncfusion/ej2-buttons';
import { Router, NavigationEnd} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {AppComponent} from '../app.component';
import {Config} from '../config/config';

@Component({
    selector: 'app-terminal',
    templateUrl: './terminal.component.html',
    //providers: [ TreeviewService ],
    styleUrls: ['./terminal.component.css'],
  })

  export class TerminalComponent implements OnInit, OnDestroy
{
    // Instance of RTE
    @ViewChild('RTE') editorInstance: RichTextEditor;
    //editorInstance: RichTextEditor = null;

    //url_TermServer = "ws://10.210.6.147:1111"
    private url_TermServer:string = "";

    // Remote server IP.
    private SERVER_IP: string = "";

    //cmd_user: string = "get userstate";
    //cmd_sessionOpen: string = "session open root root 10.210.3.63";
    //cmd_setSession: string = "set session";
  
    newTreeButton: Button = null;
    clearButton: Button = null;
    closeButton: Button = null;
    saveButton: Button = null;
    hmiButton: Button = null;

    //sessionId = "S383886777";
    sessionId = "";

    wsSubscription: Subscription = null;
    status;
    private sub: any;

    rprompt: string = "";
    promptDisplayed: boolean = false;

    // Message to server.
    message: string = "";

    // Last message to server.
    lastmessage: string = "";

    // Response from server.

    response: string = "";

    ClickHereMessage: string = "Click here to use the Terminal";

    bInvalidData: boolean = false;

    toolbarConfig: object = {
        enable: false
    };


    constructor(private wsService: WebsocketServiceTerm,
                private route: ActivatedRoute,
                private router: Router
                )
    {
        //alert("Executing TerminalComponent Constructor.")

        // this.wsSubscription = this.wsService.createObservableSocket(this.url_TermServer, "")
        // .subscribe(
        //     data=>this.handleMessage(data),
        //     // err=>alert('ERROR: Unable to Connect to server: ' + this.url_TermServer),
        //     err=>this.Cleanup(),            
        //     ()=>console.log('The Observable Stream Is Complete')
        // );
    }

    ngOnInit() 
    {      
        console.log("Executing TerminalComponent.ngOnInit().");

        this.sessionId = localStorage.getItem("sessionid");
        console.log("TerminalComponent.ngOnInit() - Session ID: " + this.sessionId);

        this.setPaths();
        
        // this.sub = this.route.params.subscribe(params => {
        //     this.sessionId = params['sessionId']; // (+) converts string 'id' to a number
        //   });

        //this.sendMessageToServer("session set " + this.sessionId);

        //alert("Executing TerminalComponent Constructor.")
        this.wsSubscription = this.wsService.createObservableSocket(this.url_TermServer, "")
        //this.wsSubscription = this.wsService.createObservableSocket(this.url_TermServer, this.cmd_setSession + " " + this.sessionId)
        .subscribe(
            data=>this.handleMessage(data),
            // err=>alert('ERROR: Unable to Connect to server: ' + this.url_TermServer),
            err=>this.Cleanup(),            
            ()=>console.log('The Observable Stream Is Complete')
        );
    
        this.CreateHeaderButtons();

        this.editorInstance.toolbarSettings.items = [];
        this.editorInstance.editorMode = "Markdown";

        this.editorInstance.element.onclick = (): void => 
        {
            //alert("Text Editor Clicked");

            if( this.promptDisplayed == true )
            {
                return;
            }
                
            this.editorInstance.value = this.rprompt;
            this.message = "";
            this.promptDisplayed = true;
        };
        
        this.editorInstance.element.onkeyup = (evt: KeyboardEvent): any =>
        {
            this.ProcessInput(evt);
        };

        this.IncrementView();
    }

    private IncrementView()
    {
        let num:number = parseInt(localStorage.getItem("numTermView"));
        console.log("IncrementView() - numTermView read: " + num);
        num += 1;
        localStorage.setItem("numTermView", num.toString() );      
        console.log("IncrementView() - numTermView written: " + num);
    }

    // call this event handler before browser refresh/close tab.
    @HostListener("window:beforeunload", ["$event"]) unloadHandler(event: Event) 
    {
        console.log("Processing beforeunload...");
        this.StopStream();
        //this.closeSocket();
        this.DestroyControls();
        this.DecrementView();
    }

    // execute this function before browser refresh
    private DecrementView(){
        let num:number = parseInt(localStorage.getItem("numTermView"));
        console.log("DecrementView() - numTermView read: " + num);
        num -= 1;
        localStorage.setItem("numTermView", num.toString() );      
        console.log("DecrementView() - numTermView written: " + num);
    }

    getServerIP()
    {
    //   // For development mode, use the next line to set the url.
    //   var url = "http://10.210.6.147";
  
    //   // TODO:  For developement mode, use the first line to set the url.
    //   // Get the server ip from user entered url.
    //   url = window.location.href;
    //   var pos1 = url.indexOf('//');
    //   var tok = url.slice(pos1+2);
    //   var pos2 = tok.indexOf('/');
    //   if( pos2 >= 0 )
    //   {    
    //     this.SERVER_IP = tok.slice(0,pos2);
    //   }
    //   else
    //   {
    //     this.SERVER_IP = tok;
    //   }

        this.SERVER_IP = localStorage.getItem("serverIP");
        console.log("SERVER_IP: " + this.SERVER_IP);
    }

    setPaths()
    {
      //debugger
      this.getServerIP();
  
      this.url_TermServer = "ws://" + this.SERVER_IP + ":" + Config.PORT_TERMSERVER.toString();
    }
  
    public onCreate()    
    { 
        // Apply bigger styles once component rendered in DOM     
        this.editorInstance.contentModule.getEditPanel().classList.add('bigger'); 
    } 

    public onFocus() 
    { 
        // Apply smaller styles when editor focused state 
        this.editorInstance.contentModule.getEditPanel().classList.remove('bigger'); 
        this.editorInstance.contentModule.getEditPanel().classList.add('smaller'); 
    } 

    private onClick() 
    {
        //alert("Text Editor Clicked");

        if( this.promptDisplayed == true )
        {
            return;
        }
            
        this.editorInstance.value = this.rprompt;
        this.message = "";
        this.promptDisplayed = true;
    };

    private onKeyUp(evt: KeyboardEvent)
    {
        this.ProcessInput(evt);
    };


    private ProcessInput(e: KeyboardEvent)
    {
        console.log('ProcessInput() e.keyCode: ', e.keyCode);
        console.log('ProcessInput() e.which: ', e.which);

        if( e.keyCode == 0xD )
        {
            // Send input.
            console.log('ProcessInput() - Enter Key / Message: ', this.message);
            this.message += "\r";
            this.sendMessageToServer(this.message);
            this.lastmessage = this.message;
            this.message = "";
            return;
        }
        else
        {
            if( e.keyCode > 64 && e.keyCode < 91 )
            {
                console.log('ProcessInput() - Valid Letter Key.');
                this.message += e.key;
                return;
            }
            if( e.which > 47 && e.which < 58 )
            {
                console.log('ProcessInput() - Valid Number Key.');
                this.message += e.key;
                return;
            }
            if( e.which == 32 )
            {
                console.log('ProcessInput() - Valid Space Key.');
                this.message += e.key;
                return;
            }
            if( e.which > 95 && e.which < 112 )
            {
                console.log('ProcessInput() - Valid Numpad Key.');
                this.message += e.key;
                return;
            }
            if( e.which > 185 && e.which < 193 )
            {
                console.log('ProcessInput() - Valid ;=,-./ Key.');
                this.message += e.key;
                return;
            }
            if( e.which > 218 && e.which < 223 )
            {
                console.log('ProcessInput() - Valid [\] Key.');
                this.message += e.key;
                return;
            }
        }
    }


    private CreateHeaderButtons()
    {
        this.newTreeButton = new Button( {iconCss: 'e-icons e-tree-icon', isPrimary: true} );
        this.newTreeButton.appendTo('#id-newTreeButton');
        this.newTreeButton.disabled = false;
        this.newTreeButton.content = "";
        this.newTreeButton.element.setAttribute("title", "New Tree View");

        this.newTreeButton.element.onclick = (): void => 
        {
            //if( Config.MODE_DEV )
            if( Config.MODE_MULTITABS )
            {
                let num:number = parseInt(localStorage.getItem("numTreeView"));
                console.log("Num Tree Views Read: " + num);
                if( num < Config.MAX_TREEVIEWS)
                {
                    AppComponent.OpenInNewTab('/treeview');
                }
                else
                {
                    alert("Maximum Tree Views Reached: Only " + Config.MAX_TREEVIEWS + " Allowed.");
                }
            }
            else
            {
                // Test for prod mode
                this.StopStream();
                this.DestroyControls();
                this.router.navigateByUrl('/treeview'); 
            }      
        };

        this.hmiButton = new Button( {iconCss: 'e-icons e-tree-icon', isPrimary: true} );
        this.hmiButton.appendTo('#id-hmiButton');
        this.hmiButton.disabled = false;
        this.hmiButton.content = "";
        this.hmiButton.element.setAttribute("title", "SLD View");

        this.hmiButton.element.onclick = (): void => 
        {
            //if( Config.MODE_DEV )
            if( Config.MODE_MULTITABS )
            {            
                let num:number = parseInt(localStorage.getItem("numSLDView"));
                console.log("Num SLD Views Read: " + num);
                if( num < Config.MAX_SLDVIEWS)
                {
                    AppComponent.OpenInNewTab('/hmi');
                }
                else
                {
                    alert("Maximum SLD Views Reached: Only " + Config.MAX_SLDVIEWS + " Allowed.");
                }
            }
            else
            {
                // Test for prod mode
                this.StopStream();
                this.DestroyControls();
                this.router.navigateByUrl('/hmi'); 
            }
        };


        this.clearButton = new Button( {iconCss: 'e-icons e-terminal-icon', isPrimary: true} );
        this.clearButton.appendTo('#id-clearButton');
        this.clearButton.disabled = false;
        this.clearButton.content = "";
        this.clearButton.element.setAttribute("title", "Clear");

        this.clearButton.element.onclick = (): void => 
        {
            //alert("Executing clearButton.element.onclick");
            this.editorInstance.value = this.rprompt;
            this.message = "";
            this.promptDisplayed = true;    
        };  

        this.saveButton = new Button( {iconCss: 'e-icons e-save-icon', isPrimary: true} );
        this.saveButton.appendTo('#id-saveButton');
        this.saveButton.disabled = false;
        this.saveButton.content = "";
        this.saveButton.element.setAttribute("title", "Save");

        this.saveButton.element.onclick = (): void => 
        {
            //alert("Executing saveButton.element.onclick.");
            this.handleSaveButton();
        };  


        this.closeButton = new Button( {iconCss: 'e-icons e-logout-icon', isPrimary: true} );
        this.closeButton.appendTo('#id-closeButton');
        this.closeButton.disabled = false;
        this.closeButton.content = "";
        this.closeButton.element.setAttribute("title", "close");
        if( ! Config.MODE_MULTITABS )
        {
          this.closeButton.element.setAttribute("title", "logout");
        }      

        this.closeButton.element.onclick = (): void => 
        {
            console.log("Executing logoutButton.element.onclick");

            //if( Config.MODE_DEV )
            if( Config.MODE_MULTITABS )
            {
                this.CloseWindow();
            }
            else
            {
                // Test for prod mode
                this.StopStream();
                this.DestroyControls();
                this.router.navigateByUrl('/app'); 
            }            
        };  
    }


    private handleMessage(msg: string)
    {
        console.log(msg)

        if( msg == "Rtu0>" )
        {
            this.rprompt = msg;
            if( this.promptDisplayed == false )
            {
               this.editorInstance.value = this.ClickHereMessage;
               this.promptDisplayed = false
            }
            this.sendMessageToServer("session set " + this.sessionId);

        }
        else if( msg == "ping" )
        {
            // Ignore ping message.
        }
        else if( msg.startsWith("logout"))
        {
          alert("TerminalComponent.handleCommMessage() - Received logout message: " + msg);
          this.StopStream();
          this.DestroyControls();
          this.router.navigateByUrl('/app');
        }    
        else
        {
            let displaytxt: string = this.editorInstance.value;

            // Append the new response to the displayed text.
            displaytxt += msg;

            if( displaytxt.endsWith("\r\n") )
            {
                displaytxt += this.rprompt;
            }

            // Set the display text.
            this.editorInstance.value = displaytxt;
        }
    }

    private sendMessageToServer(msg: string)
    {
        //msg += " " + this.sessionId;
        this.status = this.wsService.sendMessage(msg);
        console.log("TerminalComponent.sendMessageToServer() - status: " + this.status + "  msg: " + msg);
    }

    StopStream()
    {
      debugger
      if( this.wsSubscription != null )
      {
        // Send stream stop message to the server.
        let cmd: string = "terminal stop";    
  
        this.sendMessageToServer(cmd);
  
        // Close the socket.
        this.closeSocket();
      }    
    }
  

    private Cleanup()
    {
        console.log("Executing TerminalView.Cleanup");
        this.DestroyControls();
        this.router.navigateByUrl('/app'); 
    }

    private CloseWindow()
    {
        console.log("Executing TerminalView.CloseWindow");
        //this.DestroyControls();
        //this.closeSocket();
        //this.StopStream();
        window.close(); 
    }

    private DestroyControls()
    {
        this.DestroyEditor();
        this.DestroyHeaderButtons();
    }

    private DestroyEditor()
    {
        // Destroy the editor.
        if( this.editorInstance != null )
        {
            this.editorInstance.destroy();
            this.editorInstance = null;
        }
    }

    private DestroyHeaderButtons()
    {
      if( this.newTreeButton != null )
      {
        this.newTreeButton.destroy;
        this.newTreeButton = null;
      }
      if( this.clearButton != null )
      {
        this.clearButton.destroy;
        this.clearButton = null;
      }
      if( this.closeButton != null )
      {
        this.closeButton.destroy;
        this.closeButton = null;
      }
      if( this.saveButton != null )
      {
        this.saveButton.destroy;
        this.saveButton = null;
      }
      if( this.hmiButton != null )
      {
        this.hmiButton.destroy;
        this.hmiButton = null;
      }
    }    
      
    private closeSocket()
    {
          this.wsSubscription.unsubscribe();
          this.wsService.ws.close();
          this.status = "The Socket Is Closed.";
          //alert("TerminalComponent.closeSocket() = Socket Closed.");
    }
  
    ngOnDestroy()
    {
      console.log("Executing TerminalComponent.ngOnDestroy()."); 
      //this.Cleanup();      
    }

private handleSaveButton()
{
    console.log('Executing handleSaveButton');
    this.saveTextAsFile();
}

private saveTextAsFile()
{
    //var textToSave = document.getElementById("termarea").textContent;
    let textToSave: string = this.editorInstance.value;
    var textToSaveAsBlob = new Blob([textToSave], {type:"text/plain"});
    var textToSaveAsURL = window.URL.createObjectURL(textToSaveAsBlob);
    //var fileNameToSaveAs = document.getElementById("myarea").value;
    var fileNameToSaveAs = "terminal.txt";

    var downloadLink = document.createElement("a");
    downloadLink.download = fileNameToSaveAs;
    downloadLink.innerHTML = "Download File";
    downloadLink.href = textToSaveAsURL;
    downloadLink.onclick = this.destroyClickedElement;
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);

    downloadLink.click();
}

private destroyClickedElement(event)
{
    document.body.removeChild(event.target);
}

// private openInNewTab(url: string): void {
//     // open link in new tab
//     const newTab = window.open(url, '_blank')
  
//     // set opener to null so that no one can references it
//     newTab.opener = null
//   }
  



//=======================================================================================================

// WS_Connect()
// {
//      // Create Web Socket instance.
//      //var serverAddress = WS_PREFIX + SERVER_IP + ":" + SERVER_TERM_PORT;
//      var termWebSocket = new WebSocket(this.url_TermServer);

//      if( termWebSocket == null )
//      {
//          alert("WS_Connect() Error: Socket object not created.");
//          console.log('WS_Connect() Error: Socket Object Not Created.');
//          return;
//      }

//      // Connection opened
//      termWebSocket.addEventListener('open', function (event)
//      {
//          //alert( "AddEventListener() Open.");
//          console.log('AddEventListener() Open.');
//         //  CreateTermWindow();
//         //  WS_Connect_Local();
//      });
//      // Listen for messages
//      termWebSocket.addEventListener('message', function (event)
//      {
//          // Process data, comm, pulse messages.
//          console.log('message recvd: ', event.data);

//          let msg: string = event.data;

//          this.handleMessage(msg);

//          if( msg == "Rtu0>" )
//          {
//              this.rprompt = msg;
//              if( this.promptDisplayed == false )
//              {
//                 this.editorInstance.value = this.ClickHereMessage;
//                 this.promptDisplayed = false
//              }
//          }
 

//          if( event.data == "Rtu0>" )
//          {
//              prompt = event.data;
//              if( parseInt(promptDisplayed) == 0 )
//              {
//                 var textarea = dijit.byId("termarea");
//                 if( textarea != null )
//                 {
//                     textarea.set("value", ClickHereMessage);
//                 }
//              }
//          }
//          else if( event.data == "ping" )
//          {
//              // Ignore ping message.
//          }
//          else
//          {
//              var textarea = dijit.byId("termarea");
//              if( textarea != null )
//              {
//                  // Get the text area's displayed text.
//                  var displaytxt = textarea.get("value");

//                  // Append the new response to the displayed text.
//                  displaytxt += event.data;

//                  var pos = event.data.indexOf("INVALID");

//                  if( pos >= 0 )
//                  {
//                      bInvalidData = "true";
//                      console.log('Set bInvalid = true');
//                  }
//                  console.log('bInvalidData: ', bInvalidData);
//                  console.log('bInvalidData: ', bInvalidData);

//                  if( bInvalidData.valueOf() == "false" )
//                  {
//                      // Append the prompt.
//                      displaytxt += prompt;
//                      console.log('bInvalidData = false - appended prompt');
//                  }

//                  if( bInvalidData == "true" &&
//                           event.data.toLowerCase() == lastmessage )
//                  {
//                      bInvalidData = "false";
//                      console.log('Last Message Match.');
//                  }

//                  // Set the display text.
//                  textarea.set("value", displaytxt);
//              }
//          }
//      });

  

  
}