import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TerminalComponent } from '../terminal/terminal.component';
import { TreeViewComponent } from '../treeview/treeview.component';
import { DrawingBoardComponent} from '../hmi/drawingboard.component';

//import { LoginComponent } from '../login/login.component';
import {AppComponent} from '../../app/app.component';

const routes: Routes = [
    {
      path: 'treeview/:sessionId', 
      component: TreeViewComponent      
    },
    {
      //path: 'treeview/:sessionId', 
      path: 'treeview', 
      component: TreeViewComponent
    },
    {
      //path: 'hmi/:sessionId', 
      path: 'hmi', 
      component: DrawingBoardComponent
    },
    {
      //path: 'terminal/:sessionId',
      path: 'terminal',
      component: TerminalComponent
    },
    {
      path: 'app',
      component: AppComponent
    },
    { 
      path: '',   
      redirectTo: '/app', 
      pathMatch: 'full' 
    },
    { 
      path: '**', 
      component: AppComponent 
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }



