import { Injectable } from '@angular/core';
import {Observable } from 'rxjs';
import { Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class WebsocketServiceDrawingBoard {

  ws: WebSocket;
  public socketIsOpen: number = 0;

  requestArg: string = "";

  public sessionId: string = "";

  constructor() 
  {
    console.log("Executing WebsocketService Constructor.");
  }

  createObservableSocket(url: string, req: string): Observable<any>
  {
    this.requestArg = req;
    this.ws = new WebSocket(url);
    this.ws.onopen =  (evt) => 
    {
      console.log("ws.onopen().");
      this.socketIsOpen = 1;
      if( req.length > 0)
      {
        this.ws.send(this.requestArg);
      } 
    }
    this.ws.onclose = (event) =>
    {
      console.log("ws.onclose().");
      this.socketIsOpen = 0;
      this.ws.close();
    }   
    return new Observable(
      observer=>
      {
        this.ws.onmessage = (event)=>observer.next(event.data);
        this.ws.onerror = (event)=>observer.error(event);
        this.ws.onclose = (event)=>observer.complete();
        return()=>this.ws.close(1000, "The User Disconnect.");
      }
    );  
  }

  sendMessage(message: string): string
  {
    if( this.ws.readyState === this.socketIsOpen)
    {
      this.ws.send(message);
      return 'Sent Message To Server: ${message}';
    }
    else
    {
      return 'Message Not Sent - Socket Is Closed';      
    }
  }

  // sendJSON(message: string): string
  // {
  //   if( this.ws.readyState === this.socketIsOpen)
  //   {
  //     this.ws.send(JSON.stringify(object));
      
  //     return 'Sent Message To Server: ${message}';
  //   }
  //   else
  //   {
  //     return 'Message Not Sent - Socket Is Closed';      
  //   }
  // }


}
