import {ShapeComponent} from './shape.component';
import {ConfigDialog} from '../dialogs/configdialog';

export class TextComponent extends ShapeComponent{
  protected type = ShapeComponent.SYMBOL_TYPE_TEXT;
  m: TextMetrics;

  public static DEFAULT_COLOR_BORDER: string = "red";
  public static DEFAULT_COLOR_FILL: string = "green";
  public static DEFAULT_FONT_FAMILY: string = "Arial";
  public static DEFAULT_FONT_SIZE: number = 30;
  public static DEFAULT_TEXT:string = "TEXT";
  public static DEFAULT_IS_FILL:boolean = true;

  protected borderColor:string = TextComponent.DEFAULT_COLOR_BORDER;
  protected fillColor:string = TextComponent.DEFAULT_COLOR_FILL;

  protected fontFamily: string = TextComponent.DEFAULT_FONT_FAMILY;
  protected fontSize: number = TextComponent.DEFAULT_FONT_SIZE;
  protected isFill: boolean = TextComponent.DEFAULT_IS_FILL;
  protected text: string = TextComponent.DEFAULT_TEXT;

  public SetFontFamily(val: string)
  {
    this.fontFamily = val;
    this.SetFontString();
  }

  public SetFontSize(val: number)
  {
    this.fontSize = val;
    this.SetFontString();
  }

  public SetText(val: string)
  {
    this.text = val;
  }

  public SetIsFill(val: boolean)
  {
    this.isFill = val;
  }
  
    constructor(
        protected x: number,
        protected y: number,
        public ctx: CanvasRenderingContext2D
    ) 
    {
        super(x,y);

        // let fontstring:string = fontSize.toString() + "px " + fontFamily;
        // console.log("TextComponent() - font string: " + fontstring);
        // ctx.font = fontstring;
        // this.m = this.ctx.measureText(this.text);
    }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
        this.SetFontString();
    }

    private SetFontString()
    {
      let fontstring:string = this.fontSize.toString() + "px " + this.fontFamily;
      console.log("TextComponent() - font string: " + fontstring);

      this.ctx.font = fontstring;
      this.m = this.ctx.measureText(this.text);
    }
    
    protected ApplyConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      super.ApplyConfig(config);
      
      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_TEXT)
        {
          if( item.name == "border color")
          {
            this.setBorderColor(item.value);
          }
          else if( item.name == "fill color")
          {
            this.setFillColor(item.value);
          }
          else if( item.name == "font size")
          {
            this.fontSize = parseInt(item.value);
          }
          else if( item.name == "font family")
          {
            this.fontFamily = item.value;
          }
          else if( item.name == "isFill")
          {
            //this.isFill = item.value;
            this.isFill = Boolean(JSON.parse(item.value));
          }
          else if( item.name == "text")
          {
            //this.isFill = item.value;
            this.text = item.value;
          }          
        }
      }

      if( this.devicePoint )
      {
           this.devicePoint.Init(config);
      }
    }
  
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_TEXT)
        {
          if( item.name == "border color")
          {
            TextComponent.DEFAULT_COLOR_BORDER = item.default;
          }
          else if( item.name == "fill color")
          {
            TextComponent.DEFAULT_COLOR_FILL = item.default;
          }
          else if( item.name == "font size")
          {
            TextComponent.DEFAULT_FONT_SIZE = parseInt(item.default);
          }
          else if( item.name == "font family")
          {
            TextComponent.DEFAULT_FONT_FAMILY = item.default;
          }
          else if( item.name == "isFill")
          {
            TextComponent.DEFAULT_IS_FILL = Boolean(JSON.parse(item.default));
          }
          else if( item.name == "text")
          {
            TextComponent.DEFAULT_TEXT = item.default;
          }
       }
      }
    }


    public getType(): string
    {
         return this.type;
    } 

    public show()
    {
       console.log("textComponent.show():  x: " + this.x + "  y: " + this.y );
    }
      
   public draw( ctx: CanvasRenderingContext2D  )
   {
     //debugger 
     //alert("Executing TextComponent.draw()");
     ctx.beginPath();
     //ctx.font = this.font;
     let fontstring:string = this.fontSize.toString() + "px " + this.fontFamily;
     ctx.font = fontstring;
     if( this.isFill == true)
     {
       ctx.fillStyle = this.getFillColor();
        ctx.fillText(this.text, this.x, this.y);
     }
     else
     {
        ctx.strokeStyle = this.getBorderColor(); 
        ctx.strokeText(this.text, this.x, this.y);
     }
     ctx.closePath();

     if( this.drawBR )
     {
       this.drawBoundedRect(ctx);
     }
   }

   public drawBoundedRect( ctx: CanvasRenderingContext2D )
   {
     debugger
     // Draw Border.
     ctx.beginPath();
     ctx.strokeStyle = "pink";
     ctx.lineWidth = 1;
     ctx.setLineDash([1, 2]);
     ctx.rect( this.x, this.y-this.fontSize, this.m.width + 10, this.fontSize + 10);
     ctx.stroke();
     ctx.closePath();
   }
 
   public deserialize(obj:any)
   {
     debugger
     this.dragging = obj.dragging;
     this.dragTL = obj.dragTL;
     this.dragTR = obj.dragTR;
     this.dragBL = obj.dragBL;
     this.dragBR = obj.dragBR;
     this.closeEnough = obj.closeEnough;
     this.displayText = obj.displayText;
     this.borderColor = obj.borderColor;
     this.fillColor =obj.fillColor;
   }
 
   public isSelected(pos_x: number, pos_y: number): boolean
   {
     console.log("Executing text.component.isSelected() for pos_x: " + pos_x + "  pos_y: " + pos_y);

        // Make sure the given position's [x,y] coordinates 
        // fall within this shape's bounding rectangle.
        if ( (this.x <= pos_x) && 
             (this.x + this.m.width >= pos_x) &&
             (this.y >= pos_y) && 
             (this.y -this.fontSize <= pos_y))
        {
          console.log("Text Symbol Selected.");
          this.checkForResizing(pos_x, pos_y);
          return true;
        }

        console.log("Text Symbol NOT Selected.");
        return false;
   }

   checkForResizing(pos_x: number, pos_y: number) 
   {
     console.log("Executing RectangleComponent.checkForResizing() for x: " + pos_x + "  y:" + pos_y);

     this.initDraggingStates();

     if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Left corner.
          this.dragTL = true;
          console.log("dragTL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.m.width) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Right corner.
          this.dragTR = true;
          console.log("dragTR = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y + this.m.width) )
     {
          // Dragging Bottom-Left corner.
          this.dragBL = true;
          console.log("dragBL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.m.width) && this.isCloseEnough(pos_y, this.y + this.m.width) )
     {
          // Dragging Bottom-Right corner.
          this.dragBR = true;
          console.log("dragBR = true");
     }
     else
     {
          // Dragging entire symbol.
          this.dragging = true;
          console.log("dragging = true");
     }
   }


   public resizeTL(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeTL() for x: " + pos_x + "  y: " + pos_y);

     //this.m.width += this.x - pos_x;
     //this.m.width += this.y - pos_y;
     this.x = pos_x;
     this.y = pos_y;
   }

   public resizeTR(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeTR() for x: " + pos_x + "  y: " + pos_y);

   //   this.width = Math.abs(this.x - pos_x);
   //   this.height += this.y - pos_y;
   //   this.y = pos_y;
   }

   public resizeBL(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeBL() for x: " + pos_x + "  y: " + pos_y);

   //   this.width += this.x - pos_x;
   //   this.height = Math.abs(this.y - pos_y);
   //   this.x = pos_x;

   }

   public resizeBR(pos_x: number, pos_y: number)
   {
     console.log("Executing RectangleComponent.resizeBR() for x: " + pos_x + "  y: " + pos_y);

   //   this.width = Math.abs(this.x - pos_x);
   //   this.height = Math.abs(this.y - pos_y);
   }

   protected getFillColor(): string
   {
     if( this.devicePoint == null)
     {
         return this.fillColor;
     }
     return this.devicePoint.getFillColor();
   }

   protected getBorderColor(): string
   {
     if( this.devicePoint == null )
     {
         return this.borderColor;
     }
     else
     {
        //return this.devicePoint.getBorderColor();
        return this.devicePoint.getFillColor();
     }
   }

   protected setBorderColor(val: string)
   {
     this.borderColor = val;
   }

   protected setFillColor(val: string)
   {
     this.fillColor = val;
   }


   public LoadProperties(propdata: { [key: string]: Object }[])
  {
    console.log("Executing TextComponent.LoadProperties().");

    // Load the property array with symbol properties.
    let item:any = {name: "type", value: this.type};
    propdata.push(item);
    item = {name: "x", value: this.x};
    propdata.push(item);
    item = {name: "y", value: this.y};
    propdata.push(item);
    item = {name: "font", value: this.fontFamily};
    propdata.push(item);
    item = {name: "font size", value: this.fontSize};
    propdata.push(item);
    let fontstring:string = this.fontSize.toString() + "px " + this.fontFamily;
    item = {name: "font string", value: fontstring};
    propdata.push(item);
    item = {name: "text", value: this.text};
    propdata.push(item);
    item = {name: "isFill", value: this.isFill.toString()};
    propdata.push(item);
        
    if( this.devicePoint != null )
    {
      //item = {name: "", value: ""};
      //propdata.push(item);

      this.devicePoint.LoadProperties(propdata);
    }
    else
    {
      // Load the property array with symbol properties.
      let item:any = {name: "bordercolor", value: this.borderColor};
      propdata.push(item);
      item = {name: "fillcolor", value: this.fillColor};
      propdata.push(item);
    }
  }

  public saveProperty(name: string, value: string): boolean
  {
       console.log("Executing TextComponent.SaveProperty().");

       if( name == "bordercolor")
       {
           this.borderColor = value;
           return true;
       }
       else if( name == "fillcolor")
       {
           this.fillColor = value;
           return true;
       }
       else if( name == "x")
       {
           this.x = parseInt(value);
           return true;
       }
       else if( name == "y")
       {
           this.y = parseInt(value);
           return true;
       }   
       else if( name == "font")
       {
           this.fontFamily = value;
           let fontstring:string = this.fontSize.toString() + "px " + value;
           //this.font = fontstring;
           this.m = this.ctx.measureText(this.text);
           return true;
       }
       else if( name == "font size")
       {
           this.fontSize = parseInt(value);
           let fontstring:string = this.fontSize.toString() + "px " + this.fontFamily;
           //this.font = fontstring;
           //this.ctx.font = this.font;
           this.ctx.font = fontstring;
           this.m = this.ctx.measureText(this.text);
           return true;
       }
       else if( name == "text")
       {
           this.text = value;
           this.m = this.ctx.measureText(this.text);
           return true;
       }
       else if( name == "isFill")
       {
           this.isFill = Boolean(JSON.parse(value));
           return true;
       }
   
       //super.saveProperty(name, value);
       return false;
  }  

  
  public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
  {
       console.log("Executing TextComponent.LoadDefaultProperties().");

       let item:any = {name: "type", value: ShapeComponent.SYMBOL_TYPE_CIRCLE};
       propdata.push(item);
       
       item = {name: "bordercolor", value: TextComponent.DEFAULT_COLOR_BORDER};
       propdata.push(item);
       item = {name: "fillcolor", value: TextComponent.DEFAULT_COLOR_FILL};
       propdata.push(item);

       item = {name: "font", value: TextComponent.DEFAULT_FONT_FAMILY};
       propdata.push(item);
       item = {name: "font size", value: TextComponent.DEFAULT_FONT_SIZE};
       propdata.push(item);
       item = {name: "text", value: TextComponent.DEFAULT_TEXT};
       propdata.push(item);
   
     
       //super.LoadDefaultProperties(propdata);
  }


  public static saveDefaultProperty(name: string, value: string)
  {
       console.log("Executing TextComponent.SaveDefaultProperty().");

       if( name == "bordercolor")
       {
           TextComponent.DEFAULT_COLOR_BORDER = value;
       }
       else if( name == "fillcolor")
       {
           TextComponent.DEFAULT_COLOR_FILL = value;
       }
       else if( name == "font")
       {
           TextComponent.DEFAULT_FONT_FAMILY = value;
           return true;
       }
       else if( name == "font size")
       {
        TextComponent.DEFAULT_FONT_SIZE = parseInt(value);
           return true;
       }
       else if( name == "text")
       {
          TextComponent.DEFAULT_TEXT = value;
           return true;
       }
           
       //super.saveDefaultProperty(name, value);
  }
  
  // public AdjustProperties(): boolean
  // {
  //     return true;
  // }

}