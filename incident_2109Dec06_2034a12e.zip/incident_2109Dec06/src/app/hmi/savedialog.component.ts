import { Dialog } from '@syncfusion/ej2-popups';
import {DrawingBoardComponent} from './drawingboard.component';

export class SaveDialogComponent 
{
    public dialog: Dialog = null;

    private parent: DrawingBoardComponent = null; 
  
    constructor(dbc: DrawingBoardComponent)
    {
        //console.log("Executing SaveDialogComponent constructor.");
        this.parent = dbc;
    }

    // Creates the dialog.
    public CreateSaveDialog(show:boolean)
    {
        console.log("Executing SaveDialogComponent.CreateSaveDialog()");

        let dialogContent: string = "Do You Wish to Save Diagram?";

        //this.op_code = op;

        this.dialog = new Dialog(
        { 
            buttons: [
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        this.parent.Serialize(false);
                        this.Destroy();
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'YES'
                    }
                },
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        this.parent.ClearDiagram();
                        this.Destroy();
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'NO'
                    }
                },                
                // {
                //     'click': () => {
                //         this.Destroy();
                //     },
                //     buttonModel: {
                //         content: 'Cancel'
                //     }
                // }
            ],            
            header: 'Save Diagram Dialog', 
            target: document.getElementById('target'), 
            content: dialogContent,
            allowDragging: true,
            visible: show, 
            animationSettings: 
            { 
                effect: 'None' 
            }, 
            showCloseIcon: true,
            isModal: true, 
            width: '300px',
            height: '300px', 
            open: this.onDialogOpen,
            enableResize: true,
            position: {X: "center", Y:"center"},
            close: this.onDialogClose, 
            created: this.onDialogCreate.bind(this)
        }); 
        this.dialog.appendTo('#savedialog'); 
    }  


    // Dialog created Event callback.
    private onDialogCreate(args:any) 
    {
        //debugger
        //alert("Executing SaveDialogomponent.onDialogCreate()");
    } 

    // Dialog opened event callback
    private onDialogOpen()
    {
        //debugger;
        //alert("Executing SaveDialogComponent.onDialogOpen()");
    
    }

    // Dialog closed event callback.
    private onDialogClose()
    {
        //debugger;
        //alert("Executing SaveDialogComponent.onDialogClose()");

    }

    // Destroy (called when drawing board exits).
    public Destroy()
    {
        //debugger;
        //alert("Executing SaveDialogComponent.Destroy()");

        this.dialog.destroy();  
    }
    

  

}
