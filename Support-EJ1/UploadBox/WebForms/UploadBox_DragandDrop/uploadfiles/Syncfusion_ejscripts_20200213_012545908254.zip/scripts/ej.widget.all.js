﻿/*!
*  filename: ej.widget.all.js
*  version : 17.4.0.46
*  Copyright Syncfusion Inc. 2001 - 2020. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
*/


window.ej = window.Syncfusion = window.Syncfusion || {};


(function ($, ej, undefined) {
    'use strict';

    ej.version = "17.4.0.46";

    ej.consts = {
        NamespaceJoin: '-'
    };
    ej.TextAlign = {
        Center: 'center',
        Justify: 'justify',
        Left: 'left',
        Right: 'right'
    };
    ej.Orientation = { Horizontal: "horizontal", Vertical: "vertical" };

    ej.serverTimezoneOffset = 0;

    ej.parseDateInUTC = false;

    ej.persistStateVersion = null;

    ej.locales = ej.locales || [];

    if (!Object.prototype.hasOwnProperty) {
        Object.prototype.hasOwnProperty = function (obj, prop) {
            return obj[prop] !== undefined;
        };
    }

    //to support toISOString() in IE8
    if (!Date.prototype.toISOString) {
        (function () {
            function pad(number) {
                var r = String(number);
                if (r.length === 1) {
                    r = '0' + r;
                }
                return r;
            }
            Date.prototype.toISOString = function () {
                return this.getUTCFullYear()
                    + '-' + pad(this.getUTCMonth() + 1)
                    + '-' + pad(this.getUTCDate())
                    + 'T' + pad(this.getUTCHours())
                    + ':' + pad(this.getUTCMinutes())
                    + ':' + pad(this.getUTCSeconds())
                    + '.' + String((this.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5)
                    + 'Z';
            };
        }());
    }

    String.format = function () {
        var source = arguments[0];
        for (var i = 0; i < arguments.length - 1; i++)
            source = source.replace(new RegExp("\\{" + i + "\\}", "gm"), arguments[i + 1]);

        source = source.replace(/\{[0-9]\}/g, "");
        return source;
    };

    jQuery.uaMatch = function (ua) {
        ua = ua.toLowerCase();

        var match = /(chrome)[ \/]([\w.]+)/.exec(ua) ||
            /(webkit)[ \/]([\w.]+)/.exec(ua) ||
            /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) ||
            /(msie) ([\w.]+)/.exec(ua) ||
            ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) ||
            [];

        return {
            browser: match[1] || "",
            version: match[2] || "0"
        };
    };
    // Function to create new class
    ej.defineClass = function (className, constructor, proto, replace) {
        /// <summary>Creates the javascript class with given namespace & class name & constructor etc</summary>
        /// <param name="className" type="String">class name prefixed with namespace</param>
        /// <param name="constructor" type="Function">constructor function</param>
        /// <param name="proto" type="Object">prototype for the class</param>
        /// <param name="replace" type="Boolean">[Optional]Replace existing class if exists</param>
        /// <returns type="Function">returns the class function</returns>
        if (!className || !proto) return undefined;

        var parts = className.split(".");

        // Object creation
        var obj = window, i = 0;
        for (; i < parts.length - 1; i++) {

            if (ej.isNullOrUndefined(obj[parts[i]]))
                obj[parts[i]] = {};

            obj = obj[parts[i]];
        }

        if (replace || ej.isNullOrUndefined(obj[parts[i]])) {

            //constructor
            constructor = typeof constructor === "function" ? constructor : function () {
            };

            obj[parts[i]] = constructor;

            // prototype
            obj[parts[i]].prototype = proto;
        }

        return obj[parts[i]];
    };

    ej.util = {
        getNameSpace: function (className) {
            /// <summary>Internal function, this will create namespace for plugins using class name</summary>
            /// <param name="className" type="String"></param>
            /// <returns type="String"></returns>
            var splits = className.toLowerCase().split(".");
            splits[0] === "ej" && (splits[0] = "e");

            return splits.join(ej.consts.NamespaceJoin);
        },

        getObject: function (nameSpace, from) {
            if (!from || !nameSpace) return undefined;
			(typeof(nameSpace) != "string") && (nameSpace = JSON.stringify(nameSpace));
            var value = from, splits = nameSpace.split('.');

            for (var i = 0; i < splits.length; i++) {

                if (ej.util.isNullOrUndefined(value)) break;

                value = value[splits[i]];
            }

            return value;
        },

        createObject: function (nameSpace, value, initIn) {
            var splits = nameSpace.split('.'), start = initIn || window, from = start, i, t, length = splits.length;

            for (i = 0; i < length; i++) {
                t = splits[i];
                if (i + 1 == length)
                    from[t] = value;
                else if (ej.isNullOrUndefined(from[t]))
                    from[t] = {};

                from = from[t];
            }

            return start;
        },

        isNullOrUndefined: function (value) {
            /// <summary>Util to check null or undefined</summary>
            /// <param name="value" type="Object"></param>
            /// <returns type="Boolean"></returns>
            return value === undefined || value === null;
        },
        exportAll: function (action, controlIds) {
            var inputAttr = [], widget, locale = [], index, controlEle, controlInstance, controlObject, modelClone;
            var attr = { action: action, method: 'post', "data-ajax": "false" };
            var form = ej.buildTag('form', "", null, attr);
            if (controlIds.length != 0) {
                for (var i = 0; i < controlIds.length; i++) {
                    index = i;
                    controlEle = $("#" + controlIds[i]);
                    controlInstance = $("#" + controlIds[i]).data();
                    widget = controlInstance["ejWidgets"];
                    controlObject = $(controlEle).data(widget[0]);
                    locale.push({ id: controlObject._id, locale: controlObject.model.locale });
                    if (!ej.isNullOrUndefined(controlObject)) {
                        modelClone = controlObject._getExportModel(controlObject.model);
                        inputAttr.push({ name: widget[0], type: 'hidden', value: controlObject.stringify(modelClone) });
                        var input = ej.buildTag('input', "", null, inputAttr[index]);
                        form.append(input);
                    }
                }
                $('body').append(form);
                form.submit();
                setTimeout(function () {
                    var ctrlInstance, ctrlObject;
                    if (locale.length) {
                        for (var j = 0; j < locale.length; j++) {
                            if (!ej.isNullOrUndefined(locale[j].locale)) {
                                ctrlInstance = $("#" + locale[j].id).data();
                                widget = ctrlInstance["ejWidgets"];
                                ctrlObject = $("#" + locale[j].id).data(widget[0]);
                                ctrlObject.model.locale = locale[j].locale;
                            }
                        }
                    }
                }, 0);
                form.remove();
            }
            return true;
        },
        print: function (element, printWin) {
            var $div = ej.buildTag('div')
            var elementClone = element.clone();
            $div.append(elementClone);
            if (!printWin)
                var printWin = window.open('', 'print', "height=452,width=1024,tabbar=no");
            printWin.document.write('<!DOCTYPE html>');
            var links = $('head').find('link').add("style");
            if (ej.browserInfo().name === "msie") {
                var a = ""
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.write('<html><head></head><body>' + a + $div[0].innerHTML + '</body></html>');
            }
            else {
                var a = ""
                printWin.document.write('<html><head>')
                links.each(function (index, obj) {
                    if (obj.tagName == "LINK")
                        $(obj).attr('href', obj.href);
                    a += obj.outerHTML;
                });
                printWin.document.writeln(a + '</head><body>')
                printWin.document.writeln($div[0].innerHTML + '</body></html>')
            }
            printWin.document.close();
            printWin.focus();
            setTimeout(function () {
                if (!ej.isNullOrUndefined(printWin.window)) {
                    printWin.print();
                    setTimeout(function () { printWin.close() }, 1000);
                }
            }, 1000);
        },
        ieClearRemover: function (element) {
            var searchBoxHeight = $(element).height();
            element.style.paddingTop = parseFloat(searchBoxHeight / 2) + "px";
            element.style.paddingBottom = parseFloat(searchBoxHeight / 2) + "px";
            element.style.height = "1px";
            element.style.lineHeight = "1px";
        },
        //To send ajax request
        sendAjaxRequest: function (ajaxOptions) {
            $.ajax({
                type: ajaxOptions.type,
                cache: ajaxOptions.cache,
                url: ajaxOptions.url,
                dataType: ajaxOptions.dataType,
                data: ajaxOptions.data,
                contentType: ajaxOptions.contentType,
                async: ajaxOptions.async,
                success: ajaxOptions.successHandler,
                error: ajaxOptions.errorHandler,
                beforeSend: ajaxOptions.beforeSendHandler,
                complete: ajaxOptions.completeHandler
            });
        },

        buildTag: function (tag, innerHtml, styles, attrs) {
            /// <summary>Helper to build jQuery element</summary>
            /// <param name="tag" type="String">tagName#id.cssClass</param>
            /// <param name="innerHtml" type="String"></param>
            /// <param name="styles" type="Object">A set of key/value pairs that configure styles</param>
            /// <param name="attrs" type="Object">A set of key/value pairs that configure attributes</param>
            /// <returns type="jQuery"></returns>
            var tagName = /^[a-z]*[0-9a-z]+/ig.exec(tag)[0];

           var id = /#([_a-z0-9-&@\/\\,+()$~%:*?<>{}\[\]]+\S)/ig.exec(tag);
            id = id ? id[id.length - 1].replace(/[&@\/\\,+()$~%.:*?<>{}\[\]]/g, ''): undefined;

            var className = /\.([a-z]+[-_0-9a-z ]+)/ig.exec(tag);
            className = className ? className[className.length - 1] : undefined;

            return $(document.createElement(tagName))
                .attr(id ? { "id": id } : {})
                .addClass(className || "")
                .css(styles || {})
                .attr(attrs || {})
                .html(innerHtml || "");
        },
        _preventDefaultException: function (el, exceptions) {
            if (el) {
                for (var i in exceptions) {
                    if (exceptions[i].test(el[i])) {
                        return true;
                    }
                }
            }

            return false;
        },

        //Gets the maximum z-index in the document
        getMaxZindex: function () {
            var maxZ = 1;
            maxZ = Math.max.apply(null, $.map($('body *'), function (e, n) {
                if ($(e).css('position') == 'absolute' || $(e).css('position') == 'fixed')
                    return parseInt($(e).css('z-index')) || 1;
            })
            );
            if (maxZ == undefined || maxZ == null)
                maxZ = 1;
            return maxZ;
        },

        //To prevent default actions for the element
        blockDefaultActions: function (e) {
            e.cancelBubble = true;
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
            if (e.stopPropagation) e.stopPropagation();
        },

        //To get dimensions of the element when its hidden
        getDimension: function (element, method) {
            var value;
            var $hidden = $(element).parents().andSelf().filter(':hidden');
            if ($hidden) {
                var prop = { visibility: 'hidden', display: 'block' };
                var tmp = [];
                $hidden.each(function () {
                    var temp = {}, name;
                    for (name in prop) {
                        temp[name] = this.style[name];
                        this.style[name] = prop[name];
                    }
                    tmp.push(temp);
                });
                value = /(outer)/g.test(method) ?
                $(element)[method](true) :
               $(element)[method]();

                $hidden.each(function (i) {
                    var temp = tmp[i], name;
                    for (name in prop) {
                        this.style[name] = temp[name];
                    }
                });
            }
            return value;
        },
        //Get triggers when transition End
        transitionEndEvent: function () {
            var transitionEnd = {
                '': 'transitionend',
                'webkit': 'webkitTransitionEnd',
                'Moz': 'transitionend',
                'O': 'otransitionend',
                'ms': 'MSTransitionEnd'
            };

            return transitionEnd[ej.userAgent()];
        },
        //Get triggers when transition End
        animationEndEvent: function () {
            var animationEnd = {
                '': 'animationend',
                'webkit': 'webkitAnimationEnd',
                'Moz': 'animationend',
                'O': 'webkitAnimationEnd',
                'ms': 'animationend'
            };

            return animationEnd[ej.userAgent()];
        },
        //To return the start event to bind for element
        startEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchstart" : "mousedown";
        },
        //To return end event to bind for element
        endEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchend" : "mouseup"
        },
        //To return move event to bind for element
        moveEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? ($.support.hasPointer && !ej.isMobile()) ? "ejtouchmove" : "touchmove" : "mousemove";
        },
        //To return cancel event to bind for element
        cancelEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "touchcancel" : "mousecancel";
        },
        //To return tap event to bind for element
        tapEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "tap" : "click";
        },
        //To return tap hold event to bind for element
        tapHoldEvent: function () {
            return (ej.isTouchDevice() || $.support.hasPointer) ? "taphold" : "click";
        },
        //To check whether its Device
        isDevice: function () {
            if (ej.getBooleanVal($('head'), 'data-ej-forceset', false))
                return ej.getBooleanVal($('head'), 'data-ej-device', this._device());
            else
                return this._device();
        },
        //To check whether its portrait or landscape mode
        isPortrait: function () {
            var elem = document.documentElement;
            return (elem) && ((elem.clientWidth / elem.clientHeight) < 1.1);
        },
        //To check whether its in lower resolution
        isLowerResolution: function () {
            return ((window.innerWidth <= 640 && ej.isPortrait() && ej.isDevice()) || (window.innerWidth <= 800 && !ej.isDevice()) || (window.innerWidth <= 800 && !ej.isPortrait() && ej.isWindows() && ej.isDevice()) || ej.isMobile());
        },
        //To check whether its iOS web view
        isIOSWebView: function () {
            return (/(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent));
        },
        //To check whether its Android web view
        isAndroidWebView: function () {
            return (!(typeof (Android) === "undefined"));
        },
        //To check whether its windows web view
        isWindowsWebView: function () {
            return location.href.indexOf("x-wmapp") != -1;
        },
        _device: function () {
            return (/Android|BlackBerry|iPhone|iPad|iPod|IEMobile|kindle|windows\sce|palm|smartphone|iemobile|mobile|pad|xoom|sch-i800|playbook/i.test(navigator.userAgent.toLowerCase()));
        },
        //To check whether its Mobile
        isMobile: function () {
            return ((/iphone|ipod|android|blackberry|opera|mini|windows\sce|palm|smartphone|iemobile/i.test(navigator.userAgent.toLowerCase()) && /mobile/i.test(navigator.userAgent.toLowerCase()))) || (ej.getBooleanVal($('head'), 'data-ej-mobile', false) === true);
        },
        //To check whether its Tablet
        isTablet: function () {
            return (/ipad|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase())) || (ej.getBooleanVal($('head'), 'data-ej-tablet', false) === true) || (!ej.isMobile() && ej.isDevice());
        },
        //To check whether its Touch Device
        isTouchDevice: function () {
            return (('ontouchstart' in window || (window.navigator.msPointerEnabled && ej.isMobile())) && this.isDevice());
        },
        //To get the outerHTML string for object
        getClearString: function (string) {
            return $.trim(string.replace(/\s+/g, " ").replace(/(\r\n|\n|\r)/gm, "").replace(new RegExp("\>[\n\t ]+\<", "g"), "><"));
        },
        //Get the attribute value with boolean type of element
        getBooleanVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value.toLowerCase() == "true";
            else
                return option;
        },
        //Gets the Skew class based on the element current position
        _getSkewClass: function (item, pageX, pageY) {
            var itemwidth = item.width();
            var itemheight = item.height();
            var leftOffset = item.offset().left;
            var rightOffset = item.offset().left + itemwidth;
            var topOffset = item.offset().top;
            var bottomOffset = item.offset().top + itemheight;
            var widthoffset = itemwidth * 0.3;
            var heightoffset = itemheight * 0.3;
            if (pageX < leftOffset + widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topleft";
            if (pageX > rightOffset - widthoffset && pageY < topOffset + heightoffset)
                return "e-m-skew-topright";
            if (pageX > rightOffset - widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomright";
            if (pageX < leftOffset + widthoffset && pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottomleft";
            if (pageX > leftOffset + widthoffset && pageY < topOffset + heightoffset && pageX < rightOffset - widthoffset)
                return "e-m-skew-top";
            if (pageX < leftOffset + widthoffset)
                return "e-m-skew-left";
            if (pageX > rightOffset - widthoffset)
                return "e-m-skew-right";
            if (pageY > bottomOffset - heightoffset)
                return "e-m-skew-bottom";
            return "e-m-skew-center";
        },
        //Removes the added Skew class on the element
        _removeSkewClass: function (element) {
            $(element).removeClass("e-m-skew-top e-m-skew-bottom e-m-skew-left e-m-skew-right e-m-skew-topleft e-m-skew-topright e-m-skew-bottomleft e-m-skew-bottomright e-m-skew-center e-skew-top e-skew-bottom e-skew-left e-skew-right e-skew-topleft e-skew-topright e-skew-bottomleft e-skew-bottomright e-skew-center");
        },
        //Object.keys  method to support all the browser including IE8.
        _getObjectKeys: function (obj) {
            var i, keys = [];
            obj = Object.prototype.toString.call(obj) === Object.prototype.toString() ? obj : {};
            if (!Object.keys) {
                for (i in obj) {
                    if (obj.hasOwnProperty(i))
                        keys.push(i);
                }
                return keys;
            }
            if (Object.keys)
                return Object.keys(obj);
        },
        _touchStartPoints: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt;
                object._distX = 0;
                object._distY = 0;
                object._moved = false;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
            }
        },
        _isTouchMoved: function (evt, object) {
            if (evt) {
                var point = evt.touches ? evt.touches[0] : evt,
                deltaX = point.pageX - object._pointX,
                deltaY = point.pageY - object._pointY,
                timestamp = Date.now(),
                newX, newY,
                absDistX, absDistY;
                object._pointX = point.pageX;
                object._pointY = point.pageY;
                object._distX += deltaX;
                object._distY += deltaY;
                absDistX = Math.abs(object._distX);
                absDistY = Math.abs(object._distY);
                return !(absDistX < 5 && absDistY < 5);
            }
        },
        //To bind events for element
        listenEvents: function (selectors, eventTypes, handlers, remove, pluginObj, disableMouse) {
            for (var i = 0; i < selectors.length; i++) {
                ej.listenTouchEvent(selectors[i], eventTypes[i], handlers[i], remove, pluginObj, disableMouse);
            }
        },
        //To bind touch events for element
        listenTouchEvent: function (selector, eventType, handler, remove, pluginObj, disableMouse) {
            var event = remove ? "removeEventListener" : "addEventListener";
            var jqueryEvent = remove ? "off" : "on";
            var elements = $(selector);
            for (var i = 0; i < elements.length; i++) {
                var element = elements[i];
                switch (eventType) {
                    case "touchstart":
                        ej._bindEvent(element, event, eventType, handler, "mousedown", "MSPointerDown", "pointerdown", disableMouse);
                        break;
                    case "touchmove":
                        ej._bindEvent(element, event, eventType, handler, "mousemove", "MSPointerMove", "pointermove", disableMouse);
                        break;
                    case "touchend":
                        ej._bindEvent(element, event, eventType, handler, "mouseup", "MSPointerUp", "pointerup", disableMouse);
                        break;
                    case "touchcancel":
                        ej._bindEvent(element, event, eventType, handler, "mousecancel", "MSPointerCancel", "pointercancel", disableMouse);
                        break;
                    case "tap": case "taphold": case "ejtouchmove": case "click":
                        $(element)[jqueryEvent](eventType, handler);
                        break;
                    default:
                        if (ej.browserInfo().name == "msie" && ej.browserInfo().version < 9)
                            pluginObj["_on"]($(element), eventType, handler);
                        else
                            element[event](eventType, handler, true);
                        break;
                }
            }
        },
        //To bind events for element
        _bindEvent: function (element, event, eventType, handler, mouseEvent, pointerEvent, ie11pointerEvent, disableMouse) {
            if ($.support.hasPointer)
                element[event](window.navigator.pointerEnabled ? ie11pointerEvent : pointerEvent, handler, true);
            else
                element[event](eventType, handler, true);
        },
        _browser: function () {
            return (/webkit/i).test(navigator.appVersion) ? 'webkit' : (/firefox/i).test(navigator.userAgent) ? 'Moz' : (/trident/i).test(navigator.userAgent) ? 'ms' : 'opera' in window ? 'O' : '';
        },
        styles: document.createElement('div').style,
        /**
       * To get the userAgent Name     
       * @example             
       * &lt;script&gt;
       *       ej.userAgent();//return user agent name
       * &lt;/script&gt         
       * @memberof AppView
       * @instance
       */
        userAgent: function () {
            var agents = 'webkitT,t,MozT,msT,OT'.split(','),
            t,
            i = 0,
            l = agents.length;

            for (; i < l; i++) {
                t = agents[i] + 'ransform';
                if (t in ej.styles) {
                    return agents[i].substr(0, agents[i].length - 1);
                }
            }

            return false;
        },
        addPrefix: function (style) {
            if (ej.userAgent() === '') return style;

            style = style.charAt(0).toUpperCase() + style.substr(1);
            return ej.userAgent() + style;
        },
        //To Prevent Default Exception

        //To destroy the mobile widgets
        destroyWidgets: function (element) {
            var dataEl = $(element).find("[data-role *= ejm]");
            dataEl.each(function (index, element) {
                var $element = $(element);
                var plugin = $element.data("ejWidgets");
                if (plugin)
                    $element[plugin]("destroy");
            });
        },
        //Get the attribute value of element
        getAttrVal: function (ele, val, option) {
            /// <summary>Util to get the property from data attributes</summary>
            /// <param name="ele" type="Object"></param>
            /// <param name="val" type="String"></param>
            /// <param name="option" type="GenericType"></param>
            /// <returns type="GenericType"></returns>
            var value = $(ele).attr(val);
            if (value != null)
                return value;
            else
                return option;
        },

        // Get the offset value of element
        getOffset: function (ele) {
            var pos = {};
            var offsetObj = ele.offset() || { left: 0, top: 0 };
            $.extend(true, pos, offsetObj);
            if ($("body").css("position") != "static") {
                var bodyPos = $("body").offset();
                pos.left -= bodyPos.left;
                pos.top -= bodyPos.top;
            }
            return pos;
        },

        // Z-index calculation for the element
        getZindexPartial: function (element, popupEle) {
            if (!ej.isNullOrUndefined(element) && element.length > 0) {
                var parents = element.parents(), bodyEle;
                bodyEle = $('body').children();
                if (!ej.isNullOrUndefined(element) && element.length > 0)
                    bodyEle.splice(bodyEle.index(popupEle), 1);
                $(bodyEle).each(function (i, ele) { parents.push(ele); });

                var maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                    if ($(e).css('position') != 'static') return parseInt($(e).css('z-index')) || 1;
                }));
                if (!maxZ || maxZ < 10000) maxZ = 10000;
                else maxZ += 1;
                return maxZ;
            }
        },

        isValidAttr: function (element, attribute) {
            var element = $(element)[0];
            if (typeof element[attribute] != "undefined")
                return true;
            else {
                var _isValid = false;
                $.each(element, function (key) {
                    if (key.toLowerCase() == attribute.toLowerCase()) {
                        _isValid = true;
                        return false;
                    }
                });
            }
            return _isValid;
        }

    };

    $.extend(ej, ej.util);

    // base class for all ej widgets. It will automatically inhertied
    ej.widgetBase = {
        droppables: { 'default': [] },
        resizables: { 'default': [] },

        _renderEjTemplate: function (selector, data, index, prop, ngTemplateType) {
            var type = null;
            if (typeof selector === "object" || selector.startsWith("#") || selector.startsWith("."))
                type = $(selector).attr("type");
            if (type) {
                type = type.toLowerCase();
                if (ej.template[type])
                    return ej.template[type](this, selector, data, index, prop);
            }
            // For ejGrid Angular2 Template Support
            else if (!ej.isNullOrUndefined(ngTemplateType))
                 return ej.template['text/x-'+ ngTemplateType](this, selector, data, index, prop);
            return ej.template.render(this, selector, data, index, prop);
        },

        destroy: function () {

            if (this._trigger("destroy"))
                return;

            if (this.model.enablePersistence) {
                this.persistState();
                $(window).off("unload", this._persistHandler);
            }

            try {
                this._destroy();
            } catch (e) { }

            var arr = this.element.data("ejWidgets") || [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] == this.pluginName) {
                    arr.splice(i, 1);
                }
            }
            if (!arr.length)
                this.element.removeData("ejWidgets");

            while (this._events) {
                var item = this._events.pop(), args = [];

                if (!item)
                    break;

                for (var i = 0; i < item[1].length; i++)
                    if (!$.isPlainObject(item[1][i]))
                        args.push(item[1][i]);

                $.fn.off.apply(item[0], args);
            }

            this._events = null;

            this.element
                .removeClass(ej.util.getNameSpace(this.sfType))
                .removeClass("e-js")
                .removeData(this.pluginName);

            this.element = null;
            this.model = null;
        },

        _on: function (element) {
            if (!this._events)
                this._events = [];
            var args = [].splice.call(arguments, 1, arguments.length - 1);

            var handler = {}, i = args.length;
            while (handler && typeof handler !== "function") {
                handler = args[--i];
            }

            args[i] = ej.proxy(args[i], this);

            this._events.push([element, args, handler, args[i]]);

            $.fn.on.apply(element, args);

            return this;
        },

        _off: function (element, eventName, selector, handlerObject) {
            var e = this._events, temp;
            if (!e || !e.length)
                return this;
            if (typeof selector == "function") {
                temp = handlerObject;
                handlerObject = selector;
                selector = temp;
            }
            var t = (eventName.match(/\S+/g) || [""]);
            for (var i = 0; i < e.length; i++) {
                var arg = e[i],
                r = arg[0].length && (!handlerObject || arg[2] === handlerObject) && (arg[1][0] === eventName || t[0]) && (!selector || arg[1][1] === selector) && $.inArray(element[0], arg[0]) > -1;
                if (r) {
                    $.fn.off.apply(element, handlerObject ? [eventName, selector, arg[3]] : [eventName, selector]);
                    e.splice(i, 1);
                    break;
                }
            }

            return this;
        },

        // Client side events wire-up / trigger helper.
        _trigger: function (eventName, eventProp) {
            var fn = null, returnValue, args, clientProp = {};
            $.extend(clientProp, eventProp)

            if (eventName in this.model)
                fn = this.model[eventName];

            if (fn) {
                if (typeof fn === "string") {
                    fn = ej.util.getObject(fn, window);
                }

                if ($.isFunction(fn)) {

                    args = ej.event(eventName, this.model, eventProp);

                    
                    returnValue = fn.call(this, args);

                    // sending changes back - deep copy option should not be enabled for this $.extend 
                    if (eventProp) $.extend(eventProp, args);

                    if (args.cancel || !ej.isNullOrUndefined(returnValue))
                        return returnValue === false || args.cancel;
                }
            }

            var isPropDefined = Boolean(eventProp);
            eventProp = eventProp || {};
            eventProp.originalEventType = eventName;
            eventProp.type = this.pluginName + eventName;

            args = $.Event(eventProp.type, ej.event(eventProp.type, this.model, eventProp));

            this.element && this.element.trigger(args);

            // sending changes back - deep copy option should not be enabled for this $.extend 
            if (isPropDefined) $.extend(eventProp, args);

            if (ej.isOnWebForms && args.cancel == false && this.model.serverEvents && this.model.serverEvents.length)
                ej.raiseWebFormsServerEvents(eventName, eventProp, clientProp);

            return args.cancel;
        },

        setModel: function (options, forceSet) {
            // check for whether to apply values are not. if _setModel function is defined in child,
            //  this will call that function and validate it using return value

            if (this._trigger("modelChange", { "changes": options }))
                return;

            for (var prop in options) {
                if (!forceSet) {
                    if (this.model[prop] === options[prop]) {
                        delete options[prop];
                        continue;
                    }
                    if ($.isPlainObject(options[prop])) {
                        iterateAndRemoveProps(this.model[prop], options[prop]);
                        if ($.isEmptyObject(options[prop])) {
                            delete options[prop];
                            continue;
                        }
                    }
                }

                if (this.dataTypes) {
                    var returnValue = this._isValidModelValue(prop, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + prop + " - " + returnValue;
                }
                if (this.model.notifyOnEachPropertyChanges && this.model[prop] !== options[prop]) {
                    var arg = {
                        oldValue: this.model[prop],
                        newValue: options[prop]
                    };

                    options[prop] = this._trigger(prop + "Change", arg) ? this.model[prop] : arg.newValue;
                }
            }
            if ($.isEmptyObject(options))
                return;

            if (this._setFirst) {
                var ds = options.dataSource;
                if (ds) delete options.dataSource;

                $.extend(true, this.model, options);
                if (ds) {
                    this.model.dataSource = (ds instanceof Array) ? ds.slice() : ds;
                    options["dataSource"] = this.model.dataSource;
                }
                !this._setModel || this._setModel(options);

            } else if (!this._setModel || this._setModel(options) !== false) {
                $.extend(true, this.model, options);
            }
            if ("enablePersistence" in options) {
                this._setState(options.enablePersistence);
            }
        },
        option: function (prop, value, forceSet) {
            if (!prop)
                return this.model;

            if ($.isPlainObject(prop))
                return this.setModel(prop, forceSet);

            if (typeof prop === "string") {
                prop = prop.replace(/^model\./, "");
                var oldValue = ej.getObject(prop, this.model);

                if (value === undefined && !forceSet)
                    return oldValue;

                if (prop === "enablePersistence")
                    return this._setState(value);

                if (forceSet && value === ej.extensions.modelGUID) {
                    return this._setModel(ej.createObject(prop, ej.getObject(prop, this.model), {}));
                }

                if (forceSet || ej.getObject(prop, this.model) !== value)
                    return this.setModel(ej.createObject(prop, value, {}), forceSet);
            }
            return undefined;
        },

        _isValidModelValue: function (prop, types, options) {
            var value = types[prop], option = options[prop], returnValue;

            if (!value)
                return true;

            if (typeof value === "string") {
                if (value == "enum") {
                    options[prop] = option ? option.toString().toLowerCase() : option;
                    value = "string";
                }

                if (value === "array") {
                    if (Object.prototype.toString.call(option) === '[object Array]')
                        return true;
                }
                else if (value === "data") {
                    return true;
                }
                else if (value === "parent") {
                    return true;
                }
                else if (typeof option === value)
                    return true;

                return "Expected type - " + value;
            }

            if (option instanceof Array) {
                for (var i = 0; i < option.length; i++) {
                    returnValue = this._isValidModelValue(prop, types, option[i]);
                    if (returnValue !== true) {
                        return " [" + i + "] - " + returnValue;
                    }
                }
                return true;
            }

            for (var innerProp in option) {
                returnValue = this._isValidModelValue(innerProp, value, option);
                if (returnValue !== true)
                    return innerProp + " : " + returnValue;
            }

            return true;
        },

        _returnFn: function (obj, propName) {
            if (propName.indexOf('.') != -1) {
                this._returnFn(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
            }
            else
                obj[propName] = obj[propName].call(obj.propName);
        },

        _removeCircularRef: function (obj) {
            var seen = [];
            function detect(obj, key, parent) {
                if (typeof obj != 'object') { return; }
                if (!Array.prototype.indexOf) {
                    Array.prototype.indexOf = function (val) {
                        return jQuery.inArray(val, this);
                    };
                }
                if (seen.indexOf(obj) >= 0) {
                    delete parent[key];
                    return;
                }
                seen.push(obj);
                for (var k in obj) { //dive on the object's children
                    if (obj.hasOwnProperty(k)) { detect(obj[k], k, obj); }
                }
                seen.pop();
                return;
            }
            detect(obj, 'obj', null);
            return obj;
        },

        stringify: function (model, removeCircular) {
            var observables = this.observables;
            for (var k = 0; k < observables.length; k++) {
                var val = ej.getObject(observables[k], model);
                if (!ej.isNullOrUndefined(val) && typeof (val) === "function")
                    this._returnFn(model, observables[k]);
            }
            if (removeCircular) model = this._removeCircularRef(model);
            return JSON.stringify(model);
        },

        _setState: function (val) {
            if (val === true) {
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
            } else {
                this.deleteState();
                $(window).off("unload", this._persistHandler);
            }
        },

        _removeProp: function (obj, propName) {
            if (!ej.isNullOrUndefined(obj)) {
                if (propName.indexOf('.') != -1) {
                    this._removeProp(obj[propName.split('.')[0]], propName.split('.').slice(1).join('.'));
                }
                else
                    delete obj[propName];
            }
        },

        persistState: function () {
            var model;

            if (this._ignoreOnPersist) {
                model = copyObject({}, this.model);
                for (var i = 0; i < this._ignoreOnPersist.length; i++) {
                    this._removeProp(model, this._ignoreOnPersist[i]);
                }
                model.ignoreOnPersist = this._ignoreOnPersist;
            } else if (this._addToPersist) {
                model = {};
                for (var i = 0; i < this._addToPersist.length; i++) {
                    ej.createObject(this._addToPersist[i], ej.getObject(this._addToPersist[i], this.model), model);
                }
                model.addToPersist = this._addToPersist;
            } else {
                model = copyObject({}, this.model);
            }

            if (this._persistState) {
                model.customPersists = {};
                this._persistState(model.customPersists);
            }

            if (window.localStorage) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") == null)
                    window.localStorage.setItem("persistKey", ej.persistStateVersion);
                window.localStorage.setItem("$ej$" + this.pluginName + this._id, JSON.stringify(model));
            }
            else if (document.cookie) {
                if (!ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") == null)
                    ej.cookie.set("persistKey", ej.persistStateVersion);
                ej.cookie.set("$ej$" + this.pluginName + this._id, model);
            }
        },

        deleteState: function () {
            var model;
            if (window.localStorage)
                window.localStorage.removeItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                ej.cookie.set("$ej$" + this.pluginName + this._id, model, new Date());
        },

        restoreState: function (silent) {
            var value = null;
            if (window.localStorage)
                value = window.localStorage.getItem("$ej$" + this.pluginName + this._id);
            else if (document.cookie)
                value = ej.cookie.get("$ej$" + this.pluginName + this._id);

            if (value) {
                var model = JSON.parse(value);

                if (this._restoreState) {
                    this._restoreState(model.customPersists);
                    delete model.customPersists;
                }

                if (ej.isNullOrUndefined(model) === false)
                    if (!ej.isNullOrUndefined(model.ignoreOnPersist)) {
                        this._ignoreOnPersist = model.ignoreOnPersist;
                        delete model.ignoreOnPersist;
                    } else if (!ej.isNullOrUndefined(model.addToPersist)) {
                        this._addToPersist = model.addToPersist;
                        delete model.addToPersist;
                    }
            }
            if (!ej.isNullOrUndefined(model) && !ej.isNullOrUndefined(this._ignoreOnPersist)) {
                for(var i = 0, len =  this._ignoreOnPersist.length; i < len; i++) {
					if (this._ignoreOnPersist[i].indexOf('.') !== -1)
                        ej.createObject(this._ignoreOnPersist[i], ej.getObject(this._ignoreOnPersist[i], this.model), model);
                    else
                        model[this._ignoreOnPersist[i]] = this.model[this._ignoreOnPersist[i]];
				}
                this.model = model;
            }
            else
                this.model = $.extend(true, this.model, model);

            if (!silent && value && this._setModel)
                this._setModel(this.model);
        },

        //to prevent persistence
        ignoreOnPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    this._ignoreOnPersist.push(collection[i]);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    var index = this._addToPersist.indexOf(collection[i]);
                    this._addToPersist.splice(index, 1);
                }
            }
        },

        //to maintain persistence
        addToPersist: function (properties) {
            var collection = [];
            if (typeof (properties) == "object")
                collection = properties;
            else if (typeof (properties) == 'string')
                collection.push(properties);
            if (this._addToPersist === undefined) {
                this._ignoreOnPersist = this._ignoreOnPersist || [];
                for (var i = 0; i < collection.length; i++) {
                    var index = this._ignoreOnPersist.indexOf(collection[i]);
                    this._ignoreOnPersist.splice(index, 1);
                }
            } else {
                for (var i = 0; i < collection.length; i++) {
                    if ($.inArray(collection[i], this._addToPersist) === -1)
                        this._addToPersist.push(collection[i]);
                }
            }
        },

        // Get formatted text 
        formatting: function (formatstring, str, locale) {
            formatstring = formatstring.replace(/%280/g, "\"").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
            locale = ej.preferredCulture(locale) ? locale : "en-US";
            var s = formatstring;
            var frontHtmlidx, FrontHtml, RearHtml, lastidxval;
            frontHtmlidx = formatstring.split("{0:");
            lastidxval = formatstring.split("}");
            FrontHtml = frontHtmlidx[0];
            RearHtml = lastidxval[1];
            if (typeof (str) == "string" && $.isNumeric(str))
                str = Number(str);
            if (formatstring.indexOf("{0:") != -1) {
                var toformat = new RegExp("\\{0(:([^\\}]+))?\\}", "gm");
                var formatVal = toformat.exec(formatstring);
                if (formatVal != null && str != null) {
                    if (FrontHtml != null && RearHtml != null)
                        str = FrontHtml + ej.format(str, formatVal[2], locale) + RearHtml;
                    else
                        str = ej.format(str, formatVal[2], locale);
                } else if (str != null)
                    str = str;
                else
                    str = "";
                return str;
            } else if (s.startsWith("{") && !s.startsWith("{0:")) {
                var fVal = s.split(""), str = (str || "") + "", strSplt = str.split(""), formats = /[0aA\*CN<>\?]/gm;
                for (var f = 0, f, val = 0; f < fVal.length; f++)
                    fVal[f] = formats.test(fVal[f]) ? "{" + val++ + "}" : fVal[f];
                return String.format.apply(String, [fVal.join("")].concat(strSplt)).replace('{', '').replace('}', '');
            } else if (this.data != null && this.data.Value == null) {
                $.each(this.data, function (dataIndex, dataValue) {
                    s = s.replace(new RegExp('\\{' + dataIndex + '\\}', 'gm'), dataValue);
                });
                return s;
            } else {
                return this.data.Value;
            }
        },
    };

    ej.WidgetBase = function () {
    }

    var iterateAndRemoveProps = function (source, target) {
		if(source instanceof Array) {
			for (var i = 0, len = source.length; i < len; i++) {
				prop = source[i];
				if(prop === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(prop))
					iterateAndRemoveProps(prop, target[prop]);
			}
		}
		else {
			for (var prop in source) {
				if (source[prop] === target[prop])
					delete target[prop];
				if ($.isPlainObject(target[prop]) && $.isPlainObject(source[prop]))
					iterateAndRemoveProps(source[prop], target[prop]);
			}
		}
    }

    ej.widget = function (pluginName, className, proto) {
        /// <summary>Widget helper for developers, this set have predefined function to jQuery plug-ins</summary>
        /// <param name="pluginName" type="String">the plugin name that will be added in jquery.fn</param>
        /// <param name="className" type="String">the class name for your plugin, this will help create default cssClas</param>
        /// <param name="proto" type="Object">prototype for of the plug-in</param>

        if (typeof pluginName === "object") {
            proto = className;
            for (var prop in pluginName) {
                var name = pluginName[prop];

                if (name instanceof Array) {
                    proto._rootCSS = name[1];
                    name = name[0];
                }

                ej.widget(prop, name, proto);

                if (pluginName[prop] instanceof Array)
                    proto._rootCSS = "";
            }

            return;
        }

        var nameSpace = proto._rootCSS || ej.getNameSpace(className);

        proto = ej.defineClass(className, function (element, options) {

            this.sfType = className;
            this.pluginName = pluginName;
            this.instance = pInstance;

            if (ej.isNullOrUndefined(this._setFirst))
                this._setFirst = true;

            this["ob.values"] = {};

            $.extend(this, ej.widgetBase);

            if (this.dataTypes) {
                for (var property in options) {
                    var returnValue = this._isValidModelValue(property, this.dataTypes, options);
                    if (returnValue !== true)
                        throw "setModel - Invalid input for property :" + property + " - " + returnValue;
                }
            }

            var arr = (element.data("ejWidgets") || []);
            arr.push(pluginName);
            element.data("ejWidgets", arr);

            for (var i = 0; ej.widget.observables && this.observables && i < this.observables.length; i++) {
                var t = ej.getObject(this.observables[i], options);
                if (t) ej.createObject(this.observables[i], ej.widget.observables.register(t, this.observables[i], this, element), options);
            }

            this.element = element.jquery ? element : $(element);
            this.model = copyObject(true, {}, proto.prototype.defaults, options);
            this.model.keyConfigs = copyObject(this.keyConfigs);

            this.element.addClass(nameSpace + " e-js").data(pluginName, this);

            this._id = element[0].id;

            if (this.model.enablePersistence) {
                if (window.localStorage && !ej.isNullOrUndefined(ej.persistStateVersion) && window.localStorage.getItem("persistKey") != ej.persistStateVersion) {
                    for (var i in window.localStorage) {
                        if (i.indexOf("$ej$") != -1) {
                            window.localStorage.removeItem(i); //removing the previously stored plugin item from local storage
							window.localStorage.setItem("persistKey", ej.persistStateVersion);
						}				
                    }
                }
                else if (document.cookie && !ej.isNullOrUndefined(ej.persistStateVersion) && ej.cookie.get("persistKey") != ej.persistStateVersion) {
                    var model;
                    var splits = document.cookie.split(/; */);
                    for (var k in splits) {
                        if (k.indexOf("$ej$") != -1) {
                            ej.cookie.set(k.split("=")[0], model, new Date()); //removing the previously stored plugin item from local storage
							ej.cookie.set("persistKey", ej.persistStateVersion);
						}		
                    }
                }
                this._persistHandler = ej.proxy(this.persistState, this);
                $(window).on("unload", this._persistHandler);
                this.restoreState(true);
            }

            this._init(options);

            if (typeof this.model.keyConfigs === "object" && !(this.model.keyConfigs instanceof Array)) {
                var requiresEvt = false;
                if (this.model.keyConfigs.focus)
                    this.element.attr("accesskey", this.model.keyConfigs.focus);

                for (var keyProps in this.model.keyConfigs) {
                    if (keyProps !== "focus") {
                        requiresEvt = true;
                        break;
                    }
                }

                if (requiresEvt && this._keyPressed) {
                    var el = element, evt = "keydown";

                    if (this.keySettings) {
                        el = this.keySettings.getElement ? this.keySettings.getElement() || el : el;
                        evt = this.keySettings.event || evt;
                    }

                    this._on(el, evt, function (e) {
                        if (!this.model.keyConfigs) return;

                        var action = keyFn.getActionFromCode(this.model.keyConfigs, e.which, e.ctrlKey, e.shiftKey, e.altKey);
                        var arg = {
                            code: e.which,
                            ctrl: e.ctrlKey,
                            alt: e.altKey,
                            shift: e.shiftKey
                        };
                        if (!action) return;

                        if (this._keyPressed(action, e.target, arg, e) === false)
                            e.preventDefault();
                    });
                }
            }
            this._trigger("create");
        }, proto);

        $.fn[pluginName] = function (options) {
            var opt = options, args;
            for (var i = 0; i < this.length; i++) {

                var $this = $(this[i]),
                    pluginObj = $this.data(pluginName),
                    isAlreadyExists = pluginObj && $this.hasClass(nameSpace),
                    obj = null;

                if (this.length > 0 && $.isPlainObject(opt))
                    options = ej.copyObject({}, opt);

                // ----- plug-in creation/init
                if (!isAlreadyExists) {
                    if (proto.prototype._requiresID === true && !$(this[i]).attr("id")) {
                        $this.attr("id", getUid("ejControl_"));
                    }
                    if (!options || typeof options === "object") {
                        if (proto.prototype.defaults && !ej.isNullOrUndefined(ej.setCulture) && "locale" in proto.prototype.defaults && pluginName != "ejChart") {
                            if (options && !("locale" in options)) options.locale = ej.setCulture().name;
                            else if (ej.isNullOrUndefined(options)) {
                                options = {}; options.locale = ej.setCulture().name;
                            }
                        }
                        new proto($this, options);
                    }
                    else {
                        throwError(pluginName + ": methods/properties can be accessed only after plugin creation");
                    }
                    continue;
                }

                if (!options) continue;

                args = [].slice.call(arguments, 1);

                if (this.length > 0 && args[0] && opt === "option" && $.isPlainObject(args[0])) {
                    args[0] = ej.copyObject({}, args[0]);
                }

                // --- Function/property set/access
                if ($.isPlainObject(options)) {
                    // setModel using JSON object
                    pluginObj.setModel(options);
                }

                    // function/property name starts with "_" is private so ignore it.
                else if (options.indexOf('_') !== 0
                    && !ej.isNullOrUndefined(obj = ej.getObject(options, pluginObj))
                    || options.indexOf("model.") === 0) {

                    if (!obj || !$.isFunction(obj)) {

                        // if property is accessed, then break the jquery chain
                        if (arguments.length == 1)
                            return obj;

                        //setModel using string input
                        pluginObj.option(options, arguments[1]);

                        continue;
                    }

                    var value = obj.apply(pluginObj, args);

                    // If function call returns any value, then break the jquery chain
                    if (value !== undefined)
                        return value;

                } else {
                    throwError(className + ": function/property - " + options + " does not exist");
                }
            }
            if (pluginName.indexOf("ejm") != -1)
                ej.widget.registerInstance($this, pluginName, className, proto.prototype);
            // maintaining jquery chain
            return this;
        };

        ej.widget.register(pluginName, className, proto.prototype);
        ej.loadLocale(pluginName);
    };

    ej.loadLocale = function (pluginName) {
        var i, len, locales = ej.locales;
        for (i = 0, len = locales.length; i < len; i++)
            $.fn["Locale_" + locales[i]](pluginName);
    };


    $.extend(ej.widget, (function () {
        var _widgets = {}, _registeredInstances = [],

        register = function (pluginName, className, prototype) {
            if (!ej.isNullOrUndefined(_widgets[pluginName]))
                throwError("ej.widget : The widget named " + pluginName + " is trying to register twice.");

            _widgets[pluginName] = { name: pluginName, className: className, proto: prototype };

            ej.widget.extensions && ej.widget.extensions.registerWidget(pluginName);
        },
        registerInstance = function (element, pluginName, className, prototype) {
            _registeredInstances.push({ element: element, pluginName: pluginName, className: className, proto: prototype });
        }

        return {
            register: register,
            registerInstance: registerInstance,
            registeredWidgets: _widgets,
            registeredInstances: _registeredInstances
        };

    })());

    ej.widget.destroyAll = function (elements) {
        if (!elements || !elements.length) return;

        for (var i = 0; i < elements.length; i++) {
            var data = elements.eq(i).data(), wds = data["ejWidgets"];
            if (wds && wds.length) {
                for (var j = 0; j < wds.length; j++) {
                    if (data[wds[j]] && data[wds[j]].destroy)
                        data[wds[j]].destroy();
                }
            }
        }
    };

    ej.cookie = {
        get: function (name) {
            var value = RegExp(name + "=([^;]+)").exec(document.cookie);

            if (value && value.length > 1)
                return value[1];

            return undefined;
        },
        set: function (name, value, expiryDate) {
            if (typeof value === "object")
                value = JSON.stringify(value);

            value = escape(value) + ((expiryDate == null) ? "" : "; expires=" + expiryDate.toUTCString());
            document.cookie = name + "=" + value;
        }
    };

    var keyFn = {
        getActionFromCode: function (keyConfigs, keyCode, isCtrl, isShift, isAlt) {
            isCtrl = isCtrl || false;
            isShift = isShift || false;
            isAlt = isAlt || false;

            for (var keys in keyConfigs) {
                if (keys === "focus") continue;

                var key = keyFn.getKeyObject(keyConfigs[keys]);
                for (var i = 0; i < key.length; i++) {
                    if (keyCode === key[i].code && isCtrl == key[i].isCtrl && isShift == key[i].isShift && isAlt == key[i].isAlt)
                        return keys;
                }
            }
            return null;
        },
        getKeyObject: function (key) {
            var res = {
                isCtrl: false,
                isShift: false,
                isAlt: false
            };
            var tempRes = $.extend(true, {}, res);
            var $key = key.split(","), $res = [];
            for (var i = 0; i < $key.length; i++) {
                var rslt = null;
                if ($key[i].indexOf("+") != -1) {
                    var k = $key[i].split("+");
                    for (var j = 0; j < k.length; j++) {
                        rslt = keyFn.getResult($.trim(k[j]), res);
                    }
                }
                else {
                    rslt = keyFn.getResult($.trim($key[i]), $.extend(true, {}, tempRes));
                }
                $res.push(rslt);
            }
            return $res;
        },
        getResult: function (key, res) {
            if (key === "ctrl")
                res.isCtrl = true;
            else if (key === "shift")
                res.isShift = true;
            else if (key === "alt")
                res.isAlt = true;
            else res.code = parseInt(key, 10);
            return res;
        }
    };

    ej.getScrollableParents = function (element) {
        return $(element).parentsUntil("html").filter(function () {
            return $(this).css("overflow") != "visible";
        }).add($(window));
    }
    ej.browserInfo = function () {
        var browser = {}, clientInfo = [],
        browserClients = {
            opera: /(opera|opr)(?:.*version|)[ \/]([\w.]+)/i, edge: /(edge)(?:.*version|)[ \/]([\w.]+)/i, webkit: /(chrome)[ \/]([\w.]+)/i, safari: /(webkit)[ \/]([\w.]+)/i, msie: /(msie|trident) ([\w.]+)/i, mozilla: /(mozilla)(?:.*? rv:([\w.]+)|)/i
        };
        for (var client in browserClients) {
            if (browserClients.hasOwnProperty(client)) {
                clientInfo = navigator.userAgent.match(browserClients[client]);
                if (clientInfo) {
                    browser.name = clientInfo[1].toLowerCase() == "opr" ? "opera" : clientInfo[1].toLowerCase();
                    browser.version = clientInfo[2];
                    browser.culture = {};
                    browser.culture.name = browser.culture.language = navigator.language || navigator.userLanguage;
                    if (typeof (ej.globalize) != 'undefined') {
                        var oldCulture = ej.preferredCulture().name;
                        var culture = (navigator.language || navigator.userLanguage) ? ej.preferredCulture(navigator.language || navigator.userLanguage) : ej.preferredCulture("en-US");
                        for (var i = 0; (navigator.languages) && i < navigator.languages.length; i++) {
                            culture = ej.preferredCulture(navigator.languages[i]);
                            if (culture.language == navigator.languages[i])
                                break;
                        }
                        ej.preferredCulture(oldCulture);
                        $.extend(true, browser.culture, culture);
                    }
                    if (!!navigator.userAgent.match(/Trident\/7\./)) {
                        browser.name = "msie";
                    }
                    break;
                }
            }
        }
        browser.isMSPointerEnabled = (browser.name == 'msie') && browser.version > 9 && window.navigator.msPointerEnabled;
        browser.pointerEnabled = window.navigator.pointerEnabled;
        return browser;
    };
    ej.eventType = {
        mouseDown: "mousedown touchstart",
        mouseMove: "mousemove touchmove",
        mouseUp: "mouseup touchend",
        mouseLeave: "mouseleave touchcancel",
        click: "click touchend"
    };

    ej.event = function (type, data, eventProp) {

        var e = $.extend(eventProp || {},
            {
                "type": type,
                "model": data,
                "cancel": false
            });

        return e;
    };

    ej.proxy = function (fn, context, arg) {
        if (!fn || typeof fn !== "function")
            return null;

        if ('on' in fn && context)
            return arg ? fn.on(context, arg) : fn.on(context);

        return function () {
            var args = arg ? [arg] : []; args.push.apply(args, arguments);
            return fn.apply(context || this, args);
        };
    };

    ej.hasStyle = function (prop) {
        var style = document.documentElement.style;

        if (prop in style) return true;

        var prefixs = ['ms', 'Moz', 'Webkit', 'O', 'Khtml'];

        prop = prop[0].toUpperCase() + prop.slice(1);

        for (var i = 0; i < prefixs.length; i++) {
            if (prefixs[i] + prop in style)
                return true;
        }

        return false;
    };

    Array.prototype.indexOf = Array.prototype.indexOf || function (searchElement) {
        var len = this.length;

        if (len === 0) return -1;

        for (var i = 0; i < len; i++) {
            if (i in this && this[i] === searchElement)
                return i;
        }
        return -1;
    };

    String.prototype.startsWith = String.prototype.startsWith || function (key) {
        return this.slice(0, key.length) === key;
    };
    var copyObject = ej.copyObject = function (isDeepCopy, target) {
        var start = 2, current, source;
        if (typeof isDeepCopy !== "boolean") {
            start = 1;
        }
        var objects = [].slice.call(arguments, start);
        if (start === 1) {
            target = isDeepCopy;
            isDeepCopy = undefined;
        }

        for (var i = 0; i < objects.length; i++) {
            for (var prop in objects[i]) {
                current = target[prop], source = objects[i][prop];

                if (source === undefined || current === source || objects[i] === source || target === source)
                    continue;
                if (source instanceof Array) {
                    if (i === 0 && isDeepCopy) {
                        if (prop === "dataSource" || prop === "data" || prop === "predicates")
                            target[prop] = source.slice();
					  else  {
                        target[prop] = new Array();
                        for (var j = 0; j < source.length; j++) {
                            copyObject(true, target[prop], source);
                        }
					  }
                    }
                    else
                        target[prop] = source.slice();
                }
                else if (ej.isPlainObject(source)) {
                    target[prop] = current || {};
                    if (isDeepCopy)
                        copyObject(isDeepCopy, target[prop], source);
                    else
                        copyObject(target[prop], source);
                } else
                    target[prop] = source;
            }
        }
        return target;
    };
    var pInstance = function () {
        return this;
    }

    var _uid = 0;
    var getUid = function (prefix) {
        return prefix + _uid++;
    }

    ej.template = {};

    ej.template.render = ej.template["text/x-jsrender"] = function (self, selector, data, index, prop) {
        if (selector.slice(0, 1) !== "#")
            selector = ["<div>", selector, "</div>"].join("");
        var property = { prop: prop, index: index };
        return $(selector).render(data, property);
    }

    ej.isPlainObject = function (obj) {
        if (!obj) return false;
        if (ej.DataManager !== undefined && obj instanceof ej.DataManager) return false;
        if (typeof obj !== "object" || obj.nodeType || jQuery.isWindow(obj)) return false;
        try {
            if (obj.constructor &&
                !obj.constructor.prototype.hasOwnProperty("isPrototypeOf")) {
                return false;
            }
        } catch (e) {
            return false;
        }

        var key, ownLast = ej.support.isOwnLast;
        for (key in obj) {
            if (ownLast) break;
        }

        return key === undefined || obj.hasOwnProperty(key);
    };
    var getValueFn = false;
    ej.util.valueFunction = function (prop) {
        return function (value, getObservable) {
            var val = ej.getObject(prop, this.model);

            if (getValueFn === false)
                getValueFn = ej.getObject("observables.getValue", ej.widget);

            if (value === undefined) {
                if (!ej.isNullOrUndefined(getValueFn)) {
                    return getValueFn(val, getObservable);
                }
                return typeof val === "function" ? val.call(this) : val;
            }

            if (typeof val === "function") {
                this["ob.values"][prop] = value;
                val.call(this, value);
            }
            else
                ej.createObject(prop, value, this.model);
        }
    };
    ej.util.getVal = function (val) {
        if (typeof val === "function")
            return val();
        return val;
    };
    ej.support = {
        isOwnLast: function () {
            var fn = function () { this.a = 1; };
            fn.prototype.b = 1;

            for (var p in new fn()) {
                return p === "b";
            }
        }(),
        outerHTML: function () {
            return document.createElement("div").outerHTML !== undefined;
        }()
    };

    var throwError = ej.throwError = function (er) {
        try {
            throw new Error(er);
        } catch (e) {
            throw e.message + "\n" + e.stack;
        }
    };

    ej.getRandomValue = function (min, max) {
        if (min === undefined || max === undefined)
            return ej.throwError("Min and Max values are required for generating a random number");

        var rand;
        if ("crypto" in window && "getRandomValues" in crypto) {
            var arr = new Uint16Array(1);
            window.crypto.getRandomValues(arr);
            rand = arr[0] % (max - min) + min;
        }
        else rand = Math.random() * (max - min) + min;
        return rand | 0;
    }

    ej.extensions = {};
    ej.extensions.modelGUID = "{0B1051BA-1CCB-42C2-A3B5-635389B92A50}";
})(window.jQuery, window.Syncfusion);
(function () {
    $.fn.addEleAttrs = function (json) {
        var $this = $(this);
        $.each(json, function (i, attr) {
            if (attr && attr.specified) {
                $this.attr(attr.name, attr.value);
            }
        });

    };
    $.fn.removeEleAttrs = function (regex) {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && regex.test(attr.name)) {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.fn.attrNotStartsWith = function (regex) {
        var proxy = this;
        var attributes = [], attrs;
        this.each(function () {
            attrs = $(this.attributes).clone();
        });
        for ( var i = 0; i < attrs.length; i++) {
            if (attrs[i] && attrs[i].specified && regex.test(attrs[i].name)) {
                continue
            }
            else
                attributes.push(attrs[i])
        }
        return attributes;

    }
    $.fn.removeEleEmptyAttrs = function () {
        return this.each(function () {
            var $this = $(this),
                names = [],
                attrs = $(this.attributes).clone();
            $.each(attrs, function (i, attr) {
                if (attr && attr.specified && attr.value === "") {
                    $this.removeAttr(attr.name);
                }
            });
        });
    };
    $.extend($.support, {
        has3d: ej.addPrefix('perspective') in ej.styles,
        hasTouch: 'ontouchstart' in window,
        hasPointer: navigator.msPointerEnabled,
        hasTransform: ej.userAgent() !== false,
        pushstate: "pushState" in history &&
        "replaceState" in history,
        hasTransition: ej.addPrefix('transition') in ej.styles
    });
    //Ensuring elements having attribute starts with 'ejm-' 
    $.extend($.expr[':'], {
        attrNotStartsWith: function (element, index, match) {
            var i, attrs = element.attributes;
            for (i = 0; i < attrs.length; i++) {
                if (attrs[i].nodeName.indexOf(match[3]) === 0) {
                    return false;
                }
            }
            return true;
        }
    });
    //addBack() is supported from Jquery >1.8 and andSelf() supports later version< 1.8. support for both the method is provided by extending the JQuery function.
    var oldSelf = $.fn.andSelf || $.fn.addBack;
    $.fn.andSelf = $.fn.addBack = function () {
        return oldSelf.apply(this, arguments);
    };
})();;
;
(function($, undefined){
    
ej.globalize = {};
ej.cultures = {};

ej.cultures['default'] = ej.cultures['en-US'] = $.extend(true, {
    name: 'en-US',
    englishName: "English",
    nativeName: "English",
    language: 'en',
    isRTL: false,
    numberFormat: {
        pattern: ["-n"],
        decimals: 2,
        ',': ",",
        '.': ".",
        groupSizes: [3],
        '+': "+",
        '-': "-",
        percent: {
            pattern: ["-n %", "n %"],
            decimals: 2,
            groupSizes: [3],
            ',': ",",
            '.': ".",
            symbol: '%'
        },
        currency: {
            pattern: ["($n)", "$n"],
            decimals: 2,
            groupSizes: [3],
            ',': ",",
            '.': ".",
            symbol: '$'
        }
    },
    calendars: {
    	standard: {
	        '/': '/',
	        ':': ':',
	        firstDay: 0,
			week:{
			name:"Week",
			nameAbbr:"Wek",
			nameShort:"Wk"
			},
	        days: {
	            names: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
	            namesAbbr: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
	            namesShort: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
	        },
	        months: {
	            names: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""],
	            namesAbbr: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""]
	        },
	        AM: ['AM', 'am', 'AM'],
	        PM: ['PM', 'pm', 'PM'],
            twoDigitYearMax: 2029,
	        patterns: {
                d: "M/d/yyyy",
                D: "dddd, MMMM dd, yyyy",
                t: "h:mm tt",
                T: "h:mm:ss tt",
                f: "dddd, MMMM dd, yyyy h:mm tt",
                F: "dddd, MMMM dd, yyyy h:mm:ss tt",
                M: "MMMM dd",
                Y: "yyyy MMMM",
                S: "yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss"

	        }
    	}
    }
}, ej.cultures['en-US']);

ej.cultures['en-US'].calendar = ej.cultures['en-US'].calendar || ej.cultures['en-US'].calendars.standard; 



// *************************************** Numbers ***************************************
var regexTrim = /^\s+|\s+$/g,
    regexInfinity = /^[+-]?infinity$/i,
    regexHex = /^0x[a-f0-9]+$/i,
    regexParseFloat = /^[+-]?\d*\.?\d*(e[+-]?\d+)?$/;
var charMap =  {
                '9': "[0-9 ]",
				'0': "[0-9 ]",
                'a': "[A-Za-z0-9 ]",
                'A': "[A-Za-z0-9]",
                'N': "[0-9]",
                '#': "[0-9]",
                '&': '[^\x7f]+',
                '<': "",
                '>': "",
                'C': "[A-Za-z ]",
                '?': "[A-Za-z]",
            };

function  formatMapper (format, value) {
    var mask = format || "", rules = charMap, value = value.toString(), isDecimal = value.indexOf(".") > -1 || format.indexOf(".") > -1, diff = 0, stIdx = 0, preFormat = "", escFormat = "",
		separator = format.split(","), newChar = "0", expValue, exponentIdx = format.toLowerCase().indexOf("e"), valueColl, formatColl, hashIdx = mask.indexOf("#");
	if(format.indexOf("\\") > -1) {
		escFormat = format.substr(0, format.lastIndexOf("\\") + 1);
		format = format.substr(format.lastIndexOf("\\") + 1, format.length);
		hashIdx = format.indexOf("#");
	}
	if(exponentIdx > -1) {
		var maskFirst = "", mask = "";
		formatColl = format.toLowerCase().split("e");
		expValue = format.indexOf("+") > -1 ? format.split("+")[1] : format.split("-")[1];
		value = parseInt(value).toExponential();
		valueColl = value.split("e");
		diff = formatColl[1].length - valueColl[1].length;
		for(var k = formatColl[1].length - 1; k > 0; k--) {
			if(formatColl[1][k] != "0")
				mask += formatColl[1][k];
			else if(diff > 1) {
				mask += "#";
				diff--;
			}
			else
				mask += "0";
		}
		var oprMask = (format.indexOf("+") > -1) ? "+" : "";
		mask = oprMask + mask.split("").reverse().join("");
		for(var k = 0; k < valueColl[0].length; k++)
			maskFirst = (valueColl[0][k] != ".") ? maskFirst.concat("#") : maskFirst.concat(".");
		if(maskFirst.length > formatColl[0].length)
			maskFirst = formatColl[0];
		mask = escFormat + maskFirst + "e" + mask;
	}
	else if(isDecimal) {
		formatColl = format.split(".");
		valueColl = value.split(".");
		formatColl[1] = formatColl[1].replace(/[,.]/g, "");
		diff = formatColl[0].replace(/[,.]/g, "").length - valueColl[0].replace(/[,.]/g, "").length;
		if(diff < 0 && ej.isNullOrUndefined(format.match(/[\[\(\)\]]/g))) {
			separator = formatColl[0].split(",");
			preFormat = formatColl[0].split(",")
			for(var j = separator.length - 1;j >= 0; j--) {
				if(separator[j]) {
					var cnt = separator[j].length;
					for(var k = 0, len = Math.abs(diff); k < len; k++) {
						if(cnt === 3) {
							break;
							cnt = 0;
						}
						preFormat[j] = "0" + preFormat[j];
						cnt++;
						diff++;
					}
				}
			}
			preFormat = preFormat.join();
			if(diff < 0) {
				(!ej.isNullOrUndefined(cnt) && cnt != 3) && (preFormat = "," + preFormat);
				for(var k = 0, len = Math.abs(diff); k < len; k++) {
					if(cnt === 3) {
						preFormat = "," + preFormat;
						cnt = 0;
					}
					preFormat = "0" + preFormat;
					cnt++;
				}
			}
			diff = 0;
			mask = escFormat + preFormat + "." + formatColl[1];
		}
		else if(ej.isNullOrUndefined(format.match(/[\[\(\)\]]/g))){
			preFormat = formatColl[0].replace(/[,.]/g, "");
			var postFormat = "";
			var cnt = 0;
			for(var i = preFormat.length - 1; i >= 0; i--) {
				if(cnt === 3) {
					postFormat = "," + postFormat;
					cnt = 0;
				}
				else
					cnt++;
				postFormat = preFormat[i] + postFormat;
			}
			mask = escFormat + postFormat + "." + formatColl[1];
		}
	}
	else {
		var hashCount = 0, separatorColl = separator.splice(1, separator.length);
		diff = format.replace(/[,.\[\(\]\)]/g, "").length - value.replace(/[,.]/g, "").length;
		if(hashIdx > -1) {
			for(var f = 0, len = format.length; f < len; f++)
				(format[f] === "#") && hashCount++;
			if(hashCount === 1 || (separator[1] && hashCount === 2))
				newChar = "#";
			(hashCount === 1) && (separatorColl = separator[0]);
		}
		if(diff < 0) {
			formatColl = mask.split(",");
			preFormat = formatColl.splice(1, formatColl.length);	
			for(var j = separator.length - 1;j >= 0; j--) {
				if(separatorColl[j]) {
					var cnt = separatorColl[j].length;
					!preFormat[j] && (preFormat[j] = "");
					for(var k = 0, len = Math.abs(diff) + 1; k < len; k++) {
						if(hashCount != 1 && cnt === 3) {
							cnt = 0;
							break;
						}
						preFormat[j] = preFormat[j].concat(newChar);
						cnt++;
						diff++;
					}
				}
			}
			preFormat = preFormat.join();
			if(diff < 0) {
				(!ej.isNullOrUndefined(cnt) && cnt != 3) && (preFormat = "," + preFormat);
				for(var k = 0, len = Math.abs(diff) + 1; k < len; k++) {
					if(hashCount != 1 && cnt === 3) {
						preFormat = "," + preFormat;
						cnt = 0;
					}
					preFormat = newChar + preFormat;
					cnt++;
				}
			}
			diff = 0;
			mask = escFormat + preFormat;
		}
		stIdx = 0;
	}
	var mapper = [], maskChars = mask.split(""), mapperIdx = 0, i = 0, idx = 0, chr, rule, isEscChar = false, isExp = false, escIdx = format.indexOf("\\");
    for (; i < mask.length; i++) {
        chr = maskChars[i];
		if(chr === "e")
			isExp = true;
        if((chr === "0" && hashIdx < 0)) {
			if((diff > 0 && stIdx <= i)) {
				diff--;
				stIdx++;
			}
			else if(diff > 0)
				diff--;
			else
				rule = rules[chr];
		}
		else if(chr != "0" || (!isExp && chr == "0")) 
			rule = rules[chr];
		if(chr === "0" && escIdx > -1) 
			rule = rules[chr];
		if(i === mask.lastIndexOf("\\"))
			isEscChar = false;
        if (rule && !isEscChar) {
            mapper[mapperIdx] = { rule: rule };
            mapperIdx += 1;
        } else {
            if (chr === "\\") {
                chr = "";
				!(i === mask.lastIndexOf("\\")) && (isEscChar = true);
            }
            chr = chr.split("");
            for (var j = 0; j < chr.length; j++) {
                mapper[mapperIdx] = chr[j];
                mapperIdx += 1;
            }
        }
    }
    rules = mapper;
	return {"rules": rules, "format": mask};
}

function customFormat(value, format, locale) {
	if(ej.isNullOrUndefined(value) || typeof value === "string" || !format)
		throw "Bad Number Format Exception";
	var formatLength, formatObj, formatModel, rules, orgFormat = format;
	formatObj = formatMapper(format, value);
	rules = formatObj.rules;
	format = formatObj.format;
    if (!(format.indexOf("\\") >= 0))
        formatModel = format.replace(/[9?CANa#&]/g, '_');
    else {
		var escIdx = format.lastIndexOf("\\"), first = format.slice(0, escIdx), second = format.slice(escIdx + 1, format.length), altFormat;
		second = second.replace(/[9?CANa#&]/g, '_');
		altFormat = first + second;
        formatModel = altFormat.replace(/[\\]/g, "");
		format = format.replace(/[\\]/g, "");
	}
    formatModel = changeCulture(formatModel, locale);
    return validateValue(value, format, formatModel, rules, locale, orgFormat);
}

function changeCulture(formatModel, locale) {
	if (formatModel.length != 0) {
        var preferredlocale = ej.preferredCulture(locale), groupSep, currecySymbol, decimalSep,unmask = "";
        groupSep = preferredlocale.numberFormat[','];
        currecySymbol = preferredlocale.numberFormat.currency.symbol;
        decimalSep = preferredlocale.numberFormat['.'];
        for (var i = 0; i < formatModel.length; i++) {
            if (formatModel[i] == ",")
                unmask += groupSep;
            else if (formatModel[i] == ".")
                unmask += decimalSep;
            else if (formatModel[i] == "$")
                unmask += currecySymbol;
            else
                unmask += formatModel[i];
        }
        formatModel = unmask;
    }
	return formatModel;
}

function validateValue(value, format, formatModel, rules, locale, orgFormat) {
	if(ej.isNullOrUndefined(value))
		return;
	if(format.toLowerCase().indexOf("e") > -1) {
		var expValue = orgFormat.indexOf("+") > -1 ? orgFormat.split("+")[1] : orgFormat.split("-")[1];
		value = value.toExponential();
		(orgFormat.indexOf("-") > -1) && (value = value.replace("+", "")); 
    }
    var oldvalue, replacestring, i, tvalue;
	var tempValue = oldvalue = replacestring = value.toString(), tempModel = formatModel, maskIndex = i = 0, chr, prompt = "_", rule,
		strBefore, strAfter, charValue, isBracket = format.match(/[\(\[\]\)]/g);
    if (!format.indexOf("\\") >= 0)
        tempValue = value = replacestring.replace(/[\(\)-]/g, "");
    else
        tempValue = tvalue;
	var j = rules.length - 1;
	var v = oldvalue.length - 1;
	if(!ej.isNullOrUndefined(isBracket)) {
		while (j >= 0) {
			chr = oldvalue[v];
			rule = rules[j];
			if (chr == undefined) break;
			if (chr === rule || chr === prompt || (chr === "e" && (chr === rule.toLowerCase()))) {
				chr === prompt ? prompt : "";
				strBefore = tempModel.substring(0, j+1);
				strAfter = tempModel.substring(j+1);
				chr = changeCulture(chr, locale);
				tempModel = strBefore.substr(0, strBefore.length - 1)  + chr + strAfter;
				j--;
				v--;
			}
			else if (rules[j].rule != undefined ) {
				var charCode = oldvalue.charCodeAt(v);
				if (validateChars(format, charCode, j)) {
					strBefore = tempModel.substring(0, j +1);
					strAfter = tempModel.substring(j+1);
					charValue = getRoundValue(oldvalue, v, j, format, formatModel);
					tempModel = strBefore.substr(0, strBefore.length - 1) + charValue + strAfter;
					j--;
					v--;
				} else 
					j--;
			} 
			else
				j--;
			if (i > tempValue.length || j<0) break;
		}
	}
	else {
		while (maskIndex < rules.length) {
			chr = oldvalue[i];
			rule = rules[maskIndex];
			if (chr == undefined) break;
			if (chr === rule || chr === prompt || (chr === "e" && (chr === rule.toLowerCase()))) {
				chr === prompt ? prompt : "";
				strBefore = tempModel.substring(0, maskIndex);
				strAfter = tempModel.substring(maskIndex);
				chr = changeCulture(chr, locale);
				tempModel = strBefore + chr + strAfter.substr(1, strAfter.length);
				i += 1;
				maskIndex += 1;
			}
			else if (rules[maskIndex].rule != undefined ) {
				var charCode = oldvalue.charCodeAt(i);
				if (validateChars(format, charCode, maskIndex)) {
					strBefore = tempModel.substring(0, maskIndex);
					strAfter = tempModel.substring(maskIndex);
					charValue = getRoundValue(oldvalue, i, maskIndex, format, formatModel);
					tempModel = strBefore + charValue + strAfter.substr(1, strAfter.length);
					maskIndex++;
					i++;
				} else
					maskIndex++;
			} 
			else {
				if(rule === "e")
					i = oldvalue.indexOf("e") + 1;
				maskIndex++;
			}
			if (i > tempValue.length || j<0) break;
		}
	}
    if (value) {
		if((tempModel.indexOf("_") - tempModel.indexOf(",") === 1) || (tempModel.indexOf("_") - tempModel.indexOf(".") === 1))
			tempModel = tempModel.slice(0, tempModel.indexOf("_")-1);
        var strippedValue = $.trim(tempModel.replace(/[_]/g, "")) == "" ? null : tempModel.replace(/[_]/g, "");
		return strippedValue;
	}
}

function validateChars (format, keyChar, caretPos){
	var charmap = charMap, match = false, maskChar = format.substr(caretPos, 1), actualkey = String.fromCharCode(keyChar);
    $.each(charmap, function (key, value) {
        if (maskChar == key) {
            if (actualkey.match(new RegExp(value))) match = true;
                else match = false;
        }
    });
    return match;
}

function getRoundValue(value, valIdx, maskIndex, format, formatModel) {
	var isCeil = false;
	if(format.indexOf(".") > -1 && (maskIndex === formatModel.length - 1))
		(value[valIdx + 1] > 5) && (isCeil = true);
	return (isCeil ? (parseInt(value[valIdx]) + 1).toString() : value[valIdx]);
}

function patternStartsWith(value, pattern) {
    return value.indexOf( pattern ) === 0;
}

function patternEndsWith(value, pattern) {
    return value.substr( value.length - pattern.length ) === pattern;
}

function trim(value) {
    return (value+"").replace( regexTrim, "" );
}

function truncate(value){
    if(isNaN(value))
        return NaN;
    
    return Math[value < 0 ? "ceil" : "floor"](value);
}

function padWithZero(str, count, left) {
    for (var l = str.length; l < count; l++) {
        str = (left ? ('0' + str) : (str + '0'));
    }
    return str;
}

function parseNumberWithNegativePattern(value, nf, negativePattern) {
    var neg = nf["-"],
        pos = nf["+"],
        ret;
    switch (negativePattern) {
        case "n -":
            neg = ' ' + neg;
            pos = ' ' + pos;
            // fall through
        case "n-":
            if ( patternEndsWith( value, neg ) ) {
                ret = [ '-', value.substr( 0, value.length - neg.length ) ];
            }
            else if ( patternEndsWith( value, pos ) ) {
                ret = [ '+', value.substr( 0, value.length - pos.length ) ];
            }
            break;
        case "- n":
            neg += ' ';
            pos += ' ';
            // fall through
        case "-n":
            if ( patternStartsWith( value, neg ) ) {
                ret = [ '-', value.substr( neg.length ) ];
            }
            else if ( patternStartsWith(value, pos) ) {
                ret = [ '+', value.substr( pos.length ) ];
            }
            break;
        case "(n)":
            if ( patternStartsWith( value, '(' ) && patternEndsWith( value, ')' ) ) {
                ret = [ '-', value.substr( 1, value.length - 2 ) ];
            }
            break;
    }
    return ret || [ '', value ];
}

function getFullNumber(number, precision, formatInfo) {
    var groupSizes = formatInfo.groupSizes || [3],
        curSize = groupSizes[0],
        curGroupIndex = 1,
        rounded = ej._round(number, precision);
    if (!isFinite(rounded)) {
        rounded = number;
    }
    number = rounded;

    var numberString = number + "",
        right = "",
        split = numberString.split(/e/i),
        exponent = split.length > 1 ? parseInt(split[1], 10) : 0;
    numberString = split[0];
    split = numberString.split(".");
    numberString = split[0];
    right = split.length > 1 ? split[1] : "";

    var l;
    if (exponent > 0) {
        right = padWithZero(right, exponent, false);
        numberString += right.slice(0, exponent);
        right = right.substr(exponent);
    } else if (exponent < 0) {
        exponent = -exponent;
        numberString = padWithZero(numberString, exponent + 1, true);
        right = numberString.slice(-exponent, numberString.length) + right;
        numberString = numberString.slice(0, -exponent);
    }

    var dot = formatInfo['.'] || '.';
    if (precision > 0) {
        right = dot +
            ((right.length > precision) ? right.slice(0, precision) : padWithZero(right, precision));
    } else {
        right = "";
    }

    var stringIndex = numberString.length - 1,
        sep = formatInfo[","] || ',',
        ret = "";

    while (stringIndex >= 0) {
        if (curSize === 0 || curSize > stringIndex) {
            return numberString.slice(0, stringIndex + 1) + (ret.length ? (sep + ret + right) : right);
        }
        ret = numberString.slice(stringIndex - curSize + 1, stringIndex + 1) + (ret.length ? (sep + ret) : "");

        stringIndex -= curSize;

        if (curGroupIndex < groupSizes.length) {
            curSize = groupSizes[curGroupIndex];
            curGroupIndex++;
        }
    }
    return numberString.slice(0, stringIndex + 1) + sep + ret + right;
}

function formatNumberToCulture(value, format, culture) {
    if (!format || format === 'i') {
        return culture.name.length ? value.toLocaleString() : value.toString();
    }
    format = format || "D";

    var nf = culture.numberFormat,
        number = Math.abs(value),
        precision = -1,
        pattern;

    if (format.length > 1) precision = parseInt(format.slice(1), 10);

    var current = format.charAt(0).toUpperCase(),
        formatInfo;

    switch (current) {
        case 'D':
            pattern = 'n';
            number = truncate(number);
            if (precision !== -1) {
                number = padWithZero("" + number, precision, true);
            }
            if (value < 0) number = -number;
            break;
        case 'N':
            formatInfo = nf;
            formatInfo.pattern = formatInfo.pattern || ['-n'];
            // fall through
        case 'C':
            formatInfo = formatInfo || nf.currency;
            formatInfo.pattern = formatInfo.pattern || ['-$n', '$n'];
            // fall through
        case 'P':
            formatInfo = formatInfo || nf.percent;
            formatInfo.pattern = formatInfo.pattern || ['-n %', 'n %'];
            pattern = value < 0 ? (formatInfo.pattern[0] || "-n") : (formatInfo.pattern[1] || "n");
            if (precision === -1) precision = formatInfo.decimals;
            number = getFullNumber(number * (current === "P" ? 100 : 1), precision, formatInfo);
            break;
        default:
			return customFormat(value, format, culture);
    }

    return matchNumberToPattern(number, pattern, nf);
}



function matchNumberToPattern(number, pattern, nf){
    var patternParts = /n|\$|-|%/g,
        ret = "";
    for (;;) {
        var index = patternParts.lastIndex,
            ar = patternParts.exec(pattern);

        ret += pattern.slice(index, ar ? ar.index : pattern.length);

        if (!ar) {
            break;
        }

        switch (ar[0]) {
            case "n":
                ret += number;
                break;
            case "$":
                ret += nf.currency.symbol || "$";
                break;
            case "-":
                // don't make 0 negative
                if (/[1-9]/.test(number)) {
                    ret += nf["-"] || "-";
                }
                break;
            case "%":
                ret += nf.percent.symbol || "%";
                break;
        }
    }

    return ret;
}

function parseValue(value, culture, radix ) {
		// make radix optional
    if (typeof radix === "string") {
        culture = radix;
        radix = 10;
    }
    culture = ej.globalize.findCulture(culture);
    var ret = NaN, nf = culture.numberFormat, npattern = culture.numberFormat.pattern[0];
    value = value.replace(/ /g, '');
    if (value.indexOf(culture.numberFormat.currency.symbol) > -1) {
        // remove currency symbol
        value = value.replace(culture.numberFormat.currency.symbol || "$", "");
        // replace decimal seperator
        value = value.replace(culture.numberFormat.currency["."] || ".", culture.numberFormat["."] || ".");
        // pattern of the currency
        npattern = trim(culture.numberFormat.currency.pattern[0].replace("$", ""));
    } else if (value.indexOf(culture.numberFormat.percent.symbol) > -1) {
        // remove percentage symbol
        value = value.replace(culture.numberFormat.percent.symbol || "%", "");
        // replace decimal seperator
        value = value.replace(culture.numberFormat.percent["."] || ".", culture.numberFormat["."] || ".");
        // pattern of the percent
        npattern = trim(culture.numberFormat.percent.pattern[0].replace("%", ""));
    }

    // trim leading and trailing whitespace
    value = trim( value );

    // allow infinity or hexidecimal
    if (regexInfinity.test(value)) {
        ret = parseFloat(value, "" ,radix);
    }
    else if (regexHex.test(value)) {
        ret = parseInt(value, 16);
    }
    else {
        var signInfo = parseNumberWithNegativePattern( value, nf, npattern ),
            sign = signInfo[0],
            num = signInfo[1];
        // determine sign and number
        if ( sign === "" && nf.pattern[0] !== "-n" ) {
            signInfo = parseNumberWithNegativePattern( value, nf, "-n" );
            sign = signInfo[0];
            num = signInfo[1];
        }
        sign = sign || "+";
        // determine exponent and number
        var exponent,
            intAndFraction,
            exponentPos = num.indexOf( 'e' );
        if ( exponentPos < 0 ) exponentPos = num.indexOf( 'E' );
        if ( exponentPos < 0 ) {
            intAndFraction = num;
            exponent = null;
        }
        else {
            intAndFraction = num.substr( 0, exponentPos );
            exponent = num.substr( exponentPos + 1 );
        }
        // determine decimal position
        var integer,
            fraction,
            decSep = nf['.'] || '.',
            decimalPos = intAndFraction.indexOf( decSep );
        if ( decimalPos < 0 ) {
            integer = intAndFraction;
            fraction = null;
        }
        else {
            integer = intAndFraction.substr( 0, decimalPos );
            fraction = intAndFraction.substr( decimalPos + decSep.length );
        }
        // handle groups (e.g. 1,000,000)
        var groupSep = nf[","] || ",";
        integer = integer.split(groupSep).join('');
        var altGroupSep = groupSep.replace(/\u00A0/g, " ");
        if ( groupSep !== altGroupSep ) {
            integer = integer.split(altGroupSep).join('');
        }
        // build a natively parsable number string
        var p = sign + integer;
        if ( fraction !== null ) {
            p += '.' + fraction;
        }
        if ( exponent !== null ) {
            // exponent itself may have a number patternd
            var expSignInfo = parseNumberWithNegativePattern( exponent, nf, npattern );
            p += 'e' + (expSignInfo[0] || "+") + expSignInfo[1];
        }
        if ( !radix && regexParseFloat.test( p ) ) {
            ret = parseFloat( p );
        }
		else if(radix)
			ret = parseInt(p, radix);
    }
    return ret;
}

// *************************************** Dates ***************************************

var dateFormat = {
    DAY_OF_WEEK_THREE_LETTER : "ddd",
    DAY_OF_WEEK_FULL_NAME : "dddd",
    DAY_OF_MONTH_SINGLE_DIGIT : "d",
    DAY_OF_MONTH_DOUBLE_DIGIT : "dd",
    MONTH_THREE_LETTER : "MMM",
    MONTH_FULL_NAME : "MMMM",
    MONTH_SINGLE_DIGIT : "M",
    MONTH_DOUBLE_DIGIT : "MM",
    YEAR_SINGLE_DIGIT : "y",
    YEAR_DOUBLE_DIGIT : "yy",
    YEAR_FULL : "yyyy",
    HOURS_SINGLE_DIGIT_12_HOUR_CLOCK : "h",
    HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK : "hh",
    HOURS_SINGLE_DIGIT_24_HOUR_CLOCK : "H",
    HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK : "HH",
    MINUTES_SINGLE_DIGIT : "m",
    MINUTES_DOUBLE_DIGIT : "mm",
    SECONDS_SINGLE_DIGIT : "s",
    SECONDS_DOUBLE_DIGIT : "ss",
    MERIDIAN_INDICATOR_SINGLE : "t",
    MERIDIAN_INDICATOR_FULL : "tt",
    DECISECONDS : "f",
    CENTISECONDS: "ff",
    MILLISECONDS : "fff",
    TIME_ZONE_OFFSET_SINGLE_DIGIT : "z",
    TIME_ZONE_OFFSET_DOUBLE_DIGIT : "zz",
    TIME_ZONE_OFFSET_FULL : "zzz",
    DATE_SEPARATOR : "/"
};

function valueOutOfRange(value, low, high) {
    return value < low || value > high;
}

function expandYear(cal, year) {
    // expands 2-digit year into 4 digits.
    var now = new Date();
    if ( year < 100 ) {
        var twoDigitYearMax = cal.twoDigitYearMax;
        twoDigitYearMax = typeof twoDigitYearMax === 'string' ? new Date().getFullYear() % 100 + parseInt( twoDigitYearMax, 10 ) : twoDigitYearMax;
        var curr = now.getFullYear();
        year += curr - ( curr % 100 );
        if ( year > twoDigitYearMax ) {
            year -= 100;
        }
    }
    return year;
}

function arrayIndexOf( array, item ) {
    if ( array.indexOf ) {
        return array.indexOf( item );
    }
    for ( var i = 0, length = array.length; i < length; i++ ) {
        if ( array[ i ] === item ) return i;
    }
    return -1;
}

function toUpper(value) {
    // 'he-IL' has non-breaking space in weekday names.
    return value.split( "\u00A0" ).join(' ').toUpperCase();
}

function toUpperArray(arr) {
    var results = [];
    for ( var i = 0, l = arr.length; i < l; i++ ) {
        results[i] = toUpper(arr[i]);
    }
    return results;
}

function getIndexOfDay(cal, value, abbr) {
    var ret,
        days = cal.days,
        upperDays = cal._upperDays;
    if ( !upperDays ) {
        cal._upperDays = upperDays = [
            toUpperArray( days.names ),
            toUpperArray( days.namesAbbr ),
            toUpperArray( days.namesShort )
        ];
    }
    value = toUpper( value );
    if ( abbr ) {
        ret = arrayIndexOf( upperDays[ 1 ], value );
        if ( ret === -1 ) {
            ret = arrayIndexOf( upperDays[ 2 ], value );
        }
    }
    else {
        ret = arrayIndexOf( upperDays[ 0 ], value );
    }
    return ret;
}

function getIndexOfMonth(cal, value, abbr) {
    var months = cal.months,
        monthsGen = cal.monthsGenitive || cal.months,
        upperMonths = cal._upperMonths,
        upperMonthsGen = cal._upperMonthsGen;
    if ( !upperMonths ) {
        cal._upperMonths = upperMonths = [
            toUpperArray( months.names ),
            toUpperArray( months.namesAbbr )
        ];
        cal._upperMonthsGen = upperMonthsGen = [
            toUpperArray( monthsGen.names ),
            toUpperArray( monthsGen.namesAbbr )
        ];
    }
    value = toUpper( value );
    var i = arrayIndexOf( abbr ? upperMonths[ 1 ] : upperMonths[ 0 ], value );
    if ( i < 0 ) {
        i = arrayIndexOf( abbr ? upperMonthsGen[ 1 ] : upperMonthsGen[ 0 ], value );
    }
    return i;
}

function appendMatchStringCount(preMatch, strings) {
    var quoteCount = 0,
        escaped = false;
    for ( var i = 0, il = preMatch.length; i < il; i++ ) {
        var c = preMatch.charAt( i );
        if(c == '\''){
            escaped ? strings.push( "'" ) : quoteCount++;
            escaped = false;
        } else if( c == '\\'){
            if (escaped) strings.push( "\\" );
            escaped = !escaped;
        } else {
            strings.push( c );
            escaped = false;
        }
    }
    return quoteCount;
}


function parseDayByInt(value, format, culture, cal) {
    if (!value) {
        return null;
    }
    var index = 0, valueX = 0, day = null;
    format = format.split("");
    var length = format.length;
    var countDays = function (match) {
        var i = 0;
        while (format[index] === match) {
            i++;
            index++;
        }
        if (i > 0) {
            index -= 1;
        }
        return i;
    },
    getNumber = function (size) {
        var rg = new RegExp('^\\d{1,' + size + '}'),
            match = value.substr(valueX, size).match(rg);

        if (match) {
            match = match[0];
            valueX += match.length;
            return parseInt(match, 10);
        }
        return null;
    },
    getName = function (names, lower) {
        var i = 0,
            length = names.length,
            name, nameLength,
            subValue;

        for (; i < length; i++) {
            name = names[i];
            nameLength = name.length;
            subValue = value.substr(valueX, nameLength);

            if (lower) {
                subValue = subValue.toLowerCase();
            }

            if (subValue == name) {
                valueX += nameLength;
                return i + 1;
            }
        }
        return null;
    },
     lowerArray = function (data) {
         var index = 0,
             length = data.length,
             array = [];

         for (; index < length; index++) {
             array[index] = (data[index] + "").toLowerCase();
         }

         return array;
     },
     lowerInfo = function (localInfo) {
         var newLocalInfo = {}, property;

         for (property in localInfo) {
             newLocalInfo[property] = lowerArray(localInfo[property]);
         }

         return newLocalInfo;
     };
    for (; index < length; index++) {
        var ch = format[index];
        if (ch === "d") {
            var count = countDays("d");
            if (!cal._lowerDays) {
                cal._lowerDays = lowerInfo(cal.days);
            }
            day = count < 3 ? getNumber(2) : getName(cal._lowerDays[count == 3 ? "namesAbbr" : "names"], true)
        }
    }
    return day;
}


function getFullDateFormat(cal, format) {
    // expands unspecified or single character date formats into the full pattern.
    format = format || "F";
    var pattern,
        patterns = cal.patterns,
        len = format.length;
    if ( len === 1 ) {
        pattern = patterns[ format ];
        if ( !pattern ) {
            throw "Invalid date format string '" + format + "'.";
        }
        format = pattern;
    }
    else if ( len === 2  && format.charAt(0) === "%" ) {
        // %X escape format -- intended as a custom format string that is only one character, not a built-in format.
        format = format.charAt( 1 );
    }
    return format;
}

ej.globalize._getDateParseRegExp = function (cal, format) {
    // converts a format string into a regular expression with groups that
    // can be used to extract date fields from a date string.
    // check for a cached parse regex.
    var re = cal._parseRegExp;
    if ( !re ) {
        cal._parseRegExp = re = {};
    }
    else {
        var reFormat = re[ format ];
        if ( reFormat ) {
            return reFormat;
        }
    }

    // expand single digit formats, then escape regular expression characters.
    var expFormat = getFullDateFormat( cal, format ).replace( /([\^\$\.\*\+\?\|\[\]\(\)\{\}])/g, "\\\\$1" ),
        regexp = ["^"],
        groups = [],
        index = 0,
        quoteCount = 0,
        tokenRegExp = /\/|dddd|ddd|dd|d|MMMM|MMM|MM|M|yyyy|yy|y|hh|h|HH|H|mm|m|ss|s|tt|t|fff|ff|f|zzz|zz|z|gg|g/g,
        match;

    // iterate through each date token found.
    while ( (match = tokenRegExp.exec( expFormat )) !== null ) {
        var preMatch = expFormat.slice( index, match.index );
        index = tokenRegExp.lastIndex;

        // don't replace any matches that occur inside a string literal.
        quoteCount += appendMatchStringCount( preMatch, regexp );
        if ( quoteCount % 2 ) {
            regexp.push( match[ 0 ] );
            continue;
        }

        // add a regex group for the token.
        var m = match[ 0 ],
            len = m.length,
            add;
            
        switch ( m ) {
            case dateFormat.DAY_OF_WEEK_THREE_LETTER: case dateFormat.DAY_OF_WEEK_FULL_NAME:
            case dateFormat.MONTH_FULL_NAME: case dateFormat.MONTH_THREE_LETTER:
                add = "(\\D+)";
                break;
            case dateFormat.MERIDIAN_INDICATOR_FULL: case dateFormat.MERIDIAN_INDICATOR_SINGLE:
                add = "(\\D*)";
                break;
            case dateFormat.YEAR_FULL:
            case dateFormat.MILLISECONDS:
            case dateFormat.CENTISECONDS:
            case dateFormat.DECISECONDS:
                add = "(\\d{" + len + "})";
                break;
            case dateFormat.DAY_OF_MONTH_DOUBLE_DIGIT: case dateFormat.DAY_OF_MONTH_SINGLE_DIGIT:
            case dateFormat.MONTH_DOUBLE_DIGIT: case dateFormat.MONTH_SINGLE_DIGIT:
            case dateFormat.YEAR_DOUBLE_DIGIT: case dateFormat.YEAR_SINGLE_DIGIT:
            case dateFormat.HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK: case dateFormat.HOURS_SINGLE_DIGIT_24_HOUR_CLOCK:
            case dateFormat.HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK: case dateFormat.HOURS_SINGLE_DIGIT_12_HOUR_CLOCK:
            case dateFormat.MINUTES_DOUBLE_DIGIT: case dateFormat.MINUTES_SINGLE_DIGIT:
            case dateFormat.SECONDS_DOUBLE_DIGIT: case dateFormat.SECONDS_SINGLE_DIGIT:
                add = "(\\d\\d?)";
                break;
            case dateFormat.TIME_ZONE_OFFSET_FULL:
                add = "([+-]?\\d\\d?:\\d{2})";
                break;
            case dateFormat.TIME_ZONE_OFFSET_DOUBLE_DIGIT: case dateFormat.TIME_ZONE_OFFSET_SINGLE_DIGIT:
                add = "([+-]?\\d\\d?)";
                break;
            case dateFormat.DATE_SEPARATOR:
                add = "(\\" + cal["/"] + ")";
                break;
            default:
                throw "Invalid date format pattern '" + m + "'.";
                break;
        }
        if ( add ) {
            regexp.push( add );
        }
        groups.push( match[ 0 ] );
    }
    appendMatchStringCount( expFormat.slice( index ), regexp );
    regexp.push( "$" );

    // allow whitespace to differ when matching formats.
    var regexpStr = regexp.join( '' ).replace( /\s+/g, "\\s+" ),
        parseRegExp = {'regExp': regexpStr, 'groups': groups};

    // cache the regex for this format.
    return re[ format ] = parseRegExp;
}

function getParsedDate(value, format, culture) {
    // try to parse the date string by matching against the format string
    // while using the specified culture for date field names.
    value = trim( value );
    format = trim(format);
    var cal = culture.calendar,
        // convert date formats into regular expressions with groupings.
        parseInfo = ej.globalize._getDateParseRegExp(cal, format),
        match = new RegExp(parseInfo.regExp).exec(value);
    if (match === null) {
        return null;
    }
    // found a date format that matches the input.
    var groups = parseInfo.groups,
        year = null, month = null, date = null, weekDay = null,
        hour = 0, hourOffset, min = 0, sec = 0, msec = 0, tzMinOffset = null,
        pmHour = false;
    // iterate the format groups to extract and set the date fields.
    for ( var j = 0, jl = groups.length; j < jl; j++ ) {
        var matchGroup = match[ j + 1 ];
        if ( matchGroup ) {
            var current = groups[ j ],
                clength = current.length,
                matchInt = parseInt( matchGroup, 10 );
            
            switch ( current ) {
                case dateFormat.DAY_OF_MONTH_DOUBLE_DIGIT: case dateFormat.DAY_OF_MONTH_SINGLE_DIGIT:
                    date = matchInt;
                    if ( valueOutOfRange( date, 1, 31 ) ) return null;
                    break;
                case dateFormat.MONTH_THREE_LETTER:
                case dateFormat.MONTH_FULL_NAME:
                    month = getIndexOfMonth( cal, matchGroup, clength === 3 );
                    if ( valueOutOfRange( month, 0, 11 ) ) return null;
                    break;
                case dateFormat.MONTH_SINGLE_DIGIT: case dateFormat.MONTH_DOUBLE_DIGIT:
                    month = matchInt - 1;
                    if ( valueOutOfRange( month, 0, 11 ) ) return null;
                    break;
                case dateFormat.YEAR_SINGLE_DIGIT: case dateFormat.YEAR_DOUBLE_DIGIT:
                case dateFormat.YEAR_FULL:
                    year = clength < 4 ? expandYear( cal, matchInt ) : matchInt;
                    if ( valueOutOfRange( year, 0, 9999 ) ) return null;
                    break;
                case dateFormat.HOURS_SINGLE_DIGIT_12_HOUR_CLOCK: case dateFormat.HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK:
                    hour = matchInt;
                    if ( hour === 12 ) hour = 0;
                    if ( valueOutOfRange( hour, 0, 11 ) ) return null;
                    break;
                case dateFormat.HOURS_SINGLE_DIGIT_24_HOUR_CLOCK: case dateFormat.HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK:
                    hour = matchInt;
                    if ( valueOutOfRange( hour, 0, 23 ) ) return null;
                    break;
                case dateFormat.MINUTES_SINGLE_DIGIT: case dateFormat.MINUTES_DOUBLE_DIGIT:
                    min = matchInt;
                    if ( valueOutOfRange( min, 0, 59 ) ) return null;
                    break;
                case dateFormat.SECONDS_SINGLE_DIGIT: case dateFormat.SECONDS_DOUBLE_DIGIT:
                    sec = matchInt;
                    if ( valueOutOfRange( sec, 0, 59 ) ) return null;
                    break;
                case dateFormat.MERIDIAN_INDICATOR_FULL: case dateFormat.MERIDIAN_INDICATOR_SINGLE:
                    pmHour = cal.PM && ( matchGroup === cal.PM[0] || matchGroup === cal.PM[1] || matchGroup === cal.PM[2] );
                    if ( !pmHour && ( !cal.AM || (matchGroup !== cal.AM[0] && matchGroup !== cal.AM[1] && matchGroup !== cal.AM[2]) ) ) return null;
                    break;
                case dateFormat.DECISECONDS:
                case dateFormat.CENTISECONDS:
                case dateFormat.MILLISECONDS:
                    msec = matchInt * Math.pow( 10, 3-clength );
                    if ( valueOutOfRange( msec, 0, 999 ) ) return null;
                    break;
                case dateFormat.DAY_OF_WEEK_THREE_LETTER:
                    date = parseDayByInt(value, format, culture, cal);
                    break;
                case dateFormat.DAY_OF_WEEK_FULL_NAME:
                     getIndexOfDay( cal, matchGroup, clength === 3 );
                    if ( valueOutOfRange( weekDay, 0, 6 ) ) return null;
                    break;
                case dateFormat.TIME_ZONE_OFFSET_FULL:
                    var offsets = matchGroup.split( /:/ );
                    if ( offsets.length !== 2 ) return null;

                    hourOffset = parseInt( offsets[ 0 ], 10 );
                    if ( valueOutOfRange( hourOffset, -12, 13 ) ) return null;
                    
                    var minOffset = parseInt( offsets[ 1 ], 10 );
                    if ( valueOutOfRange( minOffset, 0, 59 ) ) return null;
                    
                    tzMinOffset = (hourOffset * 60) + (patternStartsWith( matchGroup, '-' ) ? -minOffset : minOffset);
                    break;
                case dateFormat.TIME_ZONE_OFFSET_SINGLE_DIGIT: case dateFormat.TIME_ZONE_OFFSET_DOUBLE_DIGIT:
                    // Time zone offset in +/- hours.
                    hourOffset = matchInt;
                    if ( valueOutOfRange( hourOffset, -12, 13 ) ) return null;
                    tzMinOffset = hourOffset * 60;
                    break;
            }
        }
    }
    var result = new Date(), defaultYear, convert = cal.convert;
    defaultYear = convert ? convert.fromGregorian( result )[ 0 ] : result.getFullYear();
    if ( year === null ) {
        year = defaultYear;
    }
    
    // set default day and month to 1 and January, so if unspecified, these are the defaults
    // instead of the current day/month.
    if ( month === null ) {
        month = 0;
    }
    if ( date === null ) {
        date = 1;
    }
    // now have year, month, and date, but in the culture's calendar.
    if ( convert ) {
        result = convert.toGregorian( year, month, date );
        if ( result === null ) return null;
    }
    else {
        // have to set year, month and date together to avoid overflow based on current date.
        result.setFullYear( year, month, date );
        // check to see if date overflowed for specified month (only checked 1-31 above).
        if ( result.getDate() !== date ) return null;
        // invalid day of week.
        if ( weekDay !== null && result.getDay() !== weekDay ) {
            return null;
        }
    }
    // if pm designator token was found make sure the hours fit the 24-hour clock.
    if ( pmHour && hour < 12 ) {
        hour += 12;
    }
    result.setHours( hour, min, sec, msec );
    if ( tzMinOffset !== null ) {
        var adjustedMin = result.getMinutes() - ( tzMinOffset + result.getTimezoneOffset() );
        result.setHours( result.getHours() + parseInt( adjustedMin / 60, 10 ), adjustedMin % 60 );
    }
    return result;
}


function formatDateToCulture(value, format, culture) {
    var cal = culture.calendar,
        convert = cal.convert;
    if ( !format || !format.length || format === 'i' ) {
        var ret;
        if ( culture && culture.name.length ) {
            if ( convert ) {
                // non-gregorian calendar, so we cannot use built-in toLocaleString()
                ret = formatDateToCulture( value, cal.patterns.F, culture );
            }
            else {
                ret = value.toLocaleString();
            }
        }
        else {
            ret = value.toString();
        }
        return ret;
    }

    var sortable = format === "s";
        format = getFullDateFormat(cal, format);


    // Start with an empty string
    ret = [];
    var hour,
        zeros = ['0','00','000'],
        foundDay,
        checkedDay,
        dayPartRegExp = /([^d]|^)(d|dd)([^d]|$)/g,
        quoteCount = 0,
        tokenRegExp = /\/|dddd|ddd|dd|d|MMMM|MMM|MM|M|yyyy|yy|y|hh|h|HH|H|mm|m|ss|s|tt|t|fff|ff|f|zzz|zz|z|gg|g/g,
        converted;

    function padWithZeros(num, c) {
        var r, s = num+'';
        if ( c > 1 && s.length < c ) {
            r = ( zeros[ c - 2 ] + s);
            return r.substr( r.length - c, c );
        }
        else {
            r = s;
        }
        return r;
    }

    function hasDay() {
        if ( foundDay || checkedDay ) {
            return foundDay;
        }
        foundDay = dayPartRegExp.test( format );
        checkedDay = true;
        return foundDay;
    }

    if ( !sortable && convert ) {
        converted = convert.fromGregorian( value );
    }

    for (;;) {
        // Save the current index
        var index = tokenRegExp.lastIndex,
            // Look for the next pattern
            ar = tokenRegExp.exec( format );

        // Append the text before the pattern (or the end of the string if not found)
        var preMatch = format.slice( index, ar ? ar.index : format.length );
        quoteCount += appendMatchStringCount( preMatch, ret );

        if ( !ar ) {
            break;
        }

        // do not replace any matches that occur inside a string literal.
        if ( quoteCount % 2 ) {
            ret.push( ar[ 0 ] );
            continue;
        }

        var current = ar[ 0 ],
            clength = current.length;


        switch ( current ) {
            case dateFormat.DAY_OF_WEEK_THREE_LETTER:
            case dateFormat.DAY_OF_WEEK_FULL_NAME:
                var names = (clength === 3) ? cal.days.namesAbbr : cal.days.names;
                ret.push( names[ value.getDay() ] );
                break;
            case dateFormat.DAY_OF_MONTH_SINGLE_DIGIT:
            case dateFormat.DAY_OF_MONTH_DOUBLE_DIGIT:
                foundDay = true;
                ret.push( padWithZeros( (converted ? converted[2] : value.getDate()), clength ) );
                break;
            case dateFormat.MONTH_THREE_LETTER:
            case dateFormat.MONTH_FULL_NAME:
                var part = converted ? converted[1] : value.getMonth();
                ret.push( (cal.monthsGenitive && hasDay())
                    ? cal.monthsGenitive[ clength === 3 ? "namesAbbr" : "names" ][ part ]
                    : cal.months[ clength === 3 ? "namesAbbr" : "names" ][ part ] );
                break;
            case dateFormat.MONTH_SINGLE_DIGIT:
            case dateFormat.MONTH_DOUBLE_DIGIT:
                ret.push( padWithZeros((converted ? converted[1] : value.getMonth()) + 1, clength ) );
                break;
            case dateFormat.YEAR_SINGLE_DIGIT:
            case dateFormat.YEAR_DOUBLE_DIGIT:
            case dateFormat.YEAR_FULL:
                part = converted ? converted[ 0 ] : value.getFullYear();
                if ( clength < 4 ) {
                    part = part % 100;
                }
                ret.push( padWithZeros( part, clength ) );
                break;
            case dateFormat.HOURS_SINGLE_DIGIT_12_HOUR_CLOCK:
            case dateFormat.HOURS_DOUBLE_DIGIT_12_HOUR_CLOCK:
                hour = value.getHours() % 12;
                if ( hour === 0 ) hour = 12;
                ret.push( padWithZeros( hour, clength ) );
                break;
            case dateFormat.HOURS_SINGLE_DIGIT_24_HOUR_CLOCK:
            case dateFormat.HOURS_DOUBLE_DIGIT_24_HOUR_CLOCK:
                ret.push( padWithZeros( value.getHours(), clength ) );
                break;
            case dateFormat.MINUTES_SINGLE_DIGIT:
            case dateFormat.MINUTES_DOUBLE_DIGIT:
                ret.push( padWithZeros( value.getMinutes(), clength ) );
                break;
            case dateFormat.SECONDS_SINGLE_DIGIT:
            case dateFormat.SECONDS_DOUBLE_DIGIT:
                ret.push( padWithZeros(value .getSeconds(), clength ) );
                break;
            case dateFormat.MERIDIAN_INDICATOR_SINGLE:
            case dateFormat.MERIDIAN_INDICATOR_FULL:
                part = value.getHours() < 12 ? (cal.AM ? cal.AM[0] : " ") : (cal.PM ? cal.PM[0] : " ");
                ret.push( clength === 1 ? part.charAt( 0 ) : part );
                break;
            case dateFormat.DECISECONDS:
            case dateFormat.CENTISECONDS:
            case dateFormat.MILLISECONDS:
                ret.push( padWithZeros( value.getMilliseconds(), 3 ).substr( 0, clength ) );
                break;
            case dateFormat.TIME_ZONE_OFFSET_SINGLE_DIGIT:
            case dateFormat.TIME_ZONE_OFFSET_DOUBLE_DIGIT:
                hour = value.getTimezoneOffset() / 60;
                ret.push( (hour <= 0 ? '+' : '-') + padWithZeros( Math.floor( Math.abs( hour ) ), clength ) );
                break;
            case dateFormat.TIME_ZONE_OFFSET_FULL:
                hour = value.getTimezoneOffset() / 60;
                ret.push( (hour <= 0 ? '+' : '-') + padWithZeros( Math.floor( Math.abs( hour ) ), 2 ) +
                    ":" + padWithZeros( Math.abs( value.getTimezoneOffset() % 60 ), 2 ) );
                break;
            case dateFormat.DATE_SEPARATOR:
                ret.push( cal["/"] || "/" );
                break;
            default:
                throw "Invalid date format pattern '" + current + "'.";
                break;
        }
    }
    return ret.join( '' );
}

//add new culture into ej 
ej.globalize.addCulture = function (name, culture) {
    ej.cultures[name] = $.extend(true, $.extend(true, {}, ej.cultures['default'], culture), ej.cultures[name]);
	ej.cultures[name].calendar = ej.cultures[name].calendars.standard;
}

//return the specified culture or default if not found
ej.globalize.preferredCulture = function (culture) {
    culture = (typeof culture != "undefined" && typeof culture === typeof this.cultureObject) ? culture.name : culture;
    this.cultureObject = ej.globalize.findCulture(culture);
    return this.cultureObject;
}
ej.globalize.setCulture = function (culture) {
	if (ej.isNullOrUndefined(this.globalCultureObject)) this.globalCultureObject = ej.globalize.findCulture(culture);
	culture = (typeof culture != "undefined" && typeof culture === typeof this.globalCultureObject) ? culture.name : culture;
    if (culture) this.globalCultureObject = ej.globalize.findCulture(culture);
    ej.cultures.current = this.globalCultureObject;
    return this.globalCultureObject;
}
ej.globalize.culture=function(name){
    ej.cultures.current = ej.globalize.findCulture(name);
}

//return the specified culture or current else default if not found
ej.globalize.findCulture = function (culture) {
    var cultureObject;
    if (culture) {

        if ($.isPlainObject(culture) && culture.numberFormat) {
            cultureObject = culture;
        }
        if (typeof culture === "string") {
            var cultures = ej.cultures;
            if (cultures[culture]) {
                return cultures[culture];
            }
            else {
                if (culture.indexOf("-") > -1) {
                    var cultureShortName = culture.split("-")[0];
                    if (cultures[cultureShortName]) {
                        return cultures[cultureShortName];
                    }
                }
                else {
                    var cultureArray = $.map(cultures, function (el) { return el });
                    for (var i = 0; i < cultureArray.length; i++) {
                        var shortName = cultureArray[i].name.split("-")[0];
                        if (shortName === culture) {
                            return cultureArray[i];
                        }
                    };
                }
            }
            return ej.cultures["default"];
        }
    }
    else {
        cultureObject = ej.cultures.current || ej.cultures["default"];
    }

    return cultureObject;
}
//formatting date and number based on given format
ej.globalize.format = function (value, format, culture) {
    var cultureObject =  ej.globalize.findCulture(culture);
    if (typeof(value) === 'number') {
        value = formatNumberToCulture(value, format, cultureObject);
    } else if(value instanceof Date){
    	value = formatDateToCulture(value, format, cultureObject);
    }

    return value;
}

ej.globalize._round = function(number, precision){
	var factor = Math.pow(10, precision);
	return Math.round(number * factor) / factor;
},

//parsing integer takes string as input and return as number
ej.globalize.parseInt = function(value, radix, culture) {
	if(!radix)
		radix = 10;
    return Math.floor( parseValue( value, culture, radix ) );
}

//returns the ISO date string from date object
ej.globalize.getISODate = function(value) {
    if(value instanceof Date) return value.toISOString();
}

//parsing floationg poing number takes string as input and return as number
ej.globalize.parseFloat = function(value, radix, culture) {
	if (typeof radix === "string") {
        culture = radix;
        radix = 10;
    }
    return parseValue( value, culture);
}

//parsing date takes string as input and return as date object
ej.globalize.parseDate = function(value, formats, culture) {
    culture = ej.globalize.findCulture(culture);

    var date, prop, patterns;
    if ( formats ) {
        if ( typeof formats === "string" ) {
            formats = [ formats ];
        }
        if ( formats.length ) {
            for ( var i = 0, l = formats.length; i < l; i++ ) {
                var format = formats[ i ];
                if ( format ) {
                    date = getParsedDate( value, format, culture );
                    if ( date ) break;
                }
            }
        }
    }
    else {
        patterns = culture.calendar.patterns;
        for ( prop in patterns ) {
            date = getParsedDate( value, patterns[prop], culture );
            if ( date ) break;
        }
    }
    return date || null;
}

function getControlObject(obj, stringArray){
    return stringArray.length ? getControlObject(obj[stringArray[0]], stringArray.slice(1)) : obj;
}

//return localized constants as object for the given widget control and culture
ej.globalize.getLocalizedConstants = function(controlName, culture){
    var returnObject,
        controlNameArray = controlName.replace("ej.", "").split(".");
    
    returnObject = getControlObject(ej, controlNameArray);

    return ( $.extend(true, {}, returnObject.Locale['default'], returnObject.Locale[culture ? culture : this.cultureObject.name]) ) ;
}

$.extend(ej, ej.globalize);

}(jQuery));;

/**
* @fileOverview Plugin to style the Html ScrollBar elements
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, window, undefined) {
    'use strict';

    ej.widget("ejScrollBar", "ej.ScrollBar", {
        defaults: {

            orientation: "horizontal",

            viewportSize: 0,

            height: 18,

            width: 18,

            smallChange: 57,

            largeChange: 57,

            value: 0,

            maximum: 0,

            minimum: 0,

            buttonSize: 18,

            infiniteScrolling: false
        },
        validTags: ["div"],
        type: "transclude",
        dataTypes: {
            buttonSize: "number",
            smallChange: "number",
            largeChange: "number",
        },
        observables: ["value"],
        value: ej.util.valueFunction("value"),
        _enabled: true,
        content: function () {
            if (!this._content || !this._content.length) {
                if (this.model.orientation === "horizontal") {
                    this._content = this.element.find(".e-hhandle");
                }
                else {
                    this._content = this.element.find(".e-vhandle");
                }
            }
            return this._content;
        },
        _init: function () {
            this.element.addClass("e-widget");
            this._ensureScrollers();
            this.content();
            this._setInitialValues();

        },

        _setInitialValues: function () {
            var xy = "X";
            if (this.model.orientation === ej.ScrollBar.Orientation.Horizontal) {
                this.element.addClass("e-hscrollbar");
            }
            else {
                this.element.addClass("e-vscrollbar");
                xy = "Y";
            }
            if (this.value() !== 0 || this.model.minimum !== 0) {
                if (this.value() < this.model.minimum)
                    this.value(this.model.minimum);
                this["scroll"](this.value(), "none");
            }
        },

        _ensureScrollers: function () {
            var jqVersion = $.fn.jquery, height, width;
            if (this.model.height) {
                this.element.height(this.model.height);
            }
            if (this.model.width) {
                this.element.width(this.model.width);
            }
            var d2;
            if (!this._scrollData) {
                if (this.model.orientation === "vertical") {
                    this._scrollData = this._createScroller("Height", "Y", "Top", "e-v");
                }
                else {
                    this._scrollData = this._createScroller("Width", "X", "Left", "e-h");
                }
            }
        },

        _setModel: function (option) {
            for (var prop in option) {
                if (prop === "value") {
                    if (this.value()) {
                        this.scroll(this.value(), "none");
                    }
                } else {
                    this.refresh();
                    break;
                }
            }
        },

        _createScroller: function (dimension, xy, position, css) {
            var height;
            var d = {};
            var jqVersion = $.fn.jquery;
            d.dimension = dimension;
            d.xy = xy;
            d.position = position;
            d.css = css;
            d.uDimension = dimension;

            this._calculateLayout(d);
            this._createLayout(d);
            var buttons = this[d.main].find(".e-button");

            this._off(buttons, "mousedown")
                ._on(buttons, "mousedown", { d: d, step: 1 }, this._spaceMouseDown);
            this._off(this[d.scroll], "mousedown")
                ._on(this[d.scroll], "mousedown", { d: d }, this._spaceMouseDown);
            this._off(this[d.handler], "mousedown touchstart")
                ._on(this[d.handler], "mousedown touchstart", { d: d }, this._mouseDown);

            return d;
        },
        _createLayout: function (d) {
            var divString = "<div class='" + d.css + "{0}' style='" + d.dimension + ":{1}px'>{2}</div>";
            var jqVersion = $.fn.jquery;
            var lit = {}, height;
            lit[d.dimension] = d.modelDim;

            var el = ej.buildTag(
                "div." + d.css + "scroll e-box",
                String.format(divString, "up e-chevron-up_01 e-icon e-box e-button", d.buttonSize) +
                String.format(divString, "handlespace", d.handleSpace,
                    String.format(divString, "handle e-box e-pinch", d.handle)) +
                String.format(divString, "down e-chevron-down_01 e-icon e-box e-button", d.buttonSize),
                lit
            );

            this.element.append(el);
            this.element.find('.e-vhandle').addClass("e-v-line e-icon");
            this.element.find('.e-hhandle').addClass("e-h-line e-icon");
            jqVersion === "1.7.1" || jqVersion === "1.7.2" ? height = d.uDimension.toLowerCase() : height = "outer" + d.uDimension;
            this[d.handler] = this.element.find("." + d.handler);
            this[d.handler].css("transition", "none");
            this[d.scroll] = this[d.handler].parent();
            this[d.main] = this[d.scroll].parent();
            this[d.main].find(".e-button")["outer" + d.uDimension](d.buttonSize);
        },
        _calculateLayout: function (d) {
            d.scrollDim = "scroll" + d.dimension;
            d.lPosition = d.position.toLowerCase();
            d.clientXy = "page" + d.xy;
            d.scrollVal = "scroll" + d.position;
            d.scrollOneStepBy = this.model.smallChange;
            d.modelDim = this.model[(d.dimension = d.dimension.toLowerCase())];
            d.handler = d.css + "handle";
            d.buttonSize = this.model.buttonSize;
            d.main = d.css + "scroll";
            d.scroll = d.css + "ScrollSpace";
            d.handleSpace = d.modelDim - 2 * d.buttonSize;
            d.scrollable = (this.model.maximum - this.model.minimum);
            var trackLength = this.model.height;
            if (this.model.orientation === "horizontal")
                trackLength = this.model.width;
            d.handle = (this.model.viewportSize / ((this.model.maximum - this.model.minimum) + this.model.viewportSize)) * (trackLength - 2 * this.model.buttonSize);
            var check;
            !ej.isNullOrUndefined(this.model.elementHeight) && typeof this.model.elementHeight === "string" && this.model.elementHeight.indexOf("%") != -1 ? check = true : check = false;
            if (d.handle < 20 && !check) d.handle = 20;
            d.onePx = d.scrollable / (d.handleSpace - d.handle);
            d.fromScroller = false;
            d.up = true;
            d.vInterval = undefined;
        },
        _updateLayout: function (d) {
            this.element.height(this.model.height);
            this.element.width(this.model.width);
            var handle = this.element.find("." + d.css + "handle");
            var handleSpace = this.element.find("." + d.css + "handlespace");
            var size = d.dimension == "width" ? handle.css('left') : handle.css('top');
            var dimension = d.dimension == "width" ? handleSpace.outerWidth() : handleSpace.outerHeight();
            if (size !== undefined && size !== "auto") {
                if (!(dimension >= d.handle + parseFloat(size)))
                    if (this.model.enableRTL) handle.css(d.dimension === "width" ? 'left' : 'top', (parseFloat(dimension) - d.handle));
                    else handle.css(d.dimension === "width" ? 'left' : 'top', (parseFloat(dimension) - d.handle) > 0 ? (parseFloat(dimension) - d.handle) : 0);
            }
            this.element.find("." + d.css + "scroll").css(d.dimension, d.modelDim + "px")
                .find(".e-button").css(d.dimension, this.model.buttonSize).end()
                .find("." + d.css + "handlespace").css(d.dimension, d.handleSpace + "px")
                .find("." + d.css + "handle").css(d.dimension, d.handle + "px");
        },
        refresh: function () {
            this._ensureScrollers();
            if (this.value()) {
                this.scroll(this.value(), "none");
            }
            if (this._scrollData) {
                this._calculateLayout(this._scrollData);
                this._updateLayout(this._scrollData);
            }
        },

        scroll: function (pixel, source, triggerEvent, e) {
            var dS = this._scrollData;
            if (!triggerEvent) {
                if (this.model.orientation === ej.ScrollBar.Orientation.Horizontal) {
                    if (this._trigger("scroll", { source: source || "custom", scrollData: this._scrollData, scrollLeft: pixel, originalEvent: e }))
                        return;
                }
                else {
                    if (this._trigger("scroll", { source: source || "custom", scrollData: this._scrollData, scrollTop: pixel, originalEvent: e }))
                        return;
                }
            }
            if (this._scrollData) {
                if (this._scrollData.enableRTL && (e == "mousemove" || e == "touchmove") && ej.browserInfo().name != "msie")
                    this.value(-dS.scrollable + pixel);
                else {
                    if (this._scrollData.enableRTL && (e == "mousemove" || e == "touchmove") && ej.browserInfo().name == "msie") this.value(-1 * pixel);
                    else this.value(pixel);
                }
                if (this.content().length > 0) {
                    if (this.model.orientation === ej.ScrollBar.Orientation.Horizontal) {
                        var left = (this.element.find('.e-hhandlespace').width() - this.element.find('.e-hhandle').outerWidth());
                        pixel = left < ((pixel - this.model.minimum) / this._scrollData.onePx) ? left : ((pixel - this.model.minimum) / this._scrollData.onePx);
                        if (this._scrollData.enableRTL && (e == "mousemove" || e == "touchmove") && ej.browserInfo().name != "msie") {
                            pixel = left - pixel;
                            pixel > 0 ? pixel = pixel * -1 : pixel;
                        }
                        if (this._scrollData.enableRTL && (e == "mousemove" || e == "touchmove") && ej.browserInfo().name == "msie") pixel = -pixel;
                        this._scrollData.enableRTL && pixel > 0 && !this._scrollData._scrollleftflag ? pixel = 0 : pixel
                        if (this._scrollData._scrollleftflag) {

                            pixel > 0 ? pixel = pixel * -1 : pixel;
                            this.value(pixel);
                        }
                        this.content()[0].style.left = pixel + "px";
                        this._scrollData._scrollleftflag = false;
                    }
                    else {
                        var top = (this.element.find('.e-vhandlespace').height() - this.element.find('.e-vhandle').outerHeight());
                        pixel = top < ((pixel - this.model.minimum) / this._scrollData.onePx) ? top : ((pixel - this.model.minimum) / this._scrollData.onePx);
                        if (ej.browserInfo().name == "msie" && isNaN(pixel)) pixel = "";
                        this.content()[0].style.top = pixel + "px";
                            }
                        }
                    }
        },

        _changeTop: function (d, step, source) {
            var start, t;
            if (d.dimension === "height")
                start = this.value();
            else
                start = this.value();
            t = start + step;
            d.step = step;
            if ((d.enableRTL && step < 0) || (step > 0 && !d.enableRTL)) {
                if (d.enableRTL) {
                    if (t < this.model.maximum * -1)
                        t = this.model.maximum * -1;
                }
                else {
                    if (t > this.model.maximum)
                        t = this.model.maximum;
                }
            }
            else {
                if (d.enableRTL) {
                    if (t > this.model.minimum)
                        t = this.model.minimum;
                }
                else {
                    if (t < this.model.minimum)
                        t = this.model.minimum;
                }
            }
            if (t !== start || this.model.infiniteScrolling) {
                this["scroll"](t, source);
            }
            return t !== start;
        },

        _mouseUp: function (e) {
            if (!e.data) return;
            var d = e.data.d;
            clearInterval(d.vInterval);
            if (e.type == "touchend") $(e.target).removeClass("e-touch");
            if (e.type === "mouseup" || e.type === "touchend" || (!e.toElement && !e.relatedTarget && !e.target)) {
                this._prevY = this._d = this._data = null;
                this._off($(document), "mousemove touchmove", this._mouseMove);
                $(document).off("mouseup touchend", ej.proxy(this._mouseUp, this));
                d.fromScroller = false;
                this[d.scroll].off("mousemove");
                this[d.handler].off("mousemove").css("transition", "");
                if (e.data.source === "thumb" && !ej.isNullOrUndefined(this.model)) {
                    $.when(this.content()).done(ej.proxy(function () {
                        this._trigger("thumbEnd", { originalEvent: e, scrollData: d });
                    }, this));
                }
            }
            d.up = true;
        },


        _mouseDown: function (down) {
            if (!this._enabled) return;
            this._d = down;
            this._data = this._d.data.d,
                this._data.target = this._d.target;
            this._data.fromScroller = true;
            this[this._data.handler].css("transition", "none");
            this._on($(document), "mousemove touchmove", { d: this._data, source: "thumb" }, this._mouseMove);
            this._trigger("thumbStart", { originalEvent: this._d, scrollData: this._data });
            $(document).one("mouseup touchend", { d: this._data, source: "thumb" }, ej.proxy(this._mouseUp, this));
            if (down.type == "touchstart") $(down.target).addClass("e-touch");
        },
        _mouseCall: function (move) {
            move.type = "mouseup";
            this._mouseUp(move);
        },
        _mouseMove: function (move) {
            var value, step = 0, top = parseInt(this[this._data.handler].css(this._data.lPosition)) || 0;
            move.preventDefault();
            var skip = 1;
            if (ej.isNullOrUndefined(move.target.tagName)) {
                if ($(move.target).is(document)) {
                    this._mouseCall(move);
                    return;
                }
            }
            else if (move.target.tagName.toLowerCase() === "iframe") { this._mouseCall(move); return; }
            var pageXY = move.type == "mousemove" ? move[this._data.clientXy] : move.originalEvent.changedTouches[0][this._data.clientXy];
            if (this._prevY && pageXY !== this._prevY) {
                step = (pageXY - this._prevY);
                if (this.model.infiniteScrolling) {
                    top = top + step;
                    this._data.step = step;
                    if (this._data.enableRTL ? top > 0 : top < 0) top = 0;
                    if ((top * (this._data.enableRTL ? -1 : 1)) + this._data.handle >= this._data.handleSpace)
                        top = (this._data.handleSpace - this._data.handle) * (this._data.enableRTL ? -1 : 1);
                    value = Math.ceil(top * this._data.onePx);
                    this["scroll"](value, "thumb");
                }
                else {
                    value = step * this._data.onePx;
                    this._changeTop(this._data, value, "thumb", this._d);
                }
                this._trigger("thumbMove", { originalEvent: move, direction: (this._data.step > 0) ? +1 : -1, scrollData: this._data });
            }
            if (skip === 1)
                this._prevY = pageXY;
        },

        _spaceMouseDown: function (e) {
            if (!e.data || !this._enabled) return;
            var d = e.data.d;
            var offsetValue = this[d.handler][0].getBoundingClientRect();
            if (e.which !== 1 || e.target === this[d.handler][0]) return;
            var step = e.data.step ? this.model.smallChange : this.model.largeChange, hTop = e.data.top || offsetValue[d.lPosition];
            e[d.clientXy] = e[d.clientXy] || 0;
            if ((e[d.clientXy] - window.pageYOffset) < hTop) step *= -1;
            d.target = e.target;
            this._changeTop(d, step, step === 3 ? "track" : "button", e);
            if (e.data.step !== 1) {
                this[d.scroll].mousemove(function () {
                    d.up = true;
                });
            }
            d.up = false;
            d.vInterval = setInterval(ej.proxy(function () {
                if (step < 0 ? hTop + (step / d.onePx) < e[d.clientXy] : hTop + d.handle + (step / d.onePx) > e[d.clientXy])
                    d.up = true;
                if (d.up) {
                    clearInterval(d.vInterval);
                    return;
                }
                this._changeTop(d, step, step === 3 ? "track" : "button", e);
                e.data ? hTop = e.data.top || offsetValue[d.lPosition] : hTop = offsetValue[d.lPosition];
            }, this), 150);

            $(document).one("mouseup", { d: d }, ej.proxy(this._mouseUp, this));
            $(document).mouseout({ d: d }, ej.proxy(this._mouseUp, this));
        },

        _remove: function () {
            if (this.model.orientation === ej.ScrollBar.Orientation.Horizontal)
                this.element.find(".e-hscroll").remove();
            if (this.model.orientation === ej.ScrollBar.Orientation.Vertical)
                this.element.find(".e-vscroll").remove();
            this._scrollData = null;
            this._content = null;
        },

        _destroy: function () {
            this.element.remove();
        },
    });

    ej.ScrollBar.Orientation = {
        Horizontal: "horizontal",
        Vertical: "vertical"
    };
})(jQuery, Syncfusion, window);;

/**
* @fileOverview Plugin to style the Html Scroller elements
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/


(function ($, ej, window, undefined) {
    'use strict';

    ej.widget("ejScroller", "ej.Scroller", {
        _addToPersist: ["scrollLeft", "scrollTop"],
        defaults: {

            height: 250,

            autoHide: false,

            animationSpeed: 600,

            width: 0,

            scrollOneStepBy: 57,

            buttonSize: 18,

            scrollLeft: 0,

            scrollTop: 0,

            targetPane: null,

            scrollerSize: 18,

            enablePersistence: false,

            enableRTL: undefined,

            enableTouchScroll: true,

            preventDefault: false,

            enabled: true,

            create: null,

            destroy: null,

            wheelStart: null,

            wheelMove: null,

            wheelStop: null
        },
        validTags: ["div"],
        type: "transclude",

        dataTypes: {
            buttonSize: "number",
            scrollOneStepBy: "number"
        },
        observables: ["scrollTop", "scrollLeft"],
        scrollTop: ej.util.valueFunction("scrollTop"),
        scrollLeft: ej.util.valueFunction("scrollLeft"),

        keyConfigs: {
            up: "38",
            down: "40",
            left: "37",
            right: "39",
            pageUp: "33",
            pageDown: "34",
            pageLeft: "ctrl+37",
            pageRight: "ctrl+39"
        },

        content: function () {
            if (!this._contentOffsetParent && this._content && this._content[0]) this._contentOffsetParent = this._content[0].offsetParent;
            if (!this._content || !this._content.length || !this._contentOffsetParent)
                this._content = this.element.children().first().addClass("e-content");

            return this._content;
        },
        _setFirst: true,
        _updateScroll: false,

        _init: function () {
            if (!ej.isNullOrUndefined(this.content()[0])) {
                this._isJquery3 = (parseInt($.fn.jquery) >= 3) ? true : false;
                this._tempWidth = this.model.width;
                this._prevScrollWidth = this.content()[0].scrollWidth, this._prevScrollHeight = this.content()[0].scrollHeight;
                this.element.addClass("e-widget");
                this.content();
                this._browser = ej.browserInfo().name;
                this._wheelStart = true;
                this._eleHeight = this.model.height;
                this._eleWidth = this.model.width;
                this._isNativeScroll = ej.isDevice();
                this.model.targetPane != null && this.content().find(this.model.targetPane).addClass('e-target-pane');
                if (this.model.enableRTL === undefined) {
                    this.model.enableRTL = this.element.css("direction") === "rtl";
                }
                this.model.autoHide && this._on((this.element), "mousedown", this._mouseDownInitContent);
                this._ensureScrollers();
                if (this.model.enableRTL) {
                    this.element.addClass("e-rtl");
                    this._rtlScrollLeftValue = this.content().scrollLeft();
                }
                this._isNativeScroll && this.element.addClass("e-native-scroll");
                this._on(this.content(), "scroll", this._scroll);
                this.model.targetPane != null && this._on(this.content().find(this.model.targetPane), "scroll", this._scroll);
                if (this.scrollLeft())
                    this._setScrollLeftValue(this.scrollLeft());
                if (this.scrollTop())
                    this.scrollTop(this._isJquery3 ? Math.ceil(this.scrollTop()) : this.scrollTop());
                this.content().scrollTop(this.scrollTop());

                if (this.model.autoHide) {
                    this._autohide();
                }
                if (this.model.enabled) {
                    this.enable();
                }
                else {
                    this.disable();
                }
                this._setDimension();
                if (this._prevScrollWidth !== this.content()[0].scrollWidth || this._prevScrollHeight !== this.content()[0].scrollHeight) this.refresh();
            }
            this._addActionClass();
            this._isNativeScroll && this._on(this.content(), "scrollstop", this._touchDown);
        },
        _mouseDownInitContent: function () {
            this.model.autoHide && this._on($(document), "mouseup", this._mouseUpContent);
            this.element.addClass("e-scroll-focus");
        },
        _addActionClass: function () {
            //e-pinch class enables the touch mode operations in IE browsers
            if (this._browser == "msie") {
                this.content().removeClass('e-pinch e-pan-x e-pan-y');
                if (this._vScrollbar && this._hScrollbar) this.content().addClass('e-pinch');
                else if (this._vScrollbar && !this._hScrollbar) this.content().addClass('e-pan-x');
                else if (this._hScrollbar && !this._vScrollbar) this.content().addClass('e-pan-y');
            }
        },
        _setDimension: function () {
            if (!ej.isNullOrUndefined(this.model.height) && typeof this.model.height === "string" && this.model.height.indexOf("%") != -1) {
                if (!(this._vScroll || this._hScroll)) $(this.content()[0]).height("");
                else this.model.height = this._convertPercentageToPixel(parseInt(this._eleHeight), this.element.parent().height());
            }
            if (!ej.isNullOrUndefined(this.model.width) && typeof this.model.width === "string" && this.model.width.indexOf("%") != -1) {
                if (!(this._hScroll || this._vScroll)) $(this.content()[0]).width("");
                else this.model.width = this._convertPercentageToPixel(parseInt(this._eleWidth), this.element.parent().width());
            }
        },
        _setScrollLeftValue: function (leftValue) {
            if (this.model.enableRTL) {
                if (ej.browserInfo().name == "mozilla")
                    leftValue = leftValue < 0 ? leftValue : (leftValue * -1);
                else if (!ej.isNullOrUndefined(this._rtlScrollLeftValue) && (ej.browserInfo().name == "chrome" || this._rtlScrollLeftValue > 0))
                    leftValue = leftValue < 0 ? (this._rtlScrollLeftValue + leftValue) : (this._rtlScrollLeftValue - leftValue);
                else
                    leftValue = Math.abs(leftValue);
            }
            this.content().scrollLeft(leftValue);
        },


        _ensureScrollers: function () {
            var jqVersion = $.fn.jquery, height, width;
            this.model.height = typeof this.model.height == "string" && this.model.height.indexOf("px") != -1 ? parseInt(this.model.height) : this.model.height;
            this.model.width = typeof this.model.width == "string" && this.model.width.indexOf("px") != -1 ? parseInt(this.model.width) : this.model.width;
            if (this.model.height) {
                this.element.height(this.model.height);
            }
            if (this.model.width) {
                this.element.width(this.model.width);
            }

            this._off(this.content(), "mousedown touchstart");
            if (this.content().length > 0) {
                if (this.isVScroll()) {
                    if (!this._tempVscrollbar) {
                        this._vScrollbar = this._createScrollbar(ej.ScrollBar.Orientation.Vertical, this.isHScroll());
                        this._tempVscrollbar = this._vScrollbar;
                    }
                    if (this.model.enableTouchScroll)
                        this._on(this.content(), "mousedown touchstart", { d: this._vScrollbar._scrollData }, this._mouseDownOnContent);
                } else {
                    this._vScrollbar = null;
                    this._tempVscrollbar = this._vScrollbar;
                    this.element.children(".e-vscrollbar").remove();
                }
                if (this.isHScroll()) {
                    if (!this._tempHscrollbar) {
                        this._hScrollbar = this._createScrollbar(ej.ScrollBar.Orientation.Horizontal, this.isVScroll());
                        this._tempHscrollbar = this._hScrollbar;
                    }
                    if (this.model.enableTouchScroll)
                        this._on(this.content(), "mousedown touchstart", { d: this._hScrollbar._scrollData }, this._mouseDownOnContent);
                } else {
                    this._hScrollbar = null;
                    this._tempHscrollbar = this._hScrollbar;
                    this.element.children(".e-hscrollbar").remove();
                }

                if (!this._vScrollbar && !this._hScrollbar)
                    this.content().css({ width: "auto", height: "auto" });

                if (!(this.element.find(".e-hscroll").length > 0)) {
                    if (this._vScrollbar) {
                        this.content().outerHeight(this.content().outerHeight() - 1);
                    }
                }
                jqVersion === "1.7.1" || jqVersion === "1.7.2" ? (this._contentHeight = "height", this._contentWidth = "width") : (this._contentHeight = "outerHeight", this._contentWidth = "outerWidth");
                this._hScroll = this.isHScroll(), this._vScroll = this.isVScroll();
                if (this._hScroll || this._vScroll) {
                    this.content().addClass("e-content");
                    var rect = this._exactElementDimension(this.element);
                    this._elementDimension(rect);
                    if (this.model.targetPane !== null && this.content().find(this.model.targetPane)[0] !== undefined) this.content().find(this.model.targetPane)[0].scrollLeft = this.scrollLeft();
                    else if (!this.isHScroll() && (this.element.children(".e-hscrollbar").length > 0)) this._ensureScrollers();
                    if ((isNaN(this._eleWidth) && (this._eleWidth.indexOf("%") > 0)) && (isNaN(this._eleHeight) && (this._eleHeight.indexOf("%") > 0))) $(window).on('resize', $.proxy(this._resetScroller, this));
                } else
                    this.content().removeClass("e-content");
                this._setDimension();
                this._parentHeight = $(this.element).parent().height(); this._parentWidth = $(this.element).parent().width();
            }
        },
        _elementDimension: function (rect) {
            this._ElementHeight = rect.height - (this["border_bottom"] + this["border_top"] + this["padding_bottom"] + this["padding_top"]);
            this.content()[this._contentHeight](this._ElementHeight - ((this._hScroll && !this.model.autoHide) ? this.model.scrollerSize :
                this.element.find(".e-hscrollbar").is(':visible') ? this.model.scrollerSize : 0));
            this._ElementWidth = rect.width - (this["border_left"] + this["border_right"] + this["padding_left"] + this["padding_right"]);
            this.content()[this._contentWidth](this._ElementWidth - ((this._vScroll && !this.model.autoHide) ? this.model.scrollerSize :
                this.element.find(".e-vscrollbar").is(':visible') ? this.model.scrollerSize : 0));
        },
        _convertPercentageToPixel: function (ele, outer) {
            return Math.floor((ele * outer) / 100);
        },

        isHScroll: function () {
            var updatedWidth = (parseFloat($.fn.jquery) >= 3) ? Math.ceil(this.element.width()) : this.element.width();
            var modelWidth = this.model.width;
            if (!ej.isNullOrUndefined(this.model.width)) {
                if (typeof this.model.width === "string" && this.model.width.indexOf("%") != -1) {
                    modelWidth = updatedWidth;
                } else {
                    modelWidth = (parseFloat($.fn.jquery) >= 3 && !isNaN(parseFloat(this.model.width))) ? Math.ceil(parseFloat(this.model.width)) : this.model.width;
                }
            }
            if (!ej.isNullOrUndefined(this._tempWidth) && typeof this._tempWidth === "string" && this._tempWidth.indexOf("%") != -1) {
                if (!ej.isNullOrUndefined(this.model.width) && typeof this.model.width === "string" && this.model.width.indexOf("%") != -1)
                    return this.content()[0].scrollWidth > updatedWidth;
                else if (this.content()[0].scrollWidth > updatedWidth) return true;
            }
            else {
                if (modelWidth > 0) {
                    var $paneObject = this.content().find(this.model.targetPane);
                    if (this.model.targetPane != null && $paneObject.length)
                        return ($paneObject[0].scrollWidth + $paneObject.siblings().width()) > modelWidth;
                    else {
                        if (this.content()[0].scrollWidth > modelWidth) return true;
                        else if (this.content()[0].scrollWidth == modelWidth)
                            if (this.model.autoHide && $(this.content()[0]).find('> *').length > 0) return $(this.content()[0]).find('> *')[0].scrollWidth > $(this.content()[0]).width();
                            else if ($(this.content()[0]).find('> *').length > 0) return $(this.content()[0]).find('> *')[0].scrollWidth > (!ej.isNullOrUndefined(this._tempVscrollbar) ? modelWidth - this.model.scrollerSize : modelWidth);
                        return false;
                    }
                    return false;
                }
                return false;
            }
        },

        isVScroll: function () {
            //To avoid unnecessarilly render the vertical scrollbar for 1 or 2 px difference range.
            var border = 2;
            if (!ej.isNullOrUndefined(this.model.height) && typeof this.model.height === "string" && this.model.height.indexOf("%") != -1)
                return this.content()[0].scrollHeight > this.element.outerHeight(); //this._convertPercentageToPixel(parseInt(this._eleHeight), this.element.parent().height());        
            else if (this.model.height > 0) {
                if ((this.content()[0].scrollHeight > Math.ceil(this.model.height))) return true;
                else if (this.isHScroll()) if ((this.content()[0].scrollHeight == this.model.height || (this.content()[0].scrollHeight > this.model.height - (this.model.scrollerSize - border)))) return true;
            }
            return false;
        },
        _setModel: function (option) {
            for (var prop in option) {
                switch (prop) {
                    case "enableRTL":
                        if (option[prop]) {
                            this.element.addClass("e-rtl");
                            this._rtlScrollLeftValue = this.content().scrollLeft();
                            if (!ej.isNullOrUndefined(this._hScrollbar)) this._hScrollbar._scrollData.enableRTL = true;

                        } else {
                            this.element.removeClass("e-rtl");
                            if (!ej.isNullOrUndefined(this._hScrollbar)) this._hScrollbar._scrollData.enableRTL = false;
                        }
                        if (this._hScrollbar) {
                            this.element.find(".e-hhandle").css("left", 0);
                            this._hScrollbar.value(0);
                        }
                        break;
                    case "preventDefault": this.model.preventDefault = option[prop];
                        break;
                    case "scrollLeft":
                        if (parseFloat(ej.util.getVal(option[prop])) < 0 || !this._hScroll) option[prop] = 0;
                        if (this._hScrollbar) option[prop] = parseFloat(ej.util.getVal(option[prop])) > this._hScrollbar._scrollData.scrollable ? this._hScrollbar._scrollData.scrollable : parseFloat(ej.util.getVal(option[prop]));
                        this._setScrollLeftValue(parseFloat(option[prop]));
                        this["scrollLeft"](option[prop]);
                        if (this._hScrollbar && !(this._hScrollbar._scrollData._scrollleftflag && this.model.enableRTL))
                            this.scrollX(option[prop], true);
                        break;
                    case "scrollTop":
                        if (this._vScrollbar) option[prop] = parseFloat(ej.util.getVal(option[prop])) > this._vScrollbar._scrollData.scrollable ? this._vScrollbar._scrollData.scrollable : parseFloat(ej.util.getVal(option[prop]));
                        if (parseFloat(option[prop]) < 0 || !this._vScroll) option[prop] = 0;
                        this.content().scrollTop(parseFloat(option[prop]));
                        this["scrollTop"](option[prop]);
                        this.scrollY(option[prop], true);
                        break;
                    case "touchScroll":
                        if (!this.model.enableTouchScroll)
                            this._off(this.content(), "mousedown touchstart");
                        else {
                            if (this._vScrollbar)
                                this._on(this.content(), "mousedown touchstart", { d: this._vScrollbar._scrollData }, this._mouseDownOnContent);
                            if (this._hScrollbar)
                                this._on(this.content(), "mousedown touchstart", { d: this._hScrollbar._scrollData }, this._mouseDownOnContent);
                        }
                        break;
                    case "scrollOneStepBy":
                        if (this._vScrollbar) {
                            this._vScrollbar._scrollData.scrollOneStepBy = option[prop];
                            this._vScrollbar.model.smallChange = option[prop];
                        }
                        if (this._hScrollbar) {
                            this._hScrollbar._scrollData.scrollOneStepBy = option[prop];
                            this._hScrollbar.model.smallChange = option[prop];
                        }
                        break;
                    case "buttonSize":
                        if (this._vScrollbar) this._vScrollbar.model.buttonSize = this.model.buttonSize;
                        if (this._hScrollbar) this._hScrollbar.model.buttonSize = this.model.buttonSize;
                        this.refresh();
                        break;
                    case "height": this._eleHeight = option[prop];
                        this.refresh();
                        break;
                    case "width": this._eleWidth = option[prop];
                        this.refresh();
                        break;
                    case "enabled":
                        if (!option[prop]) this.disable();
                        else this.enable();
                        break;
                    default:
                        this.refresh();
                }
            }
        },

        _createScrollbar: function (orientation, isOtherScroll) {
            var proxy = this;
            var id, viewportSize, width, height, maximum, value;
            var div = document.createElement("div");
            if (orientation === ej.ScrollBar.Orientation.Vertical) {
                width = this.model.scrollerSize;
                if (!ej.isNullOrUndefined(this.model.height) && typeof this.model.height === "string" && this.model.height.indexOf("%") != -1)
                    height = viewportSize = this.element.height() - (isOtherScroll ? this.model.scrollerSize : 0);
                else
                    height = viewportSize = this.model.height - (isOtherScroll ? this.model.scrollerSize : 0);
                maximum = this.content()[0]["scrollHeight"];
                value = this.scrollTop();
            }
            else {
                width = viewportSize = this.model.width - (isOtherScroll ? this.model.scrollerSize : 0);
                height = this.model.scrollerSize;
                if (!ej.isNullOrUndefined(this.model.width) && typeof this.model.width === "string" && this.model.width.indexOf("%") != -1) {
                    width = viewportSize = this.element.width() - (isOtherScroll ? this.model.scrollerSize : 0);
                    maximum = this.content()[0]["scrollWidth"];
                }
                else {
                    var $pane = this.content().find(this.model.targetPane);
                    if (this.model.targetPane != null && $pane.length)
                        maximum = $pane[0]["scrollWidth"] + $pane.parent().width() - $pane.width();
                    else
                        maximum = this.content()[0]["scrollWidth"];
                }
                value = this.scrollLeft();
            }
            if (this.element.children(".e-hscrollbar").length > 0)
                $(this.element.children(".e-hscrollbar")).before(div);
            else
                this.element.append(div);
            $(div).ejScrollBar({
                elementHeight: proxy._eleHeight,
                elementWidth: proxy._eleWidth,
                buttonSize: proxy.model.buttonSize,
                orientation: orientation,
                viewportSize: viewportSize,
                height: height,
                width: width,
                maximum: maximum - viewportSize,
                value: value,
                smallChange: this.model.scrollOneStepBy,
                largeChange: 3 * this.model.scrollOneStepBy,
                scroll: ej.proxy(this._scrollChanged, this),
                thumbEnd: ej.proxy(this._thumbEnd, this),
                thumbStart: ej.proxy(this._thumbStart, this),
                thumbMove: ej.proxy(this._thumbMove, this),
            });
            var scrollbar = $(div).ejScrollBar("instance");
            (orientation === ej.ScrollBar.Orientation.Vertical || !isOtherScroll) && this._off(this.element, this._browser == "msie" ? "wheel mousewheel" : "mousewheel DOMMouseScroll", this._mouseWheel)
                ._on(this.element, this._browser == "msie" ? "wheel mousewheel" : "mousewheel DOMMouseScroll", { d: scrollbar._scrollData }, this._mouseWheel);
            if (orientation === ej.ScrollBar.Orientation.Horizontal) {
                this._scrollXdata = scrollbar._scrollData;
            }
            else
                this._scrollYdata = scrollbar._scrollData;
            if (orientation === ej.ScrollBar.Orientation.Horizontal && this.model.enableRTL) {
                scrollbar._scrollData.enableRTL = true;
            }
            scrollbar._enabled = this.model.enabled;
            return scrollbar;
        },

        _updateScrollbar: function (orientation, isOtherScroll) {
            var scrollbar = orientation === ej.ScrollBar.Orientation.Vertical ? this._vScrollbar : this._hScrollbar;
            if (scrollbar) {
                if (orientation === ej.ScrollBar.Orientation.Vertical) {
                    scrollbar.model.width = this.model.scrollerSize;
                    scrollbar.model.height = scrollbar.model.viewportSize = this.model.height - (isOtherScroll ? this.model.scrollerSize : 0);
                    scrollbar.model.maximum = this.content()[0]["scrollHeight"] - scrollbar.model.viewportSize;
                    scrollbar.model.value = this.scrollTop();
                }
                else {
                    scrollbar.model.width = scrollbar.model.viewportSize = this.model.width - (isOtherScroll ? this.model.scrollerSize : 0);
                    scrollbar.model.height = this.model.scrollerSize;
                    scrollbar.model.maximum = ((this.model.targetPane != null && this.content().find(this.model.targetPane).length > 0) ? this.content().find(this.model.targetPane)[0]["scrollWidth"] + (this.content().width() - this.content().find($(this.model.targetPane)).outerWidth()) : this.content()[0]["scrollWidth"]) - scrollbar.model.viewportSize;
                    if (!this.model.enableRTL)
                        scrollbar.model.value = this.scrollLeft();
                }
            }
        },

        _autohide: function () {
            if (this.model.autoHide) {
                this.element.addClass("e-autohide");
                this._on(this.element, "mouseenter mouseleave touchstart touchend", this._scrollerHover);
                if (!$(':hover').filter(this.element[0]).length) this.content().siblings(".e-scrollbar.e-js").hide();
                this._elementDimension(this._exactElementDimension(this.element));
            }
            else {
                this.element.removeClass("e-autohide");
                this._off(this.element, "mouseenter mouseleave touchstart touchend", this._scrollerHover);
                this.content().siblings(".e-scrollbar.e-js").show();
            }
        },

        _mouseUpContent: function (e) {
            if (e.type == "mouseup") {
                this.element.removeClass("e-scroll-focus");
                this._autohide();
                this._off($(document), "mouseup", this._mouseUpContent);
            }
        },
        _scrollChanged: function (e) {
            this._updateScroll = true;
            if (e.scrollTop !== undefined)
                this.scrollY(e.scrollTop, true, "", e.source);
            else if (e.scrollLeft !== undefined)
                this.scrollX(e.scrollLeft, true, "", e.source);
            this._updateScroll = false;
            var proxy = this;
            $.when(this.content()).done(ej.proxy(function () {
                proxy._trigger("scrollEnd", { scrollData: e });
            }));
        },
        _bindBlurEvent: function (scrollObj, e) {
            this._scrollEle = $(scrollObj).data('ejScrollBar');
            this._event = e; var proxy = this;
            this._listener = function (e) {
                this._scrollEle._off($(document), "mousemove touchmove", this._scrollEle._mouseMove);
                $(document).off("mouseup touchend", ej.proxy(this._scrollEle._mouseUp, this._scrollEle));
                this._scrollEle._prevY = null;
                this._off($(document), "mousemove touchmove", this._mouseMove);
                this._off($(document), "mouseup touchend", this._mouseUp);
                this._off($(window), "blur");
                if (this._evtData.handler === "e-vhandle") this._scrollEle._trigger("thumbEnd", { originalEvent: this._event, scrollData: this._evtData });
                else this._scrollEle._trigger("thumbEnd", { originalEvent: this._event, scrollData: this._evtData });
            };
            this._on($(window), "blur", this._listener);
        },
        _thumbStart: function (e) {
            this._evtData = e.scrollData;
            var scrollObj = e.scrollData.handler === "e-vhandle" ? this.element.find('.' + e.scrollData.handler).closest('.e-scrollbar') : this.element.find('.' + e.scrollData.handler).closest('.e-scrollbar'); var scrollObj = e.scrollData.handler === "e-vhandle" ? this.element.find('.' + e.scrollData.handler).closest('.e-scrollbar') : this.element.find('.' + e.scrollData.handler).closest('.e-scrollbar');
            this._bindBlurEvent(scrollObj, e);
            this._trigger("thumbStart", e);
        },
        _thumbMove: function (e) {
            this._trigger("thumbMove", e);
        },
        _thumbEnd: function (e) {
            this._trigger("thumbEnd", e);
            this._off($(window), "blur");
        },

        refresh: function (needRefresh) {
            if (!needRefresh) {
                this.element.find(">.e-content").removeAttr("style");
            }
            else {
                this._tempVscrollbar = null;
                this.element.children(".e-vscrollbar").remove();
                this._tempHscrollbar = null;
                this.element.children(".e-hscrollbar").remove();
            }

            if (!ej.isNullOrUndefined(this._eleHeight) && typeof this._eleHeight === "string" && this._eleHeight.indexOf("%") != -1 && this._parentHeight != $(this.element).parent().height()) {
                var element = this._exactElementDimension(this.element.parent());
                element = element.height - (this["border_bottom"] + this["border_top"] + this["padding_bottom"] + this["padding_top"]);
                this.model.height = this._convertPercentageToPixel(parseInt(this._eleHeight), element);
            }
            if (!ej.isNullOrUndefined(this._eleWidth) && typeof this._eleWidth === "string" && this._eleWidth.indexOf("%") != -1 && this._parentWidth != $(this.element).parent().width()) {
                var element = this._exactElementDimension(this.element.parent());
                element = element.width - (this["border_left"] + this["border_right"] + this["padding_left"] + this["padding_right"]);
                this.model.width = this._convertPercentageToPixel(parseInt(this._eleWidth), element);
            }

            this._ensureScrollers();
            var scrollLeftValue = this.model.scrollLeft;
            if (this.model.enableRTL) {
                !this.element.hasClass("e-rtl") && this.element.addClass("e-rtl");
                this._rtlScrollLeftValue = this.content().scrollLeft();
                scrollLeftValue > 0 ? this.content().scrollLeft(this._rtlScrollLeftValue - scrollLeftValue) : this._setScrollLeftValue(scrollLeftValue);
            }
            else
                this.content().scrollLeft(scrollLeftValue);
            if ((this.scrollTop() && ej.isNullOrUndefined(this._vScrollbar)) || (!ej.isNullOrUndefined(this._vScrollbar) && (this._vScrollbar && this._vScrollbar._scrollData != null) && !this._vScrollbar._scrollData.skipChange))
                this.scrollTop(this._isJquery3 ? Math.ceil(this.scrollTop()) : this.scrollTop());
            this.content().scrollTop(this.scrollTop());

            if (this._vScrollbar) {
                this._vScrollbar._scrollData.dimension = "Height";
                this._updateScrollbar(ej.ScrollBar.Orientation.Vertical, this._hScroll);
                this._vScroll && !this._vScrollbar._calculateLayout(this._vScrollbar._scrollData) && this._vScrollbar._updateLayout(this._vScrollbar._scrollData);
            }
            if (this._hScrollbar) {
                this._hScrollbar._scrollData.dimension = "Width";
                this._updateScrollbar(ej.ScrollBar.Orientation.Horizontal, this._vScroll);
                this._hScroll && !this._hScrollbar._calculateLayout(this._hScrollbar._scrollData) && this._hScrollbar._updateLayout(this._hScrollbar._scrollData);
            }
            if (ej.browserInfo().name == "msie" && ej.browserInfo().version == "8.0")
                this.element.find(".e-hhandle").css("left", "0px");
            else
                this.model.targetPane != null && this._on(this.content().find(this.model.targetPane), "scroll", this._scroll);
            this._addActionClass();
            this._autohide();
        },
        _exactElementDimension: function (element) {
            var rect = element.get(0).getBoundingClientRect(), direction = ["left", "right", "top", "bottom"], width, height;
            rect.width ? width = rect.width : width = rect.right - rect.left;
            rect.height ? height = rect.height : height = rect.bottom - rect.top;
            for (var i = 0; i < direction.length; i++) {
                this["border_" + direction[i]] = isNaN(parseFloat(element.css("border-" + direction[i] + "-width"))) ? 0 : parseFloat(element.css("border-" + direction[i] + "-width"));
                this["padding_" + direction[i]] = isNaN(parseFloat(element.css("padding-" + direction[i]))) ? 0 : parseFloat(element.css("padding-" + direction[i]));
            }
            return rect = { width: width, height: height };
        },
        _keyPressed: function (action, target) {
            if (!this.model.enabled) return;
            if (["input", "select", "textarea"].indexOf(target.tagName.toLowerCase()) !== -1)
                return true;

            var d, iChar;

            if (["up", "down", "pageUp", "pageDown"].indexOf(action) !== -1) {
                if (this._vScrollbar) {
                    if (ej.browserInfo().name == "msie" && this.model.allowVirtualScrolling)
                        this._content.focus();
                    d = this._vScrollbar._scrollData;
                }
                iChar = "o";
            } else if (["left", "right", "pageLeft", "pageRight"].indexOf(action) !== -1) {
                if (this._hScrollbar)
                    d = this._hScrollbar._scrollData;
                iChar = "i";
            } else return true;
            if (!d) return true;

            return !this._changeTop(d, (action.indexOf(iChar) < 0 ? -1 : 1) * (action[0] !== "p" ? 1 : 3) * d.scrollOneStepBy, "key");
        },

        scrollY: function (pixel, disableAnimation, animationSpeed, source, e) {
            var proxy = this;
            if (pixel === "") return;
            if (disableAnimation) {
                var e = { source: source || "custom", scrollData: this._vScrollbar ? this._vScrollbar._scrollData : null, scrollTop: pixel, originalEvent: e };
                pixel = (!this._isJquery3) ? e.scrollTop : Math.ceil(e.scrollTop);
                this.scrollTop(pixel);
                if (this._trigger("scroll", e)) return;
                this.content().scrollTop(pixel);
                return;
            }
            if (ej.isNullOrUndefined(animationSpeed) || animationSpeed === "") animationSpeed = 100;
            if (this._vScrollbar) pixel = parseFloat(pixel) > this._vScrollbar._scrollData.scrollable ? this._vScrollbar._scrollData.scrollable : parseFloat(pixel)
            pixel = (!this._isJquery3) ? pixel : Math.ceil(pixel);
            this.scrollTop(pixel);
            this.content().stop().animate({
                scrollTop: pixel
            }, animationSpeed, 'linear', function () {
                if (proxy._trigger("scroll", { source: source || "custom", scrollData: proxy._vScrollbar ? proxy._vScrollbar._scrollData : null, scrollTop: pixel, originalEvent: e })) return;
            })
        },

        scrollX: function (pixel, disableAnimation, animationSpeed, source, e) {
            var proxy = this;
            if (pixel === "") return;
            if (this._hScrollbar) pixel = parseFloat(pixel) > this._hScrollbar._scrollData.scrollable ? this._hScrollbar._scrollData.scrollable : parseFloat(pixel);
            var browserName = ej.browserInfo().name;
            if (this.model.enableRTL && browserName != "mozilla") {
                if (pixel < 0) pixel = Math.abs(pixel);
                var content = this.model.targetPane != null ? this.content().find(this.model.targetPane)[0] : this.content()[0];
                if (e != "mousemove" && e != "touchmove" && (browserName != "msie")) if (browserName != "msie") pixel = this._hScrollbar._scrollData.scrollable - pixel;
            }
            this.scrollLeft(pixel);
            if (disableAnimation) {
                if (this._trigger("scroll", { source: source || "custom", scrollData: this._hScrollbar ? this._hScrollbar._scrollData : null, scrollLeft: pixel, originalEvent: e }))
                    return;
                if (this.model.targetPane != null && this.content().find(this.model.targetPane).length)
                    this.content().find(this.model.targetPane).scrollLeft(pixel);
                else
                    this.content().scrollLeft(pixel);
                return;
            }
            if (ej.isNullOrUndefined(animationSpeed) || animationSpeed === "") animationSpeed = 100;
            if (this.model.targetPane != null && this.content().find(this.model.targetPane).length)
                this.content().find(this.model.targetPane).stop().animate({
                    scrollLeft: pixel
                }, animationSpeed, 'linear');
            else this.content().stop().animate({
                scrollLeft: pixel
            }, animationSpeed, 'linear', function () {
                if (proxy._trigger("scroll", { source: source || "custom", scrollData: proxy._hScrollbar ? proxy._hScrollbar._scrollData : null, scrollLeft: pixel, originalEvent: e })) return;
            });
        },

        enable: function () {
            var scroller = this.element.find(".e-vscrollbar,.e-hscrollbar,.e-vscroll,.e-hscroll,.e-vhandle,.e-hhandle,.e-vscroll .e-icon,.e-hscroll .e-icon");
            if (scroller.hasClass("e-disable")) {
                scroller.removeClass("e-disable").attr({ "aria-disabled": false });
                this.model.enabled = true;
            }
            if (this._vScrollbar)
                this._vScrollbar._enabled = this.model.enabled;
            if (this._hScrollbar)
                this._hScrollbar._enabled = this.model.enabled;
        },

        disable: function () {
            var scroller = this.element.find(".e-vscrollbar,.e-hscrollbar,.e-vscroll,.e-hscroll,.e-vhandle,.e-hhandle,.e-vscroll .e-icon,.e-hscroll .e-icon");
            scroller.addClass("e-disable").attr({ "aria-disabled": true });
            this.model.enabled = false;
            if (this._vScrollbar)
                this._vScrollbar._enabled = this.model.enabled;
            if (this._hScrollbar)
                this._hScrollbar._enabled = this.model.enabled;
        },

        _changeTop: function (d, step, source, e) {
            var start = Math.ceil(this.model.targetPane != null && d.dimension != "height" ? this.content().find(this.model.targetPane)[d.scrollVal]() : this.content()[d.scrollVal]()), t;

            if (d.dimension == "height" && start == 0)
                start = this.scrollTop() != 0 ? this.scrollTop() : 0;
            t = start + step;
            if (!d.enableRTL ? t > d.scrollable : t < d.scrollable) t = Math.round(d.scrollable);
            if (!d.enableRTL ? t < 0 : t > 0) t = 0;

            if (t !== start) {
                this["scroll" + d.xy](t, true, "", source, e);
                if (d.xy === "X" && !ej.isNullOrUndefined(this._hScrollbar))
                    this._hScrollbar["scroll"](t, source, true, e);
                else if (!ej.isNullOrUndefined(this._vScrollbar))
                    this._vScrollbar["scroll"](t, source, true, e);
            }

            return t !== start;
        },

        _mouseWheel: function (e) {
            if (this._vScrollbar && e.ctrlKey)
                return;
            if (!this._vScrollbar && !e.shiftKey)
                return;
            if (!e.data || !this.model.enabled) return;
            var delta = 0, data = e.data.d, ori = e, direction;
            e = e.originalEvent;
            this._wheelStart && this._trigger("wheelStart", { originalEvent: e, scrollData: ori.data.d });
            this._wheelStart = false;
            clearTimeout($.data(this, 'timer'));
            if (this._wheelx != 1 && (e.wheelDeltaX == 0 || e.wheelDeltaY == 0))
                this._wheelx = 1;
            if (navigator.platform.indexOf("Mac") == 0 && (this._wheelx == 0)) {
                if (this._browser == "webkit" || this._browser == "chrome")
                    return true;
            }
            if (this._browser == "mozilla")
                e.axis == e.HORIZONTAL_AXIS ? data = this._scrollXdata : this._scrollYdata;
            else if (this._browser == "msie") {
                if ((e.type == "wheel")) delta = e.deltaX / 120;
                if ((e.type == "mousewheel" && e.shiftKey)) {
                    data = this._scrollXdata;
                    e.preventDefault ? e.preventDefault() : (e.returnValue = false);
                }
            }
            else if (this._wheelx && e.wheelDeltaX != 0 && e.wheelDeltaY == 0 && this._scrollXdata)
                data = this._scrollXdata;
            if (e.wheelDeltaX == 0) this._wheelx = e.wheelDeltaX;
            if (e.wheelDelta) {
                delta = this._normalizingDelta(e);
                if (window.opera) {
                    if (parseFloat(window.opera.version, 10) < 10)
                        delta = -delta;
                }
            } else if (e.detail) delta = e.detail / 3;
            if (!delta) return;
            if ((ori.originalEvent))
                if (ori.originalEvent.wheelDelta && ori.originalEvent.wheelDelta > 0 || ori.originalEvent.detail && ori.originalEvent.detail < 0) direction = -1;
                else direction = 1;
            if (this._changeTop(data, delta * data.scrollOneStepBy, "wheel", e)) {
                e.preventDefault ? e.preventDefault() : ori.preventDefault();
                this._trigger("wheelMove", { originalEvent: e, scrollData: ori.data.d, direction: direction });
            }
            else {
                this._trigger("scrollEnd", { originalEvent: e, scrollData: ori });
                this._wheelx = 0;
            }
            var proxy = this;
            $.data(this, 'timer', setTimeout(function () {
                proxy._wheelStart = true;
                proxy._trigger("wheelStop", { originalEvent: e, scrollData: ori.data.d, direction: direction });
            }, 250));
        },

        _normalizingDelta: function (e) {
            var delta = navigator.platform.indexOf("Mac") == 0 ? -e.wheelDelta / 3 : -e.wheelDelta / 120;
            return delta;
        },

        _contentHeightWidth: function () {
            if (this.content().siblings().css("display") == "block" && this.model.autoHide) {
                this._hScroll && this.content()[this._contentHeight](this._ElementHeight - (this.model.scrollerSize));
                this._vScroll && this.content()[this._contentWidth](this._ElementWidth - (this.model.scrollerSize));
            }
            else if (this.content().siblings().css("display") == "none" && this.model.autoHide && (this._vScroll || this._hScroll)) {
                this.content()[this._contentHeight](this._ElementHeight);
                this.content()[this._contentWidth](this._ElementWidth);
            }
        },
        _scrollerHover: function (e) {
            if (this.model.enabled) {
                if ((e.type == "mouseenter" || e.type == "touchstart") && !this.content().siblings().is(":visible")) {
                    this.content().siblings().css("display", "block");
                    this._contentHeightWidth();
                    this._ensureScrollers();
                    this._setScrollLeftValue(this.model.scrollLeft);
                    this._trigger("scrollVisible", { originalEvent: e });
                }
                else if ((e.type == "mouseleave" || e.type == "touchend") && !this.element.hasClass("e-scroll-focus")) {
                    this.content().siblings().hide();
                    this._contentHeightWidth();
                    this._trigger("scrollHide", { originalEvent: e });
                }
            }
        },

        _mouseUp: function (e) {
            if (!e.data) return;
            var d = e.data.d;
            if (this.model.enableRTL && (e.type == "mouseup" || e.type == "touchend")) {
                this.model.scrollLeft = this._rtlScrollLeftValue - this.model.scrollLeft;
            }
            if (e.type === "mouseup" || e.type === "touchend" || (!e.toElement && !e.relatedTarget)) {
                this.content().css("cursor", "default");
                this._off($(document), "mousemove touchmove");
                this._off(this.content(), "touchmove", this._touchMove);
                this._off($(document), "mouseup touchend", this._mouseUp);
                d.fromScroller = false;
                if (this._mouseMoved === true && e.data.source === "thumb" && !ej.isNullOrUndefined(this.model)) {
                    $.when(this.content()).done(ej.proxy(function () {
                        this._trigger("thumbEnd", { originalEvent: e, scrollData: d });
                    }, this));
                    this._off($(window), "blur");
                }
            }
            d.up = true;
            this._mouseMoved = false;
            window.ontouchmove = null;
        },

        _mouseDownOnContent: function (down) {
            this._startX = (down.clientX != undefined) ? down.clientX : down.originalEvent.changedTouches[0].clientX;
            this._startY = (down.clientY != undefined) ? down.clientY : down.originalEvent.changedTouches[0].clientY;
            this._timeStart = down.timeStamp || Date.now();
            if (!this.model.enabled) return;
            var d = down.data.d;
            this._evtData = down.data;
            var scrollObj = d.handler === "e-vhandle" ? this.element.find('.' + d.handler).closest('.e-scrollbar') : this.element.find('.' + d.handler).closest('.e-scrollbar');
            this._bindBlurEvent(scrollObj, down);
            if (this._trigger("thumbStart", { originalEvent: down, scrollData: d }))
                return;
            if (down.which == 3 && down.button == 2) return;
            d.fromScroller = true;
            var prevY = null, skip = 1, min = 5, direction;
            this._document = $(document); this._window = $(window);
            this._mouseMove = function (move) {
                if (this.model.enableRTL) {
                    this._UpdateScrollLeftValue(down);
                }
                if (this._startX + this._startY != move.clientX + move.clientY) {
                    this._relDisX = ((move.clientX != undefined) ? this._startx = move.clientX : this._startx = move.originalEvent.changedTouches[0].clientX) - this._startX;
                    this._relDisY = ((move.clientY != undefined) ? this._starty = move.clientY : this._starty = move.originalEvent.changedTouches[0].clientY) - this._startY;
                    this._duration = (move.timeStamp || Date.now()) - this._timeStart;
                    this._velocityY = Math.abs(this._relDisY) / this._duration;
                    this._velocityX = Math.abs(this._relDisX) / this._duration;
                    if (Math.abs(this._relDisX) > Math.abs(this._relDisY))
                        this._swipe = (this._relDisX > 0) ? "left" : "right";
                    else
                        this._swipe = (this._relDisY > 0) ? "up" : "down";
                    if (!ej.isNullOrUndefined(move.target.tagName) && move.target.tagName.toLowerCase() === "iframe") {
                        move.type = "mouseup";
                        this._mouseUp(move);
                        return;
                    }
                    var pageXY = move.type == "mousemove" ? move[d.clientXy] : move.originalEvent.changedTouches[0][d.clientXy];
                    if (prevY && pageXY !== prevY) {
                        this._mouseMoved = true;
                        var diff = pageXY - prevY, sTop = this.model[d.scrollVal] - (diff);

                        if (skip == 1 && Math.abs(diff) > min) {
                            direction = d.position;
                            skip = 0;
                        }
                        if (skip == 0) prevY = pageXY;

                        if (sTop >= 0 && sTop <= d.scrollable && direction === d.position) {
                            var top = this._velocityY > 0.5 && this._duration < 50 && d.position == "Top";
                            var left = this._velocityX > 0.5 && this._duration < 50 && d.position == "Left";
                            var swipeXY = ((this._velocityY > 0.5) || (this._velocityX > 0.5)) && this._duration < 50;
                            if (swipeXY) {
                                if (top) {
                                    sTop = Math.abs(this._relDisY) + (this._duration * this._velocityY);
                                    if (this._startY > this._starty) {
                                        sTop += this.scrollTop();
                                        if (sTop > d.scrollable) sTop = d.scrollable;
                                    }
                                    else {
                                        if (sTop < this.scrollTop()) sTop = Math.abs(sTop - this.scrollTop());
                                        if (sTop > this.scrollTop())
                                            sTop = 0;
                                    }
                                    if (this.scrollTop() <= d.scrollable) this["scrollY"](sTop, false, this.model.animationSpeed, "thumb");
                                }
                                else if (left) {
                                    sTop = Math.abs(this._relDisX);
                                    if (this._startX > this._startx) {
                                        sTop += this.scrollLeft();
                                        if (sTop > d.scrollable) sTop = d.scrollable;
                                    }
                                    else {
                                        sTop -= this.scrollLeft();
                                        sTop = Math.abs(sTop);
                                        if (sTop > d.scrollable || sTop >= this.scrollLeft()) sTop = 0;
                                    }
                                    if (this.scrollLeft() <= d.scrollable) this["scrollX"](sTop, false, this.model.animationSpeed, "thumb");
                                }
                            }
                            else {
                                this["scroll" + d.xy](sTop, true, "", "thumb", move.type);
                                if (d.xy === "X")
                                    this._hScrollbar["scroll"](sTop, "thumb", true, move.type);
                                else if (!ej.isNullOrUndefined(this._vScrollbar))
                                    this._vScrollbar["scroll"](sTop, "thumb", true, move.type);
                                this.content().css("cursor", "pointer");
                                this._trigger("thumbMove", { originalEvent: move, direction: (this._swipe == "down" || this._swipe == "right") ? 1 : -1, scrollData: d });
                            }
                        }
                    }
                    window.ontouchmove = function (e) {
                        e = e || window.event;
                        if (e.preventDefault) e.preventDefault();

                        e.returnValue = false;
                    }
                    if (prevY == null) prevY = pageXY;
                    if (((Math.round(this._content["scrollTop"]()) == 0) && this._swipe == "down" || ((Math.ceil(this._content["scrollTop"]()) == d.scrollable || Math.ceil(this._content["scrollTop"]()) + 1 == d.scrollable) && this._swipe == "up"))) {
                        this._trigger("scrollEnd", { originalEvent: move.originalEvent, scrollData: move });
                        window.ontouchmove = null;
                    }
                }
            }
            this._trigger("touchStart", { originalEvent: down, direction: (this._swipe == "down" || this._swipe == "right") ? 1 : -1, scrollData: this._scrollData, scrollTop: this.content().scrollTop(), scrollLeft: this.content().scrollLeft() });
            this._on($(document), "mousemove", { d: d, source: "thumb" }, this._mouseMove);
            if (!this._isNativeScroll) this._on($(document), "touchmove", { d: d, source: "thumb" }, this._mouseMove);
            else {
                this._on(this.content(), "touchmove", { d: d, source: "thumb" }, this._touchMove);
            }
            this._on($(document), "mouseup touchend", { d: d, source: "thumb" }, this._mouseUp);
        },

        _touchMove: function (e) {
            this.content().css("cursor", "pointer");
            this._mouseMoved = true;
            this._tempLeft = this.model.targetPane != null ? this.content().find(this.model.targetPane).scrollLeft() : this.content().scrollLeft();
            this._tempTop = this.content().scrollTop();
        },

        _touchDown: function (e) {
            var data;
            if (this._tempLeft != this.scrollLeft()) data = this._scrollXdata;
            else if (this._tempTop != this.scrollTop()) data = this._scrollYdata;
            else data = (!this._scrollYdata) ? this._scrollXdata : this._scrollYdata;
            this._trigger("scrollStop", { source: "thumb" || "custom", originalEvent: e, scrollData: data, scrollTop: this.content().scrollTop(), scrollLeft: this.content().scrollLeft() });
        },

        _speedScrolling: function (e) {
            if (this._mouseMoved) {
                if (this.element.find(".e-vhandle").length > 0) {
                    var scrollTop = this.content().scrollTop();
                    if (this._tempTop !== scrollTop) {
                        this._trigger("thumbMove", { originalEvent: e, direction: (this._swipe == "down" || this._swipe == "right") ? 1 : -1, scrollData: this._scrollData });
                        this._vScrollbar["scroll"](this.content().scrollTop(), "thumb", true, "touchmove");
                        var e = { source: "thumb" || "custom", scrollData: this._vScrollbar ? this._vScrollbar._scrollData : null, scrollTop: this.content().scrollTop(), originalEvent: e };
                        var pixel = (!this._isJquery3) ? e.scrollTop : Math.ceil(e.scrollTop);
                        this.scrollTop(pixel);
                        if (this._trigger("scroll", e)) return;
                    }
                }
                if (this.element.find(".e-hhandle").length > 0) {
                    var contentArea = this.model.targetPane != null ? this.content().find(this.model.targetPane) : this.content();
                    var scrollLeft = contentArea.scrollLeft();
                    if (this._tempLeft !== scrollLeft) {
                        this._trigger("thumbMove", { originalEvent: e, direction: (this._swipe == "down" || this._swipe == "right") ? 1 : -1, scrollData: this._scrollData });
                        this._hScrollbar["scroll"](contentArea.scrollLeft(), "thumb", true, "touchmove");
                        var e = { source: "thumb" || "custom", scrollData: this._hScrollbar ? this._hScrollbar._scrollData : null, scrollLeft: this.content().scrollLeft(), originalEvent: e };
                        var pixel = (!this._isJquery3) ? e.scrollLeft : Math.ceil(e.scrollLeft);
                        this.scrollLeft(pixel);
                        if (this._trigger("scroll", e)) return;
                    }
                }
                this.content().css("cursor", "pointer");
            }
        },

        _scroll: function (e) {
            var dS = [this._vScrollbar ? this._vScrollbar._scrollData : null, this._hScrollbar ? this._hScrollbar._scrollData : null];

            if (this._evtData) var data = this._evtData.d ? this._evtData.d : this._evtData;

            for (var i = 0; i < 2; i++) {
                var d = dS[i];
                if (!d || d.skipChange) continue;
                if (this.model && ((!this.model.targetPane) || (this.model.targetPane && data && data.xy != "X")))
                    d.dimension === "height" ? this.scrollTop(e.target[d.scrollVal]) : this.scrollLeft(e.target[d.scrollVal])
                if (this.model && this.model.targetPane != null && i == 1 && this.content().find(this.model.targetPane).length)
                    d.sTop = this.content().find(this.model.targetPane)[0][d.scrollVal];
                else d.scrollVal == "scrollTop" ? d.sTop = this.scrollTop() : d.sTop = this.scrollLeft();
                this[d.scrollVal](d.sTop);
                if (d.fromScroller) continue;
                if (i === 1) {
                    var content = this.content()[0];
                    if (this._rtlScrollLeftValue && content.scrollWidth - content.clientWidth != this._rtlScrollLeftValue)
                        this._rtlScrollLeftValue = content.scrollWidth - content.clientWidth;
                    d.sTop = (this.model && ej.browserInfo().name != "mozilla" && this.model.enableRTL && !this._hScrollbar._scrollData._scrollleftflag) ? (this._rtlScrollLeftValue == 0 ? (d.sTop * -1) : (d.sTop - this._rtlScrollLeftValue)) : d.sTop;
                    this._hScrollbar["scroll"](d.sTop, "", true);
                } else
                    this._vScrollbar["scroll"](d.sTop, "", true);
                if (dS.length == 2 && i == 1 || dS.length == 1 && i == 0) {
                    this._externalScroller = false;
                    this.model && this._trigger('scroll', { source: "custom", scrollData: this._hScrollbar ? this._hScrollbar._scrollData : null, scrollLeft: this.scrollLeft(), originalEvent: e });
                }
            }
            if (this._isNativeScroll && this.model.enableTouchScroll) this._speedScrolling(e);
            this._UpdateScrollLeftValue(e);
            var proxy = this;
            if (this._vScrollbar && this._scrollYdata && this.model) {
                if ((this._scrollYdata.scrollable - this.model.scrollOneStepBy) >= this.scrollTop()) {
                    if (!$(':hover').filter(this.element[0]).length) proxy._off(ej.getScrollableParents(proxy.wrapper), "scroll", null);
                    window.onmousewheel = function (args) {
                        if (proxy.model && proxy.model.preventDefault && $(':hover').filter(proxy.element[0]).length) args.preventDefault();
                    }
                }
            }
        },

        _UpdateScrollLeftValue: function (e) {
            if (this.model && e.type != "touchstart" && e.type != "mousedown" && this.model.enableRTL && this._rtlScrollLeftValue && this.model.scrollLeft != this._previousScrollLeft) {
                this.model.scrollLeft = this._rtlScrollLeftValue - this.model.scrollLeft;
                this._previousScrollLeft = this.model.scrollLeft;
            }
            if ((this.model && e.type == "touchstart" || e.type == "mousedown") && this.model.enableRTL) {
                this.model.scrollLeft = this.content().scrollLeft();
                this.option("scrollLeft", this.content().scrollLeft());
            }
        },

        _changevHandlerPosition: function (top) {
            var scrollbar = this._vScrollbar;
            if (scrollbar) {
                top = scrollbar._scrollData != null && top >= scrollbar._scrollData.scrollable ? scrollbar._scrollData.scrollable : top;
                if (scrollbar != null && top >= 0 && top <= scrollbar._scrollData.scrollable)
                    scrollbar[scrollbar._scrollData.handler].css(scrollbar._scrollData.lPosition, (top / scrollbar._scrollData.onePx) + "px");
            }
        },

        _changehHandlerPosition: function (left) {
            var scrollbar = this._hScrollbar;
            if (scrollbar) {
                left = scrollbar._scrollData != null && left >= scrollbar._scrollData.scrollable ? scrollbar._scrollData.scrollable : left;
                if (scrollbar != null && top >= 0 && left <= scrollbar._scrollData.scrollable)
                    scrollbar[scrollbar._scrollData.handler].css(scrollbar._scrollData.lPosition, (left / scrollbar._scrollData.onePx) + "px");
            }
        },

        _destroy: function () {
            this._off(this.content(), "scrollstop", this._touchDown);
            this._off($(document), "mouseup", this._mouseUpContent);
            this.element.css({ "width": "", "height": "" }).children(".e-vscrollbar,.e-hscrollbar").remove();
            this.content().removeClass("e-content").css({ "width": "", "height": "" });
            this.element.removeClass("e-widget");
        },
        _preventDefault: function (e) {
            e = e || window.event;
            if (e.preventDefault) e.preventDefault();

            e.returnValue = false;
        }
    });
})(jQuery, Syncfusion, window);;
/**
* @fileOverview Plugin provides support to display calendar within your web page and allows to pick the date.
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejDatePicker", "ej.DatePicker", {

        element: null,
        _rootCss: "e-datepicker",

        model: null,
        validTags: ["input", "div", "span"],
        _setFirst: false,
        _addToPersist: ["value"],
        _cancelValue: false,
        type: "editor",
        angular: {
            require: ['?ngModel', '^?form', '^?ngModelOptions'],
            requireFormatters: true
        },


        defaults: {

            dayHeaderFormat: "min",

            showPopupButton: true,

            enableAnimation: true,

            showFooter: true,

            displayInline: false,

            htmlAttributes: {},

            dateFormat: '',

            watermarkText: "Select date",

            value: null,
            minDate: new Date("01/01/1900"),

            maxDate: new Date("12/31/2099"),

            startLevel: "month",

            depthLevel: "",

            cssClass: "",

            startDay: -1,

            stepMonths: 1,

            locale: "en-US",

            showOtherMonths: true,

            enableStrictMode: false,

            enablePersistence: false,

            enabled: true,

            width: "",

            height: "",

            enableRTL: false,

            showRoundedCorner: false,

            headerFormat: 'MMMM yyyy',

            buttonText: 'Today',

            readOnly: false,

            specialDates: null,

            fields: {

                date: "date",

                tooltip: "tooltip",

                iconClass: "iconClass",

                cssClass: "cssClass"
            },

            showTooltip: true,

            showDisabledRange: true,

            highlightSection: "none",

            highlightWeekend: false,

            validationRules: null,

            validationMessage: null,
            validationMessages: null,

            allowEdit: true,

            tooltipFormat: "ddd MMM dd yyyy",

            allowDrillDown: true,

            blackoutDates: [],

            beforeDateCreate: null,

            open: null,

            close: null,

            select: null,

            change: null,

            focusIn: null,

            focusOut: null,

            beforeOpen: null,

            beforeClose: null,

            navigate: null,

            create: null,

            destroy: null,

            weekNumber: false,

            timeZone: true

        },


        dataTypes: {
            startDay: "number",
            stepMonths: "number",
            showOtherMonths: "boolean",
            enableStrictMode: "boolean",
            showRoundedCorner: "boolean",
            enableRTL: "boolean",
            displayInline: "boolean",
            showPopupButton: "boolean",
            locale: "string",
            readOnly: "boolean",
            cssClass: "string",
            dateFormat: "string",
            watermarkText: "string",
            headerFormat: "string",
            buttonText: "string",
            specialDates: "data",
            showTooltip: "boolean",
            highlightSection: "enum",
            highlightWeekend: "boolean",
            enableAnimation: "boolean",
            validationRules: "data",
            validationMessage: "data",
            validationMessages: "data",
            htmlAttributes: "data",
            tooltipFormat: "string",
            allowEdit: "boolean",
            allowDrillDown: "boolean",
            weekNumber: "boolean"

        },

        _renderPopup: function () {
            this.sfCalendar = ej.buildTag('div.e-datepicker e-popup e-widget ' + this.model.cssClass + ' e-calendar ' + (this.model.specialDates ? (this.model.specialDates[0][this._mapField._icon] ? 'e-icons ' : '') : ''), "", {}, { id: (this._id ? 'e-' + this._id : "") }).attr({ 'aria-hidden': 'true' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})
                     .insertBefore(this.element);
            if (this.model.displayInline && !this.element.is("input"))
                this.sfCalendar.addClass('e-inline');
            this.popup = this.sfCalendar;
            if (!ej.isTouchDevice()) this.sfCalendar.addClass('e-ntouch');
            this._setRestrictDateState(this.model.showDisabledRange);
            this._createCalender();
            this._setDisplayInline(this.model.displayInline);
            this._resizeCalender();
            this._setRTL(this.model.enableRTL);
            this._setRoundedCorner(this.model.showRoundedCorner);
            this._wireCalendarEvents();
        },

        _setModel: function (jsondata) {
            
            var callRefresh = false, start = false, validate = false;
            for (var key in jsondata) {
				if(key != "showPopupButton" && key != "width" && key != "dateFormat" && key != "height" && key != "readOnly" && key != "allowEdit" && key != "enabled" && key != "watermarkText" && key != "htmlAttributes" && key != "validationMessages" && key != "validationRules"){
					if (ej.isNullOrUndefined(this.sfCalendar)) this._renderPopup();
				}
                switch (key) {
                    case "dayHeaderFormat":
                        this.model.dayHeaderFormat = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "weekNumber":
                        this.model.weekNumber = jsondata[key];
                        this._refreshDatepicker();
                        break;
                    case "showPopupButton":
                        this._renderDateIcon(jsondata[key], true);
                        break;
                    case "displayInline":
                        if (!jsondata[key]) this._bindDateButton();
                        this._setDisplayInline(jsondata[key]);
                        if (!this.model.allowEdit && !jsondata[key] && this._isInputBox)
                            this.element.on("mousedown", $.proxy(this._showDatePopUp, this));
                        break;
                    case "value":
                        if (ej.isPlainObject(jsondata[key])) jsondata[key] = null;
                        if (ej.isNullOrUndefined(jsondata["minDate"]) && ej.isNullOrUndefined(jsondata["maxDate"])) {
                            this._setDateValue(jsondata[key]);
                            if (this._specificFormat())
                                this._stopRefresh = true;
                            jsondata[key] = this.model.value;
                        }
                        else
                            this._updateDateValue(jsondata[key]);
                        if (this.model.value && this.sfCalendar) {
                            $(this.element).attr("aria-activedescendant", $(this.sfCalendar.find(".e-active")).attr("id"));
                        } else {
                            $(this.element).removeAttr("aria-activedescendant");
                        }
                        validate = callRefresh = start = true;
                        break;
                    case "specialDates":
                        this.model.specialDates = jsondata[key];
                        this._createSpecialDateObject();
                        callRefresh = start = true;
                        break;
                    case "fields":
                        this.model.fields = jsondata[key];
                        this._mapField = this._getMapper();
                        callRefresh = start = true;
                        break;
                    case "showTooltip":
                        this.model.showTooltip = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "highlightWeekend":
                        this.model.highlightWeekend = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "highlightSection":
                        this.model.highlightSection = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "dateFormat":
                        this.model.dateFormat = jsondata[key];
                        this._ensureValue();
                        break;
                    case "minDate":
                        this._setMinDate(jsondata[key]);
                        jsondata[key] = this.model.minDate;
                        this._ensureValue();
                        validate = callRefresh = start = true;
                        break;
                    case "maxDate":
                        this._setMaxDate(jsondata[key]);
                        jsondata[key] = this.model.maxDate;
                        this._ensureValue();
                        validate = callRefresh = start = true;
                        break;
                    case "locale":
                        this.model.locale = jsondata[key];
                        this.model.startDay = ((ej.isNullOrUndefined(this._options.startDay)) && (this.model.startDay === this.culture.calendar.firstDay))
                            ? -1 : (this._options.startDay === this.defaults.startDay) ? -1 : this.model.startDay;
                        this.model.dateFormat = ((ej.isNullOrUndefined(this._options.dateFormat)) && (this.model.dateFormat === this.culture.calendar.patterns.d))
                            ? '' : this.model.dateFormat;
                        this._setCulture(jsondata[key]);
                        if (this.model.value) this._setDateValue(this.model.value);
                        jsondata[key] = this.model.locale;
                        callRefresh = start = true;
                        break;
                    case "showOtherMonths":
                        this.model.showOtherMonths = jsondata[key];
                        this._otherMonthsVisibility();
                        break;
                    case "enableStrictMode":
                        this.model.enableStrictMode = jsondata[key];
                        validate = callRefresh = start = true;
                        break;
                    case "validationRules":
                        if (this.model.validationRules != null) {
                            this.element.rules('remove');
                            this.model.validationMessages = null;
                        }
                        this.model.validationRules = jsondata[key];
                        if (this.model.validationRules != null) {
                            this._initValidator();
                            this._setValidation();
                        }
                        break;
                    case "validationMessages":
                        this.model.validationMessages = jsondata[key];
                        if (this.model.validationRules != null && this.model.validationMessages != null) {
                            this._initValidator();
                            this._setValidation();
                        }
                        break;
                    case "validationMessage":
                        this.model.validationMessages = jsondata[key];
                        if (this.model.validationRules != null && this.model.validationMessages != null) {
                            this._initValidator();
                            this._setValidation();
                        }
                        break;
                    case "readOnly":
                        this.model.readOnly = jsondata[key];
                        this._disbleMaualInput();
                        break;
                    case "width":
                        this._setWidth(jsondata[key]);
                        break;
                    case "height":
                        this._setHeight(jsondata[key]);
                        break;
                    case "cssClass":
                        this._setSkin(jsondata[key]);
                        break;
                    case "enableRTL":
                        this._setRTL(jsondata[key]);
                        break;
                    case "showRoundedCorner":
                        this._setRoundedCorner(jsondata[key]);
                        break;
                    case "enabled":
                        if (!jsondata[key]) this.disable();
                        else this.enable();
                        break;
                    case "buttonText":
                        if (ej.isNullOrUndefined(this._options)) this._options = {};
                        this._options["buttonText"] = this.model.buttonText = jsondata[key];
                        this._localizedLabels.buttonText = this.model.buttonText;
                        this._setFooterText(jsondata[key]);
                        break;
                    case "showFooter":
                        this._enableFooter(jsondata[key]);
                        break;
                    case "watermarkText":
                        if (ej.isNullOrUndefined(this._options)) this._options = {};
                        this._options["watermarkText"] = this.model.watermarkText = jsondata[key];
                        this._localizedLabels.watermarkText = this.model.watermarkText;
                        this._setWaterMark();
                        break;
                    case "startDay":
                        var initial = jsondata[key];
                        if (parseInt(jsondata[key]) < 0 || parseInt(jsondata[key]) > 6) {
                            jsondata[key] = this.culture.calendar.firstDay;
                            initial = -1;
                        }
                        this.model.startDay = jsondata[key];
                        if (ej.isNullOrUndefined(this._options)) this._options = {};
                        this._options["startDay"] = initial;
                        callRefresh = start = true;
                        break;
                    case "startLevel":
                        this.model.startLevel = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "headerFormat":
                        this.model.headerFormat = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "depthLevel":
                        this.model.depthLevel = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "htmlAttributes": this._addAttr(jsondata[key]); break;
                    case "allowEdit": this._changeEditable(jsondata[key]); break;
                    case "tooltipFormat":
                        this.model.tooltipFormat = jsondata[key];
                        callRefresh = start = true;
                        break;
                    case "allowDrillDown":
                        this._allowQuickPick(jsondata[key]);
                        callRefresh = start = true;
                        break;
                    case "showDisabledRange":
                        this._setRestrictDateState(jsondata[key]);
                        break;
                    case "blackoutDates":
                        this.model.blackoutDates = jsondata[key];
                        this._initDisableObj(this.model.blackoutDates);
                        callRefresh = start = true;
                        break;
                }
            }
            if (validate) {
                this._validateMinMaxDate();
                jsondata["value"] = this.model.value;
                jsondata["maxDate"] = this.model.maxDate;
                jsondata["minDate"] = this.model.minDate;
            }
            this._setWaterMark();

            if (callRefresh && (this.isValidState || this.model.displayInline))
                this._refreshDatepicker();
            if (start && !this._startNavigate) this._startLevel(this.model.startLevel);
            this._triggerChangeEvent();
            this._checkErrorClass();
        },
        observables: ["value"],

        _destroy: function () {
            if (this.model.displayInline)
                $(window).off("resize", $.proxy(this._OnWindowResize, this));
            if (this._isOpen)
                this.hide();
            this.sfCalendar && this.sfCalendar.remove();
            if (this.wrapper) {
                this.element.insertAfter(this.wrapper);
                this.wrapper.remove();
            }
            this.element.removeClass('e-datepicker e-input');
            this.element.removeAttr('aria-atomic aria-live aria-activedescendant aria-expanded role placeholder tabindex' );
            !this._cloneElement.hasAttribute("name") && this.element.removeAttr("name");
        },

        _init: function (options) {
            this._options = options;
            this._cloneElement = this.element.clone();
            this._dt_drilldown = false;
            this._ISORegex();
            this._initDisableObj(this.model.blackoutDates);
            this.animation = {
                open: { duration: 200 },
                close: { duration: 100 }
            };
            this._animating = false;
            this._isInputBox = this._isInputBox();
            this._startNavigate = false;
            this._keyboardInteraction = false;
            this._isSupport = document.createElement("input").placeholder == undefined ? false : true;
            this._checkAttribute();
            this._setValues();
            this._createDatePicker();
            if (!ej.isNullOrUndefined(options) && !ej.isNullOrUndefined(options.validationMessage))
                this.model.validationMessages = this.model.validationMessage;
            if (this.model.validationRules != null) {
                this._initValidator();
                this._setValidation();
            }
            if (options && options.value != undefined && options.value != this.element.val()) {
                this._trigger("_change", { value: this.element.val() });
            }
        },

        _ISORegex: function () {
            this._tokens = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,
            // complex case for iso 8601 regex only
            this._extISORegex = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,
            this._basicISORegex = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,
            this._isISODate = /[T]/,
            this._numberRegex = {
                2: /\d\d?/,
                4: /^\d{4}/,
                "z": /Z|[+-]\d\d(?::?\d\d)?/gi,
                "t": /T/,
                "-": /\-/,
                ":": /:/
            };
            this._zeroRegex = /Z|[+-]\d\d(?::?\d\d)?/;
            this._dates = [
                ['YYYYYY-MM-DD', /[+-]\d{6}-\d\d-\d\d/],
                ['YYYY-MM-DD', /\d{4}-\d\d-\d\d/],
                ['GGGG-[W]WW-E', /\d{4}-W\d\d-\d/],
                ['GGGG-[W]WW', /\d{4}-W\d\d/, false],
                ['YYYY-DDD', /\d{4}-\d{3}/],
                ['YYYY-MM', /\d{4}-\d\d/, false],
                ['YYYYYYMMDD', /[+-]\d{10}/],
                ['YYYYMMDD', /\d{8}/],
                // YYYYMM is NOT allowed by the standard
                ['GGGG[W]WWE', /\d{4}W\d{3}/],
                ['GGGG[W]WW', /\d{4}W\d{2}/, false],
                ['YYYYDDD', /\d{7}/]
            ];

            // iso time formats and regexes
            this._times = [
                ['HH:mm:ss.SSSS', /\d\d:\d\d:\d\d\.\d+/],
                ['HH:mm:ss,SSSS', /\d\d:\d\d:\d\d,\d+/],
                ['HH:mm:ss', /\d\d:\d\d:\d\d/],
                ['HH:mm', /\d\d:\d\d/],
                ['HHmmss.SSSS', /\d\d\d\d\d\d\.\d+/],
                ['HHmmss,SSSS', /\d\d\d\d\d\d,\d+/],
                ['HHmmss', /\d\d\d\d\d\d/],
                ['HHmm', /\d\d\d\d/],
                ['HH', /\d\d/]
            ];
        },

        _initValidator: function () {
            (!this.element.closest("form").data("validator")) && this.element.closest("form").validate();
        },
        _setValidation: function () {
            this.element.rules("add", this.model.validationRules);
            var validator = this.element.closest("form").data("validator");
            validator = validator ? validator : this.element.closest("form").validate();
            var name = this.element.attr("name");
            validator.settings.messages[name] = {};
            for (var ruleName in this.model.validationRules) {
                var message = null;
                if (!ej.isNullOrUndefined(this.model.validationRules[ruleName])) {
                    if (!ej.isNullOrUndefined(this.model.validationRules["messages"] && this.model.validationRules["messages"][ruleName]))
                        message = this.model.validationRules["messages"][ruleName];
                    else {
                        validator.settings.messages[name][ruleName] = $.validator.messages[ruleName];
                        for (var msgName in this.model.validationMessages)
                            ruleName == msgName ? (message = this.model.validationMessages[ruleName]) : "";
                    }
                    validator.settings.messages[name][ruleName] = message != null ? message : $.validator.messages[ruleName];
                }
            }
        },

        setValue: function (date){
            if(typeof(date) === "string") date = new Date(date);
            var prevValue = this.model.value;
            this._setDateValue(date);
            this._checkErrorClass();
            if(prevValue != this.model.value)this._triggerChangeEvent();
        },
        _checkAttribute: function () {
            var attr = ["min", "max", "readonly", "disabled"], propName = ["minDate", "maxDate", "readOnly", "enabled"], value, propValue;
            for (var i = 0; i < attr.length; i++) {
                value = this.element.attr(attr[i]); propValue = propName[i];
                if (!ej.isNullOrUndefined(value)) {
                    if (ej.isNullOrUndefined(this._options))
                        this.model[propValue] = ((propValue != "enabled") && (propValue != "readOnly")) ? new Date(value) : propValue == "readOnly" ? this.element.is("[readonly]") : !this.element.is("[disabled]");
                    else if (ej.isNullOrUndefined(this._options[propValue]))
                        this.model[propValue] = ((propValue != "enabled") && (propValue != "readOnly")) ? new Date(value) : propValue == "readOnly" ? this.element.is("[readonly]") : !this.element.is("[disabled]");
                }
            }
        },
        _updateDateValue: function (value) {
            var date = this._checkDateObject(value);
            if (date != null) {
                this.isValidState = true;
                if (date == "") {
                    this.element.val("");
                    this.model.value = null;
                } else {
                    this.model.value = date;
                    this._preTxtValue = this.element.val(this._formatter(this.model.value, this.model.dateFormat));
                }
            }
            else {
                (typeof date === "string" && this.model.enableStrictMode) ? this.element.val(value) : this.element.val("");
                this.model.value = null;
                this.isValidState = (this.element.val() == "") ? true : false;
            }
            this._removeWatermark();
        },
        _ensureValue: function () {
            var dateValue = this._parseDate(this.element.val(), this.model.dateFormat);
            if (this.model.value)
                this._setDateValue(this.model.value);
            else if (dateValue)
                this._setDateValue(dateValue);
        },
        _changeEditable: function (bool) {
            var action = bool ? "_on" : "_off";
            if (this.element.is(":input")) {
                if (bool) {
                    if (!this.model.readOnly) this.element.attr("readonly", false);
                    this.element.off("mousedown", $.proxy(this._showDatePopUp, this));
                }
                else {
                    if (!this.model.readOnly) this.element.attr("readonly", "readonly");
                    if (!this.model.displayInline) this.element.on("mousedown", $.proxy(this._showDatePopUp, this));
                }
                this[action](this.element, "blur", this._onFocusOut);
                this[action](this.element, "focus", this._onFocusIn);
                this[action](this.element, "keydown", this._onKeyDown);
            }
        },
        _allowQuickPick: function (value) {
            $('.e-datepicker-headertext', this.sfCalendar)[value ? "on" : "off"]("click", $.proxy(this._forwardNavHandler, this));
        },
        _setRestrictDateState: function (value) {
            var action = value ? "addClass" : "removeClass";
            this.sfCalendar[action]("e-dp-restrict-show");
        },
        _setValues: function () {
            this.Date = new Date();
            this._id = this.element[0].id;
            this.isValidState = true;
            this._setCulture(this.model.locale);
            this._setMinDate(this.model.minDate);
            this._setMaxDate(this.model.maxDate);
            this._calendarDate = this._zeroTime(new Date());
            if (this.model.startDay < 0 || this.model.startDay > 6) this.model.startDay = 0;
            this.Date.firstDayOfWeek = this.model.startDay;
            this.Date.fullYearStart = '20';
            this._showHeader = true;
            if (ej.isNullOrUndefined(this.model.value) && this.element[0].value != "")
                this.model.value = this.element[0].value;
            this._validateMinMaxDate();
            this._dateValue = new Date(this._calendarDate.toString());
            this._isIE7 = this._checkIE7();
            this._isIE8 = (ej.browserInfo().name == "msie") && (ej.browserInfo().version == "8.0") ? true : false;
            this._isIE9 = (ej.browserInfo().name == "msie") && (ej.browserInfo().version == "9.0") ? true : false;
            // this variable is set to true in DateTimePicker control
            this._getInternalEvents = false;
            this._flag = true;
            this._ejHLWeekEnd = false;
            this._isOpen = false;
            this._prevDate = null;
            this._preValue = null;
            this._isFocused = false;
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                var keyName = key.toLowerCase();
                if (keyName == "class") proxy.wrapper.addClass(value);
                else if (keyName == "disabled") proxy.disable();
                else if (keyName == "readOnly") proxy.model.readOnly = true;
                else if (keyName == "style") proxy.wrapper.attr(key, value);
                else if (keyName == "id") {
                    proxy.wrapper.attr(key, value + "_wrapper");
                    proxy.element.attr(key, value);
                }
                else if (ej.isValidAttr(proxy.element[0], key)) proxy.element.attr(key, value);
                else proxy.wrapper.attr(key, value);

            });
        },
        _createDatePicker: function () {
            this._createWrapper();
            this._wireEvents();
            if (this.model.displayInline) {
                this.show();
            }
            if (this.model.enableRTL) this._setRTL(true);
            if (this.model.showRoundedCorner) this._setRoundedCorner(true);
        },
        _checkNameAttr: function () {
            if (!this.element.attr("name") && this._isInputBox)
                this.element.attr("name", this.element[0].id);
            if (this.model.displayInline && !this._isInputBox)
                this._hiddenInput.attr("name", this.element[0].id);
        },
        _createWrapper: function () {
            this._getMapper();
            if (this.model.specialDates)
                this._createSpecialDateObject();
			if(!this.element[0].hasAttribute("tabindex"))this.element.attr("tabindex","0");
            if (this._isInputBox) {
			    this.element.addClass("e-input").attr({ 'aria-atomic': 'true', 'aria-live': 'assertive', 'aria-expanded':'false','role':'combobox' });
                this.wrapper = ej.buildTag("span.e-datewidget e-widget " + this.model.cssClass);
                this.wrapper.attr("style", this.element.attr("style"));
                this.element.removeAttr('style');
                if (!ej.isTouchDevice()) this.wrapper.addClass('e-ntouch');
                this.innerWrapper = ej.buildTag("span.e-in-wrap e-box e-padding");
                this.wrapper.append(this.innerWrapper).insertBefore(this.element);
                this.innerWrapper.append(this.element);
                this.dateIcon = ej.buildTag("span.e-select#" + this._id + "-img", "", {}, (this._isIE8) ? { 'unselectable': 'on' } : {})
                    .append(ej.buildTag("span.e-icon e-calendar", "", {}, { 'aria-label': 'Select' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})).insertAfter(this.element);
            }
            if (!this._isSupport || (this.model.displayInline && !this._isInputBox)) {
                this._hiddenInput = ej.buildTag("input.e-input e-placeholder ", "", {}, { type: "text" }).insertAfter(this.element);
                if (this._isInputBox) this._hiddenInput.val(this._localizedLabels.watermarkText);
                this._hiddenInput.css("display", "block");
                var proxy = this;
                $(this._hiddenInput).focus(function () {
                    proxy.element.focus();
                });
            }
            this._checkNameAttr();
            if (!this.model.height) this.model.height = this.element.attr("height"); if (!this.model.width) this.model.width = this.element.attr("width");
            this._setHeight(this.model.height);
            this._setWidth(this.model.width);
            if (this._id)
                $("#e-" + this._id).remove();
            this._setDateValue(this.model.value);
            this._preValue = this._parseDate(this.element.val(), this.model.dateFormat);
            this._setWaterMark();
            this._dateValue = new Date(this._calendarDate.toString());
            if (this.model.displayInline) this._renderPopup();
            else if (this._isInputBox) this._renderDateIcon(this.model.showPopupButton, false);
            if (this.model.readOnly) this._disbleMaualInput();
            if (!this.model.enabled) this.disable();
            else if (this.model.enabled && $(this.element).hasClass("e-disable")) this.enable();
            this._layoutChanged();
            this._checkErrorClass();
            this._addAttr(this.model.htmlAttributes);
        },
        _isInputBox: function () {
			if(this.element.is("input[type=date]")) this.element.attr('type',"text");
            return (this.element.is("input") && (this.element.is("input[type=text]") || !this.element.attr('type')));
        },

        _renderDateIcon: function (bool, reRender) {
            if (reRender && this.model.showPopupButton == bool) return;
            if (!bool && this.dateIcon) {
                this._bindInputEvent();
                this.dateIcon.css('display', 'none');
                this.innerWrapper.removeClass('e-padding');
            }
            else {
                if (this.innerWrapper) {
                    this.innerWrapper.addClass('e-padding');
                    this.dateIcon.css('display', 'block');
                }
                if (!this.model.displayInline)
                    this._bindDateButton();
            }
            this.model.showPopupButton = bool;
        },

        _resizeCalender: function () {
            if ((this.model.dayHeaderFormat == "short") || (this.model.dayHeaderFormat == "min") || (this.model.dayHeaderFormat == "none"))
                this.sfCalendar.removeClass("e-headerlong");
            else if (this.model.dayHeaderFormat == "long") {
                this.sfCalendar.addClass("e-headerlong");
            }
        },

        _setWidth: function (value) {
            if (value) {
                if (this.wrapper) this.wrapper.width(value);
                else this.element.width(value);
            }
            else
                this.model.width = this.wrapper ? this.wrapper.outerWidth() : this.element.width();
        },
        _setHeight: function (value) {
            if (value) {
                if (this.wrapper) this.wrapper.height(value);
                else this.element.height(value);
            }
            else
                this.model.height = this.wrapper ? this.wrapper.outerHeight() : this.element.height();
            if (this._isIE7) this.element.height(this.innerWrapper.height());
        },
        _setRTL: function (isRTL) {
            if (isRTL) {
                if (this.wrapper) {
                    this.wrapper.addClass("e-rtl");
                }
                this.sfCalendar && this.sfCalendar.addClass("e-rtl");
            }
            else {
                if (this.wrapper) {
                    this.wrapper.removeClass("e-rtl");
                }
                this.sfCalendar && this.sfCalendar.removeClass("e-rtl");
            }
        },
        _setRoundedCorner: function (bool) {
            if (bool) {
                if (this.innerWrapper)
                    this.innerWrapper.addClass("e-corner");
                this.sfCalendar && this.sfCalendar.addClass("e-corner");
            }
            else {
                if (this.innerWrapper)
                    this.innerWrapper.removeClass("e-corner");
                this.sfCalendar && this.sfCalendar.removeClass("e-corner");
            }
        },

        _refreshDatepicker: function () {
            if (this._stopRefresh) {
                this._stopRefresh = false
                return;
            }
            var _currentVal = this.element.val();
            var dateSelection = false;
            if (this.model.navigate !== null) {
                if (this.sfCalendar.find('table')[0] !== undefined) {
                    var sfCalendarClassName = this.sfCalendar.find('table')[0].className;
                    if (sfCalendarClassName === 'e-dp-viewdays' && +this._dateValue !== +this._calendarDate) {
                        this._calendarDate = this._dateValue;
                        dateSelection = true;
                    } else if (sfCalendarClassName !== 'e-dp-viewdays') {
                        if (sfCalendarClassName === 'e-dp-viewmonths' || sfCalendarClassName === 'e-dp-viewyears' || sfCalendarClassName === 'e-dp-viewallyears') {
                            this._startNavigate = true;
                        }
                        return;
                    }
                }
            }
            //  For checking the year maximum range....
            if (this._specificFormat() && this._formatter(this._preValue, this.model.dateFormat, this.model.locale) != _currentVal)
                var currentValue = this._parseDate(_currentVal, true);
            else var currentValue = this._parseDate(_currentVal);
            currentValue = this._validateYearValue(currentValue);
            if (this.model.navigate !== null && currentValue !== null && currentValue !== this._calendarDate) currentValue = this._calendarDate;
            this._setDateValue(currentValue);
            if (this._specificFormat() && this._compareDate(this.model.value, this._calendarDate))
                this.element.val(_currentVal)
            $(".e-datepicker-headertext", this.sfCalendar).text(this._formatter(this._calendarDate, this.model.headerFormat));
            this._resizeCalender();
            this._dateValue = new Date(this._calendarDate.toString());
            this._hoverDate = this._calendarDate.getDate() - 1;
            this._renderCalendar(this, this._dateValue);
            if (dateSelection && _currentVal === '') this._addFocus('day', this._hoverDate);
            this._setFooterText(this._localizedLabels.buttonText);
            this._enableFooter(this.model.showFooter);
            this._layoutChanged();
        },

        _removeCurrentMonthFromHideDate: function() {
            var rowLength = this.sfCalendar.find('tbody.e-datepicker-days tr').length;
            for (var i = 0; i < rowLength; i++) {
                var cellLength = this.sfCalendar.find('tbody.e-datepicker-days tr')[i].cells.length;
                for (var j = 0; j < cellLength; j++) {
                    var hideDay = $(this.sfCalendar.find('tbody.e-datepicker-days tr')[i].cells[j]);
                    if (hideDay.hasClass('e-hidedate')) {
                        if(hideDay.hasClass('current-month')) hideDay.removeClass('current-month');
                    }
                }
            }
        },
        _validateYearValue: function (value) {
            if (value != null) {
                var twoDigitYearMax = ej.preferredCulture(this.model.locale).calendars.standard.twoDigitYearMax;
                twoDigitYearMax = typeof twoDigitYearMax === "string" ? new Date().getFullYear() % 100 + parseInt(twoDigitYearMax, 10) : twoDigitYearMax;
                if (this._calendarDate.getFullYear() - value.getFullYear() == 100) {
                    if (this._calendarDate.getFullYear() > twoDigitYearMax)
                        value.setFullYear(this._calendarDate.getFullYear())
                }
            }
            return value;
        },
        _setFooterText: function (footerText) {
            $('.e-footer-text', this.sfCalendar).html(footerText);
        },
        _setSkin: function (skin) {
            if (this.wrapper) {
                this.wrapper.removeClass(this.model.cssClass);
                this.wrapper.addClass(skin);
            }
            else {
                this.element.removeClass(this.model.cssClass);
                this.element.addClass(skin);
            }
            this.sfCalendar.removeClass(this.model.cssClass);
            this.sfCalendar.addClass(skin);
        },
        _setDisplayInline: function (isDisplayInline) {
            this.model.displayInline = isDisplayInline;
            if (isDisplayInline && this._isInputBox) {
                this.sfCalendar.insertAfter(this.wrapper);
                this._setDatePickerPosition();
            }
            else if (isDisplayInline) {
                this.element.append(this.sfCalendar);
                if (!this._isSupport || !this._isInputBox) this._hiddenInput.css("display", "none");
            }
            else {
                this.sfCalendar.css('display', 'none');
                $('body').append(this.sfCalendar);
                this._isOpen = false;
            }
            if (isDisplayInline) {
                this.show();
                this._off(this.dateIcon, "mousedown", this._showDatePopUp);
                this.element.off("mousedown", $.proxy(this._showDatePopUp, this));
            }

        },

        _disbleMaualInput: function () {
            if (this.model.readOnly) {
                $(this.element).attr("readonly", "readonly");
                if (!this.model.displayInline) this.hide();
            }
            else if (this.model.allowEdit)
                $(this.element).prop("readonly", false);

        },
        _checkDateObject: function (date, val) {
            if (!date || (typeof JSON === "object" && JSON.stringify(date) === "{}")) return date = null;
            else if (!(date instanceof Date)) {
                if (this._specificFormat())
                    var val = this._parseDate(date, true);
                else
                    var val = this._parseDate(date, val);
                date = val ? val : (val = this._checkJSONString(date)) ? val : null;
            }
            if (!isNaN(Date.parse(date))) {
                this._dateValue = this._calendarDate = this._zeroTime(date)
                if (this._validateDate(date))
                    return this._dateValue;
            }
            return null;
        },
        _checkJSONString: function(date) {
            // Validate the string value
            if (!isNaN(Date.parse(date))) {
                if ((new Date(date).toJSON() === date) || (new Date(date).toDateString() === date) || (new Date(date).toGMTString() === date) ||
                    (new Date(date).toISOString() === date) || (new Date(date).toLocaleString() === date) ||
                    (new Date(date).toString() === date) || (new Date(date).toUTCString() === date)) {
                    if (this.model.timeZone) {
                        return new Date(new Date(date).getTime() + (ej.serverTimezoneOffset * 60 * 60 * 1000));
                    } else {
                        if (date.match(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i) && date.match(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(\.\d+)?(([+-]\d\d:\d\d)|Z)?$/i).length > 0) {
                            date = date.split('T')
                            date = date[0];
                            return ej.parseDate(date, "yyyy-MM-dd", this.model.locale);
                        }
                    }
                } else if (typeof date == "string") return this._dateFromISO(date);
            }else if(this.model.enableStrictMode && ej.parseDate(date, this.model.value, this.model.locale) == null) return null; 
			else if (this._extISORegex.exec(date) || this._basicISORegex.exec(date)) return this._dateFromISO(date);
        },
        _dateFromISO: function (date) {
            var result = this._isISODate.test(date) && (this._extISORegex.exec(date) || this._basicISORegex.exec(date)), dateFormat = '', timeFormat = '', zeroFormat = '', format;
            if (result) {
                for (var i = 0; i < this._dates.length; i++) {
                    if (this._dates[i][1].exec(result[1])) {
                        dateFormat = this._dates[i][0];
                        break;
                    }
                }
                if (result[3]) {
                    for (var k = 0; k < this._times.length; k++) {
                        if (this._times[k][1].exec(result[3])) {
                            // result[2] should be 'T' (time) or space
                            timeFormat = (result[2] || ' ') + this._times[k][0];
                            break;
                        }
                    }
                }
                if (result[4]) if (this._zeroRegex.exec(result[4])) zeroFormat = 'Z';
                format = dateFormat + timeFormat + zeroFormat;
                var token = format.match(this._tokens), input, val = [], literal, char;
                for (var j = 0; j < token.length; j++) {
                    var str = token[j];
                    literal = this._checkLiteral(token[j]);
                    var rg = this._numberRegex[literal ? token[j].toLowerCase() : str.length] || new RegExp('^\\d{1,' + str.length + '}');
                    input = date.match(rg);
                    if (input) {
                        if (date.substr(0, date.indexOf(input)) >= 0 && !literal) token[j].indexOf('M') >= 0 ? val.push(parseInt(input[0]) - 1) : val.push(parseInt(input[0]));
                        date = date.slice(date.indexOf(input[0]) + input[0].length);
                    }
                }
                //if you want to get the value in UTC format use the "new Date(Date.UTC.apply(null, val)"
                //return the date object value as exact as given input value
                //new Date(year, month, day, hour, minute, seconds);
                return result[4] == "Z" ? new Date(Date.UTC.apply(null, val)) : new Date(val[0], val[1], val[2], val[3], val[4], val[5]);
            }
            else {
                return new Date(date + "");
            }
        },
        _checkLiteral: function (str) {
            var char = str.toLowerCase();
            return (char == 't' || char == 'z' || char == ':' || char == '-') ? true : false;
        },
        _checkInstanceType: function (date) {
            date = this._stringToObject(date);
            if (!date) return null;
            else if (!(date instanceof Date)) {
                date = this._parseDate(date);
            }
            if (!isNaN(Date.parse(date))) return this._zeroTime(date);
            return null;
        },
        _stringToObject: function (value) {
            if (typeof value === "string") {
                var val = ej.parseDate(value, this.model.dateFormat, this.model.locale);
                value = (val != null) ? val : new Date(value);
            }
            return value;
        },
        _validateMinMaxDate: function () {
            var dateChange = false, valueExceed = false;
            if (this.model.maxDate < this.model.minDate) this.model.minDate = this.model.maxDate;
            if (!this.model.enableStrictMode) {
                if (this.model.value) {
                    if (this.model.value < this.model.minDate) {
                        this._calendarDate = this.model.value = this.model.minDate;
                        dateChange = true;
                    }
                    else if (this.model.value > this.model.maxDate) {
                        this._calendarDate = this.model.value = this.model.maxDate;
                        dateChange = true;
                    }
                }
                else {
                    this.element.val("");
                    if (this._calendarDate < this.model.minDate) this._calendarDate = this.model.minDate;
                    else if (this._calendarDate > this.model.maxDate) this._calendarDate = this.model.maxDate;
                }
                this.isValidState = true;
            }
            else {
                if (this.model.value) {
                    if (this.model.value < this.model.minDate) {
                        this._calendarDate = this.model.minDate;
                        this.isValidState = false;
                        valueExceed = true;
                    }
                    else if (this.model.value > this.model.maxDate) {
                        this._calendarDate = this.model.maxDate;
                        this.isValidState = false;
                        valueExceed = true;
                    }
                    else this.isValidState = true;
                }
                else {
                    if (this._calendarDate < this.model.minDate) this._calendarDate = this.model.minDate;
                    else if (this._calendarDate > this.model.maxDate) this._calendarDate = this.model.maxDate;
                }
            }
            if (dateChange) this.element.val(this._formatter(this.model.value, this.model.dateFormat));
            if (valueExceed && this._getInternalEvents) this._trigger("outOfRange");
        },
        _setCulture: function (culture) {
            this.culture = ej.preferredCulture(culture);
            if (this.culture) {
                this.model.locale = this.culture.name == "en" ? "en-US" : this.culture.name;
                this.Date.dayNames = this.culture.calendar.days.names;
                this.Date.dayNamesMin = this.culture.calendar.days.namesShort;
                this.Date.abbrDayNames = this.culture.calendar.days.namesAbbr;
                this.Date.monthNames = this.culture.calendar.months.names;
                this.Date.abbrMonthNames = this.culture.calendar.months.namesAbbr;
                this.Date.format = this.culture.calendar.patterns.d;
                if (this.model.dateFormat == '') this.model.dateFormat = this.culture.calendar.patterns.d;
                if (this.model.startDay == -1) this.model.startDay = this.culture.calendar.firstDay;
            }
            this._separator = this._getSeparator();
            this._localizedLabels = this._getLocalizedLabels();

            if (!ej.isNullOrUndefined(this._options)) {
                if (!ej.isNullOrUndefined(this._options.watermarkText))
                    this._localizedLabels.watermarkText = this._options.watermarkText;
                if (!ej.isNullOrUndefined(this._options.buttonText))
                    this._localizedLabels.buttonText = this._options.buttonText;
            }
            this._localizedLabelToModel();
        },

        _localizedLabelToModel: function () {
            this.model.watermarkText = this._localizedLabels.watermarkText;
            this.model.buttonText = this._localizedLabels.buttonText;
        },

        _setWaterMark: function () {
            if (this.element != null && this.element.hasClass("e-input")) {
                if (this._localizedLabels.watermarkText && this.element.val() == "") {
                    this.isValidState = true;
                    this._checkErrorClass();
                }
                if ((!this._isSupport) && this.element.val() == "") {
                    this._hiddenInput.css("display", "block").val(this._localizedLabels.watermarkText);
                }
                else {
                    $(this.element).attr("placeholder", this._localizedLabels.watermarkText);
                }
                return true;
            }
        },

        _setDatePickerPosition: function () {
            if (!this.model.displayInline || this._isInputBox) {
                var elementObj = this.element.is('input') ? this.wrapper : this.element;
                var pos = this._getOffset(elementObj), winLeftWidth, winRightWidth,
                winBottomHeight = $(document).scrollTop() + $(window).height() - (pos.top + $(elementObj).outerHeight()),
                winTopHeight = pos.top - $(document).scrollTop(),
                popupHeight = this.sfCalendar.outerHeight(),
                popupWidth = this.sfCalendar.outerWidth(),
                left = pos.left,
                totalHeight = elementObj.outerHeight(),
                border = (totalHeight - elementObj.height()) / 2,
                maxZ = this._getZindexPartial(), popupmargin = 3,
                topPos = (popupHeight < winBottomHeight || popupHeight > winTopHeight) ? pos.top + totalHeight + popupmargin : pos.top - popupHeight - popupmargin; // popupmargin denotes space b/w the element and the popup.
                winLeftWidth = $(document).scrollLeft() + $(window).width() - left;
                winRightWidth = $(document).scrollLeft() + left + elementObj.width();
                if (this.model.enableRTL || popupWidth > winLeftWidth && (popupWidth < left + elementObj.outerWidth()) && !ej.isNullOrUndefined(this.wrapper))
                    left += this.wrapper.width() - this.sfCalendar.width();
                if (popupWidth > winRightWidth) left = pos.left;
                this.sfCalendar.css({
                    "left": left + "px",
                    "top": topPos + "px",
                    "z-index": maxZ
                });
            }
        },

        _getOffset: function (ele) {
            return ej.util.getOffset(ele);
        },

        _getZindexPartial: function () {
            return ej.util.getZindexPartial(this.element, this.sfCalendar);
        },

        _setMinDate: function (d) {
            this.model.minDate = this._checkInstanceType(d);
            if (!this.model.minDate) {
                this.model.minDate = (new Date('11/31/1899'));
            }
        },

        _setMaxDate: function (d) {
            this.model.maxDate = this._checkInstanceType(d);
            if (!this.model.maxDate) {
                this.model.maxDate = (new Date('12/31/2099')); // using the JS Date.parse function which expects mm/dd/yyyy
            }
        },
        _setDateValue: function (date, val) {
            var newDate = this._checkDateObject(date, val);
            if (newDate != null) {
                this.isValidState = true;
                this.model.value = new Date(newDate);
                if (!this.model.displayInline)
                    this.wrapper.addClass('e-valid');
                this._validateMinMaxDate();
                this._preTxtValue = this.element.val(this._formatter(this.model.value, this.model.dateFormat));
            }
            else {
                if (date instanceof Date) {
                    this._validateMinMaxDate();
                    date = this._formatter(date, this.model.dateFormat);
                }
                (this.model.enableStrictMode) ? this.element.val(date) : this.element.val(null);
                this.model.value = null; //updating model value as null to avoid the recursive call to this method
                if (!this.model.displayInline)
                    this.wrapper.removeClass('e-valid');
                this._triggerChangeEvent();
                this.isValidState = (this.element.val() == "" || ej.isNullOrUndefined(this.element.val())) ? true : false;
            }
            this._removeWatermark();
        },
        _updateInputVal: function () {
            var val = this._validateValue();
            if ((val != null || !this.model.enableStrictMode) && this.sfCalendar && this.sfCalendar.find('.e-datepicker-days').is(':visible'))
                this._refreshDatepicker();
        },
        _validateInputVal: function () {
            var val = this._validateValue();
            if (val != null) {
                if (!this.model.enableStrictMode) {
                    if (val <= this.model.maxDate && val >= this.model.minDate)
                        this.isValidState = true;
                    else {
                        this.model.value = null;
                        this.isValidState = true;
                    }
                }
            }
        },

        _validateValue: function () {
            if (this._specificFormat() && this.element.val() != this._formatter(this._preValue, this.model.dateFormat, this.model.locale))
                var value = this._parseDate(this.element.val(), true);
            else var value = this._parseDate(this.element.val());
            return this._validateYearValue(value);
        },
        _getSeparator: function () {
            var formats;
            if (this.culture) {
                formats = this.culture.calendar.patterns.d;
            }
            else formats = this.model.dateFormat;
            var regex = new RegExp("^[a-zA-Z0-9]+$");
            for (var i = 0; i < formats.length; i++) {
                if (!regex.test(formats[i])) return formats[i];
            }
        },
        _checkIE7: function () {
            if (navigator.appName == 'Microsoft Internet Explorer') {
                var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})"), version = -1;
                if (re.exec(navigator.userAgent) != null)
                    version = parseFloat(RegExp.$1);
                if (version >= 7 && version < 8) return true;
            }
            return false;
        },
        _isValidDate: function (dateObj) {
            return dateObj && typeof dateObj.getTime === "function" && isFinite(dateObj.getTime());
        },

        //Date formatter - Convert date object to specific date format
        _formatter: function (date, format) {
            var newFormat = this._checkFormat(format);
            return ej.format(date, newFormat, this.model.locale);
        },
        _parseDate: function (date, type) {
            var newFormat = this._checkFormat(this.model.dateFormat);
            var DateValue = date;
            if ((this._specificFormat()) && DateValue != undefined && date != "" && type != true && !(ej.format(ej.parseDate(DateValue, newFormat, this.model.locale), this.model.dateFormat, this.model.locale) == DateValue)) {
                return this._dateValue;
            }
            else return ej.parseDate(date, newFormat, this.model.locale);
        },
        _checkFormat: function (format) {
            var proxy = this;
            var dateFormatRegExp = this._regExp();
            return format.replace(dateFormatRegExp, function (match) {
                match = match === "/" ? ej.preferredCulture(proxy.model.locale).calendars.standard['/'] !== "/" ? "'/'" : match : match;
                return match;
            });
        },
        _regExp: function () {
            return /\/dddd|ddd|dd|d|MMMM|MMM|MM|M|yyyy|yy|HH|H|hh|h|mm|m|fff|ff|f|tt|ss|s|zzz|zz|z|gg|g|"[^"]*"|'[^']*'|[/]/g;
        },

        isLeapYear: function (year) {
            return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
        },
        //Sets the time component of this Date to zero for cleaner, easier comparison of dates where time is not relevant.
        _zeroTime: function (date) {
            var newDate = typeof date === "string" ? this._parseDate(date) : new Date(date);
            newDate.setMilliseconds(0);
            newDate.setSeconds(0);
            newDate.setMinutes(0);
            newDate.setHours(0);
            return newDate;
        },

        _getDaysInMonth: function (date) {
            return [31, (this.isLeapYear(date) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][date.getMonth()];
        },

        _addDays: function (d, number) {
            d.setDate(d.getDate() + number);
            return d;
        },

        _addYears: function (d, number) {
            d.setFullYear(d.getFullYear() + number);
            return d;
        },

        _addMonths: function (d, number) {
            var tempDatedateMonth = d.getDate();
            d.setMonth(d.getMonth() + number);
            if (tempDatedateMonth > d.getDate())
                this._addDays(d, -d.getDate());
            return d;
        },
        //Checks if the day is a weekend day (Sat or Sun).
        _isWeekend: function (date) {
            return date.getDay() == 0 || date.getDay() == 6;
        },

        _isSpecialDates: function (dates) {
            if (this.model.specialDates) {
                for (var i = 0; i < this.model.specialDates.length; i++) {
                    if (this.model.specialDates[i] && this.model.specialDates[i][this._mapField._date]) {
                        if (dates.getDate() == this.model.specialDates[i][this._mapField._date].getDate() && dates.getMonth() == this.model.specialDates[i][this._mapField._date].getMonth() && dates.getFullYear() == this.model.specialDates[i][this._mapField._date].getFullYear()) {
                            this._getIndex = i;
                            return true;
                        }
                    }
                }
            }
            return false;
        },
        _getMapper: function () {
            var mapper = this.model.fields;
            this._mapField = {};
            this._mapField["_date"] = (mapper && mapper.date) ? mapper["date"] : "date";
            this._mapField["_tooltip"] = (mapper && mapper.tooltip) ? mapper["tooltip"] : "tooltip";
            this._mapField["_icon"] = (mapper && mapper.iconClass) ? mapper["iconClass"] : "iconClass";
            this._mapField["_custom"] = (mapper && mapper.cssClass) ? mapper["cssClass"] : "cssClass";
        },
        _createSpecialDateObject: function () {
            for (var i = 0; i < this.model.specialDates.length; i++) {
                this.model.specialDates[i][this._mapField._date] = this._checkInstanceType(this.model.specialDates[i][this._mapField._date]);
            }
        },

        _getMonthName: function (abbreviated, date) {
            return abbreviated ? this.Date.abbrMonthNames[date.getMonth()] : this.Date.monthNames[date.getMonth()];
        },



        _displayNewMonth: function (m, y) {
            this._setDisplayedMonth(this.displayedMonth + m, this.displayedYear + y, true);
            return false;
        },

        _setDisplayedMonth: function (m, y, rerender) {
            if (this.model.minDate == undefined || this.model.maxDate == undefined) {
                return;
            }
            var s = new Date(this.model.minDate.getTime());
            s.setDate(1);
            var e = new Date(this.model.maxDate.getTime());
            e.setDate(1);

            var t;
            if ((!m && !y) || (isNaN(m) && isNaN(y))) {

                t = this._zeroTime(new Date());
                t.setDate(1);
            } else if (isNaN(m)) {

                t = new Date(y, this.displayedMonth, 1);
            } else if (isNaN(y)) {

                t = new Date(this.displayedYear, m, 1);
            } else {

                t = new Date(y, m, 1);
            }

            if (t.getTime() < s.getTime()) {
                t = s;
            } else if (t.getTime() > e.getTime()) {
                t = e;
            }
            var oldMonth = this.displayedMonth;
            var oldYear = this.displayedYear;
            this.displayedMonth = t.getMonth();
            this.displayedYear = t.getFullYear();
            var tempDate = t;
            if (rerender && (this.displayedMonth != oldMonth || this.displayedYear != oldYear)) {
                this._renderCalendar(this, tempDate);
                this._dateValue = tempDate;
                this._trigger("monthChanged", [this.displayedMonth, this.displayedYear]);
            }
        },
        _clearSelected: function () {
            this.numSelected = 0;
            if (!ej.isNullOrUndefined(this.sfCalendar)) {
            if (this.model.highlightSection == "week") {
                $('td.e-active', this.sfCalendar).removeClass('e-active').addClass('e-state-hover').attr('aria-selected', false).parent().removeClass('e-selected-week');
            }
            else if (this.model.highlightSection == "month") {
                $('td.e-active', this.sfCalendar).removeClass('e-active').addClass('e-state-hover').attr('aria-selected', false).parent().parent().removeClass('e-selected-month');
            }
            else if (this.model.highlightSection == "workdays") {
                $('td.e-active', this.sfCalendar).removeClass('e-active').addClass('e-state-hover').attr('aria-selected', false).parent().removeClass('e-work-week');
            }
            else
                $('td.e-active', this.sfCalendar).removeClass('e-active').addClass('e-state-hover').attr('aria-selected', false);
            }

        },
        _addSelected: function () {
            if (this.model.highlightSection == "week") {
                $('td.e-active', this.sfCalendar).parent().addClass('e-selected-week');
            }
            else if (this.model.highlightSection == "month") {
                $('td.e-active, this.sfCalendar').parent().parent().addClass('e-selected-month');
            }
            else if (this.model.highlightSection == "workdays") {
                $('td.e-active', this.sfCalendar).parent().addClass('e-work-week');
            }
        },

        _hideOtherMonths: function (sfCalendar) {
            $('td.other-month', sfCalendar).css("visibility", "hidden");
        },
        _showOtherMonths: function (sfCalendar) {
            $('td.other-month', sfCalendar).css({ 'visibility': 'visible' });
        },
        _otherMonthsVisibility: function () {
            if (this.model.showOtherMonths)
                this._showOtherMonths(this.sfCalendar);
            else
                this._hideOtherMonths(this.sfCalendar);
        },

        _createCalender: function () {
            ej.buildTag("div.e-header").attr((this._isIE8) ? { 'unselectable': 'on' } : {})
                    .append(ej.buildTag("span.e-prev").append(ej.buildTag('a.e-icon e-arrow-sans-left').attr({ 'role': 'button' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})))
                    .append(ej.buildTag("span.e-text").append(ej.buildTag("span.e-datepicker-headertext").text(this._formatter(this._calendarDate, this.model.headerFormat)).attr({ 'aria-atomic': 'true', 'aria-live': 'assertive', 'role': 'heading' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})))
                    .append(ej.buildTag("span.e-next").append(ej.buildTag('a.e-icon e-arrow-sans-right').attr({ 'role': 'button' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})))
                    .appendTo(this.sfCalendar);
            this._enableHeader(this._showHeader);
            var table = ej.buildTag("table.e-dp-viewdays", "", {}).data("e-table", "data").attr({ 'role': 'grid'}).attr((this._isIE8) ? { 'unselectable': 'on' } : {});
            this.sfCalendar.append(table);
            this._renderCalendar(this);
            this._startLevel(this.model.startLevel);
            ej.buildTag("div.e-footer")
                .append(ej.buildTag("span.e-footer-icon"))
                .append(ej.buildTag("span.e-footer-text"))
                .appendTo(this.sfCalendar);
            $('.e-footer-text', this.sfCalendar).html(this._localizedLabels.buttonText);
            this._enableFooter(this.model.showFooter);
        },
        _enableHeader: function (show) {
            if (show) $(".e-header", this.sfCalendar).show();
            else $(".e-header", this.sfCalendar).hide();
        },
        _enableFooter: function (show) {
            if (show) $('.e-footer', this.sfCalendar).show();
            else $('.e-footer', this.sfCalendar).hide();
            this._todayBtnDisable();
        },
        _todayBtnDisable: function () {
            var today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 0, 0, 0);
            if (!(+this.model.minDate <= +today && +this.model.maxDate >= +today)) {
                $('.e-footer', this.sfCalendar).addClass('e-footer-disable')
            } else {
                $('.e-footer', this.sfCalendar).removeClass('e-footer-disable')
            }
        },
        _checkArrows: function (min, max) {
            this._preArrowCondition(min, this.model.minDate.getFullYear());
            this._nextArrowCondition(max, this.model.maxDate.getFullYear());
        },
        _checkDateArrows: function () {
            this._preArrowCondition(this._tempMinDate, this.model.minDate);
            this._nextArrowCondition(this._tempMaxDate, this.model.maxDate);
        },
        _preArrowCondition: function (val1, val2) {
            if (val1 <= val2) this.sfCalendar.find(".e-prev").addClass("e-disable").attr({ "aria-disabled": true });
            else this.sfCalendar.find(".e-prev").removeClass("e-disable").attr({ "aria-disabled": false });
        },
        _nextArrowCondition: function (val1, val2) {
            if (val1 >= val2) this.sfCalendar.find(".e-next").addClass("e-disable").attr({ "aria-disabled": true });
            else this.sfCalendar.find(".e-next").removeClass("e-disable").attr({ "aria-disabled": false });
        },

        _previousNextHandler: function (event) {
            if (this.model.readOnly || !this.model.enabled || $(event.target).hasClass("e-disable") || $(event.currentTarget).hasClass("e-disable")) return false;
            event.preventDefault();
            this._keyboardInteraction = false;
            var prevTable = $("table", this.sfCalendar), navFrom;
            navFrom = this._navigateFrom(prevTable);
            var element = ($(event.target).is('a')) ? $(event.target.parentNode) : $(event.target);
            var progress = element.hasClass('e-prev') ? true : false;
            this._processNextPrevDate(progress);
            var currentTable = $("table", this.sfCalendar), tClassName, navTo;
            tClassName = currentTable.get(0).className;
            switch (tClassName) {
                case "e-dp-viewdays": navTo = "month"; break;
                case "e-dp-viewmonths": navTo = "year"; break;
                case "e-dp-viewyears": navTo = "decade"; break;
                case "e-dp-viewallyears": navTo = "century"; break;
            }
            this._trigger("navigate", { date: this._dateValue, value: this._formatter(this._dateValue, this.model.dateFormat), navigateTo: navTo, navigateFrom: navFrom });
        },
        _processNextPrevDate: function (progress) {
            if (this._DRPdisableFade) {
                var s = new Date(this.sfCalendar.find("td.current-month").attr("data-date"));
                this._dateValue = s;
            }
            if (progress && this.sfCalendar.find(".e-arrow-sans-left").hasClass("e-disable")) return false;
            else if (!progress && this.sfCalendar.find(".e-arrow-sans-right").hasClass("e-disable")) return false;

            var currentTable = $("table", this.sfCalendar), temp;
            var tClassName = currentTable.get(0).className;
            switch (tClassName) {
                case 'e-dp-viewdays':
                    var step = this.model.stepMonths;
                    if (progress) {
                        if (this._dateValue <= this.model.minDate) {
                            this._flag = false;
                            return false;
                        }
                    } else {
                        if (this._dateValue >= this.model.maxDate) {
                            this._flag = false;
                            return false;
                        }
                    }
                    this._flag = true;
                    this._addMonths(this._dateValue, (progress ? -step : step));
                    if (this._clickedDate)
                        this._calendarDate = this._clickedDate;
                    this._dateValue = this._dateValue < this.model.minDate ? new Date(this.model.minDate.toString()) : this._dateValue;
                    this._dateValue = this._dateValue > this.model.maxDate ? new Date(this.model.maxDate.toString()) : this._dateValue;
                    this._renderCalendar(this, this._dateValue);
                    if(this._keyboardInteraction) { 
                        this._trigger("navigate", { date: this._dateValue, value: this._formatter(this._dateValue, this.model.dateFormat)});
                        this._removeCurrentMonthFromHideDate();
                        this._keyboardInteraction = false;
                    }
                    $('.e-datepicker-headertext', this.sfCalendar).text(this._formatter(this._dateValue, this.model.headerFormat));
                    this._addFocus('day', this._hoverDate);
                    var dateRange = this._findFirstLastDay(new Date(this._dateValue.toString()));
                    this._preArrowCondition(dateRange.firstDay, this.model.minDate);
                    this._nextArrowCondition(dateRange.lastDay, this.model.maxDate);
                    break;
                case 'e-dp-viewmonths':
                    var dateValue = this._dateValue;
                    dateValue.setFullYear($('.e-datepicker-headertext', this.sfCalendar).text())
                    if (progress) {
                        if (dateValue.getFullYear() <= this.model.minDate.getFullYear()) {
                            this._flag = false;
                            return false;
                        }
                    } else {
                        if (dateValue.getFullYear() >= this.model.maxDate.getFullYear()) {
                            this._flag = false;
                            return false;
                        }
                    }
                    this._flag = true;
                    this._addYears(dateValue, (progress ? -1 : 1));
                    this._renderCalendar(this, dateValue);
                    temp = dateValue.getFullYear();
                    $('.e-datepicker-headertext', this.sfCalendar).text(temp);
                    $('tbody,tr.e-week-header', currentTable).not('.e-datepicker-months').hide();
                    $($(currentTable).find('.e-datepicker-months')).show();
                    this._addFocus('month', this._hoverMonth);
                    this._checkArrows(temp, temp);
                    break;
                case 'e-dp-viewyears':
                    var yearValue;
                    yearValue = this._dateValue
                    yearValue.setFullYear($(currentTable).find(".e-state-hover").text());
                    if (progress) {
                        if (parseInt(this.popup.find('td.e-year-first:first').text()) <= this.model.minDate.getFullYear()) {
                            this._flag = false;
                            return false;
                        }
                    } else {
                        if (parseInt($('td.e-year-last:first').prev().text()) >= this.model.maxDate.getFullYear()) {
                            this._flag = false;
                            return false;
                        }
                    }
                    this._flag = true;
                    if (($(currentTable).find(".e-state-hover").hasClass('e-year-first') && progress) || ($(currentTable).find(".e-state-hover").hasClass('e-year-last') && !progress))
                        this._dateValue.setFullYear(yearValue.getFullYear());
                    else if (($(currentTable).find(".e-state-hover").hasClass('e-year-first') && !progress))
                        this._dateValue.setFullYear(yearValue.getFullYear() + 11);
                    else if (($(currentTable).find(".e-state-hover").hasClass('e-year-last') && progress))
                        this._dateValue.setFullYear(yearValue.getFullYear() - 11);
                    else
                        this._dateValue.setFullYear(yearValue.getFullYear() + (progress ? -10 : 10));
                    this._renderCalendar(this, this._dateValue);
                    var setYear = parseInt(this._dateValue.getFullYear()) - ((parseInt(this._dateValue.getFullYear()) % 10) + 1);
                    $(".e-datepicker-headertext", this.sfCalendar).text((setYear + 1) + ' - ' + (setYear + 10));
                    $('tbody,tr.e-week-header', currentTable).not('.e-datepicker-years').hide();
                    $($(currentTable).find('.e-datepicker-years')).show();
                    this._addFocus('year', this._hoverYear + (!($('.e-year-first.e-hidedate').length) ? 0 : -1));
                    this._checkArrows(setYear + 1, setYear + 10);
                    break;
                case 'e-dp-viewallyears':
                    var headYears;
                    if (progress) {
                        headYears = parseFloat($('td.e-allyear-first', currentTable.get(0)).text().split('-')[1]);
                        if (headYears <= this.model.minDate.getFullYear()) {
                            this._flag = false;
                            return false;
                        } else {
                            this._flag = true;
                        }

                    } else {
                        headYears = parseFloat($('td.e-allyear-last', currentTable.get(0)).prev().text().split('-')[1]);
                        if (headYears >= this.model.maxDate.getFullYear()) {
                            this._flag = false;
                            return false;
                        } else
                            this._flag = true;
                    }
                    this._dateValue.setFullYear((!(this._lastHoveredYear) ? this._dateValue.getFullYear() : this._lastHoveredYear) + (progress ? -100 : 100));
                    this._lastHoveredYear = this._dateValue.getFullYear();
                    this._renderCalendar(this, this._dateValue);
                    var setYear = parseInt(this._dateValue.getFullYear()) - ((parseInt(this._dateValue.getFullYear()) % 100) + 1);
                    temp = parseFloat($('td.e-allyear-last', currentTable.get(0)).prev().text().split('-')[1]);
                    $('.e-datepicker-headertext', this.sfCalendar).text((setYear + 1) + ' - ' + temp);
                    $('tbody,tr.e-week-header', currentTable).not('.e-datepicker-allyears').hide();
                    $($(currentTable).find('.e-datepicker-allyears')).show();
                    this._addFocus('allyear', this._hoverAllYear + (!($('.e-allyear-first.e-hidedate').length) ? 0 : -1));
                    this._checkArrows(setYear + 1, temp);
                    break;
            }
            this._layoutChanged();
        },
        _addFocus: function (selection, index) {
            var cls = 'e-current-' + selection;
            if (selection == 'day') cls = 'current-month';
            var items = this.sfCalendar.find('tbody tr td.' + cls);
            if (selection == "month") {
                $(items).each(function (i, ele) {
                    if (parseInt($(ele).attr("data-index")) == parseInt(index)) {
                        index = i;
                        return;
                    }
                });
            }
            var cell = items[index];
            if (!cell) cell = items.last();
            this.sfCalendar.find('table td').removeClass("e-state-hover");
            if (!$(cell).hasClass('e-hidedate')) $(cell).addClass("e-state-hover");
            this._setActiveState(selection);
            return index;
        },
        _setActiveState: function (selection) {
            if (!(this.model.value instanceof Date)) return;
            var items = this.sfCalendar.find('tbody tr td.e-current-' + selection), cell, proxy = this;
            var indx = -1;
            switch (selection) {
                case "month":
                    if (this.model.value.getFullYear() === parseInt($('.e-text', this.sfCalendar).text())) {
                        $(items).each(function (i, ele) {
                            if (parseInt($(ele).attr("data-index")) == parseInt(proxy.model.value.getMonth())) {
                                indx = i;
                                return;
                            }
                        });
                    }
                    break;
                case "year":
                    var value = this.model.value.getFullYear();
                    $(items).each(function (i, ele) {
                        if (parseInt(ele.innerHTML) == parseInt(value)) {
                            indx = i;
                            return;
                        }
                    });
                    break;
                case "allyear":
                    var start = parseInt(this.model.value.getFullYear()) - ((parseInt(this.model.value.getFullYear()) % 10) + 1);
                    var active = (start + 1) + ' - ' + (start + 10);
                    $(items).each(function (i, ele) {
                        if (parseInt(ele.innerHTML) == parseInt(active)) {
                            indx = i;
                            return;
                        }
                    });
                    break;
            }
            cell = items[indx];
            if (cell) {
                this.sfCalendar.find('table td').removeClass("e-active");
                if (!$(cell).hasClass('e-hidedate'))
                    $(cell).addClass("e-active");
            }
        },
        _setFocusByName: function (name, value) {
            var allValues = this.sfCalendar.find('tbody tr td.e-current-' + name), index, cell;
            $(allValues).each(function (i, ele) {
                if (parseInt(ele.innerHTML) == parseInt(value)) {
                    index = i;
                    return;
                }
            });
            cell = allValues[index];
            if (!cell) cell = allValues.last();
            this.sfCalendar.find('table td').removeClass("e-state-hover");
            $(cell).addClass("e-state-hover");
            this._setActiveState(name);
            return index;
        },
        _getHeaderTxt: function () {
            return this.sfCalendar.find(".e-datepicker-headertext").text();
        },
        _findFirstLastDay: function (value) {
            var y = value.getFullYear(), m = value.getMonth();
            var firstDay = new Date(y, m, 1);
            var lastDay = new Date(y, m + 1, 0);
            return { firstDay: firstDay, lastDay: lastDay }
        },
        _forwardNavHandler: function (event) {
            if (this.model.readOnly || !this.model.enabled) return false;
            if (event) event.preventDefault();

            var currentTable = $("table", this.sfCalendar);
            var tclassName = $("table", this.sfCalendar).get(0).className, proxy = this, headerTxt, navTo;
            var navFrom = this._navigateFrom(currentTable);
            switch (tclassName) {
                case 'e-dp-viewdays':
                    this._hoverMonth = this._getDateObj(currentTable.find(".e-state-hover")).getMonth() ||
                                this._getDateObj(currentTable.find(".e-active")).getMonth() || 0;
                    if (this._DRPdisableFade) {
                        this._renderCalendar(this, this._calendarDate);
                        $('.e-datepicker-headertext', this.sfCalendar).text(this._formatter(this._dateValue, this.model.headerFormat));
                    }
                    this._startLevel("year"); navTo = "year";
                    this._addFocus('month', this._hoverMonth);
                    break;
                case 'e-dp-viewmonths':
                    headerTxt = this._getHeaderTxt();
                    this._startLevel("decade"); navTo = "decade";
                    this._hoverYear = this._setFocusByName('year', headerTxt);
                    break;
                case 'e-dp-viewyears':
                    headerTxt = this._getHeaderTxt();
                    this._startLevel("century"); navTo = "century";
                    this._hoverAllYear = this._setFocusByName('allyear', headerTxt);
                    break;
            }
            if (navFrom != "century") this._trigger("navigate", { date: this._dateValue, value: this._formatter(this._dateValue, this.model.dateFormat), navigateTo: navTo, navigateFrom: navFrom });
            this._layoutChanged();
        },
        _cellSelection: function () {
            var currentTable = $("table", this.sfCalendar);
            var tclassName = $("table", this.sfCalendar).get(0).className;
            switch (tclassName) {
                case 'e-dp-viewmonths':
                    this._hoverMonth = this._addFocus('month', this._dateValue.getMonth());
                    break;
                case 'e-dp-viewyears':
                    var dateValue = new Date(this._dateValue.toString());
                    // Navigate to Prev/Next year Calendar while selecting the first/last year in the calendar view.
                    this._navigationToPrevNext('year');
                    // Reasssign the old value
                    this._dateValue = dateValue;
                    this._hoverYear = this._setFocusByName('year', this._dateValue.getFullYear());
                    break;
                case 'e-dp-viewallyears':
                    var dateValue = new Date(this._dateValue.toString());
                    // Navigate to Prev/Next year Calendar while selecting the first/last year in the calendar view.
                    this._navigationToPrevNext('allyear');
                    // Reasssign the old value
                    this._dateValue = dateValue;
                    var setYear = parseInt(this._dateValue.getFullYear()) - ((parseInt(this._dateValue.getFullYear()) % 10) + 1);
                    this._hoverAllYear = this._setFocusByName('allyear', setYear + 1 + ' - ' + setYear + 10);
                    break;
            }
            this._layoutChanged();
        },
        _navigationToPrevNext: function (name) {
            var allValues = this.sfCalendar.find('tbody tr td.e-current-' + name), index, cell;
            var value = this._dateValue.getFullYear();
            $(allValues).each(function (i, ele) {
                if (parseInt(ele.innerHTML) == parseInt(value)) {
                    index = i;
                    return;
                }
            });
            cell = allValues[index];
            if (cell) {
                if ($(cell).hasClass('e-' + name + '-last'))
                    this._processNextPrevDate(false)
                else if ($(cell).hasClass('e-' + name + '-first'))
                    this._processNextPrevDate(true);
            }
        },
        _navigateFrom: function (prevTable) {
            var tPrevClassName = prevTable.get(0).className, navFrom;
            switch (tPrevClassName) {
                case "e-dp-viewdays": navFrom = "month"; break;
                case "e-dp-viewmonths": navFrom = "year"; break;
                case "e-dp-viewyears": navFrom = "decade"; break;
                case "e-dp-viewallyears": navFrom = "century"; break;
            }
            return navFrom;
        },
        _backwardNavHandler: function (event) {
            this._animating = true;
            if (this.model.readOnly || !this.model.enabled) return false;
            var element;
            if (event.type) {
                event.preventDefault();
                element = $(event.currentTarget);
            }
            else element = event;
            var cTable = $("table", this.sfCalendar), temp;
            var tclassName = $("table", this.sfCalendar).get(0).className, proxy = this, navTo;
            var navFrom = this._navigateFrom(cTable);
            switch (tclassName) {
                case 'e-dp-viewmonths':
                    cTable.removeClass("e-dp-viewmonths").addClass("e-dp-viewdays");
                    this._lastHoveredMonth = parseInt($(element).attr('data-index'));
                    this._dateValue = new Date(this._dateValue.getFullYear(), this._lastHoveredMonth, 1);
                    if (this._DRPdisableFade) this._trigger("_month_Loaded", { currentTarget: event.currentTarget });
                    this._renderCalendar(this, this._dateValue);
                    $('tbody', cTable).not('.e-datepicker-days,.e-week-header').hide();
                    $($(cTable).find('.e-datepicker-days,.e-week-header')).fadeIn("fast", function () {
                        proxy._addFocus('day', proxy._hoverDate || 0);
                        proxy._animating = false;
                    });
                    $('.e-datepicker-headertext', this.sfCalendar).text(this._formatter(this._dateValue, this.model.headerFormat)); navTo = "month";
                    break;
                case 'e-dp-viewyears':
                    cTable.removeClass("e-dp-viewyears").addClass("e-dp-viewmonths");
                    this._lastHoveredYear = parseInt(element.text());
                    this._dateValue.setFullYear(this._lastHoveredYear);
                    this._renderCalendar(this, this._dateValue);
                    $('tbody,tr.e-week-header', cTable).not('.e-datepicker-months').hide();
                    if (ej.isNullOrUndefined(this._hoverMonth) && !ej.isNullOrUndefined(this._dateValue)) this._hoverMonth = this._dateValue.getMonth();
                    $($(cTable).find('.e-datepicker-months')).fadeIn("fast", function () {
                        proxy._addFocus('month', proxy._hoverMonth || 0);
                        proxy._animating = false;
                    });
                    temp = element.text();
                    $('.e-datepicker-headertext', this.sfCalendar).text(temp);
                    this._checkArrows(temp, temp); navTo = "year";
                    break;
                case 'e-dp-viewallyears':
                    var headYears = element.text().split('-');
                    cTable.removeClass("e-dp-viewallyears").addClass("e-dp-viewyears");
                    if (headYears[0] < this.model.minDate.getFullYear()) headYears[0] = this.model.minDate.getFullYear().toString();
                    else if (headYears[0] > this.model.maxDate.getFullYear()) headYears[0] = this.model.maxDate.getFullYear().toString();
                    this._renderCalendar(this, (new Date(headYears[0], 0, 1)));
                    $('tbody,tr.e-week-header', cTable).not('.e-datepicker-years').hide();
                    $($(cTable).find('.e-datepicker-years')).fadeIn("fast", function () {
                        proxy._addFocus('year', proxy._hoverYear || 0);
                        proxy._animating = false;
                    });
                    $('.e-datepicker-headertext', this.sfCalendar).text(headYears[0] + ' - ' + headYears[1]);
                    this._checkArrows(headYears[0], headYears[1]); navTo = "decade";
                    this._dateValue = new Date(this._dateValue.setFullYear(parseInt($.trim(headYears[0])) + ((!this._lastHoveredYear) ? this._dateValue.getFullYear() % 10 : this._lastHoveredYear % 10)));
                    break;
                default:
                    this._clearSelected();
                    this.sfCalendar.find('table td').removeClass("e-state-hover");
                    element.not('td.e-hidedate').addClass('e-active').attr('aria-selected', true);
                    this._addSelected();

                    this._hoverDate = this._getDateObj(element).getDate() - 1;
                    this._dateValue = new Date(element.attr('data-date'));
                    this._clickedDate = new Date(element.attr('data-date'));
                    this._animating = false;
                    break;
            }
            if (navFrom != "month") this._trigger("navigate", { date: this._dateValue, value: this._formatter(this._dateValue, this.model.dateFormat), navigateTo: navTo, navigateFrom: navFrom });
            this._layoutChanged();
        },

        _startLevel: function (start) {
            var cTable = $("table", this.sfCalendar);
            var headerText = $(".e-datepicker-headertext", this.sfCalendar), s, e;
            var dateValue = this._dateValue;
            switch (start) {
                case "decade":
                    cTable.removeClass("e-dp-viewallyears e-dp-viewmonths e-dp-viewdays").addClass("e-dp-viewyears");
                    $('tbody,tr.e-week-header', cTable).not('.e-datepicker-years').hide();
                    $($(cTable).find('.e-datepicker-years')).show();
                    if (this.model.enableStrictMode && this._calendarDate < this._dateValue) dateValue = this._calendarDate;
                    else dateValue = dateValue;
                    var setYear = parseInt(dateValue.getFullYear()) - ((parseInt(dateValue.getFullYear()) % 10) + 1);
                    s = setYear + 1;
                    e = setYear + 10;
                    headerText.text(s + ' - ' + e);
                    this._checkArrows(s, e);
                    this._hoverYear = this._setFocusByName('year', dateValue.getFullYear());
                    break;
                case "century":
                    if (!(this._calendarDate < this._dateValue)) this._renderCalendar(this, dateValue);
                    cTable.removeClass("e-dp-viewyears e-dp-viewdays e-dp-viewmonths").addClass("e-dp-viewallyears");
                    $('tbody,tr.e-week-header', cTable).not('.e-datepicker-allyears').hide();
                    $($(cTable).find('.e-datepicker-allyears')).show();
                    s = parseFloat($('td.e-allyear-first', cTable.get(0)).text().split('-')[1]) + 1;
                    e = parseFloat($('td.e-allyear-last', cTable.get(0)).prev().text().split('-')[1]);
                    var headYears = s + ' - ' + e;
                    headerText.text(headYears);
                    this._checkArrows(s, e);
                    var setYear = parseInt(dateValue.getFullYear()) - ((parseInt(dateValue.getFullYear()) % 10) + 1);
                    this._hoverAllYear = this._setFocusByName('allyear', (setYear + 1) + ' - ' + (setYear + 10));
                    break;
                case "year":
                    cTable.removeClass("e-dp-viewyears e-dp-viewallyears e-dp-viewdays").addClass("e-dp-viewmonths");
                    $('tbody,tr.e-week-header', cTable).hide();
                    $($(cTable).find('.e-datepicker-months')).show();
                    if (this.model.enableStrictMode && this._calendarDate < this._dateValue) s = this._calendarDate.getFullYear();
                    else s = dateValue.getFullYear();
                    headerText.text(s);
                    this._checkArrows(s, s);
                    this._hoverMonth = dateValue.getMonth();
                    this._addFocus('month', this._hoverMonth);
                    break;
                case "month":
                    cTable.removeClass("e-dp-viewyears e-dp-viewallyears e-dp-viewmonths").addClass("e-dp-viewdays ");
                    break;
            }
        },
        _depthLevel: function (depth) {
            var calendarTable = this.sfCalendar;
            switch (depth) {
                case "year":
                    $(calendarTable.find('.e-current-year,.e-current-allyear')).on("click", $.proxy(this._backwardNavHandler, this));
                    this._on($('.e-current-month', this.sfCalendar), "click", $.proxy(this._onDepthSelectHandler, this));
                    break;
                case "decade":
                    $(calendarTable.find('.e-current-allyear')).on("click", $.proxy(this._backwardNavHandler, this));
                    $('.e-current-year', this.sfCalendar).on("click", $.proxy(this._onDepthSelectHandler, this));
                    break;
                case "century":
                    $(calendarTable.find('.e-current-allyear')).on("click", $.proxy(this._onDepthSelectHandler, this));
                    break;
                case "month":
                    this._on(calendarTable.find('.current-month,.other-month,.e-current-month,.e-current-year,.e-current-allyear'), "click", $.proxy(this._backwardNavHandler, this));
                    this._on(calendarTable.find('.current-month , .other-month'), "click", $.proxy(this._onSetCancelDateHandler, this));
            }
        },
        _onDepthSelectHandler: function (e) {
            if (this.model.readOnly || !this.model.enabled) return false;
            if ($(e.target).hasClass("e-current-month"))
                this._dateValue = new Date(this._dateValue.setMonth(parseInt(e.target.attributes["data-index"].value)));
            else if ($(e.target).hasClass("e-current-year"))
                this._dateValue = new Date(this._dateValue.setFullYear(parseInt(e.target.innerHTML)));
            else if ($(e.target).hasClass("e-current-allyear"))
                this._dateValue = new Date(this._dateValue.setFullYear(parseInt(e.target.innerHTML)));
            this._onSetCancelDateHandler(e);
        },

        _datepickerMonths: function (tbody, calendarTable, currentDate) {
            var dc = function (a) {
                return document.createElement(a);
            };
            var month = 0;
            for (var i = 0; i < 3; i++) {
                var row = $(dc('tr'));
                for (var j = 0; j < 4; j++) {
                    var td = $(dc('td'))
                        .addClass('e-current-month e-state-default')
                        .attr({ 'data-index': month }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})
                        .html(this.Date.abbrMonthNames[month++]);
                    if (currentDate.getFullYear() < this.model.minDate.getFullYear() || currentDate.getFullYear() > this.model.maxDate.getFullYear()) {
                        td.addClass('e-hidedate');
                        td.removeClass('e-current-month');
                    }
                    else if ((currentDate.getFullYear() <= this.model.minDate.getFullYear() && month < this.model.minDate.getMonth() + 1) ||
                        (currentDate.getFullYear() >= this.model.maxDate.getFullYear() && month > this.model.maxDate.getMonth() + 1)) {
                        td.addClass('e-hidedate');
                        td.removeClass('e-current-month');
                    }
                    row.append(td);
                }
                tbody.append(row);
            }
            calendarTable.append(tbody);
            var s = currentDate.getFullYear();
            this._checkArrows(s, s);
        },

        _datepickerYears: function (tbody, calendarTable, currentYear) {
            var dc = function (a) {
                return document.createElement(a);
            };
            var Year = parseInt(currentYear) - ((parseInt(currentYear) % 10) + 1);
            var years = [];
            for (var j = 0; j < 12; j++) {
                years.push(Year + j);
            }
            var year = 0;
            for (var i = 0; i < 3; i++) {
                var row = $(dc('tr'));
                for (var j = 0; j < 4; j++) {
                    var td = $(dc('td'));
                    td.attr((this._isIE8) ? { 'unselectable': 'on' } : {});
                    if (year == 0)
                        td.addClass('e-year-first e-current-year ');
                    else if (year == 11)
                        td.addClass('e-year-last e-current-year ');
                    else
                        td.addClass('e-current-year e-state-default');
                    if (years[year] < this.model.minDate.getFullYear() || years[year] > this.model.maxDate.getFullYear()) {
                        td.addClass('e-hidedate');
                        td.removeClass('e-current-year');
                    }
                    td.html(years[year++]);
                    row.append(td);
                }
                tbody.append(row);
            }
            calendarTable.append(tbody);
            this._checkArrows(years[0], years[years.length]);
        },

        _datepickerAllYears: function (tbody, calendarTable, currentYear) {
            var Year = parseInt(currentYear) - ((parseInt(currentYear) % 100) + 10);
            var headYear = Year;
            var years = [], newline = this._isIE8 || this._isIE9 ? "" : "\n";

            for (var j = 0; j < 12; j++) {
                years.push(parseInt(Year) + " -" + newline + parseInt(Year + 9));
                Year = Year + 10;
            }
            var year = 0;
            for (var i = 0; i < 3; i++) {
                var row = $(document.createElement('tr'));
                for (var j = 0; j < 4; j++) {
                    var td = $(document.createElement('td'));
                    td.attr((this._isIE8) ? { 'unselectable': 'on' } : {});
                    if (year == 0)
                        td.addClass('e-allyear-first e-current-allyear ');
                    else if (year == 11)
                        td.addClass('e-allyear-last e-current-allyear ');
                    else
                        td.addClass('e-current-allyear e-state-default');
                    if (parseInt(years[year].split('-\n')[1]) < this.model.minDate.getFullYear() || parseInt(years[year].split('-\n')[0]) > this.model.maxDate.getFullYear()) {
                        td.addClass('e-hidedate');
                        td.removeClass('e-current-allyear');
                    }
                    td.html(years[year++]);
                    row.append(td);
                }
                tbody.append(row);
            }
            calendarTable.append(tbody);
        },
        _renderHeader: function (dpObject) {
            var thead = $(document.createElement('thead'));
            var cultureObj = ej.preferredCulture(this.model.locale).calendars.standard.days;
            if (dpObject.model.dayHeaderFormat != "none") {
                var headRow = ej.buildTag("tr.e-week-header").attr({ 'role': 'row' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {});
                if (this.model.weekNumber == true) {
                    var WeekCulture = ej.preferredCulture(this.model.locale).calendars.standard.week;
                    var day = WeekCulture.name;
                    var headerday;
                    if (dpObject.model.dayHeaderFormat == "short")
                        headerday = WeekCulture.nameAbbr;
                    else if (dpObject.model.dayHeaderFormat == "long") headerday = week;
                    else headerday = WeekCulture.nameShort;
                    var tr = ej.buildTag("th", "", {}, { 'scope': 'col', 'abbr': day, 'data-date': day, 'title': this._formatter(day, "dddd") }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})
                        .html(headerday);
                    headRow.append(tr);
                }
                for (var i = this.Date.firstDayOfWeek; i < this.Date.firstDayOfWeek + 7; i++) {
                    var weekday = i % 7;
                    var day = cultureObj.names[weekday];
                    var headerday;
                    if (dpObject.model.dayHeaderFormat == "short")
                        headerday = cultureObj.namesAbbr[weekday];
                    else if (dpObject.model.dayHeaderFormat == "long") headerday = day;
                    else headerday = cultureObj.namesShort[weekday];
                    var th = ej.buildTag("th", "", {}, { 'scope': 'col', 'abbr': day, 'data-date': day, 'title': this._formatter(day, "dddd"), 'class': (weekday == 0 || weekday == 6 ? 'e-week-end' : 'e-week-day') }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})
                            .html(headerday);
                    headRow.append(th);
                }
            };
            return thead.append(headRow);
        },

        _renderCalendar: function (dpObject, date) {
            var proxy = this, today;
            dpObject = $.extend({}, ej.DatePicker.prototype.defaults, dpObject);
            this.Date.firstDayOfWeek = this.model.startDay;
            if (date) today = date;
            else if (this._calendarDate) today = this._calendarDate;
            else today = proxy._zeroTime(new Date());
            var calendarTable = $('table', this.sfCalendar);
            calendarTable.empty();

            calendarTable.append(this._renderHeader(dpObject));

            var tbody = ej.buildTag('tbody.e-datepicker-allyears', "", { 'display': 'none' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {});
            this._datepickerAllYears(tbody, calendarTable, today.getFullYear());

            tbody = ej.buildTag("tbody.e-datepicker-years", "", { 'display': 'none' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {});
            this._datepickerYears(tbody, calendarTable, today.getFullYear());
            var month = dpObject.model.month == undefined ? today.getMonth() : dpObject.model.month;
            var year = dpObject.model.year || today.getFullYear();
            var currentDate = (new Date(year, month, 1, 0, 0, 0));
            var firstDayOffset = this.Date.firstDayOfWeek - currentDate.getDay() + 1;
            if (firstDayOffset > 1) firstDayOffset -= 7;
            var weeksToDraw = Math.ceil(((-1 * firstDayOffset + 1) + this._getDaysInMonth(currentDate)) / 7);
            this._addDays(currentDate, (firstDayOffset - 1));
            var newdate = proxy._zeroTime(new Date());
            var selected = this._calendarDate;
            tbody = ej.buildTag('tbody.e-datepicker-months', "", { 'display': 'none' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {});

            this._datepickerMonths(tbody, calendarTable, today);

            tbody = ej.buildTag('tbody.e-datepicker-days', "", { 'display': 'none' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {});
            var w = 0, _first = true, _last = true;
            while (w++ < weeksToDraw) {
                var r = jQuery(document.createElement('tr')).attr({'role':'row'});
                if (this.model.weekNumber == true)
                {
                    var week = this._weekDate(currentDate);
                    week = $(document.createElement('td')).attr({}).addClass('e-weeknumber').html(week)
                    r.append(week);
                }
                for (var i = 0; i < 7; i++) {
                    var thisMonth = currentDate.getMonth() == month;
                    var checkSpecialDate = this._isSpecialDates(currentDate);
                    var disable = this._checkDisableRange(currentDate);
                    var index = this._getIndex;
                    var d = $(document.createElement('td')).
                        html(checkSpecialDate ? '<span></span>' + currentDate.getDate() : currentDate.getDate() + '')
                        .attr({

                            'data-date': currentDate.toDateString(),
                            'title': (this.model.showTooltip ? (checkSpecialDate && this.model.specialDates[index][this._mapField._tooltip] ? this.model.specialDates[index][this._mapField._tooltip] : this._formatter(currentDate, this.model.tooltipFormat)) : ''),
                            'aria-selected': false,
                            'role': 'gridcell',
                            'id': this._formatter(currentDate, "yyyyddMM")
                        }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})
                        .addClass((thisMonth ? 'current-month e-state-default ' : 'other-month e-state-default ') +
                            (this._isWeekend(currentDate) ? (this._ejHLWeekEnd ? 'e-dp-weekend e-week-end ' : (this.model.highlightWeekend ? 'e-week-end ' : '')) : 'e-week-day ') +
                            (thisMonth && currentDate.getTime() == newdate.getTime() ? 'today ' : ''));

                    d.find('span:first-of-type').addClass((checkSpecialDate ? (this.model.specialDates[index][this._mapField._icon] ? 'e-special-date-icon ' + this.model.specialDates[index][this._mapField._icon] + ' ' : 'e-special-day') : ''));
                    d.addClass(checkSpecialDate ? (this.model.specialDates[index][this._mapField._custom] ? this.model.specialDates[index][this._mapField._custom] : '') : '');
                    if (disable) this._disableDates({ date: currentDate, element: d });
                    if (selected.getTime() == currentDate.getTime() && thisMonth) {
                        if (!d.hasClass('e-hidedate'))
                            if (this.model.value) {
                                d.addClass('e-active').attr({ 'aria-selected': true });
                                if (this.model.highlightSection == "week") {
                                    r.addClass('e-selected-week');
                                }
                                if (this.model.highlightSection == "month") {
                                    tbody.addClass('e-selected-month');
                                }
                                if (this.model.highlightSection == "workdays") {
                                    r.addClass('e-work-week');
                                }
                            }
                            else { if(this.model.value!=null)d.addClass('e-state-hover').attr({ 'aria-selected': false }); }
                        if (!this._hoverDate) {
                            if (!d.hasClass('e-hidedate')) d.addClass('e-state-hover');
                            this._hoverDate = currentDate.getDate() - 1;
                        }
                    }
                    var cond = true;
                    if (currentDate < this.model.minDate || currentDate > this.model.maxDate) {
                        d.addClass('e-hidedate');
                        d.removeClass('current-month');
                        if (this.model.showOtherMonths) d.removeClass('other-month');
                        cond = _last = false;
                    }
                    if (thisMonth) {
                        if (cond && _first) {
                            this._tempMinDate = currentDate;
                            _first = false; _last = true;
                        }
                        if (_last) this._tempMaxDate = currentDate;
                    }
                    this._trigger("beforeDateCreate", { date: currentDate, value: this._formatter(currentDate, this.model.dateFormat), element: d });
                    r.append(d);
                    currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 1, 0, 0, 0);
                }
                tbody.append(r);
            }
            calendarTable.append(tbody);
            if (this._DRPdisableFade) {
                $(tbody).css("display", "block");
                $(tbody).css({ display: "table-row-group", "vertical-align": "middle", "border-color": "inherit" });
            }
            else {
                (this._isIE8 || this._isIE7) ? $(tbody).css("display", "table-row-group") : $(tbody).fadeIn("fast");
            }
            if (this.model.startLevel === this.model.depthLevel)
                this._depthLevel(this.model.depthLevel);
            else if (this.model.depthLevel != "month" && this.model.depthLevel != "") {
                if (this.model.startLevel == "century")
                    this._depthLevel(this.model.depthLevel);
                else if (this.model.startLevel == "decade" && this.model.depthLevel != "century")
                    this._depthLevel(this.model.depthLevel);
                else if (this.model.startLevel == "year" && this.model.depthLevel != "decade" && this.model.depthLevel != "century")
                    this._depthLevel(this.model.depthLevel);
                else {
                    this._on(calendarTable.find('.current-month,.other-month,.e-current-month,.e-current-year,.e-current-allyear'), "click", $.proxy(this._backwardNavHandler, this));
                    this._on(calendarTable.find('.current-month , .other-month'), "click", $.proxy(this._onSetCancelDateHandler, this));
                }
            }
            else {
                this._on(calendarTable.find('.current-month,.other-month,.e-current-month,.e-current-year,.e-current-allyear'), "click", $.proxy(this._backwardNavHandler, this));
                this._on(calendarTable.find('.current-month , .other-month'), "click", $.proxy(this._onSetCancelDateHandler, this));
            }

            this._otherMonthsVisibility();
            this._checkDateArrows();
        },

        _checkDisableRange: function (value) {
            if (!ej.isNullOrUndefined(this._disableCollection[value.getFullYear()]))
                if (jQuery.inArray(value.getMonth(), this._disableCollection[value.getFullYear()]) !== -1)
                    return true;
            return false;
        },
        _initDisableObj: function (disableDates) {
            this._disableCollection = {};
            for (var i = 0; i < this.model.blackoutDates.length; i++) {
                var dateObj = this._checkInstanceType(this.model.blackoutDates[i]);
                if (dateObj) {
                    var year = dateObj.getFullYear();
                    var month = dateObj.getMonth();
                    if (ej.isNullOrUndefined(this._disableCollection[year])) this._disableCollection[year] = [];
                    if (jQuery.inArray(month, this._disableCollection[year]) == -1) this._disableCollection[year].push(month);
                }
            }
        },

        _disableDates: function (args) {
            for (var i = 0; i < this.model.blackoutDates.length; i++) {
                var dateObj = this._checkInstanceType(this.model.blackoutDates[i]);
                if (dateObj && +args.date === +dateObj)
                args.element.addClass('e-hidedate');
            }
        },

        _keyboardNavigation: function (e) {
            this._keyboardInteraction = true;
            if (this._animating) return false;
            if ((this._isOpen) && (e.keyCode == 37 || e.keyCode == 38 || e.keyCode == 39 || e.keyCode == 40 || e.keyCode == 13 || e.keyCode == 36 || e.keyCode == 35)) {
                e.preventDefault && e.preventDefault();
                if (e.altKey) { if (e.keyCode == 13) { this._setCurrDate(e); return false; } else return; }
                var t = { row: null, col: null };

                t.col = this.sfCalendar.find('tbody tr td.e-state-hover').index();
                t.row = this.sfCalendar.find('tbody tr td.e-state-hover').parent().index();

                t.col = (t.col != -1) ? t.col + 1 : this.sfCalendar.find('tbody tr td.e-active').index() + 1;
                t.row = (t.row != -1) ? t.row + 1 : this.sfCalendar.find('tbody tr td.e-active').parent().index() + 1;

                var tableClass = this.sfCalendar.find('table')[0].className, next, rowLength = 3, colLength = 4;
                switch (tableClass) {
                    case "e-dp-viewallyears":
                        next = this._changeRowCol(t, e.keyCode, rowLength, colLength, "yearall", e.ctrlKey);
                        if (!e.ctrlKey) this._hoverAllYear = this.sfCalendar.find('tbody.e-datepicker-allyears tr td').index(next);
                        break;
                    case "e-dp-viewyears":
                        next = this._changeRowCol(t, e.keyCode, rowLength, colLength, "year", e.ctrlKey);
                        if (!e.ctrlKey) this._hoverYear = this.sfCalendar.find('tbody.e-datepicker-years tr td').index(next);
                        break;
                    case "e-dp-viewmonths":
                        next = this._changeRowCol(t, e.keyCode, rowLength, colLength, "month", e.ctrlKey);
                        if (!e.ctrlKey) this._hoverMonth = this.sfCalendar.find('tbody.e-datepicker-months tr td').index(next);
                        break;
                    case "e-dp-viewdays":
                        rowLength = this.sfCalendar.find('tbody.e-datepicker-days tr').length, colLength = 7;
                        next = this._changeRowCol(t, e.keyCode, rowLength, colLength, "day", e.ctrlKey);
                        if (!e.ctrlKey) this._hoverDate = this._getDateObj(next).getDate() - 1;
                        break;
                }
                if (!e.ctrlKey) {
                    this.sfCalendar.find('table td').removeClass("e-state-hover");
                    next.addClass("e-state-hover");
                    this._setAriaAttributes(next);
                }
            }
            else if (!this.model.displayInline && (e.keyCode == 27 || e.keyCode == 9)) { this.hide(); }
            else if (e.altKey && e.keyCode == 40) { this.show(); return false; }
        },
        _setAriaAttributes: function (next) {
            if (this._popupOpen) {
                this.sfCalendar.find("[aria-selected=true]").attr("aria-selected", false)
                this.sfCalendar.find("[aria-label]").removeAttr("aria-label");
                $(this.element).attr("aria-activedescendant", next.attr('id'));
                $(next).attr("aria-selected", true);
                $(next).attr("aria-label", "The current focused date is " + this._formatter(this._getDateObj(next), "dddd, dd MMMM, yyyy"));
            }
        },
        _changeRowCol: function (t, key, rows, cols, target, ctrlKey) {
            var eleClass, cls = { parent: null, child: null };
            switch (target) {
                case "day": eleClass = "tbody.e-datepicker-days tr td.current-month";
                    cls.parent = ".e-datepicker-days", cls.child = ".current-month";
                    break;
                case "month": eleClass = "tbody.e-datepicker-months tr td.e-current-month";
                    cls.parent = ".e-datepicker-months", cls.child = ".e-current-month";
                    break;
                case "year": eleClass = "tbody.e-datepicker-years tr td.e-current-year";
                    cls.parent = ".e-datepicker-years", cls.child = ".e-current-year";
                    break;
                case "yearall": eleClass = "tbody.e-datepicker-allyears tr td.e-current-allyear";
                    cls.parent = ".e-datepicker-allyears", cls.child = ".e-current-allyear";
                    break;
            }
            if (t.row <= 0 && t.col <= 0) {
                this._removeCurrentMonthFromHideDate();
                return this.sfCalendar.find(eleClass + ':first');
            }
            var cell, proxy = this;
            switch (key) {
                case 36:
                    return this.sfCalendar.find(eleClass + ':first');
                case 35:
                    return this.sfCalendar.find(eleClass + ':last');
                case 38:
                    if (ctrlKey && this.model.allowDrillDown) {
                        this._forwardNavHandler();
                    }
                    else if (t.row > 1) {
                        t.row -= 1;
                    }
                    else {
                        this._processNextPrevDate(true);
                        cell = this.sfCalendar.find(eleClass + ':nth-child(' + t.col + '):last');
                        return cell;
                    }
                    cell = this._getCell(t, cls);
                    if (cell.length <= 1) {
                        cell = this._findVisible(t, cls, "up");
                        if (cell !== null) return cell;
                        this._processNextPrevDate(true);
                        cell = this.sfCalendar.find(eleClass + ':nth-child(' + t.col + '):last');
                    }
                    return cell;
                case 37:
                    if (ctrlKey) {
                        this._processNextPrevDate(true);
                        return this.sfCalendar.find('tbody tr td.e-state-hover');
                    }
                    else if (t.col > 1)
                        t.col -= 1;
                    else if (t.row > 1) {
                        t = { row: t.row - 1, col: cols }
                    }
                    else {
                        this._processNextPrevDate(true);
                        cell = this.sfCalendar.find(eleClass + ':last');
                        return cell;
                    }
                    cell = this._getCell(t, cls);
                    if (cell.length <= 1) {
                        cell = this._findVisible(t, cls, "left");
                        if (cell !== null) return cell;
                        this._processNextPrevDate(true);
                        cell = this.sfCalendar.find(eleClass + ':last');
                    }
                    return cell;
                case 39:
                    if (ctrlKey) {
                        this._processNextPrevDate(false);
                        return this.sfCalendar.find('tbody tr td.e-state-hover');
                    }
                    else if (t.col < cols)
                        t.col += 1;
                    else if (t.row < rows) {
                        t = { row: t.row + 1, col: 1 }
                    }
                    else {
                        this._processNextPrevDate(false);
                        cell = this.sfCalendar.find(eleClass + ':first');
                        return cell;
                    }
                    cell = this._getCell(t, cls);
                    if (cell.length <= 1) {
                        cell = this._findVisible(t, cls, "right");
                        if (cell !== null) return cell;
                        this._processNextPrevDate(false);
                        cell = this.sfCalendar.find(eleClass + ':first');
                    }
                    return cell;
                case 40:
                    if (!ctrlKey) {
                        if (t.row < rows) {
                            t.row += 1;
                        }
                        else {
                            this._processNextPrevDate(false);
                            cell = this.sfCalendar.find(eleClass + ':nth-child(' + t.col + '):first');
                            return cell;
                        }
                        cell = this._getCell(t, cls);
                        if (cell.length <= 1) {
                            cell = this._findVisible(t, cls, "down");
                            if (cell !== null) return cell;
                            this._processNextPrevDate(false);
                            cell = this.sfCalendar.find(eleClass + ':nth-child(' + t.col + '):first');
                        }
                        return cell;
                    }
                case 13:
                    var tclassName = $("table", this.sfCalendar).get(0).className, ele, element;
                    ele = this._getCell(t, cls); element = $(ele)[0];
                    if (tclassName == "e-dp-viewmonths" && this.model.startLevel == "year" && this.model.depthLevel == "year") {
                        this._dateValue = new Date(this._dateValue.setMonth(parseInt(element.attributes["data-index"].value)));
                        this._onSetCancelDateHandler({ type: null, target: ele });
                    }
                    else if ((tclassName == "e-dp-viewyears" && this.model.startLevel == "decade" && this.model.depthLevel == "decade") ||
                        (tclassName == "e-dp-viewallyears" && this.model.startLevel == "century" && this.model.depthLevel == "century")) {
                        this._dateValue = new Date(this._dateValue.setFullYear(parseInt(element.innerHTML)));
                        this._onSetCancelDateHandler({ type: null, target: ele });
                    }
                    else if (tclassName == "e-dp-viewdays") {
                        this._backwardNavHandler(ele);
                        this._onSetCancelDateHandler({ type: null, target: ele });
                    }
                    else
                        this._backwardNavHandler(ele);
                    break;
            }
            return this._getCell(t, cls);
        },
        _findVisible: function (t, cls, key) {
            var cols = t.col, rows = t.row, requiredClass = cls.child.slice(1, cls.child.length);
            for (var i = 0; i >= 0; i++) {
              var nextElement = this.sfCalendar.find('tbody' + cls.parent + ' tr:nth-child(' + rows + ') td:nth-child(' + cols + ')');
                if (nextElement.length <= 0) {
                    return null;
                }
                if (nextElement.hasClass('e-hidedate') || !nextElement.is(":visible")) {
                    key == "right" || key == "left" ? (key == "right" ? cols++ : cols--) : (key == "down" ? rows++ : rows--);
                    if ((rows <= 0) || (rows > this.sfCalendar.find('tbody' + cls.parent + ' tr').length)) {
                        // No more rows there in popup.
                        return null;
                    }
                    // Column exceeds the range. 
                    if (cols > this.sfCalendar.find('tbody' + cls.parent + ' tr:nth-child(' + rows + ') td').length) {
                        //move to next row and select first column
                        rows++;
                        cols = 1;
                    }
                    if (cols <= 0) {
                        //move to previous row and select last column
                        rows--;
                        cols = this.sfCalendar.find('tbody' + cls.parent + ' tr:nth-child(' + rows + ') td').length;
                    }
                    // Row exceeds the range.
                    if ((rows <= 0) || (rows > this.sfCalendar.find('tbody' + cls.parent + ' tr').length)) {
                        // No more rows there in popup.
                        return null;
                    }
                } else if (nextElement.hasClass('other-month')) {
                    return null;
                } else if (nextElement.hasClass(requiredClass)) {
                    t.col = cols; t.row = rows;
                    return nextElement;
                }
            }
        },
        _getCell: function (t, cls) {
            return this.sfCalendar.find('tbody' + cls.parent + ' tr:nth-child(' + t.row + ') td' + cls.child + ':nth-child(' + t.col + ')');
        },
        _getDateObj: function (element) {
            return new Date(element.attr("data-date"));
        },
        _touchCalendar: function (e) {
            var tableClass = this.sfCalendar.find('table')[0].className;
            switch (e.type) {
                case "pinchin":
                    if (tableClass != "e-dp-viewdays")
                        this._keyboardNavigation({ keyCode: 13 });
                    break;
                case "pinchout":
                    if (tableClass != "e-dp-viewallyears" && this.model.allowDrillDown)
                        this._forwardNavHandler();
                    break;
                case "swipeleft":
                    this._processNextPrevDate(false);
                    break;
                case "swiperight":
                    this._processNextPrevDate(true);
                    break;
            }
        },

        show: function (e) {
            if (ej.isNullOrUndefined(this.sfCalendar)) this._renderPopup();
            if (this._isOpen) return false;
            var proxy = this;
            this._popupOpen = true;
            $(this.element).attr("aria-expanded", true);
            var previous = this._preValue != null ? new Date(this._preValue.toString()) : this._preValue;
            if (!this.model.enabled) return;
            if (!this.model.displayInline) this._setDatePickerPosition();
            if (this._trigger("beforeOpen", { element: this.sfCalendar, events: e })) return false;
            this.sfCalendar.attr({ 'aria-hidden': 'false' });
            proxy._isOpen = true;
            this.sfCalendar.slideDown(this.model.enableAnimation ? this.animation.open.duration : 0, function () {
                if (proxy.model && !proxy.model.displayInline)
                    $(document).on("mousedown", $.proxy(proxy._onDocumentClick, proxy));
            });
            if (this._isIE8) {
                if (this.element.val() && this._compareDate(new Date(this.element.val()), previous)) this._updateInputVal();
            }
            else this._updateInputVal();
            this._refreshLevel(previous);
            this._trigger("open", { prevDate: previous, date: this.model.value, value: this._formatter(this.model.value, this.model.dateFormat) });
            $(window).on("resize", $.proxy(this._OnWindowResize, this));
            if (!this.model.displayInline) {
              this._on(ej.getScrollableParents(this.wrapper), "scroll", this.hide);
              this._on(ej.getScrollableParents(this.wrapper), "touchmove", this.hide);
			}
            this._isInputBox && this.wrapper.addClass("e-active");
            if (this.model.value != null) {
                $(this.element).attr("aria-activedescendant", $(this.sfCalendar.find(".e-active")).attr("id"));
            } else {
                $(this.element).attr("aria-activedescendant", $(this.sfCalendar.find(".today")).attr("id"));
            }
        },


        hide: function (e) {
            if (!this._isOpen || this._getInternalEvents) return false;
            if (this._trigger("beforeClose", { element: this.sfCalendar, events: e })) return false;
            var proxy = this;
            this._popupOpen = false;
            $(this.element).attr("aria-expanded", false);
            this.sfCalendar.attr({ 'aria-hidden': 'true' });
            if (this._popClose && e != undefined && e.type != "click") {
                return;
            }
            this.sfCalendar.slideUp(this.model.enableAnimation ? this.animation.close.duration : 0, function () {
                proxy._isOpen = false;
                $(document).off("mousedown", $.proxy(proxy._onDocumentClick, proxy));
                proxy._setWaterMark();
            });
            if (this.element.val() != "") this._validateInputVal();
            this._trigger("close", { prevDate: this._prevDate, date: this.model.value, value: this._formatter(this.model.value, this.model.dateFormat) });
            $(window).off("resize", $.proxy(this._OnWindowResize, this));
            this._off(ej.getScrollableParents(this.wrapper), "scroll", this.hide);
            this._off(ej.getScrollableParents(this.wrapper), "touchmove", this.hide);
            this._isInputBox && this.wrapper.removeClass("e-active");
            if (this.model.value) {
                $(this.element).attr("aria-activedescendant", $(this.sfCalendar.find(".e-active")).attr("id"));
            } else {
                $(this.element).removeAttr("aria-activedescendant");
            }
            
        },


        enable: function () {
            this.model.enabled = true;
            this.wrapper && this.wrapper.removeClass('e-disable');
            this.element.removeClass('e-disable').attr({ "aria-disabled": false });
            this.element.prop("disabled", false);
            if (this.dateIcon) this.dateIcon.removeClass('e-disable').attr({ "aria-disabled": false });
            if (this._isIE8 && this.dateIcon) this.dateIcon.children().removeClass("e-disable");
            this.element.prop("disabled", false);
            if (!this._isSupport)
                this._hiddenInput.prop("disabled", false);
            this.sfCalendar && this.sfCalendar.removeClass('e-disable').attr({ "aria-disabled": false });
        },


        disable: function () {
            this.model.enabled = false;
            this.wrapper && this.wrapper.addClass('e-disable');
            this.element.addClass('e-disable').attr({ "aria-disabled": true });
            this.element.attr("disabled", "disabled");
            if (this.dateIcon) this.dateIcon.addClass('e-disable').attr({ "aria-disabled": true });
            if (this._isIE8 && this.dateIcon) this.dateIcon.children().addClass("e-disable");
            this.element.attr("disabled", "disabled");
            if (!this._isSupport)
                this._hiddenInput.attr("disabled", "disabled");
            this.sfCalendar && this.sfCalendar.addClass('e-disable').attr({ "aria-disabled": true });
            if (this._isOpen) {
                if (this.element.is(':input')) this.element.blur();
                if (!this.model.displayInline) this.hide();
            }
        },

        getValue: function () { return this._formatter(this.model.value, this.model.dateFormat); },

        _wireCalendarEvents: function () {
            this._allowQuickPick(this.model.allowDrillDown);
            this._on($('.e-next', this.sfCalendar), "click", $.proxy(this._previousNextHandler, this));
            this._on($('.e-prev', this.sfCalendar), "click", $.proxy(this._previousNextHandler, this));
            if (!this.model.displayInline) {
                this.sfCalendar.on("mouseenter touchstart", $.proxy(function () { this._popClose = true; }, this));
                this.sfCalendar.on("mouseleave touchend", $.proxy(function () { this._popClose = false; }, this));
            }
            if (this.model.showFooter)
                this._on($('.e-footer', this.sfCalendar), "click", this._setCurrDate);
            this.sfCalendar && this._on(this.sfCalendar, "pinchin pinchout swipeleft swiperight", $.proxy(this._touchCalendar, this));
        },

        _wireEvents: function () {
            if (this.element.is(":input") && (this.model.allowEdit)) {
                this._on(this.element, "blur", this._onFocusOut);
                this._on(this.element, "focus", this._onFocusIn);
                this._on(this.element, "keydown", this._onKeyDown);
            }

            if (!this.model.allowEdit) {
                this.element.attr("readonly", "readonly");
                this.element.on("mousedown", $.proxy(this._showDatePopUp, this));
            }
        },
        _bindDateButton: function () {
            this._on(this.dateIcon, "mousedown", this._showDatePopUp);
            if (this.model.allowEdit)
                this.element.off("mousedown", $.proxy(this._showDatePopUp, this));
        },
        _bindInputEvent: function () {
            this._off(this.dateIcon, "mousedown", this._showDatePopUp);
        },

        _specificFormat: function () {
            var parseInfo = ej.globalize._getDateParseRegExp(ej.globalize.findCulture(this.model.locale).calendar, this.model.dateFormat);
            return ($.inArray("dddd", parseInfo.groups) > -1 || $.inArray("ddd", parseInfo.groups) > -1)
        },

        _onFocusOut: function (e) {
            this._isFocused = false;
            var previous = this._preValue != null ? new Date(this._preValue.toString()) : this._preValue;
			if(this.model.enableStrictMode && this.element.val() && !isNaN(+new Date(this.element.val()))){
				this._formatArray = this.model.dateFormat.split(this._getSeparator());
				this._valArray = this.element.val().split(this._getSeparator());
				for(var i = 0; i < this._formatArray.length ; i++){
					if(this._formatArray[i].startsWith("y") && this._valArray.length > 1){
						if((this._formatArray[i].length == 4 && this._valArray[i].length == 2) || (this._formatArray[i].length == 2 && this._valArray[i].length == 2)){
							this._valArray[i] = (parseInt(this._valArray[i]) + 2000).toString();
							this.element.val(this._valArray.join(this._getSeparator()));
						}
					}
				}
				
			}
            this._validateOnFocusOut(this._validateValue(), e);
            this.wrapper.removeClass("e-focus");
            (ej.isNullOrUndefined(this.model.value)) ? this.wrapper.removeClass('e-valid') : this.wrapper.addClass('e-valid');
            if ((!this._isOpen || this.model.displayInline) && !this._setWaterMark() && !this._compareDate(this._preValue, this._parseDate(this.element.val(), this.model.dateFormat))) this._updateInputVal();
            if ((!this._isOpen || this.model.displayInline)) this._refreshLevel(previous);
            if (this.element.val() != "" && (!this._isOpen || this.model.displayInline)) { this._validateInputVal(); }
            this.element.off("keydown", $.proxy(this._keyboardNavigation, this));
            if (!this.model.showPopupButton) this._off(this.element, "click", this._elementClick);
            var _currentVal = this.element.val();
            var data = { prevDate: this._prevDate, value: _currentVal };
            if (this._specificFormat()) {
                if (this._prevDate != _currentVal)
                    this._setDateValue(_currentVal, true);
            }
            else
                this._setDateValue(_currentVal);
            if (!this.model.value) this._clearSelected();
            this._trigger("focusOut", data);
            this._checkErrorClass();
        },
        _onFocusIn: function (e) {
            if (this._isSupport) {
                e.preventDefault();
                this._isFocused = true;
            }
            this.wrapper.removeClass('e-error');
            this.isValidState = true;
            this.wrapper.addClass("e-focus");
            this.wrapper.addClass('e-valid');
            if (this.model.readOnly)
                return;
            if (!this._isSupport) this._hiddenInput.css("display", "none");
            this.element.on("keydown", $.proxy(this._keyboardNavigation, this));
            if (!this.model.showPopupButton && !this.model.readOnly) this.show(e);
            if (!this.model.showPopupButton) this._on(this.element, "click", this._elementClick);
            this._trigger("focusIn", { date: this.model.value, value: this._formatter(this.model.value, this.model.dateFormat) });
        },
        _elementClick: function (e) {
            if (!this._popupOpen) this.show(e);
        },
        _removeWatermark: function () {
            if (this.element.val() != "" && !this._isSupport)
                this._hiddenInput.css("display", "none");
        },
        _refreshPopup: function () {
            this._refreshDatepicker();
            this._startLevel(this.model.startLevel);
        },
        _weekDate: function (currentDate) {
            var time, checkDate = new Date(currentDate.getTime());
            checkDate.setDate(checkDate.getDate() + 4 - (checkDate.getDay() || 7));
            time = checkDate.getTime();
            checkDate.setMonth(0);
            checkDate.setDate(1);
            return Math.floor(Math.round((time - checkDate) / 86400000) / 7) + 1;

        },
        _refreshLevel: function (previous) {
            if ((this.model.startLevel == this.model.depthLevel) && this.model.startLevel != "month") {
                var val = this._stringToObject(this.element.val());
                val = this._validateYearValue(val);
                if (val)
                    if (!this._compareDate(previous, val))
                        this._refreshPopup();
            }
        },
        _validateOnFocusOut: function (val, e) {
            var dateVal = this._preValue != null ? this._calendarDate : this._preValue;
            var calenderDate = this._formatter(dateVal, this.model.dateFormat);
			this._prevDate = this._formatter(this._preValue, this.model.dateFormat);
			var _currentVal = calenderDate;
            var data = { prevDate: this._prevDate, value: _currentVal, isInteraction: !!e };
            if (this._specificFormat() && (val > this.model.minDate) && (val < this.model.maxDate)) {
                if (val == null) this.model.value = dateVal
                else {
                    this.model.value = val;
                    var currDate = this._formatter(val, this.model.dateFormat, this.model.locale);
                }
            }
            else var currDate = this._formatter(this._parseDate((this._formatter(new Date(), "MM/dd/yyyy"))), this.model.dateFormat);
            var dateChange = false, valueExceed = false;
            if (val != null && !this.model.enableStrictMode) {
                if (ej.isNullOrUndefined(this.model.value))
                    this.model.value = this._parseDate(this.element.val());
                if (this.model.maxDate < this.model.minDate) this.model.minDate = this.model.maxDate;
                if (!this.model.enableStrictMode) {
                    if (val) {
                        if ((val < this.model.minDate) || (val > this.model.maxDate)) {
                            dateChange = true,
                            this._calendarDate = val = val < this.model.minDate ? this.model.minDate : this.model.maxDate
                        }
                    }
                    else {
                        this.element.val("");
                        if (this._calendarDate < this.model.minDate) this._calendarDate = this.model.minDate;
                        else if (this._calendarDate > this.model.maxDate) this._calendarDate = this.model.maxDate;
                    }
                    this.isValidState = true;
                }
                if (dateChange) this.element.val(this._formatter(val, this.model.dateFormat));
                if (!this._compareDate(this._preValue, this._parseDate(this.element.val(), true))) this._triggerChangeEvent(e);
            }
            else if (val == null && !this.model.enableStrictMode) {
                if (this._preTxtValue == null || this.element.val() == "") {
                    this.element.val("");
                    if (!this._isSupport) this._hiddenInput.css("display", "block");
                } else
                    this.element.val(calenderDate);
                this._triggerChangeEvent(e);
				if(this.model.value != null)
				this._trigger("change", data);
            }
            else {
                if (val) {
                    if ((val < this.model.minDate) || (val > this.model.maxDate)) {
                        this.isValidState = false, valueExceed = true,
                        this._calendarDate = val < this.model.minDate ? this.model.minDate : this.model.maxDate
                    }
                    else
                        this.isValidState = true;
                    this._triggerChangeEvent(e);
                    if (valueExceed && this._getInternalEvents) this._trigger("outOfRange");
                }
                else {
                    this.isValidState = false;
                    if (this._calendarDate < this.model.minDate) this._calendarDate = this.model.minDate;
                    else if (this._calendarDate > this.model.maxDate) this._calendarDate = this.model.maxDate;
                }
            }
        },
        _onKeyDown: function (e) {
            if (e.keyCode === 13) {
                var previous = this._preValue != null ? new Date(this._preValue.toString()) : this._preValue;
                this._validateOnFocusOut(this._validateValue(), e);
                if ((!this._isOpen || this.model.displayInline) && !this._setWaterMark() && !this._compareDate(this._preValue, this._parseDate(this.element.val(), this.model.dateFormat))) this._updateInputVal();
                if ((!this._isOpen || this.model.displayInline)) this._refreshLevel(previous);
                if (this.element.val() != "" && (!this._isOpen || this.model.displayInline)) { this._validateInputVal(); }
                this._checkErrorClass();
            }
        },
        _showhidePopup: function (e) {
            if (!this.model.enabled) return false;
            if (this._isOpen) {
                if (!this._isFocused && this.element.is(':input') && (!ej.isTouchDevice())) this.element.focus();
                if (!this._cancelValue) this.hide(e);
            }
            else {
                if (!this._isFocused && this.element.is(':input') && (!ej.isTouchDevice())) this.element.focus();
                this.show(e);
            }
        },
        _compareDate: function (first, second) {
            var result = (+first === +second) ? true : false;
            return result;
        },
        _validateDate: function (val) {
            var result = true;
            if (val != null) {
                for (var i = 0; i < this.model.blackoutDates.length; i++) {
                    var dateObj = this._checkInstanceType(this.model.blackoutDates[i]);
                    if (dateObj && +val === +dateObj)
                        result = false;
                }
                if ((val < this.model.minDate || val > this.model.maxDate) && this.model.enableStrictMode) {
                    result = false;
                    this.isValidState = false;
                }
            }

            return result;
        },

        _triggerChangeEvent: function (e) {
            var currentValue;
            var _currentVal = this.element.val() == "" ? null : this.element.val();
            this._prevDate = this._formatter(this._preValue, this.model.dateFormat);
            var data = { prevDate: this._prevDate, value: _currentVal, isInteraction: !!e };
            if (this._specificFormat() && e != undefined && e.type == "keydown" && this._formatter(this._preValue, this.model.dateFormat, this.model.locale) != this.element.val())
                currentValue = this._parseDate(this.element.val(), true);
            else if ((this._specificFormat() && e != undefined && e.type == "blur"))
                currentValue = this.model.value;
            else currentValue = this._parseDate(_currentVal);
            currentValue = this._validateYearValue(currentValue);
            if (!this._validateDate(currentValue)) currentValue = null;
            if (!this._compareDate(this._preValue, currentValue)) {
                this._preValue = this.model.value = currentValue;
                data.value = this._formatter(this.model.value, this.model.dateFormat);
                if (this.model.value) this._clickedDate = this._calendarDate = this.model.value;
                if (this.model.displayInline && !this._isInputBox) this._hiddenInput.attr('value', _currentVal);
                if (!this.model.value && !this.model.enableStrictMode) this._setDateValue(this.model.value);
                data.value = _currentVal;
                this._trigger("_change", data);
                data.value = this._formatter(this.model.value, this.model.dateFormat);
                this._trigger("change", data);
                this._checkErrorClass();
            }
            else if (!(this.element.val() == "" && this._prevDate == null) && this.element.val() != this._prevDate) {
                data.value = this.element.val();
                this._trigger("_change", data);
            }
        },

        _triggerSelectEvent: function (e) {
            var val = this.element.val();
            if (this._parseDate(val)) {
                var data = { prevDate: this._prevDate, date: this.model.value, value: val, isSpecialDay: this._isSpecialDates(this.model.value) };
                if (this._prevDate != val) {
                    if (this._parseDate(data.value) && (this.model.value >= this.model.minDate && this.model.value <= this.model.maxDate)) {
                        this._cancelValue = this._trigger("select", data);
                    }
                }
                if (this._dt_drilldown) this._trigger("dt_drilldown", data);
            }
            if (this.model.value) {
                $(this.element).attr("aria-activedescendant", $(this.sfCalendar.find(".e-active")).attr("id"));
            }
        },

        _onDocumentClick: function (e) {
            if (this.model) {
                if (!$(e.target).is(this.popup) && !$(e.target).parents(".e-popup").is(this.popup) &&
                    !$(e.target).is(this.wrapper) && !$(e.target).parents(".e-datewidget").is(this.wrapper)) {
                    this.hide(e);
                }
                else if ($(e.target).is(this.popup) || $(e.target).parents(".e-popup").is(this.popup)) {
                    e.preventDefault();
                }
            }
        },

        _OnWindowResize: function (e) {
            if (this.sfCalendar) this._setDatePickerPosition();
        },

        _showDatePopUp: function (e) {
            var isRightClick = false;
            if (e.button)
                isRightClick = (e.button == 2);
            else if (e.which)
                isRightClick = (e.which == 3); //for Opera
            if (isRightClick) return;
            if (!this._isSupport && !this.model.showPopupButton) {
                e.preventDefault();
                this._onFocusIn();
            }
            if (this.model.readOnly) return;
            e.preventDefault();
            if (!this.model.enabled && this.model.displayInline) return false;
            this._showhidePopup(e);
        },
        _layoutChanged: function (e) {
            // this event internally used to observe the layout change in "DateTimePicker" control
            if (this._getInternalEvents) this._trigger("layoutChange");
        },
        _setCurrDate: function (e) {
            if (this.model.readOnly || !this.model.enabled) return false;
            if (e) e.preventDefault();
            var proxy = this;
            this._prevDate = this._formatter(this.model.value, this.model.dateFormat);
            this._dateValue = this._zeroTime(new Date());
            this.model.value = this._calendarDate = new Date(this._dateValue.toString());
            this._setDateValue(this.model.value);
            this._triggerSelectEvent(e);
            this._triggerChangeEvent(e);
            this._refreshDatepicker();
            this._changeDayClass();
            this._startLevel(this.model.startLevel);
            this._onSetCancelDateHandler(e);
            this._layoutChanged();
        },
        _changeDayClass: function () {
            var className = this.popup.children("table")[0].className;
            if (className != "e-dp-viewdays") {
                this.popup.children("table").removeClass(className).addClass("e-dp-viewdays");
            }
        },

        _onSetCancelDateHandler: function (e) {
            if (this.model.readOnly || !this.model.enabled) return false;
            if (e && ($(e.target).hasClass("e-disable") || $(e.target).hasClass("e-hidedate"))) return false;
            if (e && e.type) e.preventDefault();
            if (this._specificFormat()) this._prevDate = this.element.val();
            else this.model.value = this._parseDate(this.element.val());
            this._prevDate = this._formatter(this.model.value, this.model.dateFormat);
            this._setDateValue(this._dateValue);
            this._triggerSelectEvent(e);
            this._triggerChangeEvent(e);
            this._dateValue = (this.model.value == null)? null:new Date(this.model.value.toString());
            if (this.element.is(':input') && !this.model.displayInline) {
                this._showhidePopup(e);
            }
            if (e && $(e.currentTarget).hasClass("other-month"))
                this._refreshDatepicker();
            this._cellSelection();
        },
        _closeCalendar: function (ele) {
            if (!ele || ele == this.element) {
                this.sfCalendar.empty().remove();
            }
        },
        //Error class for input value validation
        _checkErrorClass: function () {
            if (this.wrapper) {
                if (this.isValidState) this.wrapper.removeClass("e-error");
                else this.wrapper.addClass("e-error");
            }
        },
        _getLocalizedLabels: function () {
            return ej.getLocalizedConstants(this.sfType, this.model.locale);
        }
    });

    ej.DatePicker.Locale = ej.DatePicker.Locale || {};

    ej.DatePicker.Locale['default'] = ej.DatePicker.Locale['en-US'] = {
        watermarkText: "Select date",
        buttonText: 'Today'
    };


    ej.DatePicker.Header = {
        /**  Removes the day header */
        None: "none",
        /**  Shows the day header format in short like Sun, Mon, Tue … */
        Short: "short",
        /**  Shows the day header format in min like Su, Mo, Tu … */
        Min: "min",
        /**  Shows the day header format in long like Sunday, Monday, Tuesday … */
        Long: "long"
    };

    ej.DatePicker.HighlightSection = {
        /**  Highlight the Current Month. */
        Month: "month",
        /**  Highlight the Current Week. */
        Week: "week",
        /**  Highlight the Current WorkDays. */
        WorkDays: "workdays",
        /** Don't Highlight Anything. */
        None: "none"
    };


    ej.DatePicker.Level = {
        /**  Starts from month level view. */
        Month: "month",
        /**  Starts from year level view. */
        Year: "year",
        /**  Starts from year decade level view. */
        Decade: "decade",
        /**  Starts from century level view.  */
        Century: "century"
    };
})(jQuery, Syncfusion);;
/**
* @fileOverview Plugin to craete a Timepicker with the Html input element
* @copyright Copyright Syncfusion Inc. 2001 - 2015. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
* @version 12.1 
* @author <a href="mailto:licensing@syncfusion.com">Syncfusion Inc</a>
*/
(function ($, ej, undefined) {

    ej.widget("ejTimePicker", "ej.TimePicker", {

        element: null,

        model: null,
        validTags: ["input"],
        _addToPersist: ["value"],
        _rootCSS: "e-timepicker",
        _setFirst: false,
        type: "editor",
        angular: {
            require: ['?ngModel', '^?form', '^?ngModelOptions'],
            requireFormatters: true
        },
        _requiresID: true,

        defaults: {

            cssClass: "",

            timeFormat: "",

            value: null,

            enableAnimation: true,

            locale: "en-US",

            htmlAttributes: {},

            readOnly: false,

            showPopupButton: true,

            enableStrictMode: false,

            interval: 30,

            hourInterval: 1,

            minutesInterval: 1,

            secondsInterval: 1,

            height: "",

            width: "",

            minTime: "12:00 AM",

            maxTime: "11:59 PM",

            showRoundedCorner: false,

            enableRTL: false,

            popupHeight: "191px",

            popupWidth: "auto",

            enabled: true,

            enablePersistence: false,

            disableTimeRanges: null,

            validationRules: null,

            validationMessages: null,

            focusIn: null,

            focusOut: null,

            beforeChange: null,

            change: null,

            select: null,

            create: null,

            destroy: null,

            beforeOpen: null,

            beforeClose: null,

            open: null,

            close: null,

            watermarkText:"select a time"
        },


        dataTypes: {
            timeFormat: "string",
            minTime: "string",
            maxTime: "string",
            readOnly: "boolean",
            interval: "number",
            showPopupButton: "boolean",
            locale: "string",
            hourInterval: "number",
            minutesInterval: "number",
            secondsInterval: "number",
            enabled: "boolean",
            enablePersistence: "boolean",
            enableAnimation: "boolean",
            enableStrictMode: "boolean",
            disableTimeRanges: "data",
            htmlAttributes: "data",
            validationRules: "data",
            validationMessages: "data",
            watermarkText:"string"
        },

        observables: ["value"],

        enable: function () {
            if (!this.model.enabled) {
                this.element[0].disabled = false;
                this.element.prop("disabled", false);
                this.model.enabled = true;
                this.wrapper.removeClass('e-disable');
                this.element.removeClass("e-disable").attr("aria-disabled", false);
                if (this.model.showPopupButton) {
                    this.timeIcon.removeClass("e-disable").attr("aria-disabled", false);
                    if (this.popupList) this.popupList.removeClass("e-disable").attr("aria-disabled", false);
                }
                if (this._isIE8) this.timeIcon.children().removeClass("e-disable");
            }
        },


        disable: function () {
            if (this.model.enabled) {
                this.element[0].disabled = true;
                this.model.enabled = false;
                this.element.attr("disabled", "disabled");
                this.wrapper.addClass('e-disable');
                this.element.addClass("e-disable").attr("aria-disabled", true);
                if (this.model.showPopupButton) {
                    this.timeIcon.addClass("e-disable").attr("aria-disabled", true);
                    if (this.popupList) this.popupList.addClass("e-disable").attr("aria-disabled", true);
                }
                if (this._isIE8) this.timeIcon.children().addClass("e-disable");
                this._hideResult();
            }
        },


        getValue: function () {
            return this.element.val();
        },


        setCurrentTime: function () {
            if (!this.model.readOnly) this._setMask();
        },
        
        setValue: function (value) {
            var prevValue = this.model.value;
            this.model.value = ej.format(this._createObject(value, true), this.model.timeFormat, this.model.locale);
            this._ensureValue();
            this._enableMask();
            if (this.model.enableStrictMode && !this._isValid(value, true)) {
                    var tval = this._isValid(this.model.value) ? this._localizeTime(this.model.value) : this.model.value;
                     this.element.val(tval);
            }
            if (prevValue != this.model.value) {
                this._raiseChangeEvent(prevValue, true);
            }
            this._checkErrorClass();
        },

        show: function () {
            (!this.showDropdown && !this._getInternalEvents) && this._showResult();
        },

        hide: function () {
            (this.showDropdown) && this._hideResult();
        },


        _ISORegex: function () {
            this._tokens = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,
            // complex case for iso 8601 regex only
            this._extISORegex = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,
            this._basicISORegex = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/,
            this._numberRegex = {
                2: /\d\d?/,
                4: /^\d{4}/,
                "z": /Z|[+-]\d\d(?::?\d\d)?/gi,
                "t": /T/,
                "-": /\-/,
                ":": /:/
            };
            this._zeroRegex = /Z|[+-]\d\d(?::?\d\d)?/;
            this._dates = [
                ['YYYYYY-MM-DD', /[+-]\d{6}-\d\d-\d\d/],
                ['YYYY-MM-DD', /\d{4}-\d\d-\d\d/],
                ['GGGG-[W]WW-E', /\d{4}-W\d\d-\d/],
                ['GGGG-[W]WW', /\d{4}-W\d\d/, false],
                ['YYYY-DDD', /\d{4}-\d{3}/],
                ['YYYY-MM', /\d{4}-\d\d/, false],
                ['YYYYYYMMDD', /[+-]\d{10}/],
                ['YYYYMMDD', /\d{8}/],
                // YYYYMM is NOT allowed by the standard
                ['GGGG[W]WWE', /\d{4}W\d{3}/],
                ['GGGG[W]WW', /\d{4}W\d{2}/, false],
                ['YYYYDDD', /\d{7}/]
            ];

            // iso time formats and regexes
            this._times = [
                ['HH:mm:ss.SSSS', /\d\d:\d\d:\d\d\.\d+/],
                ['HH:mm:ss,SSSS', /\d\d:\d\d:\d\d,\d+/],
                ['HH:mm:ss', /\d\d:\d\d:\d\d/],
                ['HH:mm', /\d\d:\d\d/],
                ['HHmmss.SSSS', /\d\d\d\d\d\d\.\d+/],
                ['HHmmss,SSSS', /\d\d\d\d\d\d,\d+/],
                ['HHmmss', /\d\d\d\d\d\d/],
                ['HHmm', /\d\d\d\d/],
                ['HH', /\d\d/]
            ];
        },

        _timeFormat: function (format) {
            if (!format)
                format = ej.preferredCulture(this.model.locale).calendars.standard.patterns.t;
            var validatedformat = this._validateTimeFormat(format);
            if (validatedformat) {
                this.model.timeFormat = validatedformat;
                // Only change the format when model is not null.   
                this.model.minTime = ej.format(this._createObject(this._minTimeObj), this.model.timeFormat, this.model.locale);
                this.model.maxTime = ej.format(this._createObject(this._maxTimeObj), this.model.timeFormat, this.model.locale);

                if (this.model.value) {
                    this._setModelOption = true;
                    this.model.value = this._localizeTime(this.model.value);
                    this.element.val(this.model.value);
                }
                else {
                    this._setModelOption = false;
                    var timeValue = this._localizeTime(this.element.val());
                    if (timeValue && this._checkMinMax(timeValue)) {
                        this.model.value = timeValue;
                        this.element.val(timeValue);
                    }
                }
            }
            return validatedformat;
        },

        _getTimeFormat: function () {
            if (this._prevTimeFormat)
                this.model.timeFormat = ej.preferredCulture(this.model.locale).calendar.patterns.t || "h:mm tt";
            this.seperator = this._getSeperator();
        },

        _changeSkin: function (skin) {
            this.wrapper.removeClass(this.model.cssClass).addClass(skin);
            if (this.popupList) this.popupList.removeClass(this.model.cssClass).addClass(skin);
        },

        _localize: function (culture) {
            var currentTime = this._createObject(this.model.value, true);
            this.model.locale = culture;
            this._getTimeFormat();

            this.model.minTime = ej.format(this._createObject(this._minTimeObj), this.model.timeFormat, this.model.locale);
            this.model.maxTime = ej.format(this._createObject(this._maxTimeObj), this.model.timeFormat, this.model.locale);
            if (!ej.isNullOrUndefined(this._options)) {
                if (!ej.isNullOrUndefined(this._options.watermarkText))
                    this._localizedLabels.watermarkText = this._options.watermarkText;
            }
            if (currentTime) {
                this.model.value = this._localizeTime(currentTime);
                this.element.val(this.model.value);
            }
            else {
                currentTime = this._localizeTime(this.element.val());
                if (currentTime && this._checkMinMax(currentTime)) {
                    this.model.value = currentTime;
                    this.element.val(currentTime);
                }
            }
            this._getAmPm();
        },
        _setWaterMark: function () {
            if (this.element != null && this.element.hasClass("e-input")) {
                if (this._localizedLabels.watermarkText && this.element.val() == "") {
                    this.isValidState = true;
                    this._checkErrorClass();
                }
                if ((!this._isSupport) && this.element.val() == "") {
                    this._hiddenInput.css("display", "block").val(this._localizedLabels.watermarkText);
                }
                else {
                    $(this.element).attr("placeholder", this._localizedLabels.watermarkText);
                }
                return true;
            }
        },
        _localizedLabelToModel: function () {
            this.model.watermarkText = this._localizedLabels.watermarkText;
            this.model.buttonText = this._localizedLabels.buttonText;
        },
        _setLocalize: function (culture) {
            var culture = ej.preferredCulture(culture);
            if (culture) {
                this.model.locale = culture.name == "en" ? "en-US" : culture.name;
                if (!ej.isNullOrUndefined(this._options) && (ej.isNullOrUndefined(this._options.timeFormat) || (!this._options.timeFormat)))
                    this.model.timeFormat = ej.preferredCulture(this.model.locale).calendars.standard.patterns.t;
                    this._prevTimeFormat = (ej.isNullOrUndefined(this._options.timeFormat)||this._options.timeFormat=="") ? true : false;
            }
        },
        _updateInput: function () {
            if (ej.isNullOrUndefined(this._options)) return;
            var value = this._localizeTime(this._options.value);
            if (!ej.isNullOrUndefined(value))
                if (typeof value === "string" && this.model.enableStrictMode && !this.model.value) {
                    this.element.val(this._options.value);
                    this.isValidState = (this.element.val() == "") ? true : false;
                    this._checkErrorClass();
                }
        },
        _createMinMaxObj: function () {
            // create minTime object
            this._minTimeObj = this._createObject(this.model.minTime);
            if (!this._minTimeObj)
                this.model.minTime = ej.format(this._createObject(new Date().setHours(0, 0, 0, 0)), this.model.timeFormat, this.model.locale);

            // create maxTime object
            this._maxTimeObj = this._createObject(this.model.maxTime);
            if (!this._maxTimeObj)
                this.model.maxTime = ej.format(this._createObject(new Date().setHours(23, 59, 59, 59)), this.model.timeFormat, this.model.locale);
        },
        _setMinMax: function () {
            var minVal = new Date().setHours(0, 0, 0, 0);
            var maxval = new Date().setHours(23, 59, 59, 59);
            if (!ej.isNullOrUndefined(this._options) && ej.isNullOrUndefined(this._options.minTime))
                this.model.minTime = ej.format(this._createObject(minVal), this.model.timeFormat, this.model.locale);
            if (!ej.isNullOrUndefined(this._options) && ej.isNullOrUndefined(this._options.maxTime))
                this.model.maxTime = ej.format(this._createObject(maxval), this.model.timeFormat, this.model.locale);
            this._createMinMaxObj();
        },
        _init: function (options) {
            this._options = options;
            this._cloneElement = this.element.clone();
            this._ISORegex();
            this._isSupport = document.createElement("input").placeholder == undefined ? false : true;
            if (!this.element.is("input") || (this.element.attr('type') && this.element.attr('type') != "text")) return false;
            this._initialize();
            this._render();
            this._wireEvents();
            if (options && options.value != undefined && options.value != this.element.val()) {
                this._trigger("_change", { value: this.element.val() });
            }
            this._updateInput();
            this._updateTextbox();
            if (this.model.validationRules != null) {
                this._initTimeValidator();
                this._setTimeValidation();
            }

        },
        _updateTextbox: function () {
            if (this._options.disableTimeRanges) {
                var isValid = true;
                for (var i = 0; i < this._options.disableTimeRanges.length; i++) {
                    if (this.model.minTime >= this._options.disableTimeRanges[i].startTime || this.model.minTime <= this._options.disableTimeRanges[i].endTime) {
                        if ((this._options.disableTimeRanges[i].startTime == this.model.minTime)) {
                            isValid = false;
                            break;
                        }
                    }
                }

                if (this._options === undefined || (this._options.value === undefined && !this.model.value && isValid))
                    this._setTime(this._localizeTime(this.model.minTime));
            }

            else if (this._options === undefined || (this._options.value === undefined && !this.model.value))
                this._setTime(this._localizeTime(this.model.minTime));
        },

        _setMinMaxTime: function (prev, options) {
            if (!ej.isNullOrUndefined(options["minTime"]) && $.trim(options["minTime"]) && this._isValid(options["minTime"])) {
                this.model.minTime = options["minTime"];
                this._minTimeObj = this._createObject(this.model.minTime);
                this._validateTimes();
            }
            if (!ej.isNullOrUndefined(options["maxTime"]) && $.trim(options["maxTime"]) && this._isValid(options["maxTime"])) {
                this.model.maxTime = options["maxTime"];
                this._maxTimeObj = this._createObject(this.model.maxTime);
                this._validateTimes();
            }

            this._validateMinMax();
            this._createMinMaxObj();
            if (!ej.isNullOrUndefined(options["minTime"])) options["minTime"] = this.model.minTime;
            if (!ej.isNullOrUndefined(options["maxTime"])) options["maxTime"] = this.model.maxTime;
            if (!this._checkMinMax(this.model.value)) {
                if (!this.model.enableStrictMode) {
                    if (this.model.minTime && !this._compareTime(this.model.value, this.model.minTime, true))
                        this.model.value = this.model.minTime;
                    if (this.model.maxTime && !this._compareTime(this.model.maxTime, this.model.value, true))
                        this.model.value = this.model.maxTime;
                }
                else {
                    this.isValidState = false;
                    this.model.value = null;
                }
            }
            if (prev !== this.model.value && this._isValid(this.model.value, true))
                this.element.val(this.model.value);
        },
        _setModel: function (options) {
            var change = false, prev = this.model.value;
			
            for (var option in options) {
			if(option != "height" && option != "width" && option != "htmlAttributes" && option != "watermarkText" && option != "enabled" && option != "validationRules" && option != "validationMessages"){
				if (ej.isNullOrUndefined(this.popupList)) this._renderDropdown();
			}
                switch (option) {
                    case "timeFormat":
                        var prevTime = this._createObject(this.model.value);
                        this._preTimeformat = this.model.timeFormat;
                        var newFormat = this._timeFormat(options[option]);
                        options[option] = this.model.timeFormat;
                        if (newFormat)
                            this.seperator = this._getSeperator();
                        var currentTime = this._createObject(this.model.value);
                        change = (+prevTime === +currentTime) ? false : true;
                        break;
                    case "locale":
                        var prevTime = this._createObject(this.model.value);
                        this._localize(options[option]);
                        this.model.minTime = ej.format(this._createObject(this._minTimeObj), this.model.timeFormat, this.model.locale);
                        this.model.maxTime = ej.format(this._createObject(this._maxTimeObj), this.model.timeFormat, this.model.locale);
                        var currentTime = this._createObject(this.model.value);
                        change = (+prevTime === +currentTime) ? false : true;
                        break;
                    case "interval":
                        this.model.interval = options[option];
                        break;
                    case "cssClass": this._changeSkin(options[option]); break;
                    case "showRoundedCorner": this._setRoundedCorner(options[option]); break;
                    case "enableRTL": this._setRtl(options[option]); break;
                    case "height":
                        this._setHeight(options[option]); break;
                    case "width":
                        this.wrapper.width(options[option]);
                        this._setListWidth();
                        break;
                    case "value":
                        if (ej.isPlainObject(options[option])) options[option] = null;
                        this.model.value = ej.format(this._createObject(options[option], true), this.model.timeFormat, this.model.locale);
                        this._ensureValue();
                        this._enableMask();
                        if (this.model.enableStrictMode && !this._isValid(options[option], true)) {
                            var tval = this._isValid(options[option]) ? this._localizeTime(options[option]) : options[option];
                            this.element.val(tval);
                        }
                        options[option] = this.model.value;
                        change = true;
                        break;
                    case "enableStrictMode":
                        this.model.enableStrictMode = options[option];
                        break;
                    case "validationRules":
                        if (this.model.validationRules != null) {
                            this.element.rules('remove');
                            this.model.validationMessages = null;
                        }
                        this.model.validationRules = options[option];
                        if (this.model.validationRules != null) {
                            this._initTimeValidator();
                            this._setTimeValidation();
                        }
                        break;
                    case "validationMessages":
                        this.model.validationMessages = options[option];
                        if (this.model.validationRules != null && this.model.validationMessages != null) {
                            this._initTimeValidator();
                            this._setTimeValidation();
                        }
                        break;
                    case "popupHeight": this.model.popupHeight = options[option]; this._setListHeight(); break;
                    case "popupWidth": this.model.popupWidth = options[option]; this._setListWidth(); break;
                    case "enabled": if (options[option]) this.enable(); else this.disable(); break;
                    case "htmlAttributes": this._addAttr(options[option]); break;
                    case "disableTimeRanges":
                        this.model.disableTimeRanges = options[option];
                        this._initStartEnd();
                        this.model.value = ej.format(this._createObject(this.element.val(), true), this.model.timeFormat, this.model.locale);
                        this._ensureValue();
                        this._enableMask();
                        if (this.model.enableStrictMode && !this._isValid(this.element.val(), true))
                            this.element.val(this.element.val());
                        change = true;
                        break;
                    case "watermarkText":
                        if (ej.isNullOrUndefined(this._options)) this._options = {};
                        this._options[option] = this.model.watermarkText = options[option];
                        this._localizedLabels.watermarkText = this.model.watermarkText;
                        this._setWaterMark();
                        break;
                }
            }
            if (!ej.isNullOrUndefined(options["minTime"]) || !ej.isNullOrUndefined(options["maxTime"])) {
                this._setMinMaxTime(prev, options);
                change = true;
            }
            if (!ej.isNullOrUndefined(options["showPopupButton"]))
                this._showButton(options[option]);
            else if (this.model.showPopupButton && (newFormat || !ej.isNullOrUndefined(options["minTime"]) || !ej.isNullOrUndefined(options["maxTime"]) ||
                   !ej.isNullOrUndefined(options["locale"]) || !ej.isNullOrUndefined(options["interval"]) || !ej.isNullOrUndefined(options["disableTimeRanges"]))) {
                this._reRenderDropdown();
            }
            if (change) {
                this._raiseChangeEvent(prev, true);
                options["value"] = this.model.value;
            }
            this._checkErrorClass();
        },


        _destroy: function () {
            this.element.insertAfter(this.wrapper);
            this.wrapper.remove();
            this.element.removeClass("e-input").removeAttr("ondragstart draggable aria-atomic aria-live aria-readonly").val(this.element.attr("value"));
            if (!this._cloneElement.attr('name')) this.element.removeAttr('name');
            if (this.popupList) this.popupList.remove();
        },

        _initialize: function () {
            this.target = this.element[0];
            this.timeIcon = null;
            this._disabledItems = [];
            this.popupList = null;
            this.focused = false;
            this.start = 0;
            this.end = 0;
            this.min = null;
            this.max = null;
            this.incomplete = false;
            this.downPosition = 0;
            this._setLocalize(this.model.locale);
            this._setMinMax();
            this._getAmPm();
            this.showDropdown = false;
            this._activeItem = 0;
            this.isValidState = true;
            this._manualFocus = false;
            this._isIE7 = this._checkIE7();
            this._initStartEnd();
            this._localizedLabels = this._getLocalizedLabels();
            if (!ej.isNullOrUndefined(this._options)) {
                if (!ej.isNullOrUndefined(this._options.watermarkText))
                    this._localizedLabels.watermarkText = this._options.watermarkText;
            }
            if (ej.isNullOrUndefined(this.model.value) && this.element[0].value != "")
                this.model.value = this.element[0].value;
            this._isIE8 = (ej.browserInfo().name == "msie") && (ej.browserInfo().version == "8.0") ? true : false;
            // _getInternalEvents is used when TimePicker used as a subcontrol of DateTimePicker 
            this._getInternalEvents = false;
            this._dateTimeInternal = false;
            if (!this.model.timeFormat) this._getTimeFormat();
            else this.seperator = this._getSeperator();
        },

        _render: function () {
            this._renderWrapper();
            this._setDimentions();
            this._renderTimeIcon();
            this._validateTimes();
            this._createMinMaxObj();
            this._addAttr(this.model.htmlAttributes);
            this._checkProperties();
            this._enableMask();
            this._checkErrorClass();
            this.element.attr({ 'aria-atomic': 'true', 'aria-live': 'assertive', "aria-readonly": this.model.readOnly, "value": this.model.value });
            (ej.isNullOrUndefined(this.model.value)) ? this.wrapper.addClass('e-valid') : this.wrapper.removeClass('e-valid');
        },

        _renderWrapper: function () {
            this.element.addClass("e-input").attr({'tabindex':'0','role':'combobox','aria-expanded':'false'});
            this.wrapper = ej.buildTag("span.e-timewidget e-widget " + this.model.cssClass + "#" + this.target.id + "_timewidget").insertAfter(this.element);
            this.wrapper.attr("style", this.element.attr("style"));
            this.element.removeAttr('style');
            if (!ej.isTouchDevice()) this.wrapper.addClass('e-ntouch');
            this.container = ej.buildTag("span.e-in-wrap e-box").append(this.element);
            this.wrapper.append(this.container);
            if (!this._isSupport) {
                this._hiddenInput = ej.buildTag("input.e-input e-placeholder ", "", {}, { type: "text" }).insertAfter(this.element);
                this._hiddenInput.val(this._localizedLabels.watermarkText);
                this._hiddenInput.css("display", "block");
                var proxy = this;
                $(this._hiddenInput).focus(function () {
                    proxy.element.focus();
                });
            }
        },
        _addAttr: function (htmlAttr) {
            var proxy = this;
            $.map(htmlAttr, function (value, key) {
                var keyName = key.toLowerCase();
                if (keyName == "class") proxy.wrapper.addClass(value);
                else if (keyName == "disabled" && value == "disabled") proxy.disable();
                else if (keyName == "readOnly" && value == "readOnly") proxy.model.readOnly = true;
                else if (keyName == "style") proxy.wrapper.attr(key, value);
                else if (keyName == "id") {
                    proxy.wrapper.attr(key, value + "_wrapper");
                    proxy.element.attr(key, value);
                }
                else if (ej.isValidAttr(proxy.element[0], key)) proxy.element.attr(key, value);
                else proxy.wrapper.attr(key, value);

            });
        },
        _initTimeValidator: function () {
            (!this.element.closest("form").data("validator")) && this.element.closest("form").validate();
        },
        _setTimeValidation: function () {
            this.element.rules("add", this.model.validationRules);
            var validator = this.element.closest("form").data("validator");
            validator = validator ? validator : this.element.closest("form").validate();
            var name = this.element.attr("name");
            validator.settings.messages[name] = {};
            for (var ruleName in this.model.validationRules) {
                var message = null;
                if (!ej.isNullOrUndefined(this.model.validationRules[ruleName])) {
                    if (!ej.isNullOrUndefined(this.model.validationRules["messages"] && this.model.validationRules["messages"][ruleName]))
                        message = this.model.validationRules["messages"][ruleName];
                    else {
                        validator.settings.messages[name][ruleName] = $.validator.messages[ruleName];
                        for (var msgName in this.model.validationMessages)
                            ruleName == msgName ? (message = this.model.validationMessages[ruleName]) : "";
                    }
                    validator.settings.messages[name][ruleName] = message != null ? message : $.validator.messages[ruleName];
                }
            }
        },
        _renderTimeIcon: function () {
            if (this.model.showPopupButton) {
                this.timeIcon = ej.buildTag("span.e-select").attr({ 'role': 'button', 'aria-label': 'select' });
                var icon = ej.buildTag("span.e-icon e-clock").attr('role', 'presentation');
                if (this._isIE8) {
                    this.timeIcon.attr("unselectable", "on");
                    icon.attr("unselectable", "on");
                }
                this.timeIcon.append(icon);
                this.container.append(this.timeIcon).addClass("e-padding");
                this._on(this.timeIcon, "mousedown", this._timeIconClick);
            }

        },
        _elementClick: function (e) {
            if (!this.showDropdown) this._showResult();
        },
        _renderDropdown: function () {
            var oldWrapper = $("#" + this.element[0].id + "_popup").get(0);
            if (oldWrapper)
                $(oldWrapper).remove();
            if (this.popupList) return false;
            this.popupList = ej.buildTag("div.e-time-popup e-popup e-widget e-box " + this.model.cssClass + "#" + this.target.id + "_popup", "", {}, { 'tabindex': 0, 'role':'listbox'});
            if (!ej.isTouchDevice()) this.popupList.addClass('e-ntouch');
            this.popup = this.popupList;
            this.ul = ej.buildTag("ul.e-ul");
            if (this._isIE8)
                this.ul.attr("unselectable", "on");
            var scrollDiv = ej.buildTag("div").append(this.ul);
            $('body').append(this.popupList.append(scrollDiv));
            this._renderLiTags();
            this._setListHeight();
            this._setListWidth();
            this.popupList.ejScroller({ height: this.popupList.height(), width: 0, scrollerSize: 20 });
            this.scrollerObj = this.popupList.ejScroller("instance");
            this.popupList.css("display", "none");
            this._listSize = this.ul.find("li").length;
        },
        _renderLiTags: function () {
            this._disabledItems = [];
            var start, end, timeVal, interval = this.model.interval * 60000;
            // Maintain the min and max time as object;
            var disableTime = (!ej.isNullOrUndefined(this.model.disableTimeRanges) && this.model.disableTimeRanges.length > 0) ? true : false;
            start = this._minTimeObj;
            end = this._maxTimeObj;
            var i = 0;
            while (this._compareTime(end, start, true)) {
                timeVal = this._localizeTime(start);
                var litag = $(document.createElement('li'));
                litag[0].appendChild(document.createTextNode(timeVal));
                if (this._isIE8) litag.attr("unselectable", "on");
                if (disableTime) {
                    if (this._ensureTimeRange(timeVal)) {
                        litag.addClass('e-disable');
                        this._disabledItems.push(i);
                    }
                    else {
                        litag.removeClass('e-disable');
                    }
                }
                this.ul[0].appendChild(litag[0]);
                start = new Date(start).getTime() + interval;
                i++;
            }

            var liTags = this.ul.find("li");
            if (!ej.isTouchDevice()) {
                this._on(liTags, "mouseenter", $.proxy(this._OnMouseEnter, this));
                this._on(liTags, "mouseleave", $.proxy(this._OnMouseLeave, this));
            }
            this._on(liTags, "click", $.proxy(this._OnMouseClick, this));
            if (this.model.showPopupButton || !ej.isNullOrUndefined(this.popupList))
                this.ul.find("li").attr({ 'tabindex': -1, 'aria-selected': false,'role':'option' });
        },
        _ensureTimeRange: function (value) {
            if (!ej.isNullOrUndefined(this.model.disableTimeRanges)) {
                var timeVal = this._makeDateTimeObj(value);
                for (var i = 0; i < this.model.disableTimeRanges.length; i++) {
                    if (+timeVal >= +this._makeDateTimeObj(this.model.disableTimeRanges[i].startTime) && +timeVal <= +this._makeDateTimeObj(this.model.disableTimeRanges[i].endTime))
                        return true;
                }
            }
            return false;
        },
        _initStartEnd: function () {
            this._startTime = [];
            this._endTime = [];
            if (!ej.isNullOrUndefined(this.model.disableTimeRanges)) {
                for (var i = 0; i < this.model.disableTimeRanges.length; i++) {
                    this._startTime[i] = this._makeDateTimeObj(this.model.disableTimeRanges[i].startTime);
                    this._endTime[i] = this._makeDateTimeObj(this.model.disableTimeRanges[i].endTime);
                }
            }
        },
        _makeDateTimeObj: function (value) {
            if (typeof value === "string") {
                var dateFormat = ej.preferredCulture(this.model.locale).calendar.patterns.d;
                var dateValue = ej.format(new Date("1/1/2000"), dateFormat, this.model.locale);
                var obj = ej.parseDate(dateValue + " " + value, dateFormat + " " + this.model.timeFormat, this.model.locale);
                if (!obj) {
                    var isJSONString = new Date(value);
                    if (!isNaN(Date.parse(isJSONString)) && !ej.isNullOrUndefined(value))
                        return this._setEmptyDate(value);
                    else
                        obj = new Date("1/1/2000 " + value);
                }
                return obj;
            }
            else if (value instanceof Date)
                return this._setEmptyDate(value);
            else return null;
        },
        _reRenderDropdown: function () {
            this.ul.empty();
            this._renderLiTags();
            this._refreshScroller();
            this._changeActiveEle();
        },
        _refreshScroller: function () {
            var flag = this.popupList.css("display") == "none" ? true : false;
            this.popupList.css("height", "auto");
            this.popupList.find(".e-content, .e-vscroll").removeAttr("style");
            this.popupList.find(".e-vscroll div").removeAttr("style");

            if (flag) this.popupList.css("display", "block");
            this.scrollerObj.model.height = this.popupList.height();
            this.scrollerObj.model.scrollTop = 0;
            this.scrollerObj.refresh();
            if (this._isIE8) {
                $("#" + this.scrollerObj._id).children('.e-vscroll').children().attr("unselectable", "on");
                $("#" + this.scrollerObj._id).find('.e-vhandle').attr("unselectable", "on");
            }
            if (flag) this.popupList.css("display", "none");
        },

        _removeWatermark: function () {
            if (this.element.val() != "" && !this._isSupport)
                this._hiddenInput.css("display", "none");
        },

        _setListWidth: function () {
            if (this.popupList) {
                var timePopupWidth = this.model.popupWidth,width;
                if ((typeof (timePopupWidth) == "string" && timePopupWidth.indexOf("%") != -1) || typeof (timePopupWidth) == "string") width = parseInt(timePopupWidth) > 0 ? timePopupWidth : "auto" && (this.model.popupWidth = "auto");
                else {
                    width = timePopupWidth > 0 ? timePopupWidth : "auto" && (this.model.popupWidth = "auto");
                }
                if (width && width != "auto") this.popupList.css({ "width": width });
                else this.popupList.css({ "width": this.wrapper.width() });
            }
            if (this.scrollerObj) {
                this._refreshScroller();
                this._updateScrollTop();
            }
        },
        _setListHeight: function () {
            if (this.popupList) this.popupList.css({ "max-height": this.model.popupHeight || "191px" });
            if (this.scrollerObj) {
                this._refreshScroller();
                this._updateScrollTop();
            }
        },
        _updateScrollTop: function () {
            this.scrollerObj.setModel({ "scrollTop": this._calcScrollTop() });
        },
        _refreshPopup: function () {
            if (this.model.popupWidth == "auto") this.popupList.css({ "width": this.wrapper.width() });
            this._setListPosition();
            this._refreshScroller();
        },

        _setListPosition: function () {
            var elementObj = this.wrapper, pos = this._getOffset(elementObj), winWidth,
            winBottomHeight = $(document).scrollTop() + $(window).height() - (pos.top + $(elementObj).outerHeight()),
            winTopHeight = pos.top - $(document).scrollTop(),
            popupHeight = this.popupList.outerHeight(),
            popupWidth = this.popupList.outerWidth(),
            left = pos.left,
            totalHeight = elementObj.outerHeight(),
            border = (totalHeight - elementObj.height()) / 2,
            maxZ = this._getZindexPartial(), popupmargin = 3,
            topPos = ((popupHeight < winBottomHeight || popupHeight > winTopHeight) ? pos.top + totalHeight + popupmargin : pos.top - popupHeight - popupmargin) - border;
            winWidth = $(document).scrollLeft() + $(window).width() - left;
            if (this.model.enableRTL || popupWidth > winWidth && (popupWidth < left + elementObj.outerWidth())) left -= this.popupList.outerWidth() - elementObj.outerWidth();
            this.popupList.css({
                "left": left + "px",
                "top": topPos + "px",
                "z-index": maxZ
            });
        },

        _getOffset: function (ele) {
            return ej.util.getOffset(ele);
        },

        _getZindexPartial: function () {
            return ej.util.getZindexPartial(this.element, this.popupList);
        },

        _enableMask: function () {
            var flag = false;
            if ((this.model.minTime && this._compareTime(this.model.minTime, this.model.value)) ||
                this.model.maxTime && this._compareTime(this.model.value, this.model.maxTime))
                this.isValidState = false;
            else this.isValidState = true;
            this._setTime(this.model.value);
            (ej.isNullOrUndefined(this.model.value)) ? this.wrapper.removeClass('e-valid') : this.wrapper.addClass('e-valid');
            if (this._getInternalEvents && !this.isValidState) this._trigger("outOfRange");
            this._changeActiveEle();
            this._preVal = this.element.val();
        },
        _setTime: function (time) {
            var modifiedTime = this._localizeTime(time);
            this.element.val(modifiedTime);
            if (this.model.enableStrictMode) {
                this.model.value = (this._compareTime(this.model.value, this.model.minTime, true) && this._compareTime(this.model.maxTime, this.model.value, true)) ? modifiedTime : null;
            } else {
                this.model.value = modifiedTime;
            }
            this._setWaterMark();
        },
        _timeFromISO: function (date) {
            var result = this._extISORegex.exec(date) || this._basicISORegex.exec(date), dateFormat = '', timeFormat = '', zeroFormat = '', format;
            if (result) {
                for (var i = 0; i < this._dates.length; i++) {
                    if (this._dates[i][1].exec(result[1])) {
                        dateFormat = this._dates[i][0];
                        break;
                    }
                }
                if (result[3]) {
                    for (var k = 0; k < this._times.length; k++) {
                        if (this._times[k][1].exec(result[3])) {
                            // result[2] should be 'T' (time) or space
                            timeFormat = (result[2] || ' ') + this._times[k][0];
                            break;
                        }
                    }
                }
                if (result[4]) if (this._zeroRegex.exec(result[4])) zeroFormat = 'Z';
                format = dateFormat + timeFormat + zeroFormat;
                var token = format.match(this._tokens), input, val = [], literal, char;
                for (var j = 0; j < token.length; j++) {
                    var str = token[j];
                    literal = this._checkLiteral(token[j]);
                    var rg = this._numberRegex[literal ? token[j].toLowerCase() : str.length] || new RegExp('^\\d{1,' + str.length + '}');
                    input = date.match(rg);
                    if (input) {
                        if (date.substr(0, date.indexOf(input)) >= 0 && !literal) token[j].indexOf('M') >= 0 ? val.push(parseInt(input[0]) - 1) : val.push(parseInt(input[0]));
                        date = date.slice(date.indexOf(input[0]) + input[0].length);
                    }
                }
                //if you want to get the value in UTC format use the "new Date(Date.UTC.apply(null, val)"
                //return the date object value as exact as given input value
                //new Date(year, month, day, hour, minute, seconds);
                return result[4] == "Z" ? new Date(Date.UTC.apply(null, val)) : new Date(val[0], val[1], val[2], val[3], val[4], val[5]);
            }
            else {
                return new Date(date + "");
            }
        },
        _checkLiteral: function (str) {
            var char = str.toLowerCase();
            return (char == 't' || char == 'z' || char == ':' || char == '-') ? true : false;
        },
        _setMask: function () {
            this.model.value = new Date();
            this._enableMask();
        },

        _validateTimes: function () {
            var validatedformat = this._validateTimeFormat(this.model.timeFormat);
            if (validatedformat) this.model.timeFormat = validatedformat;
            else this.model.timeFormat = "h:mm tt";
            if (!this._isValid(this.model.minTime)) this.model.minTime = "12:00 AM";
            if (!this._isValid(this.model.maxTime)) this.model.maxTime = "11:59 PM";
            if (!this._isValid(this.model.value, true)) this.model.value = null;
            if (!this._checkMinMax(this.model.value) && !this.model.enableStrictMode) {
                if (this.model.minTime && !this._compareTime(this.model.value, this.model.minTime, true))
                    this.model.value = this.model.minTime;
                if (this.model.maxTime && !this._compareTime(this.model.maxTime, this.model.value, true))
                    this.model.value = this.model.maxTime;
            }
            this._validateMinMax();
        },
        _ensureValue: function () {
            if (!this._checkMinMax(this.model.value) && this._isValid(this.model.value, true)) {
                if (!this.model.enableStrictMode) {
                    if (this.model.minTime && !this._compareTime(this.model.value, this.model.minTime, true))
                        this.model.value = this.model.minTime;
                    if (this.model.maxTime && !this._compareTime(this.model.maxTime, this.model.value, true))
                        this.model.value = this.model.maxTime;
                }
                else
                    this.isValidState = false;
            }
        },
        _validateMinMax: function () {
            if (this.model.minTime && this.model.maxTime && this._compareTime(this.model.minTime, this.model.maxTime)) {
                this.model.minTime = this.model.maxTime;
            }
        },
        _checkProperties: function () {
            if (!this.model.enabled) {
                this.model.enabled = true;
                this.disable();
            }
            else if (this.model.enabled && this.element.hasClass("e-disable")) {
                this.model.enabled = false;
                this.enable();
            }
            this._addProperty();
            this._checkAttributes();
        },
        _addProperty: function () {
            this._setRtl(this.model.enableRTL);
            this._setRoundedCorner(this.model.showRoundedCorner);
        },
        _setRtl: function (boolean) {
            if (boolean) {
                this.wrapper.addClass("e-rtl");
                if (this.popupList) this.popupList.addClass("e-rtl");
            }
            else {
                this.wrapper.removeClass("e-rtl");
                if (this.popupList) this.popupList.removeClass("e-rtl");
            }
        },
        _setRoundedCorner: function (boolean) {
            if (boolean) {
                this.container.addClass("e-corner");
                if (this.popupList) this.popupList.addClass("e-corner");
            }
            else {
                this.container.removeClass("e-corner");
                if (this.popupList) this.popupList.removeClass("e-corner");
            }
        },
        _showButton: function (show) {
            this.model.showPopupButton = show;
            if (show) {
                this.container.addClass("e-padding");
                this._renderTimeIcon();
                this._renderDropdown();
                this._addProperty();
            }
            else {
                this.container.removeClass("e-padding");
                this.timeIcon.remove();
                this.popupList.remove();
                this.timeIcon = this.popupList = null;
                $(document).off("mousedown", $.proxy(this._OnDocumentClick, this));
            }
        },
        _checkAttributes: function () {
            if (!this.element.attr("name"))
                this.element.attr({ "name": this.element[0].id });
            if ('ondragstart' in document.createElement('input'))
                this.element.attr({ "ondragstart": "return false" });
            if ('draggable' in document.createElement('input'))
                this.element.attr({ "draggable": "false" });
        },

        _getAmPm: function () {
            var dateObj = new Date();
            dateObj.setHours(0);
            this.ttAM = $.trim(this._localizeMeridian(dateObj));
            dateObj.setHours(23);
            this.ttPM = $.trim(this._localizeMeridian(dateObj));
        },

        _setDimentions: function () {
            if (!this.model.height) this.model.height = this.element.attr("height"); if (!this.model.width) this.model.width = this.element.attr("width");
            this._setHeight(this.model.height);
            if (this.model.width) this.wrapper.width(this.model.width);
        },
        _setHeight: function (height) {
            if (height) this.wrapper.height(height);
            if (this._isIE7) this.element.height(this.container.height());
        },

        _validateTimeFormat: function (timeFormat) {
            var parts = timeFormat.split(" "), format = "";
            if (parts.length == 1 || parts.length == 2) {
                $(parts).each(function (i, part) {
                    format += $.trim(part) + " ";
                });
                return $.trim(format);
            }
            else return null;
        },

        _getSeperator: function () {
            var p = this._getElePlace(), formats = this._formatparts[p.time];
            var regex = new RegExp("^[a-zA-Z0-9]+$");

            for (var i = 0; i < formats.length; i++) {
                if (!regex.test(formats.charAt(i))) return formats.charAt(i);
            }
        },

        _checkInComplete: function () {
            var pos = this._getCaretSelection(), cursor = this._getStartEnd(pos);
            var replace = "00", selected = this._getSelectedValue(cursor), category = this._getCategory(cursor);
            if (pos.end - pos.start == this.element.val().length) this._checkAll();

            if (category && category != "tt") {
                this._findCategoryPosition(category);
                if (selected == "__") {
                    if (category == "h" || category == "hh") replace = "12";
                    this._changeToDefault(replace);
                }
                else if (category.length != 1 && selected.length == 1) {
                    selected = this._changeWhole(selected);
                    this.element.val(this._replaceAt(this.target.value, this.start, this.end, selected));
                }
            }
        },
        _checkAll: function () {
            var i, p = this._getElePlace(), categories = this._formatparts[p.time].split(this.seperator);
            for (i = 0; i < categories.length; i++) {
                this._findCategoryPosition(categories[i]);
                var selected = this._getSelectedValue({ start: this.start, end: this.end });

                if (categories[i].length != 1 && selected.length == 1) {
                    selected = this._changeWhole(selected);
                    this.element.val(this._replaceAt(this.element.val(), this.start, this.end, selected));
                }
            }
        },

        _changeToDefault: function (replace) {
            this.incomplete = true;
            var preVal = this.element[0].value
            this.element[0].value = this._replaceAt(this.target.value, this.start, this.end, replace);
            var timeValue = this._checkExceedRange(this.target.value);
            if (!!timeValue) {
                this._setTime(this.model[timeValue]);
            }
            this._setSelection(this.start, this.end);
            this._raiseChangeEvent(preVal);
        },

        _setSelection: function (start, end) {
            var element = this.element[0];

            if (element.setSelectionRange)
                element.setSelectionRange(start, end);
            else if (element.createTextRange) {
                // For lower version browsers (IE8, IE7 ...)
                element = element.createTextRange();
                element.collapse(true);
                element.moveEnd('character', end);
                element.moveStart('character', start);
                element.select();
            }
        },

        _getSelectedValue: function (cursor) {
            return this.target.value.substring(cursor.start, cursor.end);
        },

        _getMinMax: function (currPart, keydown) {
            if (currPart == "hh" || currPart == "h") {
                this.min = 1; this.max = 11;
                if (keydown) this.max = 12;
            }
            else if (currPart == "HH" || currPart == "H") {
                this.min = 0; this.max = 23;
            }
            else if (currPart == "mm" || currPart == "m" || currPart == "ss" || currPart == "s") {
                this.min = 0; this.max = 59;
            }
        },

        _focusElement: function () {
            this._manualFocus = true;
            this.element.focus();
        },
        _targetFocus: function (e) {
            this._clearRange();
            e.preventDefault();
            this.focused = true;
            this.element.on('mousewheel DOMMouseScroll', $.proxy(this._mouseWheel, this));
            this.wrapper.addClass("e-focus").removeClass("e-error").attr('aria-invalid', "false");
            this._getExactPostions();
            if (!this._manualFocus) {
                this._findCategoryPosition(this._getLeast(false));
                this._setSelection(this.start, this.end);
            }
            this._manualFocus = false;
            this._prevTimeVal = this.element.val();
            this._raiseEvent("focusIn");
            this.wrapper.addClass('e-valid');
            if (!this.model.showPopupButton) this._showResult();
            if (!this.model.showPopupButton) this._on(this.element, "click", this._elementClick);
        },
        _targetBlur: function () {
            this.focused = false;
            this.element.off('mousewheel DOMMouseScroll', $.proxy(this._mouseWheel, this));
            if (!this.model.showPopupButton) this._off(this.element, "click", this._elementClick);
            this.wrapper.removeClass("e-focus");
            if (!this.model.enableStrictMode) {
                // To remove the min value mask while focusout the timepicker.
                if (this.target.value.indexOf('_') > -1) this.element.val('');
            }
            if (!this._checkMinMax(this.target.value) && this._isValid(this.target.value, true)) {
                if (!this.model.enableStrictMode) {
                    if (this.model.minTime && !this._compareTime(this._createObject(this.target.value), this.model.minTime, true))
                        this.element.val(this.model.minTime);
                    if (this.model.maxTime && !this._compareTime(this.model.maxTime, this._createObject(this.target.value), true))
                        this.element.val(this.model.maxTime);
                    if (!this._isValid(this.model.value, true))
                        this.element.val(null);
                    this.isValidState = true;
                    (ej.isNullOrUndefined(this.model.value)) ? this.wrapper.removeClass('e-valid') : this.wrapper.addClass('e-valid');
                }
                else
                    this.isValidState = false;
            }
            else this.isValidState = true;
            this._ensureValue();
            this._raiseChangeEvent();
            this._checkErrorClass();
            this._raiseEvent("focusOut");
            if (!this.model.enableStrictMode) this._checkInComplete();
            (ej.isNullOrUndefined(this.model.value)) ? this.wrapper.removeClass('e-valid') : this.wrapper.addClass('e-valid');
        },
        _clearRange: function () {
            var input = this.element[0];
            if (!isNaN(input.selectionStart)) {
                input.selectionStart = 0;
                input.selectionEnd = 0;
            }
        },
        _checkErrorClass: function () {
            if (this.isValidState) this.wrapper.removeClass("e-error").attr('aria-invalid', "false");
            else this.wrapper.addClass("e-error").attr('aria-invalid', "true");
        },

        _getExactPostions: function(){
            var timeFormat = this.model.timeFormat;
            var tempParts = this.model.timeFormat.split(" ");
            this._formatparts= []; this._valueparts = [];
            this._amPMPosition = timeFormat.match("([t][t]+)") ?timeFormat.match("([t][t]+)").index : null ;
            if(this._amPMPosition == undefined){
                this._formatparts= this.model.timeFormat.split(" "); 
                this._valueparts = this.element.val().split(" ");
                this._noTT = true;
            }
            else{
                if(this._amPMPosition == this.model.timeFormat.length - 2){
                    this._ttAtEnd = true;
                    this._isSpace = this.model.timeFormat[this.model.timeFormat.split("").indexOf("t") - 1] == " ";
                }
                else {
                    this._ttAtEnd = false;
                    this._isSpace = this.model.timeFormat[this.model.timeFormat.split("").indexOf("t") + 2] == " ";
                }

                if(this._ttAtEnd == true){
                    this._ttStartPostion = this.model.timeFormat.match("([t]?[t]+)").index; this._ttEndPosition = this.model.timeFormat.length;
                    this._formatStartPosition = 0; 
                    var difference = 0;
                    if(this.element && this.element.val()){
                        difference = this.element.val().length - this.model.timeFormat.length;
                    }
                    this._updatedttStartPosition = this._ttStartPostion + difference;
                    this._formatEndPostion= this.model.timeFormat.match("([t][t]+)").index;
                    this._formatparts[0] = this.model.timeFormat.substr(this._formatStartPosition, this._formatEndPostion).trim();
                    this._formatparts[1] = this.model.timeFormat.substr(this._ttStartPostion,this._ttEndPosition).trim();
                    this._valueparts[0] = this.element.val().substr(this._formatStartPosition, this._formatEndPostion + difference).trim();
                    this._valueparts[1] = this.element.val().substr(this._ttStartPostion + difference, this._ttEndPosition).trim();
                }
                else{
                    this._ttStartPostion = 0; this._ttEndPosition = this.model.timeFormat.match("([t]?[t]+)") ? this._ttStartPostion + this.model.timeFormat.match("([t]?[t]+)")[0].length: 0;
                    this._formatStartPosition = this._isSpace ? this._ttEndPosition + 1: this._ttEndPosition; 
                    this._formatEndPostion= this.model.timeFormat.length;
                    this._formatparts[1] = this.model.timeFormat.substr(this._formatStartPosition, this._formatEndPostion).trim();
                    this._formatparts[0] = this.model.timeFormat.substr(this._ttStartPostion,this._ttEndPosition).trim();
                    this._valueparts[1] = this.element.val().substr(this._formatStartPosition, this._formatEndPostion).trim();
                    this._valueparts[0] = this.element.val().substr(this._ttStartPostion, this._ttEndPosition).trim();
                }
            }
        },

        _getCaretSelection: function () {
            var input = this.element[0], start = 0, end = 0;
            if (!isNaN(input.selectionStart)) {
                start = input.selectionStart;
                end = input.selectionEnd;
                return { start: Math.abs(start), end: Math.abs(end) };
            }
            // For lower version browsers (IE8, IE7 ...)
            var bookmark = document.selection.createRange().getBookmark();
            var selection = input.createTextRange();
            selection.moveToBookmark(bookmark);

            var before = input.createTextRange();
            before.collapse(true);
            before.setEndPoint("EndToStart", selection);
            var beforeLength = before.text.length, selLength = selection.text.length;
            return { start: beforeLength, end: beforeLength + selLength };
        },

        _mouseDownOnInput: function (e) {
            if (!this.focused && (!ej.isTouchDevice())) this._focusElement();
             this._getExactPostions();
            this.downPosition = this._getCaretSelection();
            $(document).on("mouseup", $.proxy(this._mouseUpOnInput, this));
        },

        _mouseUpOnInput: function (e) {
            e.preventDefault();
            $(document).off("mouseup", $.proxy(this._mouseUpOnInput, this));
            var pos = this._getCaretSelection();

            if (this.incomplete) {
                this.incomplete = false;
                pos = this.downPosition;
            }
            // Select the Complete Time value using mouse.            
            if (this.target.value != this._getSelectedText()) {
                pos = this._getStartEnd(pos);
                this._setSelection(pos.start, pos.end);
            }
        },

        _getCategoryPosition: function (category) {
            var s = 0, e = 0, parts = this._getTimeParts(), p = this._getElePlace(), sep = this.seperator, valid = false;
            var fParts = this._getFormatParts()[p.time].split(sep);
            var tParts = parts[p.time].split(sep);
            if (fParts.length > tParts.length) return { start: s, end: e, isValid: valid };

            if (category == "tt") {
                if (parts[p.tt] == this.ttAM || parts[p.tt] == this.ttPM) {
                    if (p.tt == 0) s = 0;
                    else s = parts[p.time].length + 1;
                    e = s + parts[p.tt].length;
                    if(!this._isSpace && this._ttAtEnd){
                        s = s -1;
                        e = e-1;
                    } 
                    valid = true;
                }
            }
            else {
                if (p.time == 0) s = 0;
                else s = parts[p.tt].length + 1;

                var index = fParts.indexOf(category);
                if (index != -1) {
                    for (var i = 0; i < fParts.length; i++) {
                        e = tParts[i].length + 1;
                        if (i == index) break;
                        else s += e;
                    }
                    e += s - 1;
                    if(!this._noTT && !this._isSpace && !this._ttAtEnd){
                        s = s -1;
                        e = e-1;
                    } 
                    valid = true;
                }
            }
            return { start: s, end: e, isValid: valid };
        },
        _getCategory: function (cursor) {
            var parts = this._getFormatParts(), sep = this.seperator;
            var p = this._getElePlace();
            if (cursor.isTT) return parts[p.tt];
            else return parts[p.time].split(sep)[cursor.index];
        },

        _getTimeParts: function(){
            if(this.model.timeFormat == "h:mm tt" || this.model.timeFormat == "h:m tt" || this.model.timeFormat == "hh:m tt" || this.model.timeFormat == "hh:mm:s tt"){
                var parts = this.element.val().split(" ");
            }
            else var parts = this._valueparts;
            return parts;
        },

        _getFormatParts: function(){
            if(this.model.timeFormat == "h:mm tt" || this.model.timeFormat == "h:m tt" || this.model.timeFormat == "hh:m tt" || this.model.timeFormat == "hh:mm:s tt"){
                var formatparts = this.model.timeFormat.split(" ");;
            }
            else var formatparts = this._formatparts;
            return formatparts;
        },

        _getStartEnd: function (pos) {
            this._getExactPostions();
            var tt, sep = this.seperator;
            var value = this.element.val(), parts = this._valueparts, s = 0, e = 0, place = tt = null, i, j;
            
            for (j = 0; j < parts.length; j++) {
                if (parts[j] != this.ttAM && parts[j] != this.ttPM) {
                    var time = parts[j].split(sep), tempS = s, tempE = s + time[0].length;
                    for (i = 0; i < time.length; i++) {
                        e = time[i].length + s;
                        if(!this._isSpace && this._ttAtEnd && pos.start >= this._updatedttStartPosition && pos.end <=  this._ttEndPosition
                            && this._formatparts[0].split(this._getSeperator())[1].length == this._valueparts[0].split(this._getSeperator())[1].length) {
                            s += time[i].length + 1;
                            continue;
                        }
                        if (pos.start <= e) {
                            place = i;
                            tt = false;
                            j = parts.length;
                            break;
                        }
                        else s += time[i].length + 1;
                    }
                }
                else {
                    if (!this._isSpace && !this._ttAtEnd ? pos.start < s + parts[j].length : pos.start <= s + parts[j].length) {
                        e = parts[j].length + s;
                        place = 0;
                        tt = true;
                        j = parts.length;
                        if(!this._isSpace && this._ttAtEnd){
                            s = s-1;
                            e = e-1;
                        }
                        break;
                    }
                    else s += parts[j].length + 1;
                    if(!this._isSpace && !this._ttAtEnd) s = s -1;
                }
            }
            if (place == null) s = tempS, e = tempE, place = 0, tt = false;

            return { start: s, end: e, index: place, isTT: tt };
        },

        _modifyValue: function (isIncrement) {
            if (!this._isValid(this.target.value)) return;
            if (!this.model.enableStrictMode) this._checkInComplete();
            var pos = this._getCaretSelection(), cursor;
            if (pos.start == pos.end) {
                var cate = this._getLeast(true);
                var position = this._getCategoryPosition(cate);
                cursor = this._getStartEnd(position);
            }
            else cursor = this._getStartEnd(pos);
            this.start = cursor.start; this.end = cursor.end;
            this._changeValue(cursor, isIncrement);
        },

        _keyUpOnInput: function (e) {
            e.preventDefault();
            if (this._preVal != this.element.val()) {
                this._preVal = this.element.val();
            }
            var proxy = this;
            var pos = this._getCaretSelection();
            var cursor = this._getStartEnd(pos);
            var category = this._getCategory(cursor);
            proxy = this;
            var currSelection = this._getSelectedValue(cursor);
            var spl = this.element.val();
            spl.split(":");
            if (spl[0] < 3)
                if (isNaN(spl[0] + spl[1]) == true && (spl[0]) < 10)
                    this._poschange = true;
                else
                    this._poschange = false;

            if (((category == 'h') && (pos.start == 2 && pos.end == 2) && (currSelection > 9 && currSelection < 13)) || ((category == 'H') && (currSelection > 9 && currSelection < 24)) || ((category == 'H') && (currSelection < 9) && (pos.start == 2 && pos.end == 2)) || (category == "mm" && this._poschange == true && (pos.start == 4 && pos.end == 4)) || (category == "ss" && (pos.start == 8 && pos.end == 8)) || (category == "ss" && this._poschange == true && (pos.start == 7 && pos.end == 7)) || (category == 'mm' && (pos.start == 5 && pos.end == 5))) {
                if (!((category == 'mm' && (this.model.timeFormat == "HH:mm" || this.model.timeFormat == "hh:mm" || this.model.timeFormat == "H:mm" || this.model.timeFormat == "h:mm")) || (category == "ss" && (this.model.timeFormat == "HH:mm:ss" || this.model.timeFormat == "hh:mm:ss" || this.model.timeFormat == "H:mm:ss" || this.model.timeFormat == "h:mm:ss"))))
                    this._movePosition(pos, null);
            }
            else if (((category == 'hh' || category == 'HH') && (pos.start && pos.end == 2)) && (currSelection < 24)) {
                this._movePosition(pos, null);
            }
        },

        _getNextCategory: function (cate, direction) {
            var categories = [], sep = this.seperator;
            var fParts = this._getFormatParts();
            $(fParts).each(function (i, part) {
                if (part == "tt") categories.push(part);
                else {
                    var inner = part.split(sep);
                    categories = inner.concat(categories);
                }
            });
            var index = categories.indexOf(cate), ix;
            if (index != -1) {
                if (direction) {
                    if (index == 0) ix = categories.length - 1;
                    else ix = index - 1;
                }
                else {
                    if (index == categories.length - 1) ix = 0;
                    else ix = index + 1;
                }
                return categories[ix];
            }
            return cate;
        },
        _getElePlace: function () {
            this._getExactPostions();
            var fParts = this._getFormatParts(), time, tt;
            if (fParts[0] == "tt") time = 1, tt = 0;
            else time = 0, tt = 1;
            return { time: time, tt: tt };
        },
        _movePosition: function (pos, direction) {
            var cursor = this._getStartEnd(pos);
            var currCate = this._getCategory(cursor);
            if (!currCate) currCate = this._getLeast(direction);
            var next = this._getNextCategory(currCate, direction);
            var cursor = this._getCategoryPosition(next);

            if (cursor.isValid) {
                this._setSelection(cursor.start, cursor.end);
            }
        },
        _findActiveIndex: function () {
            var elements = this.ul.find("li");
            var currTime = this.element.val(), firstTime = elements.first().html(), index;
            index = (this._parse(currTime) - this._parse(firstTime)) / (this.model.interval * 60000);
            index = Math.round(index);
            this._activeItem = (index == elements.length) ? index : index + 1;
            if (this._activeItem < 0 || this._activeItem > elements.length || isNaN(this._activeItem)) this._activeItem = 0;
        },
        _keyDownOnInput: function (e) {
            if (this.model.readOnly && !this._readOnlyKeys(e)) return false;
            var pos, cursor, category, key = e.keyCode, activeItem, prevActiveItem;

            // _getInternalEvents is set to true when TimePicker used inside DateTimePicker control
            // in DateTimePicker control it allows Up, Down, Home, End, Tab keys only
            if (this._getInternalEvents && key != 38 && key != 40 && key != 36 && key != 35 && key != 9) return false;
            // Up, Down, Esc
            if (!this.model.enableStrictMode) {
                // Prevent type operation on popup open in state.
                if (this.showDropdown && key != 38 && key != 40 && key != 27 && !this._readOnlyKeys(e)) return false;
                else if (this.showDropdown && (key == 37 || key == 39)) e.keyCode = (key == 37) ? 38 : 40;
            }
            pos = this._getCaretSelection();
            cursor = this._getStartEnd(pos);
            category = this._getCategory(cursor);
            switch (e.keyCode) {
                case 38:
                    e.preventDefault();
                    if (!this.showDropdown) {
                        if (this._isValid(this.target.value)) this._modifyValue(true);
                    }
                    else if (this.showDropdown) {
                        e.preventDefault();
                        this._findActiveIndex();
                        prevActiveItem = this._activeItem;
                        this._activeItem = this._disableItemSelectUp(this._activeItem - 1);
                        if (this._activeItem == 0) this._activeItem = prevActiveItem;
                        this._addListHover();
                        activeItem = this._getActiveItem();
                        if (activeItem.length) this._selectTimeItem(activeItem);
                    }
                    break;
                case 40:
                    e.preventDefault();
                    if (e.altKey && this.model.showPopupButton)
                        this._showhidePopup();
                    else if (!this.showDropdown) {
                        if (this._isValid(this.target.value)) this._modifyValue(false);
                    }
                    else if (this.showDropdown) {
                        e.preventDefault();
                        this._findActiveIndex();
                        prevActiveItem = this._activeItem;
                        this._activeItem = this._disableItemSelectDown(this._activeItem);
                        if (this._activeItem < this._listSize) this._activeItem += 1;
                        else
                            this._activeItem = prevActiveItem;
                        this._addListHover();
                        this._selectTimeItem(this._getActiveItem());
                    }
                    break;
                case 37:
                    e.preventDefault();
                    if (pos.start == pos.end) this._setSelection(pos.start - 1, pos.start - 1);
                    else this._movePosition(pos, true);
                    break;
                case 39:
                    e.preventDefault();
                    if (pos.start == pos.end) this._setSelection(pos.start + 1, pos.start + 1);
                    else this._movePosition(pos, false);
                    break;

                case 36:
                    // Home key 
                    e.preventDefault();
                    if (!this.showDropdown) {
                        var homecate = this._firstlastVal(true);
                        var hPos = this._getCategoryPosition(homecate);
                        if (hPos.isValid) this._setSelection(hPos.start, hPos.end);
                    }
                    else {
                        this._activeItem = 0;
                        prevActiveItem = this._activeItem;
                        this._activeItem = this._disableItemSelectDown(this._activeItem);
                        if (this._activeItem < this._listSize) this._activeItem += 1;
                        else
                            this._activeItem = prevActiveItem;
                        this._addListHover();
                        this._selectTimeItem(this._getActiveItem());
                    }
                    break;
                case 35:
                    // End key
                    e.preventDefault();
                    if (!this.showDropdown) {
                        var endcate = this._firstlastVal(false);
                        var ePos = this._getCategoryPosition(endcate);
                        if (ePos.isValid) this._setSelection(ePos.start, ePos.end);
                    }
                    else {
                        this._activeItem = this._listSize + 1;
                        prevActiveItem = this._activeItem;
                        this._activeItem = this._disableItemSelectUp(this._activeItem - 1);
                        if (this._activeItem == 0) this._activeItem = prevActiveItem;
                        this._addListHover();
                        this._selectTimeItem(this._getActiveItem());
                    }
                    break;
                case 9:
                    if (this._getInternalEvents) break;
                    this._hideResult();
                    var flag = null;
                    if (e.shiftKey && pos.start > 0) flag = true;
                    else if (!e.shiftKey && pos.end < this.element.val().length) flag = false;
                    if (flag != null) {
                        e.preventDefault();
                        this._checkInComplete();
                        this._movePosition(pos, flag);
                    }
                    break;
                case 13:
                    if (!this.showDropdown) {
                        this._raiseChangeEvent();
                        break;
                    }
                case 27:
                    e.preventDefault();
                    this._hideResult();
                    break;
                case 8:
                case 46:
                    if (this.model.enableStrictMode) return;
                    if (this.target.value != this._getSelectedText()) {
                        e.preventDefault();
                        if (category && category != "tt") {
                            this._findCategoryPosition(category);
                            var _doBackspace = (key == 8 && pos.start != this.start), _doDelete = (key == 46 && pos.end != this.end), len;
                            len = this.end - this.start;

                            if ((pos.start != pos.end || len == 1) && (_doBackspace || _doDelete || pos.start != pos.end)) {
                                var s1 = this.start, s2 = this.end, te;
                                this.element[0].value = this._replaceAt(this.target.value, s1, s2, "__");
                                te = (s2 - s1 != 2) ? s2 + 1 : s2;
                                this._setSelection(s1, te);
                            }
                            else {
                                if (_doBackspace) {
                                    this.element[0].value = this._replaceAt(this.target.value, pos.start - 1, pos.start, "");
                                    this._setSelection(pos.start - 1, pos.start - 1);
                                }
                                else if (_doDelete) {
                                    this.element[0].value = this._replaceAt(this.target.value, pos.end, pos.end + 1, "");
                                    this._setSelection(pos.end, pos.end);
                                }
                            }
                        }

                    }
                    break;

            }

            var currSelection = this._getSelectedValue(cursor);
            var unicode = e.keyCode ? e.keyCode : e.charCode, actualkey;

            if (e.keyCode > 47 && e.keyCode < 58)
                actualkey = String.fromCharCode(unicode);
            else if (e.keyCode > 95 && e.keyCode < 106)
                actualkey = String.fromCharCode(unicode - 48);
            if (category == "tt" && ((!e.shiftKey && !e.ctrlKey && !e.altKey) && (e.keyCode > 64 && e.keyCode < 91) || (e.keyCode > 47 && e.keyCode < 58) || (e.keyCode > 95 && e.keyCode < 106))) {
                e.preventDefault();
                var ttPos = this._getCategoryPosition(category);
                this.start = ttPos.start;
                this.end = ttPos.end;
                this._changeAmPm(currSelection);
                this._raiseChangeEvent();
            }

            // Select complete text and then press time value in the textbox               
            if (this.target.value == this._getSelectedText() && (!e.shiftKey && !e.ctrlKey && !e.altKey)) {
                if (e.keyCode > 64 && e.keyCode < 91 && !this.model.enableStrictMode) e.preventDefault();
                if ((e.keyCode > 47 && e.keyCode < 58) || (e.keyCode > 95 && e.keyCode < 106)) {
                    var cursor = this._getStartEnd(pos);
                    this._setSelection(cursor.start, cursor.end);
                }
            }

            if ((!e.shiftKey && !e.ctrlKey && !e.altKey) && (e.keyCode > 47 && e.keyCode < 58) || (e.keyCode > 95 && e.keyCode < 106)) {
                if (category != "tt") {
                    this._getMinMax(category, true);
                    if (pos.start == pos.end) {
                        this._findCategoryPosition(category);
                        var newVal;
                        if (pos.start == this.start) {
                            newVal = actualkey + currSelection;
                            if (this.model.enableStrictMode == false) {
                                this._validateTimes();
                                this._targetBlur();
                            }
                            if (this.model.value == null) this.element.val(this.model.minTime);
                            var cursor = this._getStartEnd(pos);
                            this._setSelection(cursor.start, cursor.end);
                        }
                        else {
                            newVal = currSelection + actualkey;
                        }
                        if (newVal.length > 2 || !(Number(newVal) >= this.min && this.max >= Number(newVal))) {
                            !this.model.enableStrictMode && e.preventDefault();
                        }
                    }
                    else if (!(Number(actualkey) >= this.min && this.max >= Number(actualkey))) {
                        !this.model.enableStrictMode && e.preventDefault();
                    }
                }
            }
            else if (!this._allowKeyCodes(e)) {
                !this.model.enableStrictMode ? (e.keyCode == 8 || e.keyCode == 46) ? e.stopPropagation() : e.preventDefault() : e.stopPropagation();
            }
        },

        _getSelectedText: function (e) {
            if (window.getSelection) {
                var element = $('#' + this.element[0].id).get(0);
                return element.value.substring(element.selectionStart, element.selectionEnd);
            }
                // For IE
            else return document.selection.createRange().text;
        },
        _allowKeyCodes: function (e) {
            if ((e.ctrlKey && (e.keyCode == 65 || e.keyCode == 67 || e.keyCode == 90 || e.keyCode == 89))
                || e.keyCode == 9 || e.keyCode == 116 || e.keyCode == 13)
                return true;
            return false;
        },
        _readOnlyKeys: function (e) {
            if (e.keyCode == 35 || e.keyCode == 36 || e.keyCode == 37 || e.keyCode == 39 || this._allowKeyCodes(e))
                return true;
            return false;
        },

        _firstlastVal: function (initial) {
            var parts = this._getFormatParts(), sep = this.seperator;
            if (initial) {
                if (parts[0] != "tt") return parts[0].split(sep)[0];
                return "tt";
            }
            else {
                if (parts[0] != "tt") return "tt";
                else if (parts[1]) {
                    var lastItem = parts[1].split(sep);
                    return lastItem.length ? lastItem[lastItem.length - 1] : "tt";
                }
                return "tt";
            }
        },

        _mouseWheel: function (event) {
            event.preventDefault();
            if (this.model.readOnly) return false;
            var delta, rawEvent = event.originalEvent;
            if (rawEvent.wheelDelta) {
                // IE and Opera use wheelDelta, which is a multiple of 120 (possible values -120, 0, 120).
                delta = rawEvent.wheelDelta / 120;
                // In Opera, value is negated.
                //if (Sys.Browser.agent === Sys.Browser.Opera) delta = -delta;
            }
            else if (rawEvent.detail) {
                // Firefox uses detail property, which is a multiple of 3.
                delta = -rawEvent.detail / 3;
            }
            if (delta > 0)
                this._modifyValue(true);
            else if (delta < 0)
                this._modifyValue(false);
        },

        _addListHover: function () {
            this._addSelected();
            this._updateScrollTop();
        },
        _addSelected: function () {
            this.ul.find("li").removeClass("e-active e-hover");
            var activeItem = this._getActiveItem();
            if (activeItem.length && !activeItem.hasClass('e-disable'))
                activeItem.addClass('e-active');
        },
        _disableItemSelectDown: function (current) {
            if (current == null || current < 0) current = 0;
            if (current < this._listSize) {
                if ($.inArray(current, this._disabledItems) < 0)
                    return current;
                else
                    return this._disableItemSelectDown(current + 1);
            }
            else return this._listSize;
        },

        _disableItemSelectUp: function (current) {
            current = current - 1;
            if (current == null || current < 0) current = 0;
            if (current < this._listSize) {
                if ($.inArray(current, this._disabledItems) < 0)
                    return current + 1;
                else if (current > 0)
                    return this._disableItemSelectUp(current);
            }
            return 0;
        },
        _getActiveItem: function () {
            return $(this.ul.find("li")[this._activeItem - 1]);
        },

        _timeIconClick: function (event) {
            if (ej.isNullOrUndefined(this.popupList)) {
                this._renderDropdown();
                this._addProperty();
            };
            var isRightClick = false;
            if (event.button)
                isRightClick = (event.button == 2);
            else if (event.which)
                isRightClick = (event.which == 3); //for Opera
            if (isRightClick) return;
            event.preventDefault();
            if (!this.model.enabled || this.model.readOnly || this.ul.find("li").length < 1) return false;
            this._showhidePopup();
            var len = this.element.val().length;
            if (!ej.isTouchDevice()) this._setSelection(len, len);
        },
        _showhidePopup: function () {
            if (this._getInternalEvents) return false;
            if (!this.showDropdown)
                this._showResult();
            else
                this._hideResult();
        },
        _showResult: function () {
            if (this.popupList == null) this._renderDropdown();
            if (this._raiseEvent("beforeOpen")) return false;
            if (!this.focused && (!ej.isTouchDevice())) this._focusElement();
            if (this.model.value) this._changeActiveEle();
            else
                this.ul.find("li").removeClass("e-active");

            var proxy = this, sTop = this._visibleAndCalculateTop();
            this.popupList.slideDown(this.model.enableAnimation ? 200 : 0, function () {
                $(document).on("mousedown", $.proxy(proxy._OnDocumentClick, proxy));
            });
            this.scrollerObj.setModel({ "scrollTop": sTop });
            this.showDropdown = true;
            this._listSize = this.ul.find("li").length;
            $(window).on("resize", $.proxy(this._OnWindowResize, this));
            this._on(ej.getScrollableParents(this.wrapper), "scroll", this._hideResult);
            this._on(ej.getScrollableParents(this.wrapper), "touchmove", this._hideResult);
            this._raiseEvent("open");
            this.wrapper.addClass("e-active");
        },
        _hideResult: function (e) {
            if (this._raiseEvent("beforeClose")) return false;
			if ( e && (e.type == "touchmove" || e.type== "scroll")) {
				if ($(e.target).parents("#"+this.popupList[0].id).length > 0)
			   return;
			}           
			if (this.showDropdown && !this._getInternalEvents) {
			this.showDropdown = false;
			this.popupList.slideUp(this.model.enableAnimation ? 100 : 0);
			$(document).off("mousedown", $.proxy(this._OnDocumentClick, this));
			$(window).off("resize", $.proxy(this._OnWindowResize, this));
			this._off(ej.getScrollableParents(this.wrapper), "scroll", this._hideResult);
			this._off(ej.getScrollableParents(this.wrapper), "touchmove", this._hideResult);
			this._raiseEvent("close");
			this.wrapper.removeClass("e-active");
            }
        },

        _visibleAndCalculateTop: function () {
            this.popupList.css({ "display": "block" });
            var scrollTop = this._calcScrollTop();
			this._refreshPopup();
            this.popupList.css({ "display": "none" });
            return scrollTop;
        },
        _calcScrollTop: function () {
            var ulH = this.ul.outerHeight(), liH = this.ul.find("li").outerHeight(), index, top;
            index = this.ul.find("li.e-active").index();
            top = (liH * index) - ((this.popupList.outerHeight() - liH) / 2);
            return top;
        },
        _changeActiveEle: function () {
            if (!this.popupList) return false;
            var elements = this.ul.find("li");
            var currTime = this.element.val(), firstTime = elements.first().html(), index;
            index = (this._parse(currTime) - this._parse(firstTime)) / (this.model.interval * 60000);
            index = Math.round(index);
            this._activeItem = (index == elements.length) ? index : index + 1;
            if (this._activeItem < 0 || this._activeItem > elements.length || isNaN(this._activeItem) || this._ensureTimeRange(currTime)) this._activeItem = 0;
            this._addListHover();
        },

        _OnDocumentClick: function (e) {
            if (!$(e.target).is(this.popupList) && !$(e.target).parents(".e-time-popup").is(this.popupList) &&
                !$(e.target).is(this.wrapper) && !$(e.target).parents(".e-timewidget").is(this.wrapper)) {
                this._hideResult();
            }
            else if ($(e.target).is(this.popupList) || $(e.target).parents(".e-time-popup").is(this.popupList))
                e.preventDefault();
        },
        _OnWindowResize: function (e) {
            this._refreshPopup();
        },

        _OnMouseEnter: function (e) {
            var targetEle = e.target;
            this.ul.find("li").removeClass("e-hover");
            if (!$(targetEle).hasClass('e-disable'))
                $(targetEle).addClass("e-hover");
        },
        _OnMouseLeave: function (e) {
            if (!this._dateTimeInternal || this.model.value)
                this.ul.find("li").removeClass("e-hover");
        },
        _OnMouseClick: function (e) {
            e.preventDefault();
            if ($(e.target).hasClass('e-disable')) return;
            if (this.model.enabled && !this.model.readOnly) {
                this._activeItem = $(e.target).index() + 1;
                this.ul.find("li").attr({ 'tabindex': -1, 'aria-selected': false });
                $(e.target).attr({ 'aria-selected': true, 'tabindex': 0 });
                this._addSelected();
                this._selectTimeItem($(e.target));
            }
            this._showhidePopup();
        },
        _selectTimeItem: function (ele) {
            this._beforeChange(ele);
            var flag = this._raiseChangeEvent();
            if (flag)
                this._trigger("select", { value: this.model.value, prevTime: this._previousValue });
        },

        _findCategoryPosition: function (category) {
            if (category == "least") category = this._getLeast(true);
            var pos = this._getCategoryPosition(category);
            this.start = pos.start;
            this.end = pos.end;
        },

        _getLeast: function (lower) {
            var formats = this._getFormatParts(), sep = this.seperator, res = null;
            $(formats).each(function (i, e) {
                if (e != "tt") {
                    var times = e.split(sep);
                    if (lower) res = times[times.length - 1];
                    else res = times[0];
                }
            });
            return res;
        },

        _changeValue: function (cursor, isIncrement) {
            var preVal = this.target.value, currValue, category = this._getCategory(cursor);
            if (!category) return false;
            this._setSelection(this.start, this.end);
            currValue = this.target.value.substring(this.start, this.end);
            if (this._checkMinMax(this.target.value)) {
                if (currValue != this.ttAM && currValue != this.ttPM) {
                    currValue = this._changeCurrentValue(currValue, category, isIncrement);
                    if (category.length != 1) currValue = this._changeWhole(currValue);
                    this._findCategoryPosition(category);
                    this.element.val(this._replaceAt(this.target.value, this.start, this.end, currValue));
                    this.end = this.start + currValue.toString().length;
                    this._setSelection(this.start, this.end);
                    if (this._ensureTimeRange(this.target.value) && this._checkMinMax(this.target.value)) {
                        var timeObject = this._createObject(this.target.value);
                        var hour = timeObject.getHours();
                        var fromTime = isIncrement ? this._startTime : this._endTime;
                        var toTime = isIncrement ? this._endTime : this._startTime;
                        if (!ej.isNullOrUndefined(this.model.disableTimeRanges)) {
                            for (var i = 0; i < this.model.disableTimeRanges.length; i++) {
                                if ((fromTime[i].getHours() === hour) || ((+timeObject >= +this._startTime[i]) && +timeObject <= +this._endTime[i])) {
                                    this.target.value = this._localizeTime(toTime[i]);
                                    this._findCategoryPosition(category);
                                    this._setSelection(this.start, this.end);
                                    this._changeValue(cursor, isIncrement);
                                }
                            }
                        }
                    }
                }
                else this._changeAmPm(currValue);
            }
            else {
                var timeValue = this._checkExceedRange(this.target.value);
                this._setTime(this.model[timeValue]);
                this._findCategoryPosition(category);
                this._setSelection(this.start, this.end);
            }
            if (!this._checkMinMax(this.target.value)) {
                this.element.val(this.model.value);
                this._findCategoryPosition(category);
                this._setSelection(this.start, this.end);
            }
            else this._raiseChangeEvent();
        },

        _checkMinMax: function (value) {
            var res = this._checkExceedRange(value);
            if (res == null) res = false;
            return !res;
        },
        _checkExceedRange: function (value) {
            if (value) {
                if (this.model.minTime && !this._compareTime(value, this.model.minTime, true)) return "minTime";
                if (this.model.maxTime && !this._compareTime(this.model.maxTime, value, true)) return "maxTime";
            }
            return null;
        },

        _changeWhole: function (currValue) {
            return currValue > 9 ? "" + currValue : "0" + currValue;
        },
        _changeAmPm: function (ampm) {
            ampm = ampm == this.ttAM ? this.ttPM : this.ttAM;
            this.element.val(this._replaceAt(this.target.value, this.start, this.end, ampm));
            this._setSelection(this.start, this.end);
        },
        _changeMinute: function (isIncrement) {
            var formats = ["mm", "m"];
            var currFormat = this._getExactFormat(formats);
            if (currFormat) {
                this._findCategoryPosition(currFormat);
                var minute = Number(this.target.value.substring(this.start, this.end));
                this._getMinMax(currFormat);
                if (isIncrement) {
                    if (minute == this.max) {
                        minute = this.min;
                        this._changeHour(isIncrement);
                    }
                    else minute += 1;
                }
                else {
                    if (minute == this.min) {
                        minute = this.max;
                        this._changeHour(isIncrement);
                    }
                    else minute -= 1;
                }
                this._findCategoryPosition(currFormat);
                if (currFormat.length != 1) minute = this._changeWhole(minute);
                this.element.val(this._replaceAt(this.target.value, this.start, this.end, minute));
            }
        },
        _changeHour: function (isIncrement) {
            var formats = ["hh", "h", "HH", "H"];
            var currFormat = this._getExactFormat(formats);
            if (currFormat) {
                this._findCategoryPosition(currFormat);
                var hour = Number(this.target.value.substring(this.start, this.end));
                this._getMinMax(currFormat);
                if (isIncrement) {
                    if (hour == this.max) {
                        hour += 1;
                        this._changeMeridian();
                    }
                    else if (hour > this.max) hour = this.min;
                    else hour += 1;
                }
                else {
                    if (hour == this.min) hour = this.max + 1;
                    else if (hour > this.max) {
                        hour = this.max;
                        this._changeMeridian();
                    }
                    else hour -= 1;
                }
                this._findCategoryPosition(currFormat);
                if (currFormat.length != 1) hour = this._changeWhole(hour);
                this.element.val(this._replaceAt(this.target.value, this.start, this.end, hour));
            }
        },
        _getExactFormat: function (cate) {
            var tFormat = this.model.timeFormat;
            for (var i = 0; i < cate.length; i++) {
                if (tFormat.indexOf(cate[i]) != -1) return cate[i];
            }
            return null;
        },
        _changeMeridian: function () {
            var start = this.model.timeFormat.indexOf("tt");
            if (start != -1) {
                this._findCategoryPosition("tt");
                var meridian = this.target.value.substring(this.start, this.end);
                meridian = (meridian == this.ttAM) ? this.ttPM : this.ttAM;
                this.element.val(this._replaceAt(this.target.value, this.start, this.end, meridian));
            }
        },
        _changeCurrentValue: function (current, category, isIncrement) {
            current = Number(current);
            var c = category, step = 1, change = true;
            this._getMinMax(c);

            if (c == "hh" || c == "h" || c == "HH" || c == "H") step = this.model.hourInterval;
            else if (c == "mm" || c == "m") step = this.model.minutesInterval;
            else if (c == "ss" || c == "s") step = this.model.secondsInterval;
            if (step <= 0) return current;

            if (isIncrement) {
                if ((c == "hh" || c == "h") && current > this.max) current = this.min - 1 + step;
                else if (current < this.max) current += step;
                else {
                    change = false;
                    if (c != "hh" && c != "h") current = this.min - 1 + step;
                    else current += step;
                    this._changeAdjacent(c, isIncrement);
                }
                if ((c == "hh" || c == "h") && current == this.max + 1)
                    change && this._changeAdjacent(c, isIncrement);
                else if (current > this.max + 1) {
                    current = current - (this.max + 1);
                    change && this._changeAdjacent(c, isIncrement);
                }
                if ((c != "hh" && c != "h") && current == this.max + 1) {
                    current = this.min;
                    change && this._changeAdjacent(c, isIncrement);
                }
            }
            else {
                if ((c != "hh" && c != "h") && current > this.min) current -= step;
                else if ((c == "hh" || c == "h") && current > this.min && current <= this.max) current -= step;
                else if ((c == "hh" || c == "h") && current == this.min) current = this.max + 2 - step;
                else {
                    change = false;
                    current = this.max + 1 - step;
                    this._changeAdjacent(c, isIncrement);
                }
                if (current < this.min) {
                    current = current + (this.max + 1);
                    change && this._changeAdjacent(c, isIncrement);
                }
            }
            return current;
        },
        _changeAdjacent: function (c, isIncrement) {
            if (c == "ss" || c == "s") this._changeMinute(isIncrement);
            else if (c == "mm" || c == "m") this._changeHour(isIncrement);
            else if (c == "hh" || c == "h" || c == "HH" || c == "H") this._changeMeridian();
        },

        _valueChange: function (e) {
            this._raiseChangeEvent();
        },

        _beforeChange: function (ele) {
            if (!this._raiseEvent("beforeChange")) {
                this.element.val(ele.text());
            }
            return true;
        },

        _raiseChangeEvent: function (prev, isCode) {
            prev = (prev === undefined) ? this.model.value : prev;
            this._previousValue = prev;
            var current = !this.target.value ? null : this.target.value;
            if (prev == current) return false;
            if (this._checkMinMax(this.target.value) && this._isValid(this.target.value, this.model.enableStrictMode) || !this.target.value) this.isValidState = true;
            else this.isValidState = false;
            this.model.value = this._isValid(this.target.value, true) && this._checkMinMax(this.target.value) ? this.target.value : null;
            if (!this.model.value && !this.model.enableStrictMode) this._setTime(this.model.value);
            if (this.model.value == this._previousValue) return false;
            this._raiseEvent("change", isCode);
            this._raiseEvent("_change", isCode);
            return true;
        },
        _raiseEvent: function (name, isCode) {
            var data = { value: this.model.value, prevTime: this._previousValue };
            if (name == "change") data.isInteraction = !isCode;
            return (this._trigger(name, data));
        },
        _checkIE7: function () {
            if (navigator.appName == 'Microsoft Internet Explorer') {
                var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})"), version = -1;
                if (re.exec(navigator.userAgent) != null)
                    version = parseFloat(RegExp.$1);
                if (version >= 7 && version < 8) return true;
            }
            return false;
        },
        _replaceAt: function (mainString, from, to, replace) {
            return mainString.substring(0, from) + replace + mainString.substring(to);
        },
        _localizeTime: function (value) {
            if (value)
                return $.trim(ej.format(this._createObject(value), this.model.timeFormat, this.model.locale));
            return null;
        },
        _localizeMeridian: function (value) {
            return $.trim(ej.format(value, "tt", this.model.locale));
        },
        _compareTime: function (time1, time2, orEqual) {
            orEqual = (!orEqual) ? false : true;
            if (orEqual) return this._parse(time1) >= this._parse(time2);
            else return this._parse(time1) > this._parse(time2);
        },
        _isValid: function (time, validate) {
            time = this._createObject(time, validate);
            return time && typeof time.getTime === "function" && isFinite(time.getTime());
        },
        _parse: function (time) {
            return Date.parse(this._createObject(time));
        },
        _setEmptyDate: function (date) {
            var newDate = new Date(date);
            newDate.setDate(1);
            newDate.setMonth(0);
            newDate.setFullYear(2000);
            return newDate;
        },
        _createObject: function (value, validate) {
            var obj = null;
            if (typeof value === "string") {
                var format = this._setModelOption ? this._preTimeformat : this.model.timeFormat;
                var dateFormat = ej.preferredCulture(this.model.locale).calendar.patterns.d;
                var dateValue = ej.format(new Date("1/1/2000"), dateFormat, this.model.locale);
                obj = ej.parseDate(dateValue + " " + value, dateFormat + " " + format, this.model.locale);
                if (this._extISORegex.exec(value) || this._basicISORegex.exec(value)) this.model.value = obj = this._timeFromISO(value);
                this._setModelOption = false;
                if (!obj) {
                    var isJSONString = new Date(value);
                    if (!isNaN(Date.parse(isJSONString)) && !ej.isNullOrUndefined(value))
                        obj = this._setEmptyDate(value);
                    else
                        obj = !this._dateTimeInternal || value == "" ? null : new Date("1/1/2000 " + value);
                }
            }
            else if (typeof value === "number")
                obj = new Date(value);
            else if (value instanceof Date)
                obj = this._setEmptyDate(value);

            if (obj && !this._dateTimeInternal && validate) {
                var timeVal = this._localizeTime(obj);
                if (this._ensureTimeRange(timeVal))
                    obj = null;
            }
            return obj;
        },
        _getLocalizedLabels: function () {
            return ej.getLocalizedConstants(this.sfType, this.model.locale);
        },

        _wireEvents: function () {
            this._on(this.element, "focus", this._targetFocus);
            this._on(this.element, "blur", this._targetBlur);
            this._on(this.element, "mousedown", this._mouseDownOnInput);
            this._on(this.element, "keydown", this._keyDownOnInput);
            this._on(this.element, "keyup", this._keyUpOnInput);
        }
    });
    ej.TimePicker.Locale = ej.TimePicker.Locale || {};

    ej.TimePicker.Locale['default'] = ej.TimePicker.Locale['en-US'] = {
        watermarkText: "select a time",
    };
    
})(jQuery, Syncfusion);;
/// <reference path="../../common/jquery.d.ts" />
/// <reference path="../../ej.web.all.d.ts" />
"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};

var ejDateRangePicker = (function (_super) {
    __extends(ejDateRangePicker, _super);
    function ejDateRangePicker(element, options) {
        _super.call(this);
        this._rootCSS = "e-daterangepicker";
        this._isApplied = true;
        this._setFirst = false;
        this.PluginName = "ejDateRangePicker";
        this.id = "myDateRange";
        this._addToPersist = ["value"];
        this.type = "editor";
        this.angular = {
            require: ['?ngModel', '^?form', '^?ngModelOptions'],
            requireFormatters: true
        };
        this._requiresID = true;
        this.model = null;
        this.validTags = ["input"];
        this.defaults = {
            height: "",
            width: "",
			isResponsive:false,
            value: "",
            cssClass: "",
            enabled: true,
            startDate: null,
            endDate: null,
            enableTimePicker: false,
            backwardSelection: false,
            minDate: new Date("01/01/1900"),
            maxDate: new Date("12/31/2099"),
            ranges: null,
            locale: "en-US",
            separator: "-",
            watermarkText: "Select Range",
            dateFormat: "",
            timeFormat: "",
            showPopupButton: true,
            showRoundedCorner: false,
            allowEdit: true,
            enablePersistence: false,
            create: null,
            change: null,
            beforeClose: null,
            beforeOpen: null,
            close: null,
            open: null,
            hover: null,
            click: null,
            clear: null,
            destroy: null,
			select: null,
			htmlAttributes: {},

        };
        this._isIE8 = (ej.browserInfo().name == "msie") && (ej.browserInfo().version == "8.0") ? true : false;
        this._prevValue = null;
        this._validState = null;
        ejDateRangePicker.prototype.observables = ["value"];
        if (element) {
            if (!element["jquery"]) {
                element = $("#" + element);
            }
            if (element.length) {
                return $(element).ejDateRangePicker().data(this.PluginName);
            }
        }
    }
    ejDateRangePicker.prototype.setModel = function (opt, forceSet) {
        this.setModel(opt, forceSet);
    };
    ejDateRangePicker.prototype.option = function (opt, forceSet) {
        this.option(opt, forceSet);
    };

    ejDateRangePicker.prototype._setModel = function (options) {
        var option;
        for (option in options) {
            switch (option) {
                case "allowEdit":
                    if (!options[option]) {
                        this.element.attr("readonly", "readonly");
                        this.element.on("mousedown", $.proxy(this._showDatePopUp, this));
                        this.element.off("blur", $.proxy(this._onMainFocusOut, this));
                    }
                    break;
                case "startDate":
                    var status = this._validateValues(options[option], "left");
                    if (status == false)
                        options[option] = null;
                    else {
                        if (!this._startEndValidation() && this.model.endDate != null) {
                            this._resetValues();
                            this.model.endDate = null;
                        }
                        this._updateValues();
                        this._selectedStartDate = this.model.startDate;
                        options[option] = this.model.startDate;
                    }

                    break;
                case "endDate":
                    var status = this._validateValues(options[option], "right");
                    if (status == false)
                        options[option] = null;
                    else {
                        if (!this._startEndValidation()) {
                            this._rightDP.element.parents(".e-datewidget").addClass("e-val-error");
                            this.model.endDate = null;
                        }
                        this._updateValues();
                        options[option] = this.model.endDate;
                    }
                    break;
                case "minDate":
                    if (this._leftDP)
                        this._leftDP.option(option, options[option]);
                    if (this._rightDP)
                        this._rightDP.option(option, options[option]);
                    this._updateInput();
                    break;
                case "maxDate":
                    if (this._leftDP)
                        this._leftDP.option(option, options[option]);
                    if (this._rightDP)
                        this._rightDP.option(option, options[option]);
                    this._updateInput();
                    break;
                case "enableTimePicker":
                    this.model.enableTimePicker = options[option];
                    if (options[option]) {
                        this._renderTimePicker();
                    } else
                        this._removeTimePicker();
                    if (this._scrollerObj) {
                        this._scrollerObj.model.height = this.datePopup.height();
                        this._scrollerObj.refresh();
                    }
                    break;
                case "backwardSelection":
                    this.model.backwardSelection = options[option];
                    this._mainValue();
                    break;    
                case "locale":
                    this._setCulture(options[option]);
                    options[option] = this.model.locale;
                    break;
                case "separator":
                    this.model.separator = options[option];
                    this._mainValue();
                    break;
                case "dateFormat":
                    if (this._leftDP)
                        this._leftDP.option(option, options[option]);
                    if (this._rightDP)
                        this._rightDP.option(option, options[option]);
                    this.model.dateFormat = options[option];
                    this._getDateTimeFormat();
                    this._updateInput();
                    break;
                case "timeFormat":
                    if (this._leftTP)
                        this._leftTP.option(option, options[option]);
                    if (this._rightTP)
                        this._rightTP.option(option, options[option]);
                    this.model.timeFormat = options[option];
                    this._getDateTimeFormat();
                    this._updateInput();
                    break;
                case "watermarkText":
                    if (ej.isNullOrUndefined(this._options))
                        this._options = {};
                    this._options["watermarkText"] = this.model.watermarkText = options[option];
                    this._localizedLabels.watermarkText = this.model.watermarkText;
                    this._setWaterMark();
                    break;
                case "cssClass":
                    this._changeSkin(options[option]);
                    break;

                case "showRoundedCorner":
                    this._setRoundedCorner(options[option]);
                    break;
                case "showPopupButton":
                    this._renderDateIcon(options[option]);
                    break;

                case "value":
                    this.element.val(options[option]);
                    this._onMainFocusOut();
                    options[option] = this.model.value;
                    break;

                case "height":
                    this.wrapper.height(options[option]);
                    break;
                case "width":
                    this.wrapper.width(options[option]);
                    break;
                case "enabled":
                    if (options[option])
                        this.enable();
                    else
                        this.disable();
                    break;
                case "htmlAttributes":
                    this._addAttr(options[option]);
                    break;
            }
        }
    };
    ejDateRangePicker.prototype._init = function (options) {
        this._cloneElement = this.element.clone();
        this._options = options;
        this._flagevents = false;
        this._id = this.element.attr("id");
        this._isSupport = document.createElement("input").placeholder == undefined ? false : true;
		if (!this._startEndValidation()) this.model.endDate = null;
        if (this.element.val() == "" && this.model.value) {
            this.element.val(this.model.value);
        }
		this._getDateTimeFormat();
        if (this.element.val()) {
            this._setInitValue();
            this._updateValues();
        }
		else if (this.model.startDate != null && this.model.endDate != null && this._startEndValidation()) 
		{
        this._updateValues();			
		this._mainValue();
        }
        this._prevStartDate = this.model.startDate;
        this._prevEndDate = this.model.endDate;
        this._createWrapper();
		this.renderpopup();
        this._setLocalizedText();
        if (this._validState == false && this.element.val())
            this.wrapper.addClass("e-error");
        this._popupOpen = false, this._isPopScroll = false;
        if (!this.model.enabled) this.disable();
        this._wireEvents();
        if(this.model.startDate && !this._selectedStartDate) { this._selectedStartDate = this.model.startDate}
        if(this.model.endDate && !this._selectedEndDate) { this._selectedEndDate = this.model.endDate}
        };
    ejDateRangePicker.prototype._setInitValue = function () {
        var datestring = this.element.val().split(this.model.separator), _startdate = ej.parseDate(datestring[0], this._dateTimeFormat, this.model.locale), _enddate = ej.parseDate(datestring[1], this._dateTimeFormat, this.model.locale);
        if (_startdate && _enddate) {
            this.model.startDate = _startdate;
            this.model.endDate = _enddate;
        }
        if (this.model.startDate < new Date(this.model.minDate) || this.model.startDate > new Date(this.model.maxDate)) this.model.startDate = new Date(this.model.minDate);
        if (this.model.endDate > new Date(this.model.maxDate) || this.model.endDate < new Date(this.model.minDate)) this.model.endDate = new Date(this.model.maxDate);
    };
    ejDateRangePicker.prototype._getNextMonth = function (current) {
        var local = current;
        if (!(local instanceof Date))
            return new Date();
        var month = local.getMonth();
        if (month == 11) {
            var year = local.getFullYear() + 1;
            month = -1;
        } else
        var year = local.getFullYear();
    var dummy = new Date();
    dummy = new Date(dummy.setFullYear(year));
    dummy = new Date(dummy.setDate(1));
    dummy = new Date(dummy.setMonth(month + 1));
    if (dummy > new Date(this.model.maxDate))
        dummy = new Date(dummy.setMonth(month));
    if (new Date(this.model.minDate).getFullYear() == new Date(this.model.maxDate).getFullYear()) {
        if (new Date(this.model.minDate).getMonth() == new Date(this.model.maxDate).getMonth())
            dummy = new Date(dummy.setDate(new Date(this.model.minDate).getDate()));
    }
    return dummy;
};
    ejDateRangePicker.prototype._getDateTimeFormat = function () {
        var pattern = ej.preferredCulture(this.model.locale).calendars.standard.patterns;
        if (!this.model.dateFormat) this.model.dateFormat = pattern.d;
        if (this.model.enableTimePicker) {
            if (!this.model.timeFormat) this.model.timeFormat = pattern.t;
            this._dateTimeFormat = this.model.dateFormat + " " + this.model.timeFormat;
        }
        else
            this._dateTimeFormat = this.model.dateFormat;
    };
    ejDateRangePicker.prototype._setValues = function () {
        this._leftDP.option("value", this.model.startDate);
        this._rightDP.option("value", this.model.endDate || null);
        if (this.model.startDate) this._setStartDate(this.model.startDate, $('.current-month[data-date="' + this.model.startDate.toDateString() + '"]'), true);
        if (this.model.endDate) this._setEndDate(this.model.endDate, $('.current-month[data-date="' + this.model.endDate.toDateString() + '"]'), true);
        this._rangeRefresh(this._setArgs(this._leftDP.popup));
        this._rangeRefresh(this._setArgs(this._rightDP.popup));
        this._rightDP.element.parents(".e-datewidget").removeClass("e-error");
        if (this.model.enableTimePicker) {
            this._leftTP.option("value", this.model.startDate);
            this._rightTP.option("value", this.model.endDate);
        }
        this._updateRanges("left");
        this._updateRanges("right");
    };

    ejDateRangePicker.prototype._customSet = function () {
        this._selectedStartDate = this.model.startDate;
        this._selectedEndDate = this.model.endDate;
        this._resetValues();
        if (this.popup && this.datePopup) this._setValues();
        if (!this._popupOpen)
            this._mainValue();
        this._refreshMinMax();
        this._setWaterMark();
    };
    ejDateRangePicker.prototype._setCulture = function (culture) {
        culture = ej.preferredCulture(culture).name;
        this.model.locale = culture;
        this._setOption("locale", culture);
        this._localizedLabels = this._getLocalizedLabels();
        this._setLocalizedText();
        this._updateInput();
    };
    ejDateRangePicker.prototype._setRoundedCorner = function (boolean) {
        if (boolean) {
            this._input_innerWrapper.addClass("e-corner");
            if (this.popup) this.popup.addClass("e-corner");
        } else {
            this._input_innerWrapper.removeClass("e-corner");
            if (this.popup) this.popup.removeClass("e-corner");
        }
        this._setOption("showRoundedCorner", boolean);
    };
    ejDateRangePicker.prototype._renderDateIcon = function (boolean) {
        if (boolean) {
            this.dateRangeIcon = ej.buildTag("span.e-select#" + this.id + "-img", "", {}, (this._isIE8) ? { 'unselectable': 'on' } : {}).append(ej.buildTag("span.e-icon e-calendar", "", {}, { 'aria-label': 'Select' }).attr((this._isIE8) ? { 'unselectable': 'on' } : {})).insertAfter(this.element);
            this._input_innerWrapper.addClass('e-padding');
            this._on(this.dateRangeIcon, "mousedown", this._showDatePopUp);
            this._off(this.dateRangeIcon, "click", this._showDatePopUp);

        }
        else {
            if (this.dateRangeIcon) {
                this.dateRangeIcon.remove();
            }
            this._input_innerWrapper.removeClass('e-padding');
            this._off(this.dateRangeIcon, "click", this._showDatePopUp);
        }
    },
	ejDateRangePicker.prototype._validateValues = function (val, cal_type ,isTimePicker) {
        var obj = cal_type == "right" ? this._rightDP : this._leftDP;
        var time_Type = cal_type == "right" ? this._rightTP : this._leftTP;
        if (isTimePicker) {
            if(time_Type && time_Type._preVal && time_Type._preVal == val){
                return true;
            }
        } else {
            if(cal_type == "left" && obj && this._selectedStartDate && this._selectedStartDate.getFullYear() == new Date(val).getFullYear() && this._selectedStartDate.getMonth() == new Date(val).getMonth() && this._selectedStartDate.getDate() == new Date(val).getDate()
            && this._selectedStartDate.getHours() == new Date(val).getHours() && this._selectedStartDate.getMinutes() == new Date(val).getMinutes()){
                return true;
            }
            if(cal_type == "right" && obj && this._selectedEndDate && this._selectedEndDate.getFullYear() == new Date(val).getFullYear() && this._selectedEndDate.getMonth() == new Date(val).getMonth() && this._selectedEndDate.getDate() == new Date(val).getDate() 
            && this._selectedEndDate.getHours() == new Date(val).getHours() && this._selectedEndDate.getMinutes() == new Date(val).getMinutes()){
                return true;
            }
        }
	    var datavalu = val;
	    if (datavalu != null && typeof datavalu == "string") {
            if (cal_type == "left") {
                if (this.model.enableTimePicker) {
                    if (isTimePicker) {
                        var dateValue = ej.format(this._leftDP.model.value, this.model.dateFormat, this.model.locale);
                        this.model.startDate = ej.parseDate(dateValue + " " + val, this.model.dateFormat + " " + this.model.timeFormat, this.model.locale) || null;
                    } else {
                        this.model.startDate = ej.parseDate(val + " " + this._leftTP.model.value, this.model.dateFormat + " " + this.model.timeFormat, this.model.locale) || null;
                    }
                }
                else {
                    this.model.startDate = ej.parseDate(val, this.model.dateFormat, this.model.locale) || null;
                }
                this.model.startDate = (this.model.startDate != null) ? this.model.startDate : new Date(datavalu);
            }
            else {
                if (this.model.enableTimePicker) {
                    if (isTimePicker) {
                        var dateValue = ej.format(this._rightDP.model.value, this.model.dateFormat, this.model.locale);
                        this.model.endDate = ej.parseDate(dateValue + " " + val, this.model.dateFormat + " " + this.model.timeFormat, this.model.locale) || null;
                    } else {
                        this.model.endDate = ej.parseDate(val + " " + this._rightTP.model.value, this.model.dateFormat + " " + this.model.timeFormat, this.model.locale) || null;
                    }
                }
                else {
                    this.model.endDate = ej.parseDate(val, this.model.dateFormat, this.model.locale) || null;
                }
                this.model.endDate = (this.model.endDate != null) ? this.model.endDate : new Date(datavalu);
            }
	    } else {
	        if (val instanceof Date) {
	            if (cal_type == "left") {
	                this.model.startDate = val;
	                if (!isNaN(val.getDate())) {
	                    if (typeof this._formatter(this.model.startDate, this.model.locale) != "string")
	                        this.model.startDate = ej.parseDate(this._formatter(this.model.startDate, this.model.locale), this.model.dateFormat);
	                } else
	                    return false;
	            } else if (cal_type == "right") {
	                this.model.endDate = val;
	                if (!isNaN(val.getDate())) {
	                    if (typeof this._formatter(this.model.endDate, this.model.locale) != "string")
	                        this.model.endDate = ej.parseDate(this._formatter(this.model.endDate, this.model.locale), this.model.dateFormat);
	                } else
	                    return false;
	            }
	        } else
	            return false;
	    }
	    return true;
	};
    //Date formatter - Convert date object to specific date format
    ejDateRangePicker.prototype._formatter = function (date, format) {
        var newFormat = this._checkFormat(format);
        return ej.format(date, newFormat, this.model.locale);
    };

    ejDateRangePicker.prototype._checkFormat = function (format) {
        var proxy = this;
        var dateFormatRegExp = this._regExp();
        return format.replace(dateFormatRegExp, function (match) {
            match = match === "/" ? ej.preferredCulture(proxy.model.locale).calendars.standard['/'] !== "/" ? "'/'" : match : match;
            return match;
        });
    };
    ejDateRangePicker.prototype._regExp = function () {
        return /\/dddd|ddd|dd|d|MMMM|MMM|MM|M|yyyy|yy|HH|H|hh|h|mm|m|fff|ff|f|tt|ss|s|zzz|zz|z|gg|g|"[^"]*"|'[^']*'|[/]/g;
    };

    ejDateRangePicker.prototype._setArgs = function (element) {
        var date = new Date($(element.find(".current-month")[0]).attr("data-date"));
        this.args = {};
        this.args.element = element;
        this.args.month = date.getMonth();
        this.args.year = date.getFullYear();
        return this.args;
    };
    ejDateRangePicker.prototype._changeSkin = function (skin) {
        this.wrapper.removeClass(this.model.cssClass).addClass(skin);
        this.popup.removeClass(this.model.cssClass).addClass(skin);

        this._setOption("cssClass", skin);
    };

    ejDateRangePicker.prototype._renderDatePicker = function () {
        this.calendar_left = ej.buildTag("input.leftDate_wrapper#" + this.element[0].id + "leftDate_wrapper", "", {}, { "type": "text" });
        this._leftDiv.append(this.calendar_left);
        this.calendar_right = ej.buildTag("input.rightDate_wrapper#" + this.element[0].id + "rightDate_wrapper", "", {}, { "type": "text" });
        this._rightDiv.append(this.calendar_right);
        var proxy = this;
        var DPSettings = {
            displayInline: true,
            showFooter: false,
            watermarkText: "",
            enableStrictMode: true,
            locale: this.model.locale,
            dateFormat: this.model.dateFormat,
            _month_Loaded: function (e) {
                proxy._previousNextHandler(e);
            },
            focusOut: function(e){
                if (e.prevDate != e.value) {
                    proxy._isApplied = false;
                }
            },
            enablePersistence: this.model.enablePersistence,
            minDate: this.model.minDate,
            maxDate: this.model.maxDate,
        }
        this.calendar_left.ejDatePicker(DPSettings);
        this.calendar_left.ejDatePicker("option", "layoutChange", function (e) {
            proxy._refreshEvents("left");
            proxy._updateRanges("left");
            if (!proxy.popup.hasClass("e-daterange-responsive")) {
                if (proxy._scrollerObj) {
                    proxy._scrollerObj.model.height = proxy.datePopup.height();
                    proxy._scrollerObj.refresh();
                }
            }
        })
        this._leftDP = this.calendar_left.data("ejDatePicker");
        this._leftDP.option("showPopupButton", false);
        this._leftDP._getInternalEvents = true, this._leftDP._DRPdisableFade = true;
        this._leftDP.popup.css({ "position": "static", "visibility": "inherit" });
        this.calendar_right.ejDatePicker(DPSettings);
        this.calendar_right.ejDatePicker("option", "layoutChange", function (e) {
            proxy._refreshEvents("right");
            proxy._updateRanges("right");
            if (!proxy.popup.hasClass("e-daterange-responsive")) {
                if (proxy._scrollerObj) {
                    proxy._scrollerObj.model.height = proxy.datePopup.height();
                    proxy._scrollerObj.refresh();
                }
            }
        })
        this._rightDP = this.calendar_right.data("ejDatePicker");
        this._rightDP.option("showPopupButton", false);
        this._rightDP._getInternalEvents = true, this._rightDP._DRPdisableFade = true; // to get the layout change client side event
        this._rightDP.popup.css({ "position": "static", "visibility": "inherit" });
        this._on($(this._leftDP.sfCalendar.find('table .e-datepicker-months td')), "click", $.proxy(this._previousNextHandler, this));
        this._on(this._leftDP.element, "keydown", this._onKeyDown);
        this._on(this._rightDP.element, "keydown", this._onKeyDown);
    };

    ejDateRangePicker.prototype._renderPopup = function () {
		if (!this.popup) {
			this.popup = ej.buildTag("div.e-daterangepicker-popup e-popup e-widget e-box" + this.model.cssClass + "#" + this.element[0].id + "_popup").css("display", "none");
			$('body').append(this.popup);
		}
        this.datePopup = ej.buildTag("div.e-datepickers-popup");
        this.popup.append(this.datePopup);
        this._leftDiv = ej.buildTag("div.e-left-datepicker");
        this._rightDiv = ej.buildTag("div.e-right-datepicker");
        this.datePopup.append(this._leftDiv);
        this.datePopup.append(this._rightDiv);
        this._renderDatePicker();
        if (this.model.ranges && !this._customRangePicker)
            this._renderRanges();
        if (this.model.enableTimePicker)
            this._renderTimePicker();
        this._renderButton();
        this._bindDateButton();
        this._refreshEvents("left");
        this._refreshEvents("right");
        this._updateRanges("left");
        this._updateRanges("right");
        this._setRoundedCorner(this.model.showRoundedCorner);
        this._addAttr(this.model.htmlAttributes);
        this._on(this.popup.find(".leftDate_wrapper.e-datepicker.e-js.e-input"), "blur", this._onPopupFocusOut);
        this._on(this.popup.find(".rightDate_wrapper.e-datepicker.e-js.e-input"), "blur", this._onPopupFocusOut);
        this._on(this.popup.find(".leftTime.e-timepicker.e-js.e-input"), "blur", this._onPopupFocusOut);
        this._on(this.popup.find(".rightTime.e-timepicker.e-js.e-input"), "blur", this._onPopupFocusOut);
        this.popup.on("mouseenter touchstart", $.proxy(function () { this._isPopScroll = true; }, this));
        this.popup.on("mouseleave touchend", $.proxy(function () { this._isPopScroll = false; }, this));
        this._on($(window), "resize", this._resizePopup);
		this._wirePopupEvents();
    };

    ejDateRangePicker.prototype._createWrapper = function () {
        this._localizedLabels = this._getLocalizedLabels();
        this.element.addClass("e-input").attr({ 'aria-atomic': 'true', 'aria-live': 'assertive', 'tabindex': '0', 'role':'combobox', 'aria-expanded':'false', 'name' : this.element.attr('name') == undefined ? this._id : this.element.attr('name') }); 
        this.wrapper = ej.buildTag("span.e-daterangewidget e-widget " + this.model.cssClass);
        if (!ej.isTouchDevice())
            this.wrapper.addClass('e-ntouch');
        this._input_innerWrapper = ej.buildTag("span.e-in-wrap e-box");
        this.wrapper.append(this._input_innerWrapper).insertBefore(this.element);
        this._input_innerWrapper.append(this.element);
        this._input_innerWrapper.addClass('e-padding');

        var proxy = this;
        this.culture = ej.preferredCulture(this.model.locale);
        this._setRoundedCorner(this.model.showRoundedCorner);
        this._renderDateIcon(this.model.showPopupButton);
        if (!this._isSupport) {
            this._hiddenInput = ej.buildTag("input.e-input e-placeholder ", "", {}, { type: "text" }).insertAfter(this.element);
            this._hiddenInput.val(this._localizedLabels.watermarkText);
            this._hiddenInput.css("display", "block");
            var proxy = this;
            $(this._hiddenInput).focus(function () {
                proxy.element.focus();
            });
        }
        if (this.wrapper) {
            if (this.model.width) this.wrapper.width(this.model.width);
            if (this.model.height) this.wrapper.height(this.model.height);
        }
        this._setWaterMark();
    };
    ejDateRangePicker.prototype._updateOnRender = function (e) {
        if (this.model.enableTimePicker) {
            if (this._rightTime) {
                this._rightTP = this._rightTime.ejTimePicker("instance");
                this._updateValues();
            }
        } else {
            if (this.calendar_right) {
                this._rightDP = this.calendar_right.ejDatePicker("instance");
                this._updateValues();
            }
        }
    };
    ejDateRangePicker.prototype._updateRangesList = function () {
        $(".e-dateranges-ul").find(".rangeItem.e-active").removeClass("e-active");
        $(".e-dateranges-ul").find(".rangeItem.e-custompic").addClass("e-active");
    }
    ejDateRangePicker.prototype._updateValues = function () {
        this._updateRangesList();
        this._getDateTimeFormat();
        if (this._startEndValidation() || (this.model.startDate != null && this.model.endDate != null)) {
            this._validateValues(this.model.startDate, "left");
            this._validateValues(this.model.endDate, "right");
            if (this.popup && this.datePopup) this._setValues();
            this._mainValue();
        } else {
            this._clearRanges();
            this.element.val("");
        }
        this._refreshMinMax();
        this._setWaterMark();
    };
    ejDateRangePicker.prototype._startEndValidation = function () {
        if (this.model.startDate && this.model.endDate) {
            var start = this.model.startDate, end = this.model.endDate;
            return !(end && start > end);
        }
        return false;
    };
    ejDateRangePicker.prototype._addAttr=function (htmlAttr) {
        var proxy = this;
        $.map(htmlAttr, function (value, key) {
            var keyName = key.toLowerCase();
            if (keyName == "class") proxy.wrapper.addClass(value);
            else if (keyName == "disabled") proxy.disable();
            else if (keyName == "readOnly") proxy.model.readOnly = true;
            else if (keyName == "style" || keyName == "id") proxy.wrapper.attr(key, value);
            else if (ej.isValidAttr(proxy.element[0], key)) proxy.element.attr(key, value);
            else proxy.wrapper.attr(key, value);

        });
    },
    ejDateRangePicker.prototype._renderButton = function () {
        this._buttonDiv = ej.buildTag("div.e-drpbuttons");
        var _reset = ej.buildTag("div.e-drp-button e-drp-reset e-btn e-select e-flat").attr({ 'tabindex': '0' });
        var _apply = ej.buildTag("div.e-drp-button e-drp-apply e-disable e-btn e-select e-flat").attr({ 'tabindex': '0' });
        var _cancel = ej.buildTag("div.e-drp-button e-drp-cancel e-btn e-select e-flat").attr({ 'tabindex': '0' });
        this._buttonDiv.append(_reset);
        this._buttonDiv.append(_apply);
        this._buttonDiv.append(_cancel);
        this.popup.append(this._buttonDiv);
        this._setLocalizedText();
        this._on($(this._buttonDiv.find("div.e-drp-reset")), "click", this.clearRanges);
        var $this = this;
        this._on($(this._buttonDiv.find("div.e-drp-apply")), "click", function (e) {
            if ($this._buttonDiv.find(".e-drp-apply").hasClass("e-disable")) {
                return;
            }
            this._isApplied = true;
            $this._isPopScroll = false;
            $this._updateInput();
            $this._showhidePopup();
            $this._buttonDiv.find(".e-drp-apply").addClass("e-disable");
			this._prevStartDate = this.model.startDate;
			this._prevEndDate = this.model.endDate;
            this._trigger("change", { value: this.model.value, startDate: this.model.startDate, endDate: this.model.endDate });
            this._trigger("select", { startDate: this.model.startDate, endDate: this.model.endDate, value: this.model.value });
        });
        this._on($(this._buttonDiv.find("div.e-drp-cancel")), "click", this._cancelButton);
    };
    ejDateRangePicker.prototype._setLocalizedText = function () {
        if (!ej.isNullOrUndefined(this._options)) {
            if (!ej.isNullOrUndefined(this._options.buttonText))
                $.extend(this._localizedLabels.ButtonText, this._options.buttonText);
            if (!ej.isNullOrUndefined(this._options.watermarkText))
                this._localizedLabels.watermarkText = this._options.watermarkText;
        }
        this.model.buttonText = this._localizedLabels.ButtonText;
        if(this._buttonDiv){
        $(this._buttonDiv.find("div.e-drp-reset")).text(this.model.buttonText.reset);
        $(this._buttonDiv.find("div.e-drp-apply")).text(this.model.buttonText.apply);
        $(this._buttonDiv.find("div.e-drp-cancel")).text(this.model.buttonText.cancel);
        }
        if (this._customRangePicker && this._customRangePicker.find("ul li.e-custompic").length > 0)
            (this._customRangePicker.find("ul li.e-custompic")).text(this._localizedLabels.customPicker);
        this._setWaterMark();
    };

    ejDateRangePicker.prototype._renderRanges = function () {
        this._renderRangesWrapper();
        this.popup.append(this._customRangePicker);
        this._ranges_li = "";
        var proxy = this;
        if (this.model.ranges) {
            for (var i = 0; i < this.model.ranges.length; i++) {
                var s = this.model.ranges[i];
                var value = s.range;
                if (value.length === 2) {
                    var start = new Date(value[0]);
                    var end = new Date(value[1]);
                    if (ej.isNullOrUndefined(start))
                        start = new Date(value[0]);
                    if (ej.isNullOrUndefined(end))
                        end = new Date(value[1]);
                    if (start <= end) {
                        proxy._ranges_li += "<li role='menuitem' title='" + s.label + "' class='rangeItem' data-e-range='" + JSON.stringify(value) + "' data-e-value='" + s.range + "'>" + s.label + "</li>";
                    }
                }
            }
        }
        this._ranges_li += "<li role='menuitem' class='rangeItem e-active e-custompic' data-e-range='customPicker'>" + this._localizedLabels.customPicker + "</li>";
        this.popup.find("div.e-custom-dateranges ul").append(this._ranges_li);
        this._on(this._customRangePicker.find("ul li.rangeItem"), "click", this._customSelection);
        this._customRangePicker.ejScroller({ height: this.datePopup ? this.datePopup.height() : 200, width: 0, scrollerSize: 15 });
        proxy._scrollerObj = this._customRangePicker.ejScroller("instance");
    };
    ejDateRangePicker.prototype._removeTimePicker = function () {
        this._leftDiv.removeClass("e-left-timepicker");
        this._rightDiv.removeClass("e-right-timepicker");
        this._leftTP.destroy();
        this._rightTP.destroy();
        this._rightTP = null;
        this._leftTP = null;
        this._leftTime.remove();
        this._rightTime.remove();
        this._setOption("width", "");
        this._setOption("width", "100%");
        this._updateValues();
    };
    ejDateRangePicker.prototype._setOption = function (option, value) {
        if (this._leftDP)
            this._leftDP.option(option, value);
        if (this._rightDP)
            this._rightDP.option(option, value);
        if (this.model.enableTimePicker) {
            if (this._leftTP)
                this._leftTP.option(option, value);
            if (this._rightTP)
                this._rightTP.option(option, value);
        }
    };
    ejDateRangePicker.prototype._renderTimePicker = function () {
        if (this.model.timeFormat == '')
            this.model.timeFormat = this.culture.calendar.patterns.t;
        this._leftTime = ej.buildTag("input.leftTime#" + this._id + "_lTime");
        this._leftDiv.append(this._leftTime);
        this._leftDiv.addClass("e-left-timepicker");
        var proxy = this;
        var TPSettings = {
            popupWidth: "115px",
            locale: this.model.locale,
            timeFormat: this.model.timeFormat,
			watermarkText:"",
            open: function () {
                this.popup.addClass("e-daterange-timepopup");
                this.model.open = null;
            },
            focusOut: function (e) {
                proxy._isApplied = false;
            }
        }
        this._leftTime.ejTimePicker(TPSettings);
        this._leftTime.ejTimePicker({
            "select": function(e) {
                if (proxy._selectedStartDate) {
                    var value = e.value ? e.value : e.model.value;
                    proxy.model.startDate = proxy._selectedStartDate = new Date(proxy._selectedStartDate.toDateString() + " " + value);
                    if (proxy._rightDP.element.val() != "" && proxy._rightTP.element.val() != "") {
                        proxy._buttonDiv.find(".e-drp-apply").removeClass("e-disable");
                    }
                    proxy._isApplied = false;
                    return;
                }
                proxy._selectedEndDate = null;
                proxy._leftDP.option("value", proxy._selectedStartDate ||
                    ((+new Date(new Date().setHours(0, 0, 0, 0)) >= +proxy.model.minDate && +new Date(new Date().setHours(0, 0, 0, 0)) <= +proxy.model.maxDate) ? new Date(new Date().setHours(0, 0, 0, 0)) : proxy.model.minDate));
                proxy._selectedStartDate = proxy.model.startDate = proxy._selectedStartDate || ((+new Date(new Date().setHours(0, 0, 0, 0)) >= +proxy.model.minDate && +new Date(new Date().setHours(0, 0, 0, 0)) <= +proxy.model.maxDate) ? new Date(new Date().setHours(0, 0, 0, 0)) : proxy.model.minDate)
                if (proxy._selectedStartDate) proxy._setStartDate(proxy.model.startDate, $('.current-month[data-date="' + proxy.model.startDate.toDateString() + '"]'), true);
                proxy._rangeRefresh(proxy._setArgs(proxy._leftDP.popup));
                if (proxy.model.startDate && proxy.model.endDate) {
                    proxy._updateRanges("left");
                    if (proxy._rightTP && proxy.model.startDate.toLocaleDateString() == proxy.model.endDate.toLocaleDateString())                
                    proxy._buttonDiv.find(".e-drp-apply").removeClass("e-disable");
                }
            }
        })
        this._leftTP = this._leftTime.ejTimePicker("instance");
        this._rightTime = ej.buildTag("input.rightTime#" + this._id + "_rTime");
        this._rightDiv.append(this._rightTime);
        this._rightDiv.addClass("e-right-timepicker");
        this._rightTime.ejTimePicker(TPSettings);
        this._rightTime.ejTimePicker({
            "select": function (e) {
                if (proxy._selectedEndDate) {
                    var value = e.value ? e.value : e.model.value;
                    proxy.model.endDate = proxy._selectedEndDate = new Date(proxy._selectedEndDate.toDateString() + " " + value);
                    if (proxy._leftDP.element.val() != "" && proxy._leftTP.element.val() != "") {
                        proxy._buttonDiv.find(".e-drp-apply").removeClass("e-disable");
                    }
                    proxy._isApplied = false;
                    return;
                }
                var tempDateVal = new Date(new Date().toDateString() + " " + this.model.value);
                proxy._rightDP.option("value", proxy._selectedEndDate ||
                    ((+new Date(tempDateVal) >= +proxy.model.minDate && +new Date(new Date(tempDateVal)) <= +proxy.model.maxDate) ? new Date(new Date(tempDateVal)) : proxy.model.minDate));
                proxy._selectedEndDate = proxy.model.endDate = proxy._selectedEndDate || ((+new Date(new Date(tempDateVal)) >= +proxy.model.minDate && +new Date(new Date(tempDateVal)) <= +proxy.model.maxDate) ? new Date(new Date(tempDateVal)) : proxy.model.minDate)
                var cal_type = ($($('.current-month[data-date="' + proxy.model.endDate.toDateString() + '"]')).parents(".e-left-datepicker").length > 0) ? "left" : "right";
                var currentDate = proxy._selectedEndDate;
                var dateString = proxy.model.endDate.toDateString();
                if ((proxy._selectedEndDate >= proxy._selectedStartDate)) {
                    proxy._setEndDate(proxy.model.endDate, $('.current-month[data-date="' + proxy.model.endDate.toDateString() + '"]'), true);
                } else if ((currentDate < proxy._selectedStartDate && proxy.model.backwardSelection)) {
                    var minDate = currentDate;
                    var dateString = $($('.current-month[data-date="' + proxy.model.endDate.toDateString() + '"]')).attr("data-date");
                    proxy._updateDP(proxy, new Date(currentDate), "rightDP");
                    proxy._rightDP._stopRefresh = false;
                    proxy._rightDP.element.parents(".e-datewidget").removeClass("e-error");
                    var endElement = $(proxy.datePopup.find('.current-month[data-date="' + dateString + '"]'));
                    proxy._selectedStartDate = proxy.model.startDate;
                    proxy._selectedEndDate = new Date(currentDate);
                    proxy._setEndDate(proxy._selectedEndDate, endElement, true);
                    proxy._startDate.date = proxy._selectedStartDate;
                    if (cal_type == "left") {
                        proxy.model.startDate = proxy._selectedEndDate;
                        proxy.model.endDate = proxy._selectedStartDate;
                        proxy._updateDP(proxy, proxy._selectedStartDate, "rightDP");
                        proxy._updateDP(proxy, proxy._selectedEndDate, "leftDP");
                    }
                    else if (cal_type == "right") {
                        proxy._updateDP(proxy,  proxy.model.endDate, "leftDP");
                        proxy._updateDP(proxy,  proxy.model.startDate, "rightDP");
                    }
                }
                else {
                    proxy._selectedStartDate = currentDate;
                    proxy._selectedEndDate = null;
                    if (proxy._endDate)
                        proxy._endDate.date = null;
                    proxy.popup.find(".in-range").removeClass("in-range");
                    proxy._leftDP.option("value", proxy._selectedStartDate ||
                        ((+new Date(new Date(tempDateVal)) >= +proxy.model.minDate && +new Date(new Date(tempDateVal)) <= +proxy.model.maxDate) ? new Date(new Date(tempDateVal)) : proxy.model.minDate));
                    proxy._leftTP.option("value", ej.format(proxy._selectedStartDate, proxy.model.timeFormat, proxy.model.locale));
                    if (cal_type == "right") {
                        proxy._updateDP(proxy, proxy._selectedStartDate, "leftDP");
                    }
                    proxy._updateDP(proxy, null, "rightDP");
                    proxy._setStartDate(proxy._selectedStartDate, $('.current-month[data-date="' + proxy.model.endDate.toDateString() + '"]'), true);
                }
                proxy._updateRanges("left");
                proxy._updateRanges("right");
                if (proxy.model.startDate && proxy.model.endDate) {
                    proxy._updateRanges("left");
                    proxy._buttonDiv.find(".e-drp-apply").removeClass("e-disable");
                }
            }
        })
        this._rightTP = this._rightTime.ejTimePicker("instance");
        this._on(this._leftTP.element, "keydown", this._onKeyDown);
        this._on(this._rightTP.element, "keydown", this._onKeyDown);
        //below code for position the timepicker and datepicker
        this._setTimePickerPos();
    };
    ejDateRangePicker.prototype._updateDP = function (obj, value, element) {
        var proxy = obj;
        var dpElement;
        if (element === "rightDP") {
            dpElement = proxy._rightDP;
            dpElement.option("value", value);
            dpElement.element.val(ej.format(value, proxy.model.dateFormat, proxy.model.locale));
            proxy._rightTP.option("value", ej.format(value, proxy.model.timeFormat, proxy.model.locale));
        } else {
            dpElement = proxy._leftDP;
            dpElement.option("value", value);
            dpElement.element.val(ej.format(value, proxy.model.dateFormat, proxy.model.locale));
            proxy._leftTP.option("value", ej.format(value, proxy.model.timeFormat, proxy.model.locale));
        }

    };
    ejDateRangePicker.prototype._setTimePickerPos = function () {
        $("#" + this._id + "_lTime_timewidget").css({
            position: "absolute",
            top: 0,
            left: this._leftDP.popup.width() + this._leftDP.popup.position().left - this.popup.find($("#" + this._id + "_lTime_timewidget")).outerWidth()
        });
        $("#" + this._id + "_rTime_timewidget").css({
            position: "absolute",
            top: !this.popup.hasClass("e-daterange-responsive") ? 0 : this._rightDP.wrapper.position().top,
            left: this._rightDP.popup.width() + this._rightDP.popup.position().left - this.popup.find($("#" + this._id + "_rTime_timewidget")).outerWidth()
        });
    };
    ejDateRangePicker.prototype._updateInput = function (e) {
        if (!(this.model.startDate && this.model.endDate)) {
            if (this.model.value)
                this.element.val(this.model.value);
            if (this._popupOpen)
                this.popupHide();
            return;
        }
        this._resetValues();
        this.wrapper.removeClass("e-error");
        this._mainValue();
        this._refreshMinMax();
    };
    ejDateRangePicker.prototype._removeWatermark = function () {
        if (this.element.val() != "" && !this._isSupport)
            this._hiddenInput.css("display", "none");
    };
    ejDateRangePicker.prototype._mainValue = function () {
        if (this.model.startDate < new Date(this.model.minDate) || this.model.startDate > new Date(this.model.maxDate)) this.model.startDate = new Date(this.model.minDate);
        if (this.model.endDate > new Date(this.model.maxDate) || this.model.endDate < new Date(this.model.minDate))
            this.model.endDate = new Date(this.model.maxDate);
        var startDt = this.model.startDate, endDt = this.model.endDate;
        if (startDt > endDt && endDt != null && this.model.backwardSelection) {
             var lefttime = ej.format(endDt, this.model.timeFormat, this.model.locale), righttime = ej.format(startDt, this.model.timeFormat, this.model.locale);
             var _startDateString = ej.format(endDt, this.model.dateFormat, this.model.locale);
             var _endDateString = ej.format(startDt, this.model.dateFormat, this.model.locale);
        } else {
        var lefttime = ej.format(startDt, this.model.timeFormat, this.model.locale), righttime = ej.format(endDt, this.model.timeFormat, this.model.locale);
        var _startDateString = ej.format(startDt, this.model.dateFormat, this.model.locale);
        var _endDateString = ej.format(endDt, this.model.dateFormat, this.model.locale);
        }
        if (this.model.enableTimePicker) {
			if (this.popup && this.datePopup && this._leftTP && this._rightTP && this._leftTP.model.value && this._rightTP.model.value) {
				lefttime = this._leftTP.model.value;
				righttime = this._rightTP.model.value;
			}
			_startDateString = ej.format(_startDateString + " " + lefttime, this._dateTimeFormat, this.model.locale);
			_endDateString = ej.format(_endDateString + " " + righttime, this._dateTimeFormat, this.model.locale);
			this.model.startDate = ej.parseDate(_startDateString, this._dateTimeFormat, this.model.locale);
			this.model.endDate = ej.parseDate(_endDateString, this._dateTimeFormat, this.model.locale);
            }
		else {
			if (this.popup && this.datePopup) {
			this.model.startDate = ej.parseDate(_startDateString, this._leftDP.model.dateFormat, this.model.locale);
			this.model.endDate = ej.parseDate(_endDateString, this._rightDP.model.dateFormat, this.model.locale);
			}
		}
        if (_startDateString != null && _endDateString != null) {
            this.model.value = _startDateString + " " + this.model.separator + " " + _endDateString;
            this.element.val(this.model.value);
            if (this._hiddenInput)
                this._hiddenInput.attr('value', this.model.value);
            this._removeWatermark();
            this._validState = true;
        } else {
            this.model.value = null;
            this._setWaterMark();
            this._validState = false;
        }
        this._prevValue = this.model.value;
        if (this._buttonDiv)
            this._buttonDiv.find(".e-drp-apply").addClass("e-disable");
        this._trigger("_change", { value: this.model.value });
    };
    ejDateRangePicker.prototype._bindDateButton = function () {
        if (this.dateRangeicon)
            this._on(this.dateRangeIcon, "click", this._showDatePopUp);
        if (!this.model.allowEdit) {
            this.element.attr("readonly", "readonly");
            this.element.on("mousedown", $.proxy(this._showDatePopUp, this));
            this.element.off("blur", $.proxy(this._onMainFocusOut, this));
        }
        if (this.model.allowEdit) {
            this.element.off("mousedown", $.proxy(this._showDatePopUp, this));
        }
    };

    ejDateRangePicker.prototype._showDatePopUp = function (e) {
        if (!this.model.enabled)
            return false;
        var isRightClick = false;
        if (e.button)
            isRightClick = (e.button == 2);
        else if (e.which)
            isRightClick = (e.which == 3); //for Opera
        if (isRightClick)
            return;
        this._showhidePopup(e);
    };
    ejDateRangePicker.prototype._showhidePopup = function (e) {
        if (this._popupOpen) {
            if (!this._isFocused && this.element.is(':input') && (!ej.isTouchDevice())) {
                this.wrapper.addClass('e-focus');
            }
            this.popupHide(e);
        } else {
            if (!this._isFocused && this.element.is(':input') && (!ej.isTouchDevice())) {
                this.wrapper.addClass('e-focus');
            }
            this.popupShow(e);
        }
    };
    ejDateRangePicker.prototype.popupHide = function (e) {
	   if ( e && (e.type == "touchmove" || e.type== "scroll")) {
		   if ($(e.target).parents("#"+this.popup[0].id).length > 0)
			   return;
	   }
        if (!this._popupOpen || this._isPopScroll) return false;
        var proxy = this;
        if (this._trigger("beforeClose", { element: this.popup, events: e })) return false;
        this.popup.attr({ 'aria-hidden': 'true' });
		this.element.attr({'aria-expanded':'false'})
        if (this._leftTP && !this._leftTP._popupOpen)
            this._leftTP.hide();
        if (this._rightTP && !this._rightTP._popupOpen)
            this._rightTP.hide();
        this.popup.css("visibility", "visible").slideUp(100, function () {
            proxy._popupOpen = false;
        });
        this._off(ej.getScrollableParents(this.wrapper), "scroll", this.popupHide);
        this._off(ej.getScrollableParents(this.wrapper), "touchmove", this.popupHide);
        this._trigger("close", { element: this.popup, events: e });
        this.wrapper.removeClass("e-active");
    };

    ejDateRangePicker.prototype.renderpopup = function (e) {
        if (!this.popup) {
			this.popup = ej.buildTag("div.e-daterangepicker-popup e-popup e-widget e-box" + this.model.cssClass + "#" + this.element[0].id + "_popup").css("display", "none");
			$('body').append(this.popup);
			if (this.model.isResponsive) {
				if (this.model.ranges) {
					if (this.model.ranges) this._renderRanges();
					if (this._customRangePicker) this._customRangePicker.addClass("e-responsive");
					this._showRangesOnly = true;
				}
				else if (!this.model.ranges) {
					this._renderPopup();
					this._onMainFocusOut();
					this._showRangesOnly = false;
				}
			}
			else {
				this._renderPopup();
				this._onMainFocusOut();
				this._showRangesOnly = false;
			}
		}
		else if (this.model.isResponsive && this._customRangePicker && this.datePopup) {
			this.datePopup.hide();
			this._buttonDiv.hide();
			this._customRangePicker.show().addClass("e-responsive");
			this._showRangesOnly = true;
		}
		if (typeof (this.model.value) === "string" && !ej.isNullOrUndefined(this.model.value) && !this._notapplied) this._updateValues();
        else if (typeof (this.model.value) === "object" && this.model.value == null && !this._notapplied) this._updateValues();
	};
	ejDateRangePicker.prototype.popupShow = function (e) {
        if (!this.model.enabled)
            return false;
        if (this._popupOpen)
            return false;
        var proxy = this;
        if (this._trigger("beforeOpen", { element: this.popup, events: e })) return false;
        this.wrapper.addClass('e-focus');
        this.popup.attr({ 'aria-hidden': 'false' });
		this.element.attr({'aria-expanded':'true'})
        proxy._popupOpen = true;
        this.popup.css({ 'visibility': 'hidden', 'display': 'block' });
        this._resizePopup();
        this.popup.css({ 'display': 'none', 'visibility': 'visible' }).slideDown(100, function () {
        });
        this._on(ej.getScrollableParents(this.wrapper), "scroll", this.popupHide);
        this._on(ej.getScrollableParents(this.wrapper), "touchmove", this.popupHide);
        this._trigger("open", { element: this.popup, events: e });
        this.wrapper.addClass("e-active");
    };
    ejDateRangePicker.prototype._resizePopup = function () {
        var proxy = this, range_width = 0, ran_height = 0, cal_width = 300, cal_height= 200 ;
		if (!this._showRangesOnly && this.datePopup) {
        cal_width = this.datePopup.find(".e-popup.e-calendar").outerWidth();
        cal_height = this.datePopup.find(".e-popup.e-calendar").height();
		}
        if (this._customRangePicker && this._customRangePicker.height() <= 0)
            this._customRangePicker.height(!this._showRangesOnly ? this.datePopup.height() : 200);
        if (this.model.ranges && this.model.ranges.length > 0)
            var ran_height = this._customRangePicker.find("ul").height(), range_width = proxy._customRangePicker.outerWidth();
        if ($(window).width() - this.wrapper.position().left < ((cal_width * 2) + range_width) + 25) {
            proxy.popup.addClass("e-daterange-responsive");
			if (this.model.isResponsive) {
				this._isMobile = true;
				this._resetValues();
			}
            proxy._setOption("width", "95%");
            if (this.model.enableTimePicker) {
                this._setOption("width", "47%");
                this._setDatePickerPosition();
                $("#" + this._id + "_lTime_timewidget").css({
                    left: this._leftDP.wrapper.outerWidth() + 5
                });

                $("#" + this._id + "_rTime_timewidget").css({
                    left: this._rightDP.wrapper.outerWidth() + 5
                });
                if (proxy._scrollerObj) {
                    proxy._scrollerObj.model.height = ran_height < cal_height ? ran_height + 10 : cal_height;
                    proxy._scrollerObj.refresh();
                }
                return;
            }
            if (proxy._scrollerObj) {
                proxy._scrollerObj.model.height = ran_height < cal_height ? ran_height + 10 : cal_height;
                proxy._scrollerObj.refresh();
            }
        } else {
			if (this._isMobile) {
				this._isMobile = false;
				this._resetValues();
			}
            proxy.popup.removeClass("e-daterange-responsive");
            if (this.model.enableTimePicker && this.datePopup) {
                this._leftTP.option("width", "115px");
                this._rightTP.option("width", "115px");
                this._setTimePickerPos();
            }
            if (proxy._scrollerObj) {
                proxy._scrollerObj.model.height = !this._showRangesOnly ? this.datePopup.height() : "200px";
                proxy._scrollerObj.refresh();
            }
        }
		(this._isMobile && this.popup && this.datePopup) ? this.popup.addClass("e-responsive"): this.popup.removeClass("e-responsive")
        this._setDatePickerPosition();
    };
    ejDateRangePicker.prototype._onDocumentClick = function (e) {
        if (this.model) {
            if (!this.popup) this.wrapper.removeClass('e-focus');
            else if (this.popup && !$(e.target).is(this.popup) && !$(e.target).parents(".e-popup").is(this.popup) && !$(e.target).is(this.wrapper) && !$(e.target).parents(".e-daterangewidget").is(this.wrapper)) {
                if (!this.model.enableTimePicker) {
                    if (this._popupOpen)
                        this.popupHide(e);
                    this.wrapper.removeClass('e-focus');
                }
                else if (this.model.enableTimePicker && !$(e.target).is(this._leftTP.popup) && !$(e.target).parents(".e-popup").is(this._leftTP.popup) && !$(e.target).is(this._rightTP.popup) && !$(e.target).parents(".e-popup").is(this._rightTP.popup)) {
                    if (this._popupOpen)
                        this.popupHide(e);
                    this.wrapper.removeClass('e-focus');
                }
				this._notapplied = !this._buttonDiv.find(".e-drp-apply").hasClass("e-disable");
            }
        }
    };
    ejDateRangePicker.prototype._getOffset = function (ele) {
        var pos = ele.offset() || { left: 0, top: 0 };
        if ($("body").css("position") != "static") {
            var bodyPos = $("body").offset();
            pos.left -= bodyPos.left;
            pos.top -= bodyPos.top;
        }
        return pos;
    };

    ejDateRangePicker.prototype._getZindexPartial = function (element, popupEle) {
        if (!ej.isNullOrUndefined(element) && element.length > 0) {
            var parents = element.parents(), bodyEle;
            bodyEle = $('body').children();
            if (!ej.isNullOrUndefined(element) && element.length > 0)
                bodyEle.splice(bodyEle.index(popupEle), 1);
            $(bodyEle).each(function (i, ele) {
                parents.push(ele);
            });

            var maxZ = Math.max.apply(maxZ, $.map(parents, function (e, n) {
                if ($(e).css('position') != 'static')
                    return parseInt($(e).css('z-index')) || 1;
            }));
            if (!maxZ || maxZ < 10000)
                maxZ = 10000;
            else
                maxZ += 1;
            return maxZ;
        }
    };

    ejDateRangePicker.prototype._setDatePickerPosition = function () {
        var elementObj = this.element.is('input') ? this.wrapper : this.element;
        var pos = this._getOffset(elementObj), winLeftWidth, winRightWidth, winBottomHeight = $(document).scrollTop() + $(window).height() - (pos.top + $(elementObj).outerHeight()), winTopHeight = pos.top - $(document).scrollTop(), popupHeight = this.popup.outerHeight(), popupWidth = this.popup.outerWidth(), left = pos.left, totalHeight = elementObj.outerHeight(), border = (totalHeight - elementObj.height()) / 2, maxZ = this._getZindexPartial(this.element, this.popup), popupmargin = 3, topPos = (popupHeight < winBottomHeight || popupHeight > winTopHeight) ? pos.top + totalHeight + popupmargin : pos.top - popupHeight - popupmargin;
        winLeftWidth = $(document).scrollLeft() + $(window).width() - left;
		if (this._showRangesOnly) left = pos.left + this.wrapper.outerWidth() - this.popup.outerWidth();
        else if (popupWidth > winLeftWidth && (popupWidth < left + elementObj.outerWidth()))
            left -= this.popup.outerWidth() - elementObj.outerWidth();
        this.popup.css({
            "left": left + "px",
            "top": topPos + "px",
            "z-index": maxZ
        });

        if (this.model.enableTimePicker && this.datePopup) {
            $("#" + this._id + "_lTime_timewidget").css({
                position: "absolute",
                top: 0,
                left: this._leftDP.popup.width() + this._leftDP.popup.position().left - $("#" + this._id + "_lTime_timewidget").width()
            });
            $("#" + this._id + "_rTime_timewidget").css({
                position: "absolute",
                top: !this.popup.hasClass("e-daterange-responsive") ? 0 : this._rightDP.wrapper.position().top,
                left: this._rightDP.popup.width() + this._rightDP.popup.position().left - $("#" + this._id + "_rTime_timewidget").width()
            });
        }
    };
    ejDateRangePicker.prototype._getDateValue = function(date){
        var dateStringValue = date.toDateString();
        var dateValue = new Date(dateStringValue);
        return dateValue;
    };
    ejDateRangePicker.prototype._dateEleClicked = function (e) {
        this._updateRangesList();
        this._activeItem = $(e.currentTarget);
        if (this._activeItem.hasClass("e-hidedate")) {
            e.stopPropagation();
            return;
        }
        if (this._activeItem.hasClass("other-month")) {
            this._refreshMinMax();
        }
        var dateString = this._activeItem.attr("data-date");
        var cal_type = ($(e.currentTarget).parents(".e-left-datepicker").length > 0) ? "left" : "right";
        if (ej.isNullOrUndefined(dateString) || dateString === "")
            return;
        var currentDate = new Date(dateString);
        if (this._selectedStartDate != null && this._selectedEndDate != null)
            this._selectedStartDate = null;
        if (this._selectedStartDate == null) {
            this._selectedStartDate = currentDate;
            this._selectedEndDate = null;
            if (this._startDate)
                this._startDate.date = null;
            this._rightDP.element.val(null);
            if (cal_type == "right") {
                this._leftDP._stopRefresh = true;
                this._leftDP.option("value", this._selectedStartDate);
                this._leftDP.element.val(ej.format(this._selectedStartDate, this.model.dateFormat, this.model.locale));
            }
            if (this._rightTP){
                this._rightTP.option("value", "");
            }
            this.popup.find(".in-range").removeClass("in-range");
            this.datePopup.find("td.e-state-default.e-active").removeClass("e-active");
            this._rightDP.element.parents(".e-datewidget").removeClass("e-error");
            var startElement = $(this.datePopup.find('.current-month[data-date="' + dateString + '"]'));
            this._selectedStartDate = new Date(startElement.attr("data-date"));
            if (this.model.enableTimePicker && this._leftTP.model.value) {
                this._selectedStartDate = new Date(this._selectedStartDate.toDateString() + " " + this._leftTP.model.value);
            }
            this._setStartDate(this._selectedStartDate, startElement, true);
        } else if ((this._selectedStartDate !== null && this._selectedEndDate == null) && !(this._getDateValue(currentDate) < this._getDateValue(this._selectedStartDate))) {
            var minDate = currentDate;
            var dateString = $(e.currentTarget).attr("data-date");
			this._leftDP._stopRefresh = true;
			this._leftDP.option("value", new Date(this._selectedStartDate));
			this._leftDP._stopRefresh = false;
            this._rightDP._stopRefresh = true;
            this._rightDP.option("value", new Date(dateString));
            this._rightDP._stopRefresh = false;
            if (this._rightTP)
                this._rightTP.option("value", new Date(dateString));
            if(this._getDateValue(currentDate).toDateString() == this._getDateValue(this._selectedStartDate).toDateString() && this._leftTP.model.value){
                this._rightTP.option("minTime",  this._leftTP.model.value);
            }
            this._rightDP.element.parents(".e-datewidget").removeClass("e-error");
            var endElement = $(this.datePopup.find('.current-month[data-date="' + dateString + '"]'));
            this._selectedStartDate = this.model.startDate;
            this._selectedEndDate = new Date(dateString);
            if (this.model.enableTimePicker && this._rightTP.model.value) {
                this._selectedEndDate = new Date(this._selectedEndDate.toDateString() + " " + this._rightTP.model.value);
            }
            this._setEndDate(this._selectedEndDate, endElement, true);
            this._startDate = {};
            this._startDate.date = this._selectedStartDate;
            this._updateRanges("left");
            this._updateRanges("right");
            if (cal_type == "left") {
                this._leftDP._stopRefresh = true;
                this._leftDP.option("value", this.model.startDate);
                this._leftDP.element.val(ej.format(this._selectedStartDate, this.model.dateFormat, this.model.locale));
            }
        }else if ((this._selectedStartDate !== null && this._selectedEndDate == null) && ((this._getDateValue(currentDate) < this._getDateValue(this._selectedStartDate)) && this.model.backwardSelection)) {
            var minDate = currentDate;
            var dateString = $(e.currentTarget).attr("data-date");
            this._rightDP._stopRefresh = true;
            this._rightDP.option("value", new Date(dateString));
            this._rightDP._stopRefresh = false;
            if (this._rightTP)
                this._rightTP.option("value", new Date(dateString));
            this._rightDP.element.parents(".e-datewidget").removeClass("e-error");
            var endElement = $(this.datePopup.find('.current-month[data-date="' + dateString + '"]'));
            this._selectedStartDate = this.model.startDate;
            this._selectedEndDate = new Date(dateString);
            this._setEndDate(this._selectedEndDate, endElement, true);
            this._startDate = {};
            this._startDate.date = this._selectedStartDate;
            if (cal_type == "left") {
                this._rightDP._stopRefresh = true;
                this._rightDP.option("value", this.model.startDate);
                this._rightDP.element.val(ej.format(this._selectedStartDate, this.model.dateFormat, this.model.locale));
            }
            else if (cal_type == "right") {
                this._leftDP._stopRefresh = true;
                this._leftDP.option("value", this.model.endDate);
                this._leftDP.element.val(ej.format(this._selectedStartDate, this.model.dateFormat, this.model.locale));
                this._rightDP._stopRefresh = true;
                this._rightDP.option("value", this.model.startDate);
                this._rightDP.element.val(ej.format(this._selectedStartDate, this.model.dateFormat, this.model.locale));
            }

        } else {
            this._selectedStartDate = currentDate;
            this._selectedEndDate = null;
            if (this._endDate)
                this._endDate.date = null;
            this.popup.find(".in-range").removeClass("in-range");
            this._rightDP.option("value", null);
            if (this._rightTP)
                this._rightTP.option("value", "");
            if (cal_type == "right") {
                this._leftDP._stopRefresh = true;
                this._leftDP.option("value", this._selectedStartDate);
                this._leftDP.element.val(ej.format(this._selectedStartDate, this.model.dateFormat, this.model.locale));
            }
            this._setStartDate(this._selectedStartDate, this._activeItem, true);
            this._updateRanges("left");
            this._updateRanges("right");
        }
        this._trigger("click", { element: $(e.currentTarget), startDate: this.model.startDate, endDate: this.model.endDate, value: new Date($(e.currentTarget).attr("data-date")) });
    };
    ejDateRangePicker.prototype._setStartDate = function (value, current_element, newset, isRestrict) {
        this._startDate = {};
        this._startDate.date = value;
        if (newset && !isRestrict) {
            this._endDate = {};
            this._endDate.date = null;
        }
        this._leftDP._checkDateArrows();
        var removeClass = "";
        if (!isRestrict) {
            removeClass = "e-select e-start-date e-active showrange e-end-date e-state-hover";
        } else {
            removeClass = "e-select e-start-date e-active showrange e-state-hover";
        }
        this.datePopup.find("td.e-state-default").removeClass(removeClass);
        if (!isRestrict) {
            this.popup.find(".in-range").removeClass("in-range");
        }
        current_element.addClass("e-start-date");
        this.model.startDate = value;
        if (this._buttonDiv && this._isApplied)
            this._buttonDiv.find(".e-drp-apply").addClass("e-disable");
        else if (!this._isApplied && this._buttonDiv.find(".e-drp-apply").hasClass("e-disable") && this._rightDP.element.val() != "" &&
        (this._prevStartDate ? this._prevStartDate.getTime() != value.getTime(): true)) {
            this._buttonDiv.find(".e-drp-apply").removeClass("e-disable");
        }
        if (!this.model.enableTimePicker)
            return;
        var $this = this._leftTP;
        var _value = ej.format(this._leftTP.model.value || this._leftDP.model.value || this._rightDP.model.value, $this.model.timeFormat, this.model.locale);
        //if (_value)
         //   this._rightTP.option("minTime", _value);
        if (_value)
            this._leftTP.option("value", _value);
        this._prevStartDate = this.model.startDate;
        this._selectedStartDate = this.model.startDate;
    };
    ejDateRangePicker.prototype._setEndDate = function (value, current_element, newset) {
        this._rightDP.element.parents(".e-datewidget").removeClass("e-val-error");
        this._endDate = {};
        this._endDate.date = value;
        this.popup.find("td.e-end-date").removeClass("e-select e-end-date");
        current_element.addClass("e-end-date");
        if (this._buttonDiv && (this._prevEndDate && this._selectedStartDate )? (this._prevEndDate.getTime() != value.getTime() || this._prevStartDate.toISOString() != this._selectedStartDate.toISOString() ): true)
            this._buttonDiv.find(".e-disable").removeClass("e-disable");
        this.model.endDate = value;
        if (this.model.startDate > this.model.endDate) {
            this.popup.find("td.e-start-date").removeClass("e-start-date").addClass("e-end-date");
            current_element.removeClass("e-end-date").addClass("e-start-date showrange");
        }
        if ( this._startDate && !ej.isNullOrUndefined(this._startDate.date) && this._startDate.date.getFullYear() == this._endDate.date.getFullYear()) {
            if (this._startDate.date.getMonth() == this._endDate.date.getMonth()) {
                return;
            }
        }
        if (!this.model.enableTimePicker)
            return;
        if (this.model.startDate && this._getDateValue(this.model.startDate).toDateString() == this._getDateValue(this.model.endDate).toDateString()) {
            this._rightTP.option("minTime", this._leftTP.option("value") || "");
            this._rightTP.option("value", this._leftTP.option("value") || "");
        } else {
            var $this = this._rightTP;
            var _value = ej.format(this._rightTP.model.value, $this.model.timeFormat, this.model.locale);
         //   if (_value)
           //     this._rightTP.option("minTime", _value);
            if (_value)
                this._rightTP.option("value", _value);
        }
        this._prevEndDate = this.model.endDate;
        this._selectedEndDate = this.model.endDate;
    };

    ejDateRangePicker.prototype._rangeRefresh = function (args) {
        var startElement, endElement;
        if (this._rightDP) {
            var popup = args.element.parent().hasClass("e-left-datepicker") ? this._leftDP.popup : this._rightDP.popup;
        }
        if (this._startDate && this._startDate.date && this._startDate.date.getMonth() == args.month && this._startDate.date.getFullYear() == args.year) {
            startElement = $(popup.find('.current-month[data-date="' + this._startDate.date.toDateString() + '"]'));
            this._setStartDate(this._startDate.date, startElement, false);
            if (this._startDate.date.getDate() + 1 == startElement.next("td").text())
                $(startElement).addClass("showrange");
        }
        if (this._endDate && this._endDate.date && this._endDate.date.getMonth() == args.month && this._endDate.date.getFullYear() == args.year) {
            endElement = $(popup.find('.current-month[data-date="' + this._endDate.date.toDateString() + '"]'));
            this._setEndDate(this._endDate.date, endElement, false);
        }
        if (startElement == endElement)
            $(startElement).removeClass("showrange");
        if (this._rightDP)
            if ((this._startDate && this._startDate.date) && (this._endDate && this._endDate.date)) {
                if (this._startDate.date.getFullYear() <= args.year && this._endDate.date.getFullYear() >= args.year) {
                    var s = args.element.parent().hasClass("e-left-datepicker") ? $(popup.find('td.current-month')[0]) : $(popup.find('td.current-month')[0]);
                    var type = args.element.parent().hasClass("e-left-datepicker") ? "left" : "right";
                    this._updateRanges(type);
                }
            }
    };
    ejDateRangePicker.prototype._renderRangesWrapper = function () {
        if (ej.isNullOrUndefined(this._customRangePicker)) {
            this._customRangePicker = ej.buildTag("div.e-custom-dateranges").css("height", this.datePopup ? this.datePopup.height() :"200px");
            this.popup.append(this._customRangePicker);
            if (this._buttonDiv) this._customRangePicker.insertBefore(this._buttonDiv);
            this._ranges_li = "<ul class='e-dateranges-ul' role=menu></ul>";
            this._customRangePicker.append(this._ranges_li);
        }
    };
    ejDateRangePicker.prototype.setRange = function (range) {
        var startDate, endDate, ranges;
        this._clearRanges();
        if (typeof range == "string") {
            for (var i = 0; i < this.model.ranges.length; i++) {
                ranges = this.model.ranges[i];
                if (ranges.label == range) {
                    this.model.startDate = ranges.range[0];
                    this.model.endDate = ranges.range[1];
                    this._updatePreRanges();
                    return;
                }
            }
        } else if (typeof range == "object") {
            if (range.length == 2) {
                this.model.startDate = range[0];
                this.model.endDate = range[1];
                this._updatePreRanges();
                return;
            }
        }
    };
    ejDateRangePicker.prototype._updatePreRanges = function () {
        this._selectedStartDate = this.model.startDate;
        this._selectedEndDate = this.model.endDate;
        this._resetValues();
        if (this.popup && this.datePopup) this._setValues();
        this._refreshMinMax();
        if (!this._popupOpen)
            this._mainValue();
        this._setWaterMark();
    };
    ejDateRangePicker.prototype.destroy = function () {
        this.destroy();
    };
    ejDateRangePicker.prototype._destroy = function () {
        if (this._popupOpen)
            this._showhidePopup();
        if (this.wrapper) {
            this.element.removeClass("e-input");
            this.element.removeAttr("aria-atomic aria-live placeholder");
            !this._cloneElement.attr("tabindex") && this.element.attr("tabindex") && this.element.removeAttr("tabindex");
            this.element.insertAfter(this.wrapper);
            this.wrapper.remove();
        }
        if (!ej.isNullOrUndefined(this._leftDP))
            this._leftDP.destroy();
        if (!ej.isNullOrUndefined(this._rightDP))
            this._rightDP.destroy();
        if (!ej.isNullOrUndefined(this._rightTP))
            this._rightTP.destroy();
        if (!ej.isNullOrUndefined(this._leftTP))
            this._leftTP.destroy();
        if (!ej.isNullOrUndefined(this._scrollerObj))
            this._scrollerObj.destroy();
        this.popup.remove();
    };
    ejDateRangePicker.prototype.addRanges = function (label,range) {
        var proxy = this, _ranges_li = "", title;
        if (range) {
                var value = range;
                if (value.length === 2) {
                    var start = new Date(value[0]);
                    var end = new Date(value[1]);
                    if (ej.isNullOrUndefined(start))
                        start = new Date(value[0]);
                    if (ej.isNullOrUndefined(end))
                        end = new Date(value[1]);
                    if (start <= end) {
                        if (!label)
                            label = "PreDefined Ranges";
                        _ranges_li += "<li aria-selected='false' title='" + label + "'class='rangeItem' data-e-range='" + JSON.stringify(value) + "' data-e-value='" + range + "'>" + label + "</li>";
                    }
            }
        }
        this._renderRangesWrapper();
        this._customRangePicker.find(".e-dateranges-ul").append(_ranges_li);
        this._off(this._customRangePicker.find("ul li.rangeItem"), "click", this._customSelection);
        this._on(this._customRangePicker.find("ul li.rangeItem"), "click", this._customSelection);
        if (this._scrollerObj)
            this._scrollerObj.refresh();
    };
    ejDateRangePicker.prototype._righthoverRange = function (e) {
        this._activeItem = $(e.currentTarget);
        if (this._activeItem.hasClass("e-hidedate")) {
            e.stopPropagation();

            return;
        }
        this.popup.find(".range-hover").removeClass("range-hover");
        if (this._activeItem.hasClass("in-range"))
            this._activeItem.addClass("range-hover");
        var dateString = this._activeItem.attr("data-date");
        var currentDate = new Date(dateString);
        this._trigger("hover", { element: e.currentTarget, events: e, value: new Date(this._activeItem.attr("data-date")) });

        var that = this;
        if (!ej.isNullOrUndefined(that._selectedStartDate) && (ej.isNullOrUndefined(that._selectedEndDate)))
            this.popup.find(".current-month").each(function (index, el) {
                var element = $(el);
                var dateString = element.attr("data-date");
                if (ej.isNullOrUndefined(dateString) || dateString === "")
                    return;
                var date = new Date(dateString);
                if (date > that._startDate.date && date < currentDate) {
                    element.addClass("in-range");
                } else {
                    element.removeClass("in-range");
                }
                if (that.model.backwardSelection) {
                    if (date < that._startDate.date && date > currentDate && currentDate < that._startDate.date) {
                        element.addClass("in-range");
                    }
                }
                if (date.getTime() === that._selectedStartDate.getTime() && element.next().length !== 0 && element.next("td.current-month").length !== 0 && currentDate > that._selectedStartDate && new Date(new Date(that._selectedStartDate.getTime()).setDate(that._selectedStartDate.getDate() + 1)).getTime() !== currentDate.getTime()) {
                    element.addClass("showrange");
                } else {
                    element.removeClass("showrange");
                }
            });
    };
    ejDateRangePicker.prototype._customSelection = function (e) {
        this._customRangePicker.find(".e-active").removeClass("e-active");
        if ($(e.currentTarget).attr("data-e-range") != "customPicker") {
            var range = $(e.currentTarget).attr("data-e-value").split(",");
            this.model.startDate = new Date(range[0]);
            this.model.endDate = new Date(range[1]);
            if (!this._showRangesOnly){
				this._rightDP.element.parents(".e-datewidget").removeClass("e-error");
				this._customSet();
			}
			else {
				this._mainValue();
				this._isPopScroll = false;
				this.popupHide();
			}
        } else {
			this._showRangesOnly = false;
            if (!this.datePopup) this._renderPopup();
            this.model.startDate = null;
            this.model.endDate = null;
			this.datePopup.show();
			this._buttonDiv.show();
			this.clearRanges();
			this._setDatePickerPosition();
			this._resizePopup();
			this._customRangePicker.removeClass("e-responsive");
			if (this.popup.hasClass("e-daterange-responsive")) this._customRangePicker.insertBefore(this._buttonDiv).hide();
        }
        $(e.currentTarget).addClass("e-active");
    };
    ejDateRangePicker.prototype._setWaterMark = function () {
        if (this.element != null && this.element.hasClass("e-input")) {
            if ((!this._isSupport) && this.element.val() == "") {
                this._hiddenInput.css("display", "block").val(this._localizedLabels.watermarkText);
            }
            else {
                $(this.element).attr("placeholder", this._localizedLabels.watermarkText);
            }
            return true;
        }
    };
    ejDateRangePicker.prototype._clearRanges = function (e) {
        this._updateRangesList();
        this._setOption("value", "");
        if (this.popup && this.datePopup) this._rightDP.element.parents(".e-datewidget").removeClass("e-val-error");
        this._selectedStartDate = null;
        this._selectedEndDate = null;
        if (this._startDate)
            this._startDate.date = null;
        if (this._endDate)
            this._endDate.date = null;
        if (this.popup) this.popup.find("td").removeClass("e-start-date e-end-date in-range e-active e-state-hover today");
        this.model.value = null;
        this.model.startDate = null;
        this.model.endDate = null;
        if(this.model.enableTimePicker){
            this._leftTP && this._leftTP.option("value", null);
            this._rightTP && this._rightTP.option("value", null);
            this._rightTP && this._rightTP.option("minTime", "12:00 AM");
        }
        if (this._buttonDiv)
            this._buttonDiv.find(".e-drp-apply").addClass("e-disable");
    };
    ejDateRangePicker.prototype.clearRanges = function () {
        this._clearRanges();
        this._refreshMinMax();
        this.element.val("");
        this._trigger("_change", { value: this.model.value });
        this._trigger("change", { value: this.model.value, startDate: this.model.startDate, endDate: this.model.endDate });
        this._trigger("clear", {});
    };
    ejDateRangePicker.prototype._getLocalizedLabels = function () {
        return ej.getLocalizedConstants("ej.DateRangePicker", this.model.locale);
    };
    ejDateRangePicker.prototype._unWireEvents = function () {
        this._off($('.e-next', this.popup), "click", $.proxy(this._previousNextHandler, this));
        this._off($('.e-prev', this.popup), "click", $.proxy(this._previousNextHandler, this));
        this._off($(this._buttonDiv.find("div.e-drp-cancel")), "click", this._cancelButton);
        this._off($(this._buttonDiv.find("div.e-drp-reset")), "click", this.clearRanges);
        this._off(this.popup.find(".leftDate_wrapper.e-datepicker.e-js.e-input"), "blur", this._onPopupFocusOut);
        this._off(this.popup.find(".rightDate_wrapper.e-datepicker.e-js.e-input"), "blur", this._onPopupFocusOut);
        if (this.model.allowEdit) {
            this._off(this.element, "blur", this._onMainFocusOut);
            this._off(this.element, "focus", this._onFocusIn);
            this._off(this.element, "keydown", this._onKeyDown);
        }
    };
    ejDateRangePicker.prototype._onDocumentKeyDown = function (e) {
        if (e.keyCode != "13")
            return;
        if (this.popup && !this._buttonDiv.find(".e-drp-apply").hasClass("e-disable") && this.wrapper.hasClass("e-focus")) {
            this._buttonDiv.find(".e-drp-apply").click();
        }
    };
    ejDateRangePicker.prototype._wirePopupEvents = function () {
		this._on($('.e-next', this.popup), "click", $.proxy(this._previousNextHandler, this));
        this._on($('.e-prev', this.popup), "click", $.proxy(this._previousNextHandler, this));
	};
    ejDateRangePicker.prototype._wireEvents = function () {
        $(document).on("mousedown", $.proxy(this._onDocumentClick, this));
        $(document).on("keydown", $.proxy(this._onDocumentKeyDown, this));
        if (this.model.allowEdit) {
            this._on(this.element, "blur", this._onMainFocusOut);
            this._on(this.element, "focus", this._onFocusIn);
            this._on(this.element, "keydown", this._onKeyDown);
        }
    };
    ejDateRangePicker.prototype._onFocusIn = function (e) {
        if (this._isSupport) {
            e.preventDefault();
            this._isFocused = true;
        }
        if (this.wrapper.hasClass("e-error")) {
            this._validState = false;
            this.wrapper.removeClass('e-error');
        }
        if (!this.model.showPopupButton && !this.model.readOnly) this.popupShow(e);
        if (!this.model.showPopupButton) this._on(this.element, "click", this._elementClick);
        this.wrapper.addClass("e-focus");
		if (!this._isSupport)
        this._hiddenInput.css("display", "none");
    };

    ejDateRangePicker.prototype._onKeyDown = function (e) {        
        if (e.keyCode == 13) {
            if ($(e.currentTarget).hasClass("e-datepicker")) {
                this._validateValues($(e.currentTarget).val(), $(e.currentTarget).parents(".e-left-datepicker").length > 0 ? "left" : "right", e.currentTarget.classList.contains("e-timepicker") ? true : false);
                $(e.currentTarget).parents(".e-left-datepicker").length > 0 ? this._leftDP.model.value = this.model.startDate : this._rightDP.model.value = this.model.endDate;
                this._onPopupFocusOut(e);
            } else if(this.popup && this.model.enableTimePicker){
                $(e.currentTarget).hasClass("leftTime") && this._leftTP && this._rightTP ? this._leftTP._trigger("select") : this._rightTP._trigger("select");
            }
        }
        e.stopImmediatePropagation();
    };
    ejDateRangePicker.prototype._cancelButton = function () {
        this._prevValue = null, this._isPopScroll = false;
        this._clearRanges();
        this._onMainFocusOut();
        this._showhidePopup();
    };
    ejDateRangePicker.prototype._updateRanges = function (cal_type) {
        var cal = cal_type == "left" ? this._leftDP : this._rightDP;
        var proxy = this;
        cal.popup.find("td.current-month").each(function (index, el) {
            var element = $(el);
            var dateString = element.attr("data-date");
            if (ej.isNullOrUndefined(dateString) || dateString === "")
                return;
            var date = new Date(dateString);
            if (!ej.isNullOrUndefined(proxy._startDate) && !ej.isNullOrUndefined(proxy._startDate.date) && !ej.isNullOrUndefined(proxy._endDate.date))
                if (date > proxy._startDate.date && date < proxy._endDate.date) {
                    element.addClass("in-range").removeClass("e-state-hover");
                } else {
                    element.removeClass("in-range");
                }
            if (!ej.isNullOrUndefined(proxy._startDate) && !ej.isNullOrUndefined(proxy._startDate.date) && !ej.isNullOrUndefined(proxy._endDate.date))
                if (date > proxy._endDate.date && date < proxy._startDate.date && proxy._endDate.date < proxy._startDate.date) {
                    element.addClass("in-range").removeClass("e-state-hover");
                }
            if (!ej.isNullOrUndefined(proxy._startDate) && !ej.isNullOrUndefined(proxy._startDate.date) && date.toDateString() == proxy._startDate.date.toDateString() && proxy._endDate.date >= proxy._startDate.date) {
                element.addClass("e-start-date").removeClass("e-active");
                if (!ej.isNullOrUndefined(proxy._endDate) && !ej.isNullOrUndefined(proxy._endDate.date) && proxy._startDate.date.toDateString() != proxy._endDate.date.toDateString())
                    element.addClass("showrange");
                element.removeClass("in-range");
            }
            if (!ej.isNullOrUndefined(proxy._startDate) && !ej.isNullOrUndefined(proxy._endDate.date))
                if (!ej.isNullOrUndefined(proxy._endDate) && date.toDateString() == proxy._endDate.date.toDateString() && proxy._endDate.date >= proxy._startDate.date) {
                    element.addClass("e-end-date").removeClass("e-state-hover e-active");
                    element.removeClass("in-range");
                }
            if (!ej.isNullOrUndefined(proxy._startDate) && !ej.isNullOrUndefined(proxy._startDate.date) && date.toDateString() == proxy._startDate.date.toDateString() && proxy._endDate.date < proxy._startDate.date) {
                element.addClass("e-end-date").removeClass("e-state-hover e-active");
                element.removeClass("in-range");
            }
            if (!ej.isNullOrUndefined(proxy._startDate) && !ej.isNullOrUndefined(proxy._endDate.date))
                if (!ej.isNullOrUndefined(proxy._endDate) && date.toDateString() == proxy._endDate.date.toDateString() && proxy._endDate.date < proxy._startDate.date) {
                    element.addClass("e-start-date").removeClass("e-active");
                    if (!ej.isNullOrUndefined(proxy._endDate) && !ej.isNullOrUndefined(proxy._endDate.date) && proxy._startDate.date.toDateString() != proxy._endDate.date.toDateString())
                        element.addClass("showrange");
                    element.removeClass("in-range");
                }
        });
        if (cal.popup.find(".e-start-date").length > 0) {
            if ($(cal.popup.find(".e-start-date")).next("td.in-range").length > 0)
                return;
            else
                $(cal.popup.find(".e-start-date")).removeClass("showrange");
        }
    };

    ejDateRangePicker.prototype.getSelectedRange = function () {
        var args = { startDate: this.model.startDate, endDate: this.model.endDate };
        return args;
    };
    ejDateRangePicker.prototype.enable = function () {
        this.element[0].disabled = false;
        this.model.enabled = true;
        this.wrapper.removeClass('e-disable');
        this.element.removeClass("e-disable");
        this.element.attr("aria-disabled", "false");        
        if (!this._isSupport)
            this._hiddenInput.attr("enabled", "enabled");
        if (this.dateRangeIcon)
            this.dateRangeIcon.removeClass("e-disable").attr("aria-disabled", "false");
        if (this.popup) this.popup.children("div").removeClass("e-disable").attr("aria-disabled", "false");
        this._setOption("enabled", true);
    };
    ejDateRangePicker.prototype.disable = function () {
        this.element[0].disabled = true;
        this.model.enabled = false;
        this.wrapper.addClass('e-disable');
        this.element.addClass("e-disable");
        this.element.attr("aria-disabled", "true");
        this.element.attr("disabled", "disabled");
        if (!this._isSupport)
            this._hiddenInput.attr("disabled", "disabled");
        if (this.dateRangeIcon)
            this.dateRangeIcon.addClass("e-disable").attr("aria-disabled", "true");
        if (this.popup) this.popup.children("div").addClass("e-disable").attr("aria-disabled", "true");
        this.popupHide();
        this._setOption("enabled", false);
    };

    ejDateRangePicker.prototype._onMainFocusOut = function (e) {
        var element_value = this.element.val(), setError;
        this.wrapper.removeClass('e-focus');
        if (!this._isSupport && this.element.val() == "") {
            this._hiddenInput.css("display", "block");
        }
        if (this.element.val() == "" && this._prevValue == null) return;
        if (this._prevValue && this._prevValue == this.element.val()) {
            this._validState ? this.wrapper.removeClass('e-error') : this.wrapper.addClass('e-error');
            return;
        }
        else this._updateRangesList();
        if ((this.element.val() == "" || this.element.val() == null) && !this._isSupport)
            this._hiddenInput.css("display", "block");
        if (this.element.val() == "") {
            this.wrapper.removeClass('e-error');
            this._clearRanges();
            this._setWaterMark();
            this._refreshMinMax();
            this._prevValue = this.model.value;
            this._trigger("change", { value: this.model.value, startDate: null, endDate: null });
            this._trigger("_change", { value: this.model.value });
            return;
        }
        this.wrapper.removeClass("e-error");
        var datestring = this.element.val().split(this.model.separator), _startdate = ej.parseDate(datestring[0], this._dateTimeFormat, this.model.locale), _enddate = ej.parseDate(datestring[1], this._dateTimeFormat, this.model.locale);
        this._validState = true;
        if (!this._validateValues(_startdate, "left") || !this._validateValues(_enddate, "right") || !this._startEndValidation()) {
            this._clearRanges();
            this._refreshMinMax();
            setError = true;
        }
        if (element_value != "" && setError) {
            this.element.val(element_value);
            this.wrapper.addClass("e-error");
            this.model.value = null;
            this._prevValue = this.model.value;
            this._validState = false;
            this._trigger("_change", { value: this.element.val() });
            this._trigger("change", { value: this.model.value, startDate: null, endDate: null });
            return;
        }
        this._resetValues();
        if (this.popup && this.datePopup) this._setValues();
        this._refreshMinMax();
        this.model.value = this._validState && element_value != "" ? element_value : null;
        if (!this._popupOpen)
            this._mainValue();
        this._prevValue = this.model.value;
        this._validState ? this.wrapper.removeClass('e-error').removeClass("e-focus") : this.wrapper.addClass('e-error').removeClass("e-focus");
        this._trigger("change", { value: this.model.value, startDate: this.model.startDate, endDate: this.model.endDate });
    };
    ejDateRangePicker.prototype._onPopupFocusOut = function (e) {
        if (e.currentTarget.classList.contains("leftTime")) {
            var dateValue = ej.format(this._leftDP.model.value, this.model.dateFormat, this.model.locale);
            this._selectedStartDate = ej.parseDate(dateValue + " " + this._leftTP.model.value, this.model.dateFormat + " " + this.model.timeFormat, this.model.locale) || null;
            this.model.startDate = this._selectedStartDate;
            if (this.model.startDate) this._setStartDate(this.model.startDate, $('.current-month[data-date="' + this.model.startDate.toDateString() + '"]'), true, true);
            if (this._rightDP.element.val() == "" || this._rightTP.element.val() == "" || !this._isApplied) {
                return;
            }          
        } else if (e.currentTarget.classList.contains("rightTime")) {
            var dateValue = ej.format(this._rightDP.model.value, this.model.dateFormat, this.model.locale);
            this._selectedEndDate = ej.parseDate(dateValue + " " + this._rightTP.model.value, this.model.dateFormat + " " + this.model.timeFormat, this.model.locale) || null;
            this.model.endDate = this._selectedEndDate;
            if (this.model.endDate) this._setEndDate(this.model.endDate, $('.current-month[data-date="' + this.model.endDate.toDateString() + '"]'), true);
            if (!this._isApplied) {
                return;
            }
        }
        if (ej.format(this._selectedStartDate, "M/d/yyyy") != $("#daterangeleftDate_wrapper").val() || ej.format(this._selectedEndDate, "M/d/yyyy") != $("#daterangerightDate_wrapper").val()) {
            this._updateRangesList();
        }
        var picker = $(e.currentTarget).parents(".e-left-datepicker").length > 0 ? this._leftDP : this._rightDP;
        this._validateValues($(e.currentTarget).val(), $(e.currentTarget).parents(".e-left-datepicker").length > 0 ? "left" : "right", e.currentTarget.classList.contains("e-timepicker") ? true : false);
        $(e.currentTarget).parents(".e-left-datepicker").length > 0 ? this._leftDP.model.value = this.model.startDate : this._rightDP.model.value = this.model.endDate;
        var _prevStartValue = this.model.startDate;
        var _prevEndValue = this.model.endDate, stop = false;
        this._rightDP.element.parents(".e-datewidget").removeClass("e-val-error");
        if (!this._startEndValidation()) {
            if ($(e.currentTarget).parents(".e-left-datepicker").length > 0) {
                this._clearRanges();
                this.model.startDate = _prevStartValue;
                this._selectedStartDate = this.model.startDate;
            } else {
                this._rightDP.element.parents(".e-datewidget").addClass("e-val-error");
                this.model.endDate = null;
                stop = true;
            }
        }
        if (_prevStartValue == null) {
            this._clearRanges();
            return;
        }
        this._selectedStartDate = this.model.startDate;
        this._selectedEndDate = this.model.endDate;
        this._resetValues();
        if (this.popup && this.datePopup) this._setValues();
        if (!this.model.showPopupButton) this._off(this.element, "click", this._elementClick);
        this._refreshMinMax();
        if (!this._popupOpen)
            this._mainValue();
        if (stop)
            this._rightDP.element.val(_prevEndValue.toLocaleDateString());
        this._setWaterMark();
    };
    ejDateRangePicker.prototype._resetValues = function () {
		if (this._isMobile) {
			if (this._leftDP) this._leftDP.option("maxDate", null);
			return;
		}
        if (this.popup && this.datePopup) {
            this._leftDP.option("maxDate", null);
            this._rightDP.option("minDate", null);
            this._leftDP.option("value", this._leftDP.model.value);
            this._rightDP.option("value", this._rightDP.model.value);
        }
    };
    ejDateRangePicker.prototype._resetRanges = function () {
        if (this.popup) {
            this._leftDP.option("maxDate", null);
            this._rightDP.option("minDate", null);
            this._leftDP.option("value", this._leftDP.model.value);
            this._rightDP.option("value", this._rightDP.model.value);
        }
    };
    ejDateRangePicker.prototype._setMinMax = function () {
        var rightdate = this._rightDP.popup.find("td.e-state-default").length;
        for (var i = 0; i < rightdate; i++) {
            var rightDateString = $(this._rightDP.popup.find("td.e-state-default")[i]).attr("data-date");
            var rightDate = new Date(rightDateString);
            if (rightDate < new Date(this.model.minDate))
                $(this._rightDP.popup.find("td.e-state-default")[i]).addClass("e-hidedate");
        }
        var leftdate = this._leftDP.popup.find("td.e-state-default").length;
        for (var i = 0; i < leftdate; i++) {
            var leftDateString = $(this._leftDP.popup.find("td.e-state-default")[i]).attr("data-date");
            var leftDate = new Date(leftDateString);
            if (leftDate < new Date(this.model.minDate))
                $(this._leftDP.popup.find("td.e-state-default")[i]).addClass("e-hidedate");
        }
    };
    ejDateRangePicker.prototype._refreshMinMax = function () {
		if (this._isMobile) return;
        if (this.popup && this.datePopup) {
            var local = this._getNextMonth(this._leftDP._calendarDate);
            if (local.toDateString() > this._rightDP._calendarDate.toDateString()) {
                var temp = this._rightDP.model.value;
                this._rightDP._calendarDate = local;
                this._rightDP._dateValue = local;
                this._rightDP.option("value", local);
            }
            this._rightDP.option("minDate", local);
            this._rightDP.option("value", temp);
            var temp = this._rightDP._calendarDate, y = temp.getFullYear(), m = temp.getMonth();
            this._leftDP.option("maxDate", new Date(y, m, 0));
            this._setMinMax();
        }
        if (this.popup) this.popup.find("td.e-state-default").removeClass("e-state-hover");
    };
    ejDateRangePicker.prototype._refreshEvents = function (cal_type) {
        this._off(this._rightDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "click", this._dateEleClicked);
        this._off(this._leftDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "click", this._dateEleClicked);
        this._off(this._rightDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "mouseover", this._righthoverRange);
        this._off(this._leftDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "mouseover", this._righthoverRange);
        this._on(this._leftDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "mouseover", this._righthoverRange);
        this._on(this._leftDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "click", this._dateEleClicked);
        this._on(this._rightDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "mouseover", this._righthoverRange);
        this._on(this._rightDP.sfCalendar.find('table .e-datepicker-days td.e-state-default'), "click", this._dateEleClicked);
        this._on($(this._leftDP.sfCalendar.find('table .e-datepicker-months td')), "click", $.proxy(this._previousNextHandler, this));
    };
    ejDateRangePicker.prototype._previousNextHandler = function (e) {
		if (this._isMobile) return;
        var selectedCalender = $(e.currentTarget).closest(".e-calendar").parent();
        var cal_type = selectedCalender.hasClass("e-left-datepicker") ? "left" : "right", leftDateString, rightDateString;
        if (e.type == "_month_Loaded") {
            if (cal_type == "left") {
                rightDateString = $(this._rightDP.popup.find("td.current-month")[0]).attr("data-date");
                leftDateString = this._leftDP._dateValue.toDateString();
            } else if (cal_type == "right") {
                leftDateString = $(this._leftDP.popup.find("td.current-month")[0]).attr("data-date");
                rightDateString = this._rightDP._dateValue.toDateString();
            }
        } else {
            rightDateString = $(this._rightDP.popup.find("td.current-month")[0]).attr("data-date");
            leftDateString = $(this._leftDP.popup.find("td.current-month")[0]).attr("data-date");
        }
        var leftDate = new Date(leftDateString);
        var rightDate = new Date(rightDateString);
        leftDate.setHours(0, 0, 0, 0);
        rightDate.setHours(0, 0, 0, 0);
        var status = true;
        if (cal_type == "right") {
            var cls = $("table", this._leftDP.sfCalendar).get(0).className;
            if (cls == "e-dp-viewdays")
                this._leftDP._stopRefresh = true;
            this._rightDP._stopRefresh = false;
            var temp = rightDate, y = temp.getFullYear(), m = temp.getMonth();
            this._leftDP.option("maxDate", new Date(y, m, 0));
            if (cls == "e-dp-viewmonths")
                this._leftDP._startLevel("year");
            this._leftDP._checkDateArrows();
        } else {
            var cls = $("table", this._rightDP.sfCalendar).get(0).className;
            if ($("table", this._rightDP.sfCalendar).get(0).className == "e-dp-viewdays")
                this._rightDP._stopRefresh = true;
            this._leftDP._stopRefresh = false;
            this._rightDP.option("minDate", this._getNextMonth(leftDate));
            if (cls == "e-dp-viewmonths")
                this._rightDP._startLevel("year");
            this._rightDP._checkDateArrows();
        }
        this._setMinMax();
        this._rightDP.element.parents(".e-datewidget").removeClass("e-error");
    };
    return ejDateRangePicker;
})(ej.WidgetBase);
window.ej.widget("ejDateRangePicker", "ej.DateRangePicker", new ejDateRangePicker());
window["ejDateRangePicker"] = null;

ej.DateRangePicker.Locale = {};

ej.DateRangePicker.Locale = ej.DateRangePicker.Locale || {};

ej.DateRangePicker.Locale['default'] = ej.DateRangePicker.Locale['en-US'] = {
    ButtonText: {
        apply: "Apply",
        cancel: "Cancel",
        reset: "Reset"
    },
    watermarkText: "Select Range",
    customPicker: "Custom Picker"
};
//# sourceMappingURL=ej.daterangepicker.js.map
;