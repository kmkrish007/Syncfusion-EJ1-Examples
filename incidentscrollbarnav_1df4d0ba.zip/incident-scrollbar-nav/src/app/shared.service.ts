import {Injectable} from '@angular/core';
import { Observable, of } from 'rxjs';

// @Injectable({
//   providedIn: 'root',
// })

export class SharedService {

  sessionId: string;

  
  constructor() {
    console.log("Executing SharedService Construtor.");
  };

  // public getSessionID(): Observable<string>
  // {
  //     console.log("SharedServer.getSessionID() - sessionId: " + this.sessionId);
  //     return of (this.sessionId);
  // }

  // public setSessionId(id: string)
  // {
  //   this.sessionId = id;
  //   console.log("SharedService.setSessionId(): " + this.sessionId);
  // }



}




