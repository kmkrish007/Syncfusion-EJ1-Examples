import {ShapeComponent} from './shape.component';
import {ConfigDialog} from '../dialogs/configdialog';
//import { StatusPointComponent } from 'current-code/src/app/hmi/statuspoint.component';


export interface Coordinate { 
  x: number;
  y: number;
}

export class SwitchComponent extends ShapeComponent{

  protected type = ShapeComponent.SYMBOL_TYPE_SWITCH;

  public static DEFAULT_COLOR_BORDER: string = "red";
  public static DEFAULT_COLOR_FILL: string = "white";
  public static DEFAULT_LENGTH: number = 50;
  public static DEFAULT_ROTATION_CLOSED: number = 0;
  public static DEFAULT_ROTATION_OPEN: number = 45;
  public static DEFAULT_ROTATION: number = SwitchComponent.DEFAULT_ROTATION_CLOSED;


  protected borderColor:string = SwitchComponent.DEFAULT_COLOR_BORDER;
  protected fillColor:string = SwitchComponent.DEFAULT_COLOR_FILL;
  protected length:number = SwitchComponent.DEFAULT_LENGTH;
  protected rotationClosed:number = SwitchComponent.DEFAULT_ROTATION_CLOSED;
  protected rotationOpen:number = SwitchComponent.DEFAULT_ROTATION_OPEN;
  protected rotation:number = SwitchComponent.DEFAULT_ROTATION;

  private midpoint: Coordinate;
  private startpoint: Coordinate;
  private endpoint: Coordinate;

    constructor(
        protected x: number,
        protected y: number
    ) 
    { 
      super(x,y);
      this.setMidpoint(x,y);
      this.setStartpoint(x,y);
      this.setEndpoint(x,y);
    }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
    }
      
    protected ApplyConfig(config: Array<any>)
    {
      debugger

      if( ! config )
      {
          return;
      }


      super.ApplyConfig(config);

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_SWITCH)
        {
          if( item.name == "border color")
          {
            this.setBorderColor(item.value);
          }
          else if( item.name == "fill color")
          {
            this.setFillColor(item.value);
          }
          else if( item.name == "length")
          {
            this.length = parseInt(item.value);
          }
          else if( item.name == "rotation open")
          {
            this.rotationOpen = parseInt(item.value);
          }
          else if( item.name == "rotation closed")
          {
            this.rotationClosed = parseInt(item.value);
          }
        }

        if( this.devicePoint )
        {
             this.devicePoint.Init(config);
        }

      }
    }
  
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_LINE)
        {
          if( item.name == "border color")
          {
            SwitchComponent.DEFAULT_COLOR_BORDER = item.default;
          }
          else if( item.name == "fill color")
          {
            SwitchComponent.DEFAULT_COLOR_FILL = item.default;
          }
          else if( item.name == "length")
          {
            SwitchComponent.DEFAULT_LENGTH = parseInt(item.default);
          }
          else if( item.name == "rotation open")
          {
            SwitchComponent.DEFAULT_ROTATION_OPEN = parseInt(item.default);
          }
          else if( item.name == "rotation closed")
          {
            SwitchComponent.DEFAULT_ROTATION_CLOSED = parseInt(item.default);
          }
       }
      }
    }
  

    public getType(): string
    {
         return this.type;
    } 

    private setMidpoint(x:number, y:number)
    {        
      this.midpoint = {
        x: x,
        y: y
      };
    }

    private setStartpoint(x:number, y:number)
    {        
      this.startpoint = {
        x: x,
        y: y
      };
    }

    private setEndpoint(x:number, y:number)
    {        
      this.endpoint = {
        x: x,
        y: y
      };
    }
  
  public draw( ctx: CanvasRenderingContext2D  )
  {
    debugger

   this.SetRotation();
   this.calcEndPoints();

   ctx.beginPath();
   ctx.strokeStyle = this.getFillColor();
   ctx.moveTo(this.startpoint.x, this.startpoint.y);
   ctx.lineTo(this.endpoint.x, this.endpoint.y);
   ctx.stroke();

   ctx.fillStyle = this.getFillColor();
   ctx.fill();
 
   if( this.drawBR )
   {
     this.drawBoundedRect(ctx);
   }
  }

  private calcEndPoints()
  {
    //debugger
    this.setMidpoint(this.x, this.y);

    if(this.rotation == 0 || this.rotation == 180 || this.rotation == 360)
    {
      this.startpoint.y = this.midpoint.y - this.length/2;
      this.endpoint.y = this.midpoint.y + this.length/2;

      this.startpoint.x = this.midpoint.x;
      this.endpoint.x = this.midpoint.x;
    }
    else if(this.rotation == 90 || this.rotation == 270)
    {
      this.startpoint.y = this.midpoint.y;
      this.startpoint.x = this.midpoint.x - this.length/2;

      this.endpoint.y = this.midpoint.y;
      this.endpoint.x = this.midpoint.x + this.length/2;
    }
    //else if(this.rotation == 45)
    else if(this.rotation == 45 || this.rotation == 225)
    {
      this.startpoint.x = this.midpoint.x - this.length/2;
      this.startpoint.y = this.midpoint.y + this.length/2;

      this.endpoint.x = this.midpoint.x + this.length/2;
      this.endpoint.y = this.midpoint.y - this.length/2;
    }
    // else if(this.rotation == 135)
    else if(this.rotation == 135 || this.rotation == 315)
    {
      this.startpoint.x = this.midpoint.x - this.length/2;
      this.startpoint.y = this.midpoint.y - this.length/2;

      this.endpoint.x = this.midpoint.x + this.length/2;
      this.endpoint.y = this.midpoint.y + this.length/2;
    }  

    // //else if(this.rotation == 45)
    // else if(this.rotation > 0 && this.rotation < 90 ||
    //         this.rotation < 180 && this.rotation < 270 )
    // {
    //   this.startpoint.x = this.midpoint.x - this.len/2;
    //   this.startpoint.y = this.midpoint.y + this.len/2;

    //   this.endpoint.x = this.midpoint.x + this.len/2;
    //   this.endpoint.y = this.midpoint.y - this.len/2;
    // }
    // //else if(this.rotation == 135)
    // else if(this.rotation > 90 && this.rotation < 180 ||
    //   this.rotation > 270 && this.rotation < 360 )
    // {
    //   this.startpoint.x = this.midpoint.x - this.len/2;
    //   this.startpoint.y = this.midpoint.y - this.len/2;

    //   this.endpoint.x = this.midpoint.x + this.len/2;
    //   this.endpoint.y = this.midpoint.y + this.len/2;
    // }  

  }

  public drawBoundedRect( ctx: CanvasRenderingContext2D )
  {
    // Draw Border.
    ctx.beginPath();
    ctx.strokeStyle = "pink";
    ctx.lineWidth = 2;
    //ctx.setLineDash([1, 2]);
  
    ctx.beginPath();
    ctx.strokeStyle = this.getFillColor();
    ctx.moveTo(this.startpoint.x, this.startpoint.y);
    ctx.lineTo(this.endpoint.x, this.endpoint.y);
    ctx.stroke();
 
    ctx.fillStyle = this.getFillColor();
    ctx.fill(); 
  }

   public deserialize(obj:any)
   {
     debugger
     this.dragging = obj.dragging;
     this.dragTL = obj.dragTL;
     this.dragTR = obj.dragTR;
     this.dragBL = obj.dragBL;
     this.dragBR = obj.dragBR;
     this.closeEnough = obj.closeEnough;
     this.displayText = obj.displayText;
     this.borderColor = obj.borderColor;
     this.fillColor = obj.fillColor;
    //  this.rotationClosed = obj.rotationClosed;
    //  this.rotationOpen = obj.rotationOpen;
    //  this.length = obj.length;
     this.SetRotation();
   }
 

   public isSelected(pos_x: number, pos_y: number): boolean
   {
        // Make sure the given position's [x,y] coordinates 
        // fall within this shape's bounding rectangle.
        if(  this.rotation == 0 || this.rotation == 180 || this.rotation == 360 )
        {
          // Vertical
          if( (this.startpoint.y <= pos_y) && 
              (this.endpoint.y  >= pos_y ) &&
              (this.endpoint.x <= pos_x + 10 ) &&
              (this.endpoint.x >= pos_x - 10 ) )
          {
            console.log("V Line Selected for x: " + pos_x + "  y: " + pos_y);
            this.checkForResizing(pos_x, pos_y);
            return true;    
          }
        }
        else if(  this.rotation == 90 || this.rotation == 270 )
        {
          // Horizontal
          if ((this.startpoint.x <= pos_x) && 
              (this.endpoint.x  >= pos_x) &&
              (this.endpoint.y <= pos_y + 10) &&
              (this.endpoint.y >= pos_y - 10) )
          {
            console.log("H Line Selected for x: " + pos_x + "  y: " + pos_y);
            this.checkForResizing(pos_x, pos_y);
            return true;    
          }
        }
        else
        {
          // TODO: Check y-coordinate limits.

          // Diag Angle
          if (this.rotation == 45 || this.rotation == 225 )
          {
            if ( (this.startpoint.x <= pos_x) && 
                (this.endpoint.x  >= pos_x) &&
                (this.startpoint.y >= pos_y ) &&
                (this.endpoint.y <= pos_y ) )
            {
              console.log("Diagonal 45% Line Selected for x: " + pos_x + "  y: " + pos_y);
              this.checkForResizing(pos_x, pos_y);
              return true;    
            }
          }
          else if (this.rotation == 135 || this.rotation == 315 )
          {
            if ( (this.startpoint.x <= pos_x) && 
                (this.endpoint.x  >= pos_x) &&
                (this.startpoint.y <= pos_y ) &&
                (this.endpoint.y >= pos_y ) )
            {
              console.log("Diagonal 135% Line Selected for x: " + pos_x + "  y: " + pos_y);
              this.checkForResizing(pos_x, pos_y);
              return true;    
            }
          }
        }

        //this.dragging = false;
        return false;
   }

   checkForResizing(pos_x: number, pos_y: number) 
   {
     console.log("Executing LineComponent.checkForResizing() for pos_x: " + pos_x + "  pos_y:" + pos_y + "\r\n" + 
          "startpoint: [" + this.startpoint.x  + "," + this.startpoint.y + "]");

     this.initDraggingStates();

     if ( this.isCloseEnough(pos_x, this.startpoint.x) && this.isCloseEnough(pos_y, this.startpoint.y) )
     {
          // Dragging Top-Left corner.
          this.dragTL = true;
          console.log("dragTL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.endpoint.x) && this.isCloseEnough(pos_y, this.endpoint.y) )
     {
          // Dragging Top-Right corner.
          //this.dragTR = true;
          this.dragTL = true;
          console.log("dragTR = true");
     }
     else
     {
          // Dragging entire symbol.
          this.dragging = true;
          console.log("dragging = true");
     }
   }

   // Resize for all positions.
   public resizeTL(pos_x: number, pos_y: number)
   {
     console.log("Executing LineComponent.resizeTL() for x: " + pos_x + "  y: " + pos_y);

    if( this.rotation == 0 || this.rotation == 180 || this.rotation == 360 )
    {
      // Vertical
      this.length = Math.abs(this.midpoint.y - pos_y) * 2;
      this.calcEndPoints();
    }
    else if( this.rotation == 90 || this.rotation == 270)
    {
      // Horizontal
      this.length = Math.abs(this.midpoint.x - pos_x) * 2;
      this.calcEndPoints();
    }
    else
    {
      // Diagonal.
      let diff = Math.abs(this.midpoint.x-pos_x);
      this.length = Math.abs(diff/Math.cos(this.rotation)) * 2;
      this.calcEndPoints();
    }
   }

   public resizeTR(pos_x: number, pos_y: number)
   {
     console.log("Executing LineComponent.resizeTR() for x: " + pos_x + "  y: " + pos_y);

     this.resizeTL(pos_x, pos_y);
     return;

   }

   public resizeBL(pos_x: number, pos_y: number)
   {
     console.log("Executing LineComponent.resizeBL() for x: " + pos_x + "  y: " + pos_y);

     this.resizeTL(pos_x, pos_y);
     return;
   }

   public resizeBR(pos_x: number, pos_y: number)
   {
     console.log("Executing LineComponent.resizeBR() for x: " + pos_x + "  y: " + pos_y);

     this.resizeTL(pos_x, pos_y);
     return;
   }

   protected getFillColor(): string
   {
     if( this.devicePoint == null)
     {
         return this.fillColor;
     }
     return this.devicePoint.getFillColor();
   }

   protected getBorderColor(): string
   {
     if( this.devicePoint == null )
     {
         return this.borderColor;
     }
     else
     {
         return this.devicePoint.getBorderColor();
     }
   }

   protected setBorderColor(val: string)
   {
     this.borderColor = val;
   }

   protected setFillColor(val: string)
   {
     this.fillColor = val;
   }

   public setRotationOpen(val: number)
   {
     this.rotationOpen = val;
   }

   public getRotationOpen(): number
   {
     return this.rotationOpen;
   }

   public setRotationClosed(val: number)
   {
     this.rotationClosed = val;
   }

   public getRotationClosed(): number
   {
     return this.rotationClosed;
   }


   public setLength(val: number)
   {
     this.length = val;
   }

   public getLength(): number
   {
     return this.length
   }

  public LoadProperties(propdata: { [key: string]: Object }[])
  {
    console.log("Executing LineComponent.LoadProperties().");
    // Load the property array with symbol properties.

    let item:any = {name: "type", value: this.type};
    propdata.push(item);
    item = {name: "startpoint x", value: this.startpoint.x};
    propdata.push(item);
    item = {name: "startpoint y", value: this.startpoint.y};
    propdata.push(item);
    item = {name: "midpoint x", value: this.midpoint.x};
    propdata.push(item);
    item = {name: "midpoint y", value: this.midpoint.y};
    propdata.push(item);
    item = {name: "endpoint x", value: this.endpoint.x};
    propdata.push(item);
    item = {name: "endpoint y", value: this.endpoint.y};
    propdata.push(item);
    item = {name: "x", value: this.x};
    propdata.push(item);
    item = {name: "y", value: this.y};
    propdata.push(item);
    item = {name: "length", value: this.length};
    propdata.push(item);
    item = {name: "rotation open", value: this.rotationOpen};
    propdata.push(item);
    item = {name: "rotation closed", value: this.rotationClosed};
    propdata.push(item);

    if( this.devicePoint != null )
    {
      //item = {name: "", value: ""};
      //propdata.push(item);
      this.devicePoint.LoadProperties(propdata);
    }
    else
    {        
      // Load the property array with symbol properties.
      //let item:any = {name: "bordercolor", value: this.borderColor};
      //propdata.push(item);
      item = {name: "fillcolor", value: this.fillColor};
      propdata.push(item);

    }
  }

  public saveProperty(name: string, value: string): boolean
  {
      console.log("Executing LineComponent.SaveProperty().");

      if( name == "bordercolor")
      {
          this.borderColor = value;
          return true;
      }
      else if( name == "fillcolor")
      {
          this.fillColor = value;
          return true;
      }
      else if( name == "midpoint x")
      {
          this.midpoint.x = parseInt(value);
          this.x = parseInt(value);
          return true;
      }
      else if( name == "midpoint y")
      {
          this.midpoint.y = parseInt(value);
          this.y = parseInt(value);
          return true;
      }
      else if( name == "rotation open")
      {
          this.rotationOpen = parseInt(value);
          this.SetRotation();
          return true;
      }
      else if( name == "rotation closed")
      {
          this.rotationClosed = parseInt(value);
          this.SetRotation();
          return true;
      }
      else if( name == "length")
      {
          this.length = parseInt(value);
          return true;
      }
            
      //super.saveProperty(name, value);
      return false;
  } 

  public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
  {
      console.log("Executing LineComponent.LoadDefaultProperties().");

      let item:any = {name: "type", value: ShapeComponent.SYMBOL_TYPE_CIRCLE};
      propdata.push(item);

      //item = {name: "bordercolor", value: LineComponent.COLOR_BORDER};
      //propdata.push(item);
      item = {name: "fillcolor", value: SwitchComponent.DEFAULT_COLOR_FILL};
      propdata.push(item);
      item = {name: "length", value: SwitchComponent.DEFAULT_LENGTH};
      propdata.push(item);
      item = {name: "rotation open", value: SwitchComponent.DEFAULT_ROTATION_OPEN};
      propdata.push(item);
      item = {name: "rotation closed", value: SwitchComponent.DEFAULT_ROTATION_CLOSED};
      propdata.push(item);
    
      //super.LoadDefaultProperties(propdata);
  }


  public static saveDefaultProperty(name: string, value: string)
  {
      console.log("Executing LineComponent.SaveDefaultProperty().");

      if( name == "bordercolor")
      {
          SwitchComponent.DEFAULT_COLOR_BORDER = value;
      }
      else if( name == "fillcolor")
      {
          SwitchComponent.DEFAULT_COLOR_FILL = value;
      }
      else if( name == "length")
      {
          SwitchComponent.DEFAULT_LENGTH = parseInt(value);
      }
      else if( name == "rotation open")
      {
          SwitchComponent.DEFAULT_ROTATION_OPEN = parseInt(value);
      }
      else if( name == "rotation closed")
      {
          SwitchComponent.DEFAULT_ROTATION_CLOSED = parseInt(value);
      }
            
      //super.saveDefaultProperty(name, value);
  }

  private SetRotation()
  {
    if( this.devicePoint != null )
    {
      if( this.devicePoint.getValue() == this.devicePoint.onValue )
      {
        this.rotation = this.rotationOpen;
      }
      else
      {
        this.rotation = this.rotationClosed;
      }
    }
  }

  // public GetRotation(): number
  // {
  //   if( this.devicePoint != null )
  //   {
  //     if( this.devicePoint.getValue() == this.devicePoint.onValue )
  //     {
  //       return SwitchComponent.DEFAULT_ROTATION_OPEN;
  //     }
  //     else
  //     {
  //       return SwitchComponent.DEFAULT_ROTATION_CLOSED;
  //     }
  //   }
  // }

  
  public AdjustProperties(): boolean
  {
    this.SetRotation();
    return true;
  }

}
