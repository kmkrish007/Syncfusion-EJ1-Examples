import {ShapeComponent} from './shape.component';
import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';

export class CircleComponent extends ShapeComponent{

     protected type = ShapeComponent.SYMBOL_TYPE_CIRCLE;

     public static DEFAULT_COLOR_BORDER: string = "red";
     public static DEFAULT_COLOR_FILL: string = "green";
     public static DEFAULT_RADIUS: number = 20; 
     public static DEFAULT_STARTANGLE: number = 0;
     public static DEFAULT_ENDANGLE: number = 2*Math.PI;
     public static DEFAULT_COUNTERCLOCKWISE: boolean = false;

     protected borderColor:string = CircleComponent.DEFAULT_COLOR_BORDER;
     protected fillColor:string = CircleComponent.DEFAULT_COLOR_FILL;

     protected radius:number = CircleComponent.DEFAULT_RADIUS;
     protected startAngle:number = CircleComponent.DEFAULT_STARTANGLE;
     protected endAngle:number = CircleComponent.DEFAULT_ENDANGLE;
     protected counterclockwise:boolean = CircleComponent.DEFAULT_COUNTERCLOCKWISE;


     constructor(
        protected x: number,
        protected y: number
    ) 
    { 
        super(x,y);
    }

    public Init(config: Array<any>)
    {
        this.ApplyConfig(config);
    }

    public setRadius(val:number)
    {
         this.radius = val;
    }

    public setStartAngle(val:number)
    {
         this.startAngle = val;
    }

    public setEndAngle(val:number)
    {
         this.endAngle = val;
    }

    public setCounterclockwise(val:boolean)
    {
         this.counterclockwise = val;
    }

    protected getFontString(): string
    {
      debugger
      if( this.devicePoint == null )
      {
        console.log("ShapeComponent.getFontString(): " + DevicePointComponent.GetFontString());
        return DevicePointComponent.GetFontString();
      }
      else
      {
        console.log("ShapeComponent.getFontString(): " + this.devicePoint.getFontString());
        return this.devicePoint.getFontString();
      }
    }
 
  
    protected ApplyConfig(config: Array<any>)
    {
     //debugger

     if( ! config )
     {
         return;
     }

     super.ApplyConfig(config);

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_CIRCLE)
        {
          if( item.name == "border color")
          {
            this.setBorderColor(item.value);
          }
          else if( item.name == "fill color")
          {
            this.setFillColor(item.value);
          }
          else if( item.name == "radius")
          {
            this.radius = parseInt(item.value);
          }
        }

        if( this.devicePoint )
        {
             this.devicePoint.Init(config);
        }
      }
    }
  
    public static ApplyDefaultConfig(config: Array<any>)
    {
     if( ! config )
     {
         return;
     }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_SYMBOL_CIRCLE)
        {
          if( item.name == "border color")
          {
            CircleComponent.DEFAULT_COLOR_BORDER = item.default;
          }
          else if( item.name == "fill color")
          {
            CircleComponent.DEFAULT_COLOR_FILL = item.default;
          }
          else if( item.name == "radius")
          {
            CircleComponent.DEFAULT_RADIUS = parseInt(item.default);
          }
       }
      }
    }
  

    public deserialize(obj:any)
    {
      debugger
      this.dragging = obj.dragging;
      this.dragTL = obj.dragTL;
      this.dragTR = obj.dragTR;
      this.dragBL = obj.dragBL;
      this.dragBR = obj.dragBR;
      this.closeEnough = obj.closeEnough;
      this.displayText = obj.displayText;
      this.borderColor = obj.borderColor;
      this.fillColor = obj.fillColor;
    }

    public getType(): string
    {
         return this.type;
    }
      
    public show()
    {
          console.log("Executing CircleComponent.show() - x: " + this.x + "  y: " + this.y + "  radius: " + this.radius + " Start Angle: " + this.startAngle + "  End Angle: " + this.endAngle);

    }
      
   public draw( ctx: CanvasRenderingContext2D  )
   {    
        console.log("Executing CircleComponent.draw()");

        // Draw the border.
        ctx.beginPath();
        ctx.strokeStyle = this.getBorderColor();
        ctx.arc(this.x, this.y, this.radius, this.startAngle, this.endAngle, this.counterclockwise);
        ctx.stroke();

        // Draw the fill.
        ctx.fillStyle = this.getFillColor();
        ctx.fill();

        // Draw Display Text (e.g. value).
        ctx.font = this.getFontString();
        let txt: string = this.getDisplayText();
        //ctx.fillStyle = "black";
        ctx.fillStyle = this.getTextColor();
        let x:number = this.x - ctx.measureText(txt).width/2;
        let y:number = this.y;
        ctx.fillText(this.getDisplayText(), x, y);

        if( this.drawBR )
        {
          this.drawBoundedRect(ctx);
        }
   }

   public drawBoundedRect( ctx: CanvasRenderingContext2D )
   {
     console.log("Executing CircleComponent.drawBoundedRect()");

        // Draw the border.
        ctx.beginPath();
        ctx.strokeStyle = "pink"
        ctx.lineWidth = 1;
        ctx.setLineDash([1, 2]);
        ctx.arc(this.x, this.y, this.radius + 20, this.startAngle, this.endAngle, this.counterclockwise);
        ctx.stroke();  
    }
 
   public isSelected(pos_x: number, pos_y: number): boolean
   {
       console.log("CircleComponent.isSelected() for radius: " + this.radius + "  x: " + this.x + "  y: " + this.y + " pos_x: " + pos_x + "  + pos_y: " + pos_y );

        // Make sure the given position's [x,y] coordinates 
        // fall within this shape's bounding rectangle.
        if ( (this.x + this.radius >= pos_x) &&
             (this.x - this.radius <= pos_x) &&
             (this.y + this.radius >= pos_y) &&
             (this.y - this.radius <= pos_y) )
        {
          //    this.dragging = true;
          //    return true;

             console.log("Circle Selected.");
             this.checkForResizing(pos_x, pos_y);
             return true;
        }

     //    this.dragging = false;
        return false;
   }

   checkForResizing(pos_x: number, pos_y: number) 
   {
     console.log("Executing CircleComponent.checkForResizing() for pos_x: " + pos_x + "  pos_y:" + pos_y + "  radius: " + this.radius + "  x: " + this.x + "  y: " + this.y);

     this.initDraggingStates();

     let x = this.x + this.radius;
     let y = this.y + this.radius;

     if( pos_x < this.x)
     {
          x = this.x - this.radius;
     }

     if( pos_y < this.y)
     {
          y = this.y - this.radius;
     }

     if ( this.isCloseEnough(pos_x, x) || this.isCloseEnough(pos_y, y) )
     {
          this.dragTL = true;
          console.log("dragTL = true");
     }
     else
     {
          // Dragging entire symbol.
          this.dragging = true;
          console.log("dragging = true");
     }
   }

   public resizeTL(pos_x: number, pos_y: number)
   {
        this.resize(pos_x, pos_y);
   }

   public resizeTR(pos_x: number, pos_y: number)
   {
        this.resize(pos_x, pos_y);
   }

   public resizeBL(pos_x: number, pos_y: number)
   {
        this.resize(pos_x, pos_y);
   }

   public resizeBR(pos_x: number, pos_y: number)
   {
        this.resize(pos_x, pos_y);
   }


   // This method is the reize handler.
   // User must resize by top/side/bottom of circle (not arc in between).
   private resize(pos_x: number, pos_y: number)
   {
     console.log("Executing CircleComponent.resize() for pos_x: " + pos_x + "  pos_y: " + pos_y);

      let a = Math.abs(this.x - pos_x);
      let b = Math.abs(this.y - pos_y);
      console.log("Executing CircleComponent.resize() - a: " + a + "  b: " + b);

      this.radius = Math.sqrt((a*a) + (b*b));
      console.log("Executing CircleComponent.resize() - new radius: " + this.radius);
   }

   protected getFillColor(): string
   {
     if( this.devicePoint == null)
     {
         return this.fillColor;
     }
     return this.devicePoint.getFillColor();
   }

   protected getBorderColor(): string
   {
     if( this.devicePoint == null )
     {
         return this.borderColor;
     }
     else
     {
         return this.devicePoint.getBorderColor();
     }
   }

   protected setBorderColor(val: string)
   {
     this.borderColor = val;
   }

   protected setFillColor(val: string)
   {
     this.fillColor = val;
   }

     public LoadProperties(propdata: { [key: string]: Object }[])
     {
          console.log("Executing CircleComponent.LoadProperties().");

          // Load the property array with symbol properties.
          let item:any = {name: "type", value: this.type};
          propdata.push(item);  
          item = {name: "x", value: this.x};
          propdata.push(item);
          item = {name: "y", value: this.y};
          propdata.push(item);
          item = {name: "radius", value: this.radius};
          propdata.push(item);
          item = {name: "start angle", value: this.startAngle};
          propdata.push(item);
          item = {name: "end angle", value: this.endAngle};
          propdata.push(item);
          item = {name: "counter clockwise", value: this.counterclockwise};
          propdata.push(item);

          
          if( this.devicePoint != null )
          {
               //item = {name: "", value: ""};
               //propdata.push(item);
               
               this.devicePoint.LoadProperties(propdata);
          }
          else
          {               
               // Load the property array with symbol properties.
               let item:any = {name: "bordercolor", value: this.borderColor};
               propdata.push(item);
               item = {name: "fillcolor", value: this.fillColor};
               propdata.push(item);
          }
     }

     public saveProperty(name: string, value: string): boolean
     {
          console.log("Executing CircleComponent.SaveProperty().");

          debugger
          if( name == "bordercolor")
          {
              this.borderColor = value;
              return true;
          }
          else if( name == "fillcolor")
          {
              this.fillColor = value;
              return true;
          }
          else if( name == "x")
          {
              this.x = parseInt(value);
              return true;
          }
          else if( name == "y")
          {
              this.y = parseInt(value);
              return true;
          }      
          else if( name == "radius")
          {
              this.radius = parseInt(value);
              return true;
          }
          // else if( name == "start angle")
          // {
          //     this.startAngle = parseInt(value);
          //     return true;
          // }
          // else if( name == "end angle")
          // {
          //     this.endAngle = parseInt(value);
          //     return true;
          // }
          // else if( name == "counter clockwise")
          // {
          //      this.counterclockwise = false;
          //      if( value == "true")
          //      {
          //           this.counterclockwise = true;
          //      }
          //      return true;
          // }
                
          //super.saveProperty(name, value);

          return false;
     }  

     public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
     {
          console.log("Executing CircleComponent.LoadDefaultProperties().");

          let item:any = {name: "type", value: ShapeComponent.SYMBOL_TYPE_CIRCLE};
          propdata.push(item);

          item = {name: "bordercolor", value: CircleComponent.DEFAULT_COLOR_BORDER};
          propdata.push(item);
          item = {name: "fillcolor", value: CircleComponent.DEFAULT_COLOR_FILL};
          propdata.push(item);
          item = {name: "radius", value: CircleComponent.DEFAULT_RADIUS};
          propdata.push(item);
          item = {name: "start angle", value: CircleComponent.DEFAULT_STARTANGLE};
          propdata.push(item);
          item = {name: "end angle", value: CircleComponent.DEFAULT_ENDANGLE};
          propdata.push(item);
          item = {name: "counter clockwise", value: CircleComponent.DEFAULT_COUNTERCLOCKWISE};
          propdata.push(item);
        
          //super.LoadDefaultProperties(propdata);
     }


     public static saveDefaultProperty(name: string, value: string)
     {
          console.log("Executing CircleComponent.SaveDefaultProperty().");

          if( name == "bordercolor")
          {
              CircleComponent.DEFAULT_COLOR_BORDER = value;
          }
          else if( name == "fillcolor")
          {
              CircleComponent.DEFAULT_COLOR_FILL = value;
          }
          else if( name == "radius")
          {
              CircleComponent.DEFAULT_RADIUS = parseInt(value);
          }               
          // else if( name == "start angle")
          // {
          //      CircleComponent.DEFAULT_STARTANGLE = parseInt(value);
          //     return true;
          // }
          // else if( name == "end angle")
          // {
          //     CircleComponent.DEFAULT_ENDANGLE = parseInt(value);
          //     return true;
          // }
          // else if( name == "counter clockwise")
          // {
          //      let bvalue: boolean = false;
          //      if( value == "true")
          //      {
          //           bvalue = true;
          //      }
          //     CircleComponent.DEFAULT_COUNTERCLOCKWISE = bvalue;
          //     return true;
          // }

          //super.saveDefaultProperty(name, value);
     }
     
     public AdjustProperties(): boolean
     {
       debugger
       this.radius = CircleComponent.DEFAULT_RADIUS;
       return true;
     }




}