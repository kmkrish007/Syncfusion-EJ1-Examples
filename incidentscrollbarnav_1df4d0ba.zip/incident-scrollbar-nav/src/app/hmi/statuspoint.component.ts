import {DevicePointComponent} from './devicepoint.component';
import { ConfigDialog } from '../dialogs/configdialog';
import { Config } from '../config/config';

export class StatusPointComponent extends DevicePointComponent{

    private text_type = StatusPointComponent.POINT_TYPE_STATUS;

    protected forced: number = 0;

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_COLOR_ON: string = "red";
    public static DEFAULT_COLOR_OFF: string = "yellowgreen";
    public static DEFAULT_COLOR_ON_TEXT: string = "purple";
    public static DEFAULT_COLOR_OFF_TEXT: string = "magenta";

    // public static COLOR_FAILED: string = "red";
    // public static COLOR_FORCED: string = "blue";

    // Configurable when point type selected on toolbox tree.
    public static DEFAULT_FILLCOLOR: string = "black";
    public static DEFAULT_BORDERCOLOR: string = "red";
    public static DEFAULT_TEXTCOLOR: string = "red";
    public static DEFAULT_DISPLAYTEXT: string = "";
    public static DEFAULT_FONTFAMILY: string = "Arial";
    public static DEFAULT_FONTSIZE: number = 50;
    public static DEFAULT_ON_TEXT: string = "on";
    public static DEFAULT_OFF_TEXT: string = "off";

    // Configurable when point mapped to symbol on map.
    protected onColor: string = StatusPointComponent.DEFAULT_COLOR_ON;
    protected offColor: string = StatusPointComponent.DEFAULT_COLOR_OFF;
    protected onTextColor: string = StatusPointComponent.DEFAULT_COLOR_ON_TEXT;
    protected offTextColor: string = StatusPointComponent.DEFAULT_COLOR_OFF_TEXT;
    
    // Configurable when point mapped to symbol on map.
    //protected borderColor: string = StatusPointComponent.DEFAULT_BORDERCOLOR;
    //protected fillColor: string = StatusPointComponent.DEFAULT_FILLCOLOR;
    //protected displayText: string = StatusPointComponent.DEFAULT_DISPLAYTEXT;
    //protected fontFamily: string = StatusPointComponent.DEFAULT_FONTFAMILY;
    //protected fontSize: number = StatusPointComponent.DEFAULT_FONTSIZE;
    //protected textColor: string = StatusPointComponent.DEFAULT_TEXTCOLOR;

    //protected failedColor: string = DevicePointComponent.DEFAULT_COLOR_FAILED;
    //protected forcedColor: string = DevicePointComponent.DEFAULT_COLOR_FORCED;
    

    constructor(
        protected deviceType: string,
        protected deviceName: string,
        protected sn: number,
        protected ied: number,
        protected pointid: string,
        protected pointname: string,
        protected units: number,
        private ts: number,
        private offText: string,
        private onText: string
    ) 
    {
        super(deviceType, deviceName, sn, ied, pointid, pointname, units);

        this.borderColor = StatusPointComponent.DEFAULT_BORDERCOLOR;
        this.fillColor = StatusPointComponent.DEFAULT_FILLCOLOR;
        this.displayText = StatusPointComponent.DEFAULT_DISPLAYTEXT;
        this.fontFamily = StatusPointComponent.DEFAULT_FONTFAMILY;
        this.fontSize = StatusPointComponent.DEFAULT_FONTSIZE;
        this.textColor = StatusPointComponent.DEFAULT_TEXTCOLOR;

        this.Init(Config.configdata);
    }
   
    public Init(config: Array<any>)
    {
      this.ApplyConfig(config);
    }
  
    protected ApplyConfig(config: Array<any>)
    {
      if( ! config )
      {
        return;
      }

      super.ApplyConfig(config);

      for( let i:number=0;i<config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_STATUS)
        {
          if( item.name == "on text")
          {
            this.onText = item.value;
          }
          else if( item.name == "off text")
          {
            this.offText = item.value;
          }
          else if( item.name == "on text color")
          {
            this.onTextColor = item.value;
          }
          else if( item.name == "off text color")
          {
            this.offTextColor = item.value;
          }
          else if( item.name == "on fill color")
          {
            this.onColor = item.value;
          }
          else if( item.name == "off fill color")
          {
            this.offColor = item.value;
          }
          else if( item.name == "font size")
          {
            //debugger
            this.fontSize = parseInt(item.value);
            console.log("StatusPointComponent - Applied config parameter - fontSize: " + this.fontSize.toString())
          }
          else if( item.name == "font family")
          {
            this.fontFamily = item.value;
          }          
          else if( item.name == "border color")
          {
            this.borderColor = item.value;
          }          
        }
      }
    }
    
    public static ApplyDefaultConfig(config: Array<any>)
    {
      if( ! config )
      {
          return;
      }

      for( let i:number=0;i>config.length; ++i )
      {
        let item: any = config[i];
        if( item.type == ConfigDialog.CONFIGTYPE_STATUS)
        {
          if( item.name == "on text")
          {
            StatusPointComponent.DEFAULT_ON_TEXT = item.default;
          }
          else if( item.name == "off text")
          {
            StatusPointComponent.DEFAULT_OFF_TEXT = item.default;
          }
          else if( item.name == "on text color")
          {
            StatusPointComponent.DEFAULT_COLOR_ON_TEXT = item.default;
          }
          else if( item.name == "off text color")
          {
            StatusPointComponent.DEFAULT_COLOR_OFF_TEXT = item.default;
          }
          else if( item.name == "on fill color")
          {
            StatusPointComponent.DEFAULT_COLOR_ON = item.default;
          }
          else if( item.name == "off fill color")
          {
            StatusPointComponent.DEFAULT_COLOR_OFF = item.default;
          }
          else if( item.name == "font size")
          {
            debugger
            StatusPointComponent.DEFAULT_FONTSIZE = parseInt(item.default);
          }
          else if( item.name == "font family")
          {
            debugger
            StatusPointComponent.DEFAULT_FONTFAMILY = item.default;
          }          
          else if( item.name == "border color")
          {
            StatusPointComponent.DEFAULT_BORDERCOLOR = item.default;
          }          
        }
      }
    }
      

      public deserialize(obj:any)
      {
          //debugger
          this.borderColor = obj.devicePoint.borderColor;
          this.fillColor = obj.devicePoint.fillColor;
          this.displayText = obj.devicePoint.displayText;
          this.fontFamily = obj.devicePoint.fontFamily;
          this.fontSize = obj.devicePoint.fontSize;
          this.textColor = obj.devicePoint.textColor;
          this.onColor = obj.devicePoint.onColor;
          this.offColor = obj.devicePoint.offColor;
          this.setTextColor();
      }

  

      public setTimestamp(val: number)
      {
          this.ts = val;
      }
  
      public getTimestamp()
      {
          return this.ts;
      }

      public setForced(val: number)
      {
          this.forced = val;
      }
  
      public getForced(): number
      {
          return this.forced;
      }

      // public GetFontString(): string
      // {
      //     return this.fontSize.toString + "px" + this.fontFamily;
      // }
  
    //   public setTextColor()
    //   {
    //     debugger
    //     // console.log("AnalogPointComponent.getFillColor() for: " + 
    //     //               this.getSN() + ":" + 
    //     //               this.getIed() + "-" + 
    //     //               this.getPointId());
    //     if( this.getFailed() )
    //     {
    //       // Failed Point.
    //       //console.log("Returning LOW LIMIT COLOR.");
    //       this.textColor = this.failedColor;
    //     }
    //     else if( this.getForced() )
    //     {
    //       // Forced Point.
    //       alert("Returning FORCED COLOR: " + this.forcedColor + " For Pt: " + this.getExtName());
    //       this.textColor = this.forcedColor;
    //     }
    //     else
    //     {
    //       // Normal Limit.
    //       //console.log("Returning NORMAL LIMIT COLOR.");
    //       this.textColor = this.normalColor;
    //     }
    //   }

      public getFillColor(): string
      {
        //debugger
        console.log("StatusPointComponent.getFillColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        
        // TODO: TEST ONLY.
        //this.setFailed(1);

        // if( this.getFailed()  )
        // {
        //     console.log("Returning FAILED COLOR.");
        //     return this.failedColor;
        // }
        if( this.value == this.onValue )
        {
            console.log("Returning ON COLOR.");
            return this.onColor;
        }
        else
        {
            console.log("Returning OFF COLOR.");
            return this.offColor;
        }
      }

      public getOnColor(): string
      {
        console.log("StatusPointComponent.getOnColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return this.onColor;
      }
  
      public getOffColor(): string
      {
        console.log("StatusPointComponent.getOnColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        return this.offColor;
      }
  

      public getDisplayText(): string
      {
        //console.log("StatusPointComponent.getDisplayText() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
        //return this.displayText;

        let txt:string = "";

        if( this.value == this.onValue )
        {
            txt = this.onText;
        }
        else if( this.value == this.offValue )
        {
            txt = this.offText;
        }

        if( this.getFailed() )
        {
            txt +=  " Failed";
        }
        if( this.getForced() )
        {
            txt += " Forced";
        }


        return txt;        
      }

      public LoadProperties(propdata: { [key: string]: Object }[])
      {
        console.log("Executing StatusPointComponent.LoadProperties().");

        // Load the property array with point properties.
        let item:any = {name: "type", value: this.getPointType()};
        propdata.push(item);

        item = {name: "ext name", value: this.getExtName()};
        propdata.push(item);
        item = {name: "sn", value: this.getSN()};
        propdata.push(item);
        item = {name: "ied", value: this.getIed()};
        propdata.push(item);
        item = {name: "pt", value: this.getPointId()};
        propdata.push(item);
        item = {name: "pid", value: this.getPid()};
        propdata.push(item);
        
        item = {name: "on text", value: this.onText};
        propdata.push(item);
        item = {name: "off text", value: this.offText};
        propdata.push(item);

        item = {name: "oncolor", value: this.onColor};
        propdata.push(item);
        item = {name: "offcolor", value: this.offColor};
        propdata.push(item);
        item = {name: "failed color", value: this.failedColor};
        propdata.push(item);
        item = {name: "forced color", value: this.forcedColor};
        propdata.push(item);
        item = {name: "on text color", value: this.onTextColor};
        propdata.push(item);
        item = {name: "off text color", value: this.offTextColor};
        propdata.push(item);


        item = {name: "bordercolor", value: this.borderColor};
        propdata.push(item);
        item = {name: "fontFamily", value: this.fontFamily};
        propdata.push(item);
        item = {name: "fontSize", value: this.fontSize};
        propdata.push(item);
        item = {name: "text color", value: this.textColor};
        propdata.push(item);    
      }

      public saveProperty(name: string, value: string): boolean
      {
          console.log("Executing StatusPointComponent.SaveProperty().");
  
          if( name == "bordercolor")
          {
              this.borderColor = value;
              return true;
          }
          else if( name == "oncolor")
          {
              this.onColor = value;
              return true;
          }
          else if( name == "offcolor")
          {
              this.offColor = value;
              return true;
          }
          else if( name == "failed color")
          {
              this.failedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "forced color")
          {
              this.forcedColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "on text color")
          {
              this.onTextColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "off text color")
          {
              this.offTextColor = value;
              this.setTextColor();
              return true;
          }
          else if( name == "fontsize")
          {
              this.fontSize = parseInt(value);
              return true;
          }
          else if( name == "fontfamily")
          {
              this.fontFamily = value;
              return true;
          }

        //   else if( name == "text color")
        //   {
        //       this.textColor = value;
        //       return true;
        //   }

          return false;
      }
  
      public static LoadDefaultProperties(propdata: { [key: string]: Object }[])
      {
        console.log("Executing StatusPointComponent.LoadDefaultProperties().");

        let item:any = {name: "type", value: StatusPointComponent.POINT_TYPE_STATUS};
        propdata.push(item);

        // Load the property array with point properties.
        item = {name: "bordercolor", value: StatusPointComponent.DEFAULT_BORDERCOLOR};
        propdata.push(item);
        item = {name: "displayText", value: StatusPointComponent.DEFAULT_DISPLAYTEXT};
        propdata.push(item);
        item = {name: "fontFamily", value: StatusPointComponent.DEFAULT_FONTFAMILY};
        propdata.push(item);
        item = {name: "fontSize", value: StatusPointComponent.DEFAULT_FONTSIZE};
        propdata.push(item);
        item = {name: "text color", value: StatusPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "on color", value: StatusPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        item = {name: "off color", value: StatusPointComponent.DEFAULT_TEXTCOLOR};
        propdata.push(item);    
        
        //super.LoadDefaultProperties(propdata);
      }

      public static saveDefaultProperty(name: string, value: string)
      {
          console.log("Executing StatusPointComponent.SaveProperty().");
  
          if( name == "bordercolor")
          {
            StatusPointComponent.BORDERCOLOR_DEFAULT = value;
          }
          else if( name == "oncolor")
          {
              StatusPointComponent.DEFAULT_COLOR_ON = value;
          }
          else if( name == "offcolor")
          {
              StatusPointComponent.DEFAULT_COLOR_OFF = value;
          }
          else if( name == "fontsize")
          {
              StatusPointComponent.DEFAULT_FONTSIZE = parseInt(value);
          }
          else if( name == "fontfamily")
          {
              StatusPointComponent.DEFAULT_FONTFAMILY = value;
          }
          else if( name == "text color")
          {
              StatusPointComponent.DEFAULT_TEXTCOLOR = value;
          }
      }

      // public getTextColor(): string
      // {
      // //console.log("DevicePointComponent.getTextColor() for: " + this.getSN() + ":" + this.getIed() + "-" + this.getPointId());
      // return this.textColor;
      // }
  

      public setTextColor()
      {
        //debugger

        // TODO: TEST ONLY.
        //this.setFailed(1);
        //this.setForced(1);

        // console.log("AnalogPointComponent.getFillColor() for: " + 
        //               this.getSN() + ":" + 
        //               this.getIed() + "-" + 
        //               this.getPointId());
        if( this.getFailed() )
        {
          // Failed Point.
          this.textColor = this.failedColor;
        }
        else if( this.getForced() )
        {
          // Forced Point.
          //console.log("Returning FORCED COLOR: " + this.forcedColor + " For Pt: " + this.getExtName());
          this.textColor = this.forcedColor;
        }
        else if( this.value == this.onValue )
        {
            this.textColor = this.onTextColor;
        }
        else if( this.value == this.offValue )
        {
            this.textColor = this.offTextColor;            
        }
      }


  
      public AdjustProperties(): boolean
      {
        //this.fontSize = 20;
        this.setTextColor();
        return true;
      }
 
}