import {ShapeComponent} from './shape.component';

export class CircularGradientComponent extends ShapeComponent{
    constructor(
        //The x-coordinate of the starting circle of the gradient
        public x0: number,

        //The y-coordinate of the starting circle of the gradient
        public y0: number,

        //The radius of the starting circle
        public r0: number,

        //The x-coordinate of the starting circle of the gradient
        public x1: number,

        //The y-coordinate of the starting circle of the gradient
        public y1: number,

        //The radius of the ending circle
        public r1: number,
        
        public colorStop1: string,
        public colorStop2: string,
        
        // A value between 0.0 and 1.0 that represents the position between start and end in a gradient
        public colorStopValue1: number,
        public colorStopValue2: number,

        // The x-coordingate of the enclosing rectangle.
        protected x: number,
        // The y-coordinate of the enclosing rectangle.
        protected y: number,

        // The width of the enclosing rectangle.
        public width: number,

        // The height of the enclosing rectangle.
        public height: number
    ) { super(x,y) } 
      
   public draw( ctx: CanvasRenderingContext2D  )
   {    
      // Create gradient
      var grd = ctx.createRadialGradient(this.x0, this.y0, this.r0, this.x1,this.y1, this.r1);
      grd.addColorStop(this.colorStopValue1, this.colorStop1);
      grd.addColorStop(this.colorStopValue2, this.colorStop2);

      // Fill with gradient
      ctx.fillStyle = grd;
      ctx.strokeStyle = "red";
      ctx.fillRect(this.x, this.y, this.width, this.height);
   }

   public isSelected(pos_x: number, pos_y: number): boolean
   {
       console.log("Executing CircularGradientComponent.isSelected() for x: " + pos_x + "  y:" + pos_y);

        // Make sure the given position's [x,y] coordinates 
        // fall within this shape's bounding rectangle.
        if ( (this.x <= pos_x) && 
             (this.x + this.width >= pos_x) &&
             (this.y <= pos_y) && 
             (this.y + this.height >= pos_y))
        {
            console.log("CircularGradient Selected.");
            this.checkForResizing(pos_x, pos_y);
            return true;  
        }

        return false;
   }

   checkForResizing(pos_x: number, pos_y: number) 
   {
     console.log("Executing CircularGradientComponent.checkForResizing() for x: " + pos_x + "  y:" + pos_y);

     this.initDraggingStates();

     if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Left corner.
          this.dragTL = true;
          console.log("dragTL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.width) && this.isCloseEnough(pos_y, this.y) )
     {
          // Dragging Top-Right corner.
          this.dragTR = true;
          console.log("dragTR = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x) && this.isCloseEnough(pos_y, this.y + this.height) )
     {
          // Dragging Bottom-Left corner.
          this.dragBL = true;
          console.log("dragBL = true");
     }
     else if ( this.isCloseEnough(pos_x, this.x + this.width) && this.isCloseEnough(pos_y, this.y + this.height) )
     {
          // Dragging Bottom-Right corner.
          this.dragBR = true;
          console.log("dragBR = true");
     }
     else
     {
          // Dragging entire symbol.
          this.dragging = true;
          console.log("dragging = true");
     }
   }


   public resizeTL(pos_x: number, pos_y: number)
   {
     console.log("Executing CircularGradientComponent.resizeTL() for x: " + pos_x + "  y: " + pos_y);

     this.width += this.x - pos_x;
     this.height += this.y - pos_y;
     this.x = pos_x;
     this.y = pos_y;
   }

   public resizeTR(pos_x: number, pos_y: number)
   {
     console.log("Executing CircularGradientComponent.resizeTR() for x: " + pos_x + "  y: " + pos_y);

     this.width = Math.abs(this.x - pos_x);
     this.height += this.y - pos_y;
     this.y = pos_y;
   }

   public resizeBL(pos_x: number, pos_y: number)
   {
     console.log("Executing CircularGradientComponent.resizeBL() for x: " + pos_x + "  y: " + pos_y);

     this.width += this.x - pos_x;
     this.height = Math.abs(this.y - pos_y);
     this.x = pos_x;

   }

   public resizeBR(pos_x: number, pos_y: number)
   {
     console.log("Executing CircularGradientComponent.resizeBR() for x: " + pos_x + "  y: " + pos_y);

     this.width = Math.abs(this.x - pos_x);
     this.height = Math.abs(this.y - pos_y);
   }


}