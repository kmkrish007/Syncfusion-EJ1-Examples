import { Component} from '@angular/core';
import { Grid, Column} from '@syncfusion/ej2-grids';
import { ColorPicker, TextBox} from '@syncfusion/ej2-inputs';
import { Dialog } from '@syncfusion/ej2-popups';
import {isNullOrUndefined } from 'util';
import {StreamWriter} from '@syncfusion/ej2-file-utils';
import {Config} from '../config/config'

export class ConfigDialog 
{ng
    private propgrid: Grid = null;

    public dialog: Dialog = null;


    // public static PARENT_TYPE_NONE:number = 0;
    // public static PARENT_TYPE_TREEVIEW:number = 1;
    // public static PARENT_TYPE_DBC:number = 2;

    // Data store associated with the property grid
    //public propdata_toolbox: { [key: string]: Object }[] = []; 


    // List of configuration parameters/values.
    //public configdata: { [key: string]: Object }[] = [];

    // private static CONFIGTYPE_NONE = 0;
    // private static CONFIGTYPE_GENERAL = 10;
    // private static CONFIGTYPE_ALLPOINTS = 20;
    // private static CONFIGTYPE_STATUS = 21;
    // private static CONFIGTYPE_ANALOG = 22;
    // private static CONFIGTYPE_ACCUM = 23;
    // private static CONFIGTYPE_CONTROL = 24;
    // private static CONFIGTYPE_SETPOINT = 25;
    // private static CONFIGTYPE_SYMBOL_ALL = 30;
    // private static CONFIGTYPE_SYMBOL_RECT =31;
    // private static CONFIGTYPE_SYMBOL_CIRCLE = 32;
    // private static CONFIGTYPE_SYMBOL_LINE = 33;
    // private static CONFIGTYPE_SYMBOL_TEXT = 34;

    public static CONFIGTYPE_NONE = 0;
    public static CONFIGTYPE_GENERAL = 1;
    public static CONFIGTYPE_ALLPOINTS = 2;
    public static CONFIGTYPE_STATUS = 3;
    public static CONFIGTYPE_ANALOG = 4;
    public static CONFIGTYPE_ACCUM = 5;
    public static CONFIGTYPE_CONTROL = 6;
    public static CONFIGTYPE_SETPOINT = 7;
    public static CONFIGTYPE_SYMBOL_ALL = 8;
    public static CONFIGTYPE_SYMBOL_RECT =9;
    public static CONFIGTYPE_SYMBOL_CIRCLE = 10;
    public static CONFIGTYPE_SYMBOL_LINE = 11;
    public static CONFIGTYPE_SYMBOL_TEXT = 12;
    public static CONFIGTYPE_SYMBOL_SWITCH = 13;

    private static CONFIG_NONE = "0-none";
    private static CONFIG_GENERAL = "10-general";
    private static CONFIG_ALLPOINTS = "12-all points";
    private static CONFIG_STATUS = "13-status points";
    private static CONFIG_ANALOG = "14-analog points";
    private static CONFIG_ACCUM = "15-accumulator points";
    private static CONFIG_CONTROL = "16-control points";
    private static CONFIG_SETPOINT = "17-setpoints";
    private static CONFIG_SYMBOL_ALL = "18-all synbols";
    private static CONFIG_SYMBOL_RECT = "19-rectangle";
    private static CONFIG_SYMBOL_CIRCLE = "20-circle";
    private static CONFIG_SYMBOL_LINE = "21-line";
    private static CONFIG_SYMBOL_TEXT = "22-text";



    // private configdefs: { [key: string]: Object }[] = 
    // [
    //     {value:ConfigComponent.CONFIGTYPE_NONE,name:"none" },
    //     {value:ConfigComponent.CONFIGTYPE_GENERAL,name:"general" },
    //     {value:ConfigComponent.CONFIGTYPE_ALLPOINTS,name:"all points" },
    //     {value:ConfigComponent.CONFIGTYPE_STATUS,name:"all points" },
    //     {value:ConfigComponent.CONFIGTYPE_ANALOG,name:"analog points" },
    //     {value:ConfigComponent.CONFIGTYPE_ACCUM,name:"accumulator points" },
    //     {value:ConfigComponent.CONFIGTYPE_CONTROL,name:"control points" },
    //     {value:ConfigComponent.CONFIGTYPE_SETPOINT,name:"setpoints" },
    //     {value:ConfigComponent.CONFIGTYPE_SYMBOL_ALL,name:"all synbols" },
    //     {value:ConfigComponent.CONFIGTYPE_SYMBOL_RECT,name:"rectangle" },
    //     {value:ConfigComponent.CONFIGTYPE_SYMBOL_CIRCLE,name:"circle" },
    //     {value:ConfigComponent.CONFIGTYPE_SYMBOL_LINE,name:"line" },
    //     {value:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,name:"text" },
    //     {value:ConfigComponent.CONFIGTYPE_SYMBOL_SWITCH,name:"switch" },
    // ]


    //private sortResults: Array<any> = [];

    //public static configdata: { [key: string]: Object }[] = [];
    
    // public static configdata: { [key: string]: Object }[] = 
    // [
    //     // FOR TEST:
    //     // {name:"failed color",value:"red",type:ConfigComponent.CONFIGTYPE_ALLPOINTS,group:"Status Points",description:"The failed text color for all point types."},
    //     // {name:"forced color",value:"blue",type:ConfigComponent.CONFIGTYPE_ALLPOINTS,group:"Analog Points",description:"The forced text color for status, analog and accumulor point types."},
    //     // {name:"on fill color",value:"red",type:ConfigComponent.CONFIGTYPE_STATUS,group:"Status Points",description:"The fill color for normal (on) state status points."},
    //     {name:"point order",value:"status",default:"status",type:ConfigComponent.CONFIGTYPE_GENERAL,group:ConfigComponent.CONFIG_GENERAL,description:"Whether to display status or analog points first; accumulators are always third then controls then setpoints."},

    //     {name:"failed color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_ALLPOINTS,group:ConfigComponent.CONFIG_ALLPOINTS,description:"The failed text color for all point types."},
    //     {name:"forced color",value:"blue",default:"blue",type:ConfigComponent.CONFIGTYPE_ALLPOINTS,group:ConfigComponent.CONFIG_ALLPOINTS,description:"The forced text color for status, analog and accumulor point types."},

    //     {name:"on fill color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The fill color for normal (on) state status points."},
    //     {name:"off fill color",value:"purple",default:"yellowgreen",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The fill color for alarm (off) state status points."},
    //     {name:"on text color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The text color for normal (on) status points."},
    //     {name:"off text color",value:"yellow",default:"red",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The text color for alarm (off) status points."},
    //     {name:"on text",value:"open",default:"on",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The text for normal (on) state status points."},
    //     {name:"off text",value:"closed",default:"off",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The text for alarm (off) state status points."},

    //     {name:"high text color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The text color for high value analog points."},
    //     {name:"low text color",value:"blue",default:"blue",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The text color for low value analog points."},
    //     {name:"normal text color",value:"green",default:"green",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The text color for normal value analog points."},
    //     {name:"precision",value:"2",default:"0",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The number of digits to display after the decimal point for analog points."},

    //     {name:"precision",value:"2",default:"0",type:ConfigComponent.CONFIGTYPE_ACCUM,group:ConfigComponent.CONFIG_ACCUM,description:"The number of digits to display after the decimal point for accumulator points."},
    //     {name:"normal text color",value:"green",default:"magenta",type:ConfigComponent.CONFIGTYPE_ACCUM,group:ConfigComponent.CONFIG_ACCUM,description:"The text color for non-failed/non-forced accumulator points."},

    //     {name:"on fill color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_CONTROL,group:ConfigComponent.CONFIG_CONTROL,description:"The fill color for on state control points."},
    //     {name:"off fill color",value:"orange",default:"purple",type:ConfigComponent.CONFIGTYPE_CONTROL,group:ConfigComponent.CONFIG_CONTROL,description:"The fill color for off state control points."},

    //     {name:"normal text color",value:"yellow",default:"orange",type:ConfigComponent.CONFIGTYPE_SETPOINT,group:ConfigComponent.CONFIG_SETPOINT,description:"The text color for normal value setpoints."},

    //     {name:"font size",value:"50",default:"30",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The text font size for status points."},
    //     {name:"font size",value:"50",default:"30",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The text font size for analog points."},
    //     {name:"font size",value:"50",default:"30",type:ConfigComponent.CONFIGTYPE_ACCUM,group:ConfigComponent.CONFIG_ACCUM,description:"The text font size for accumulator points."},
    //     {name:"font size",value:"50",default:"30",type:ConfigComponent.CONFIGTYPE_CONTROL,group:ConfigComponent.CONFIG_CONTROL,description:"The text font size for control points."},
    //     {name:"font size",value:"50",default:"30",type:ConfigComponent.CONFIGTYPE_SETPOINT,group:ConfigComponent.CONFIG_SETPOINT,description:"The text font size for setpoints."},

    //     {name:"font family",value:"Arial",default:"Arial",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The text font family for status points."},
    //     {name:"font family",value:"4Arial",default:"Arial",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The text font family for analog points."},
    //     {name:"font family",value:"Arial",default:"Arial",type:ConfigComponent.CONFIGTYPE_ACCUM,group:ConfigComponent.CONFIG_ACCUM,description:"The text font family for accumulator points."},
    //     {name:"font family",value:"Arial",default:"Arial",type:ConfigComponent.CONFIGTYPE_CONTROL,group:ConfigComponent.CONFIG_CONTROL,description:"The text font family for control points."},
    //     {name:"font family",value:"Arial",default:"Arial",type:ConfigComponent.CONFIGTYPE_SETPOINT,group:ConfigComponent.CONFIG_SETPOINT,description:"The text font family for setpoints."},

    //     {name:"border color",value:"violet",default:"red",type:ConfigComponent.CONFIGTYPE_STATUS,group:ConfigComponent.CONFIG_STATUS,description:"The border color for status points."},
    //     {name:"border color",value:"violet",default:"red",type:ConfigComponent.CONFIGTYPE_ANALOG,group:ConfigComponent.CONFIG_ANALOG,description:"The border color for analog points."},
    //     {name:"border color",value:"violet",default:"red",type:ConfigComponent.CONFIGTYPE_ACCUM,group:ConfigComponent.CONFIG_ACCUM,description:"The border color for accumulator points."},
    //     {name:"border color",value:"violet",default:"red",type:ConfigComponent.CONFIGTYPE_CONTROL,group:ConfigComponent.CONFIG_CONTROL,description:"The border color for control points."},
    //     {name:"border color",value:"violet",default:"red",type:ConfigComponent.CONFIGTYPE_SETPOINT,group:ConfigComponent.CONFIG_SETPOINT,description:"The border color for setpoints."},

    //     {name:"height",value:"25",default:"25",type:ConfigComponent.CONFIGTYPE_SYMBOL_RECT,group:ConfigComponent.CONFIG_SYMBOL_RECT,description:"The default width of a rectangle symbol."},
    //     {name:"width",value:"25",default:"25",type:ConfigComponent.CONFIGTYPE_SYMBOL_RECT,group:ConfigComponent.CONFIG_SYMBOL_RECT,description:"The default height of a rectangle symbol."},
    //     {name:"fill color",value:"purple",default:"green",type:ConfigComponent.CONFIGTYPE_SYMBOL_RECT,group:ConfigComponent.CONFIG_SYMBOL_RECT,description:"The default fill color of a rectangle symbol."},
    //     {name:"border color",value:"blue",default:"red",type:ConfigComponent.CONFIGTYPE_SYMBOL_RECT,group:ConfigComponent.CONFIG_SYMBOL_RECT,description:"The default border color of a rectangle symbol."},
    
    //     {name:"radius",value:"30",default:"20",type:ConfigComponent.CONFIGTYPE_SYMBOL_CIRCLE,group:ConfigComponent.CONFIG_SYMBOL_CIRCLE,description:"The default radius of a circle symbol."},
    //     {name:"fill color",value:"green",default:"green",type:ConfigComponent.CONFIGTYPE_SYMBOL_CIRCLE,group:ConfigComponent.CONFIG_SYMBOL_CIRCLE,description:"The default fill color of a circle symbol."},
    //     {name:"border color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_SYMBOL_CIRCLE,group:ConfigComponent.CONFIG_SYMBOL_CIRCLE,description:"The default border color of a circle symbol."},

    //     {name:"length",value:"200",default:"100",type:ConfigComponent.CONFIGTYPE_SYMBOL_LINE,group:ConfigComponent.CONFIG_SYMBOL_LINE,description:"The default length of a line symbol."},
    //     {name:"rotation",value:"90",default:"0",type:ConfigComponent.CONFIGTYPE_SYMBOL_LINE,group:ConfigComponent.CONFIG_SYMBOL_LINE,description:"The default rotation of a line symbol."},
    //     {name:"fill color",value:"white",default:"red",type:ConfigComponent.CONFIGTYPE_SYMBOL_LINE,group:ConfigComponent.CONFIG_SYMBOL_LINE,description:"The default border color of a circle symbol."},

    //     {name:"border color",value:"red",default:"red",type:ConfigComponent.CONFIGTYPE_SYMBOL_ALL,group:ConfigComponent.CONFIG_SYMBOL_ALL,description:"The default symbol border."},
    //     {name:"fill color",value:"green",default:"green",type:ConfigComponent.CONFIGTYPE_SYMBOL_ALL,group:ConfigComponent.CONFIG_SYMBOL_ALL,description:"The default symbol fill."},

    //     // {name:"font size",value:"30",default:"30",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default font size of a text symbol."},
    //     // {name:"font size",value:"30",default:"30",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default font size of a text symbol."},
    //     {name:"font size",value:"30",default:"20",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default font size of a text symbol."},
    //     {name:"font family",value:"Arial",default:"Arial",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default font family of a text symbol."},
    //     {name:"fill color",value:"yellow",default:"green",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default fill color of a text symbol."},
    //     {name:"border color",value:"purple",default:"red",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default border color of a text symbol."},
    //     {name:"isFill",value:"true",default:"false",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default fill mode of a text symbol."},
    //     {name:"text",value:"LABEL",default:"TEXT",type:ConfigComponent.CONFIGTYPE_SYMBOL_TEXT,group:ConfigComponent.CONFIG_SYMBOL_TEXT,description:"The default text string of a text symbol."},
    // ]; 

    private elem: HTMLElement = null;
    private elem2: HTMLElement = null;
    private colorPickerObj: ColorPicker = null;
    private colorPickerObj2: ColorPicker = null;
    private rowData: object = null;

    // private parent: DrawingBoardComponent = null; 
    private parent: any = null; 

    private parentType: number;

    // Temp data store for serialized string data.
    private serialData: string[] = []; 

    // True if editing prior to saving.
    private DirtyBit: boolean = false;

    private static DEFAULT_CFG:string = "hmi-master.cfg";

    // Used for local file load.
    private fileReader:FileReader = null;

    private loadLocal:boolean = false;


    //constructor(dbc:DrawingBoardComponent)
    constructor(dbc:any, type:number)
    {
        console.log("Executing ConfigComponent.Constructor()");

        this.parent = dbc;
        //this.CopyConfig();
        //this.SortGrid();
        this.CreateGrid();
        this.parentType = type;
    }

    // OnChange(args:ChangeEventArgs)
    // {
    //     alert("OnCheckBox_ChangeEventArgs Fired.")
    // }


    private SortGrid()
    {
        //this.configdefault.sort((t1, t2)=>{
        Config.configdata.sort((t1, t2)=>{
            return t1.group > t2.group ? 1:-1;
        });
    }

    public GetLoadLocal(): boolean
    {
        return this.loadLocal;
    }

    public GetConfigData(): Array<any>
    {
        return Config.configdata;
    }


    private CopyConfig()
    {   
        //debugger     
        Config.configdata = Array.from(Config.configdata);
    }

    // private SaveConfig()
    // {
    //     for( let i:number=0;i<this.configdata.length;++i)
    //     {
    //         let item:any = this.configdata[i];
    //         if( item != null )
    //         {
                
    //         }
    //     }
    // }

    private CreateGrid()
    {
        //debugger
        console.log("Executing ConfigComponent.CreateGrid()");

        if( this.propgrid != null )
        {
            console.log("ConfigComponent.CreateGrid() - Not NULL.");
            return;
        }

        this.CopyConfig();
        this.SortGrid();

        this.propgrid = new Grid({
            dataSource: Config.configdata,
            //dataSource: this.configdefault,
            editSettings: { allowEditing: true,  mode: 'Dialog'},
            allowSorting: false,
            allowSelection: true,
            gridLines: 'Both',
            allowGrouping: true,
            groupSettings: {columns:['group']},
            enableHover: true,
            selectionSettings: {type: 'Single', mode: 'Row'},
            enableVirtualization: false,
            allowPaging: false,
            toolbar: ['Update', 'Cancel'],
            actionBegin: this.configGrid_actionBegin.bind(this),
            rowHeight: 15,
            columns: [
                { field: 'name', headerText: 'Property', textAlign: 'Right', width: 120, isPrimaryKey: true, isIdentity: true },
                { field: 'value', headerText: 'Value', width: 125, edit: 
//                { field: 'value', headerText: 'Value', validationRules: { required: true }, width: 125, edit: 
                    {
                        create: () => 
                        {
                            this.elem = document.createElement('input');
                            return this.elem;
                        },
                        read: (args: any) => 
                        {
                            if(!isNullOrUndefined(this.colorPickerObj)) 
                            {
                                //debugger
                                return this.colorPickerObj.value;
                            } 
                            else 
                            {
                                //debugger
                                return args.value;
                            }
                        },
                        destroy: () => 
                        {
                            if(!isNullOrUndefined(this.colorPickerObj)) 
                            {
                                this.colorPickerObj.destroy();
                                this.colorPickerObj = null;
                            }
                        },
                        write: (args: { rowData: object, column: Column, element: HTMLElement }) => 
                        {
                            this.rowData = args.rowData;
                            let name:string = args.rowData["name"];
                            let inx:number = name.toLowerCase().indexOf("color");
                            if( inx >= 0 ) 
                            {
                                this.colorPickerObj = new ColorPicker({
                                value: args.rowData["value"],
                                mode: 'Palette',
                                modeSwitcher: false
                                });
                                this.colorPickerObj.appendTo(this.elem);                    
                            }
                            else 
                            {
                                args.element["value"] = args.rowData["value"];
                            }    
                        }
                    },
                },
                { field: 'default', headerText: 'Default', width: 100, 
                //{ field: 'default', headerText: 'Default', validationRules: { required: true }, width: 100, 

                edit: {
                    create: (e) => {
                      this.elem2 = document.createElement("input");
                      return this.elem2;
                    },
                    read: (args: any) => {
                      if (!isNullOrUndefined(this.colorPickerObj2)) 
                      {
                        return this.colorPickerObj2.value;
                      } 
                      else 
                      {
                        return args.value;
                      }
                    },
                    destroy: () => {
                      if (!isNullOrUndefined(this.colorPickerObj2)) 
                      {
                        this.colorPickerObj2.destroy();
                        this.colorPickerObj2 = null;
                      }
                    },
                    write: (args: {
                      rowData: object;
                      column: Column;
                      element: HTMLElement;
                    }) => {
                        this.rowData = args.rowData;
                        let name: string = args.rowData["name"];
                        let inx: number = name.toString().indexOf("color");
                        if (inx >= 0) {
                            this.colorPickerObj2 = new ColorPicker({
                            value: args.rowData["default"],
                            mode: "Palette",
                            modeSwitcher: false
                            });
                            this.colorPickerObj2.appendTo(this.elem2);
                        }                    
                        else 
                        {
                            args.element["default"] = args.rowData["default"];
                        }
                  }
                },                
                visible:true},
                { field: 'type', headerText: 'Type', width: 25, visible: false},
                { field: 'group', headerText: 'Group', width: 100, visible: true},                
                { field: 'description', headerText: 'Description', width: 200},
                ],
            });
    }


    // private CreateGrid()
    // {
    //     //debugger
    //     console.log("Executing ConfigComponent.CreateGrid()");

    //     if( this.propgrid != null )
    //     {
    //         console.log("ConfigComponent.CreateGrid() - Not NULL.");
    //         return;
    //     }

    //     this.CopyConfig();
    //     this.SortGrid();

    //     this.propgrid = new Grid({
    //         dataSource: Config.configdata,
    //         //dataSource: this.configdefault,
    //         editSettings: { allowEditing: true,  mode: 'Dialog'},
    //         allowSorting: false,
    //         allowSelection: true,
    //         gridLines: 'Both',
    //         allowGrouping: true,
    //         groupSettings: {columns:['group']},
    //         enableHover: true,
    //         selectionSettings: {type: 'Single', mode: 'Row'},
    //         enableVirtualization: false,
    //         allowPaging: false,
    //         toolbar: ['Update', 'Cancel'],
    //         actionBegin: this.configGrid_actionBegin.bind(this),
    //         rowHeight: 15,
    //         columns: [
    //             { field: 'name', headerText: 'Property', textAlign: 'Right', width: 120, isPrimaryKey: true, isIdentity: true },
    //             { field: 'value', headerText: 'Value', width: 125, edit: 
    //                 {
    //                     create: () => 
    //                     {
    //                         this.elem = document.createElement('input');
    //                         return this.elem;
    //                     },
    //                     read: (args: any) => 
    //                     {
    //                         if(!isNullOrUndefined(this.colorPickerObj)) 
    //                         {
    //                             //debugger
    //                             return this.colorPickerObj.value;
    //                         } 
    //                         else 
    //                         {
    //                             //debugger
    //                             return args.value;
    //                         }
    //                     },
    //                     destroy: () => 
    //                     {
    //                         if(!isNullOrUndefined(this.colorPickerObj)) 
    //                         {
    //                             this.colorPickerObj.destroy();
    //                             this.colorPickerObj = null;
    //                         }
    //                     },
    //                     write: (args: { rowData: object, column: Column, element: HTMLElement }) => 
    //                     {
    //                         this.rowData = args.rowData;
    //                         let name:string = args.rowData["name"];
    //                         let inx:number = name.toLowerCase().indexOf("color");
    //                         if( inx >= 0 ) 
    //                         {
    //                             this.colorPickerObj = new ColorPicker({
    //                             value: args.rowData["value"],
    //                             mode: 'Palette',
    //                             modeSwitcher: false
    //                             });
    //                             this.colorPickerObj.appendTo(this.elem);                    
    //                         } 
    //                         else 
    //                         {
    //                             args.element["value"] = args.rowData["value"];
    //                         }
    //                     }
    //                 },
    //             },
    //             { field: 'default', headerText: 'Default', width: 100, visible:true},
    //             { field: 'type', headerText: 'Type', width: 25, visible: false},
    //             { field: 'group', headerText: 'Group', width: 100, visible: true},                
    //             { field: 'description', headerText: 'Description', width: 200},
    //             ],
    //         });
    // }

    // Creates the dialog.
    public CreateDialog(show:boolean)
    {
        //debugger
        console.log("Executing ConfigComponent.ShowTBPropGridDialog()");

        //debugger
        let dialogContent: string = `<form id='ConfigForm'>
            <div id="gridelem"></div>
        </form>` 

        this.dialog = new Dialog(
        { 
            header: 'HMI Master Configuration Dialog', 
            target: document.getElementById('target'), 
            content: dialogContent,
            allowDragging: true,
            visible: show,
            isModal: false, 
            animationSettings: 
            { 
                effect: 'None' 
            }, 
            showCloseIcon: false, 
            width: '1500px',
            height: '700px', 
            open: this.onDialogOpen,
            enableResize: true,
            position: {X: "center", Y:"center"},
            close: this.onDialogClose,
            //beforeClose: this.onBeforeDialogClose, 
            created: this.onDialogCreate.bind(this),
            buttons:  
            [
                // {
                //     // Click the footer buttons to hide the Dialog
                //     'click': () => {
                //         //this.parent.ClearConfigDialog();
                //         //this.dialog.destroy();
                //         //this.dialog.visible = false;
                //         this.Destroy();
                //     },
                //     // Accessing button component properties by buttonModel property
                //     buttonModel: {
                //         //Enables the primary button
                //         isPrimary: true,
                //         content: 'CLOSE'
                //     }
                // },                
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        this.Serialize(false);
                        //this.Destroy();
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'SAVE LOCAL'
                    }
                },
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        this.loadLocal = true;
                        document.getElementById("loadfile").style.display = "block"; 
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'Load LOCAL'
                    }
                },
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        this.Serialize(true);
                        //this.Destroy();
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'SAVE REMOTE'
                    }
                },
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        this.ReadConfigFileFromServer();
                        //this.Destroy();
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'Load REMOTE'
                    }
                },
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        //this.parent.ClearConfigDialog();
                        //this.Destroy();
                        //this.dialog.visible = false;
                        if( this.parent != null )
                        {
                            this.parent.ApplyConfig_ActiveDiagram();
                        }
                
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'Apply to Diagram'
                    }
                },
                {
                    // Click the footer buttons to hide the Dialog
                    'click': () => {
                        //this.parent.ClearConfigDialog();
                        //this.dialog.destroy();
                        this.dialog.visible = false;
                        // debugger
                        // if( this.DirtyBit )
                        // {
                        //     this.OnSaveConfig_Remote();
                        // }
                        // this.Destroy();
                    },
                    // Accessing button component properties by buttonModel property
                    buttonModel: {
                        //Enables the primary button
                        isPrimary: true,
                        content: 'CLOSE'
                    }
                },                
            ],            

        });
        if( this.parentType == Config.PARENT_TYPE_DBC)
        { 
            this.dialog.appendTo('#configdialog-dbc');
        }
        else if( this.parentType == Config.PARENT_TYPE_TREEVIEW)
        { 
            this.dialog.appendTo('#configdialog-tvc');
        }
    }  


    // Dialog created Event callback.
    private onDialogCreate(args:any) 
    {
        //debugger
        console.log("Executing ConfigComponent.onDialogCreate()");
        if( this.propgrid != null )
        {
            this.propgrid.appendTo('#gridelem');
        }
    } 

    // Dialog opened event callback
    private onDialogOpen()
    {
        //debugger;
        console.log("Executing ConfigComponent.onDialogOpen()");
    
    }

    // Dialog closed event callback.
    private onDialogClose()
    {
        //debugger
        console.log("Executing ConfigComponent.onDialogClose()");

        // this.dialog.destroy();
        //this.parent.ClearConfigDialog();
    }

    // Destroy (called when drawing board exits or navigates to another view).
    public Destroy()
    {
        //debugger;
        console.log("Executing ConfigComponent.Destroy()");

        //Config.configdata = [];

        if( this.propgrid != null )
        {
            this.propgrid.destroy();
            this.propgrid = null;
        }

        if( this.dialog != null )
        {
            this.dialog.destroy();
            this.dialog = null;
        }

        // if( this.parent != null )
        // {            
        //     this.parent.ClearConfigDialog();
        // }  
    }
    

    // Callback when some property grid action begins.
    private configGrid_actionBegin(args: any): void 
    {       
        //debugger 
        console.log("Executing ConfigComponent.ConfigGrid_actionBegin callback.");
        if( args.requestType == 'beginEdit' )
        {
        }
        else if (args.requestType === 'save') 
        {
            console.log("ConfigGrid_actionBegin requestType = save.");

            //debugger
        
            let prop:any = args.data;
            let name:string = prop.name;
            let value: string = prop.value;

            this.DirtyBit = true;

            // Replace correct entry in configdata.
            for(let i:number = 0; i<Config.configdata.length; ++i)
            {
                let item:any = Config.configdata[i];

                if( item.type == prop.type && item.name == name)
                {
                    Config.configdata[i] = prop;
                }
            }

            // if( this.parent == null )
            // {
            //     console.log("ConfigComponent.ConfigToolbox_actionBegin() - NULL Parent Object.");
            //     return;
            // }

            // let config:Array<any> = ConfigComponent.configdata;
            // if( this.parent)
            // {
            //     this.parent.SaveConfig(config);
            // }
        }
    }

      // This method deserializes each symbol object and loads it into memory.
  Deserialize() : boolean
  {
    console.log("Executing ConfigComponet.Deserialize().");

    if( this.serialData == null )
    {
      alert("DrawingBoardComponent.Deserialize() - NULL serial data");
      return false;
    }

    if( this.serialData.length == 0)
    {
      alert("DrawingBoardComponent.Deserialize() - No data to deserialize");
      return false;
    }

    Config.configdata = [];

    for( let i: number = 0; i<this.serialData.length; ++i)
    {
      let serial: string = this.serialData[i];

      if( serial != null && serial.length > 0)
      {
        let obj:any = JSON.parse(serial);
        let item: any;
        item =  { name: obj.name,
                  value: obj.value,
                  default: obj.default,
                  type: obj.type,
                  group: obj.group,
                  description: obj.description
                };
        Config.configdata.push(item);  
      }
    }

    console.log("ConfigComponent.Deserialize() - SUCCESS.");

    this.resetConfigGrid();

    return true;
  }


    // This method serializes the configuration and pushes it to the server.
    public Serialize(isRemote: boolean) : boolean
    {
        console.log("Executing ConfigComponet.Serialize().");

        this.serialData = [];

        for( let i: number = 0; i<Config.configdata.length; ++i)
        {
            let item: any = Config.configdata[i];

            if( item != null)
            {
                let serial: string = JSON.stringify(item);
                this.serialData.push(serial);
            }
        }

        console.log("ConfigComponent.Serialize() - SUCCESS.");

        if( isRemote)
        {
            this.OnSaveConfig_Remote();
        }
        else
        {
            this.OnSaveConfig_Local();
        }

        //this.DirtyBit = false;
        return true;
    }

    OnSaveConfig_Local()
    {
      console.log('Executing ConfigComponent.OnSaveConfig_Local()');
  
      //debugger
      this.WriteLocalFile();    
    }

    WriteLocalFile()
    {    
        console.log('Executing ConfigComponent.WriteLocalFile()');

        //debugger
        let writer = new StreamWriter();
        for( let i: number = 0; i<this.serialData.length; ++i)
        {
            writer.writeLine(this.serialData[i]);
        }
        writer.save(ConfigDialog.DEFAULT_CFG);
        //this.DirtyBit = false;
    }

    public DisplayMsg(msg: string)
    {
        alert(msg);
    }


    OnSaveConfig_Remote()
    {
      console.log('Executing ConfigComponent.OnSaveConfig_Remote()');
      //this.ShowSaveServerFileDialog();
      this.parent.SendConfig(this.serialData, ConfigDialog.DEFAULT_CFG);
    }
  
    // Reads master config file from server.
    ReadConfigFileFromServer()
    {
        //debugger
        console.log("Executing ConfigComponent.ReadConfigFileFromServer().");

        //debugger

        let file: string = this.parent.GetDiagramPath() + ConfigDialog.DEFAULT_CFG;
        
        var contents: string;
        this.parent.treeviewService.getTextFile(file)
        .subscribe((result:string) => 
        {
            if( result)
            contents = result;
            console.log("Set Contents: ", contents);

            let arr: Array<string> = contents.split('\r\n');
            this.serialData = [];
            //debugger
            for( let i=0; i<arr.length; ++i)
            {
            let line:string = arr[i];
            this.serialData.push(line);
            }  
            this.Deserialize();

            alert("CFG: REMOTE LOAD SUCCESS.")
        });
    }


    OnConfigLoaded(e:ProgressEvent)
    {
      //debugger
      let data:any = this.fileReader.result;
      let arr: Array<string> = data.split('\r\n');
      this.serialData = [];
      for( let i=0; i<arr.length; ++i)
      {
        let line:string = arr[i];
        this.serialData.push(line);
      }  
      this.Deserialize();

      this.loadLocal = false;

      document.getElementById("loadfile").style.display = "none"; 

      alert("CFG: LOCAL LOAD SUCCESS.")
    }
  

    OnLoadLocalConfig(files: FileList)
    {
      console.log('Executing DrawingBoardComponent.OnLoadLocalConfig().');

      //debugger
      let file:File = files[0];
      this.fileReader = new FileReader();
      this.fileReader.onload = this.OnConfigLoaded.bind(this);
  
      var blob = file.slice(0, file.size);
      this.fileReader.readAsText(blob);    
    //   document.getElementById("loadfile").style.display = "none"; 
    }
  

    // Called to update or clear the property grid data store.
    public resetConfigGrid()
    {
        console.log("Executing ConfigComponent.resetPropData_Toolbox().");

        if( this.propgrid == null )
        {
            console.log("ConfigComponent.resetPropData_Toolbox() - NULL propgrid - returning.")
            return;
        }

        if( ! Config.configdata )
        {
            console.log("ConfigComponent.resetPropData_Toolbox() - NULL configdata - returning.")
            return;
        }

        this.propgrid.dataSource = [];
        this.propgrid.dataSource = Config.configdata;
    }

ShowSaveServerFileDialog()
{
  let tb_filename: TextBox;

  let dialogContent: string = `<div class='col-lg-12 control-section'><div class='content-wrapper'><form id='LocalFileForm'> 
    <div class="row"> 
    <div class="col-xs-10 col-sm-10 col-lg-10 col-md-10"> 
      <input id="textboxelement" name="File Name: " />
        <div id="filenameError" class="error"></div> 
    </div>
  </form> 
  </div> 
  </div>` 


  let dialog: Dialog = new Dialog({ 
    header: 'Save to Server File Dialog', 
    target: document.getElementById('target'), 
    content: dialogContent, 
    animationSettings: { 
        effect: 'None' 
    }, 
    buttons: [
      { 
        'click': () => 
        {          
          this.parent.SendConfig(this.serialData, tb_filename.value);
          this.DirtyBit = false;        
          dialog.destroy();
        },

        buttonModel: 
        { 
            content: 'OK', 
            isPrimary: true, 
            cssClass: 'e-outline'
        }
    },
    { 
      'click': () => 
      {
          dialog.destroy();
      },

      buttonModel: 
      { 
          content: 'Cancel', 
          isPrimary: true, 
          cssClass: 'e-outline'
      }
  }
  ], 
    showCloseIcon: true, 
    width: '500px', 
    open: onDialogOpen, 
    close: onDialogClose, 
    created: onDialogCreate
  }); 
  dialog.appendTo('#filedialog'); 

  function onDialogCreate(args) 
  {
    console.log("Executing onDialogCreate()");
    // initialize ComboBox component
    tb_filename = new TextBox({
      //set the data to dataSource property
      floatLabelType: 'Always', 
      // set placeholder to ComboBox input element
      placeholder: "File Name:"
    });


    // render initialized ComboBox
    tb_filename.appendTo('#textboxelement');
  } 

  function onDialogOpen()
  {
    console.log("Executing onDialogOpen()");
  }

  function onDialogClose()
  {
    // alert("Executing onDialogClose()");
    dialog.destroy();  
  }
}


}
