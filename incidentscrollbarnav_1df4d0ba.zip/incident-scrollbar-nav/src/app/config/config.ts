import { Component} from '@angular/core';
export class Config 
{
    public static CONFIGTYPE_NONE = 0;
    public static CONFIGTYPE_GENERAL = 1;
    public static CONFIGTYPE_ALLPOINTS = 2;
    public static CONFIGTYPE_STATUS = 3;
    public static CONFIGTYPE_ANALOG = 4;
    public static CONFIGTYPE_ACCUM = 5;
    public static CONFIGTYPE_CONTROL = 6;
    public static CONFIGTYPE_SETPOINT = 7;
    public static CONFIGTYPE_SYMBOL_ALL = 8;
    public static CONFIGTYPE_SYMBOL_RECT =9;
    public static CONFIGTYPE_SYMBOL_CIRCLE = 10;
    public static CONFIGTYPE_SYMBOL_LINE = 11;
    public static CONFIGTYPE_SYMBOL_TEXT = 12;
    public static CONFIGTYPE_SYMBOL_SWITCH = 13;

    private static CONFIG_NONE = "0-none";
    private static CONFIG_GENERAL = "10-general";
    private static CONFIG_ALLPOINTS = "12-all points";
    private static CONFIG_STATUS = "13-status points";
    private static CONFIG_ANALOG = "14-analog points";
    private static CONFIG_ACCUM = "15-accumulator points";
    private static CONFIG_CONTROL = "16-control points";
    private static CONFIG_SETPOINT = "17-setpoints";
    private static CONFIG_SYMBOL_ALL = "18-all synbols";
    private static CONFIG_SYMBOL_RECT = "19-rectangle";
    private static CONFIG_SYMBOL_CIRCLE = "20-circle";
    private static CONFIG_SYMBOL_LINE = "21-line";
    private static CONFIG_SYMBOL_TEXT = "22-text";
    private static CONFIG_SYMBOL_SWITCH = "23-switch";

    public static PARENT_TYPE_NONE:number = 0;
    public static PARENT_TYPE_TREEVIEW:number = 1;
    public static PARENT_TYPE_DBC:number = 2;

    public static MAX_TERMVIEWS = 1;
    public static MAX_TREEVIEWS = 3;
    public static MAX_SLDVIEWS = 2;

    public static PORT_COMMSERVER:number = 1113;
    public static PORT_TERMSERVER:number = 1111;

    // public static MODE_DEV:boolean = true;
    public static MODE_DEV:boolean = false;
    public static MODE_MULTITABS:boolean = false;
    public static SERVERIP_TEST:string = "http://10.210.6.146";
    //public static SERVERIP_TEST:string = "http://10.210.6.147";
n
    private configdefs: { [key: string]: Object }[] = 
    [
        {value:Config.CONFIGTYPE_NONE,name:"none" },
        {value:Config.CONFIGTYPE_GENERAL,name:"general" },
        {value:Config.CONFIGTYPE_ALLPOINTS,name:"all points" },
        {value:Config.CONFIGTYPE_STATUS,name:"all points" },
        {value:Config.CONFIGTYPE_ANALOG,name:"analog points" },
        {value:Config.CONFIGTYPE_ACCUM,name:"accumulator points" },
        {value:Config.CONFIGTYPE_CONTROL,name:"control points" },
        {value:Config.CONFIGTYPE_SETPOINT,name:"setpoints" },
        {value:Config.CONFIGTYPE_SYMBOL_ALL,name:"all synbols" },
        {value:Config.CONFIGTYPE_SYMBOL_RECT,name:"rectangle" },
        {value:Config.CONFIGTYPE_SYMBOL_CIRCLE,name:"circle" },
        {value:Config.CONFIGTYPE_SYMBOL_LINE,name:"line" },
        {value:Config.CONFIGTYPE_SYMBOL_TEXT,name:"text" },
    ]
    
    public static configdata: { [key: string]: Object }[] = 
    [
        {name:"point order",value:"status",default:"status",type:Config.CONFIGTYPE_GENERAL,group:Config.CONFIG_GENERAL,description:"Whether to display status or analog points first; accumulators are always third then controls then setpoints."},

        {name:"failed color",value:"red",default:"red",type:Config.CONFIGTYPE_ALLPOINTS,group:Config.CONFIG_ALLPOINTS,description:"The failed text color for all point types."},
        {name:"forced color",value:"blue",default:"blue",type:Config.CONFIGTYPE_ALLPOINTS,group:Config.CONFIG_ALLPOINTS,description:"The forced text color for status, analog and accumulor point types."},

        {name:"on fill color",value:"red",default:"red",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The fill color for normal (on) state status points."},
        {name:"off fill color",value:"purple",default:"yellowgreen",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The fill color for alarm (off) state status points."},
        {name:"on text color",value:"red",default:"red",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The text color for normal (on) status points."},
        {name:"off text color",value:"yellow",default:"red",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The text color for alarm (off) status points."},
        {name:"on text",value:"open",default:"on",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The text for normal (on) state status points."},
        {name:"off text",value:"closed",default:"off",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The text for alarm (off) state status points."},

        {name:"high text color",value:"red",default:"red",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The text color for high value analog points."},
        {name:"low text color",value:"blue",default:"blue",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The text color for low value analog points."},
        {name:"normal text color",value:"green",default:"green",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The text color for normal value analog points."},
        {name:"precision",value:"2",default:"0",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The number of digits to display after the decimal point for analog points."},

        {name:"precision",value:"2",default:"0",type:Config.CONFIGTYPE_ACCUM,group:Config.CONFIG_ACCUM,description:"The number of digits to display after the decimal point for accumulator points."},
        {name:"normal text color",value:"green",default:"magenta",type:Config.CONFIGTYPE_ACCUM,group:Config.CONFIG_ACCUM,description:"The text color for non-failed/non-forced accumulator points."},

        {name:"on fill color",value:"red",default:"red",type:Config.CONFIGTYPE_CONTROL,group:Config.CONFIG_CONTROL,description:"The fill color for on state control points."},
        {name:"off fill color",value:"orange",default:"purple",type:Config.CONFIGTYPE_CONTROL,group:Config.CONFIG_CONTROL,description:"The fill color for off state control points."},

        {name:"normal text color",value:"yellow",default:"orange",type:Config.CONFIGTYPE_SETPOINT,group:Config.CONFIG_SETPOINT,description:"The text color for normal value setpoints."},

        {name:"font size",value:"50",default:"30",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The text font size for status points."},
        {name:"font size",value:"50",default:"30",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The text font size for analog points."},
        {name:"font size",value:"50",default:"30",type:Config.CONFIGTYPE_ACCUM,group:Config.CONFIG_ACCUM,description:"The text font size for accumulator points."},
        {name:"font size",value:"50",default:"30",type:Config.CONFIGTYPE_CONTROL,group:Config.CONFIG_CONTROL,description:"The text font size for control points."},
        {name:"font size",value:"50",default:"30",type:Config.CONFIGTYPE_SETPOINT,group:Config.CONFIG_SETPOINT,description:"The text font size for setpoints."},

        {name:"font family",value:"Arial",default:"Arial",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The text font family for status points."},
        {name:"font family",value:"4Arial",default:"Arial",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The text font family for analog points."},
        {name:"font family",value:"Arial",default:"Arial",type:Config.CONFIGTYPE_ACCUM,group:Config.CONFIG_ACCUM,description:"The text font family for accumulator points."},
        {name:"font family",value:"Arial",default:"Arial",type:Config.CONFIGTYPE_CONTROL,group:Config.CONFIG_CONTROL,description:"The text font family for control points."},
        {name:"font family",value:"Arial",default:"Arial",type:Config.CONFIGTYPE_SETPOINT,group:Config.CONFIG_SETPOINT,description:"The text font family for setpoints."},

        {name:"border color",value:"violet",default:"red",type:Config.CONFIGTYPE_STATUS,group:Config.CONFIG_STATUS,description:"The border color for status points."},
        {name:"border color",value:"violet",default:"red",type:Config.CONFIGTYPE_ANALOG,group:Config.CONFIG_ANALOG,description:"The border color for analog points."},
        {name:"border color",value:"violet",default:"red",type:Config.CONFIGTYPE_ACCUM,group:Config.CONFIG_ACCUM,description:"The border color for accumulator points."},
        {name:"border color",value:"violet",default:"red",type:Config.CONFIGTYPE_CONTROL,group:Config.CONFIG_CONTROL,description:"The border color for control points."},
        {name:"border color",value:"violet",default:"red",type:Config.CONFIGTYPE_SETPOINT,group:Config.CONFIG_SETPOINT,description:"The border color for setpoints."},

        {name:"height",value:"25",default:"25",type:Config.CONFIGTYPE_SYMBOL_RECT,group:Config.CONFIG_SYMBOL_RECT,description:"The default width of a rectangle symbol."},
        {name:"width",value:"25",default:"25",type:Config.CONFIGTYPE_SYMBOL_RECT,group:Config.CONFIG_SYMBOL_RECT,description:"The default height of a rectangle symbol."},
        {name:"fill color",value:"purple",default:"green",type:Config.CONFIGTYPE_SYMBOL_RECT,group:Config.CONFIG_SYMBOL_RECT,description:"The default fill color of a rectangle symbol."},
        {name:"border color",value:"blue",default:"red",type:Config.CONFIGTYPE_SYMBOL_RECT,group:Config.CONFIG_SYMBOL_RECT,description:"The default border color of a rectangle symbol."},
    
        {name:"radius",value:"30",default:"20",type:Config.CONFIGTYPE_SYMBOL_CIRCLE,group:Config.CONFIG_SYMBOL_CIRCLE,description:"The default radius of a circle symbol."},
        {name:"fill color",value:"green",default:"green",type:Config.CONFIGTYPE_SYMBOL_CIRCLE,group:Config.CONFIG_SYMBOL_CIRCLE,description:"The default fill color of a circle symbol."},
        {name:"border color",value:"red",default:"red",type:Config.CONFIGTYPE_SYMBOL_CIRCLE,group:Config.CONFIG_SYMBOL_CIRCLE,description:"The default border color of a circle symbol."},

        {name:"length",value:"200",default:"100",type:Config.CONFIGTYPE_SYMBOL_LINE,group:Config.CONFIG_SYMBOL_LINE,description:"The default length of a line symbol."},
        {name:"rotation",value:"90",default:"0",type:Config.CONFIGTYPE_SYMBOL_LINE,group:Config.CONFIG_SYMBOL_LINE,description:"The default rotation of a line symbol."},
        {name:"fill color",value:"white",default:"red",type:Config.CONFIGTYPE_SYMBOL_LINE,group:Config.CONFIG_SYMBOL_LINE,description:"The default fill color of a circle symbol."},

        {name:"length",value:"200",default:"100",type:Config.CONFIGTYPE_SYMBOL_SWITCH,group:Config.CONFIG_SYMBOL_SWITCH,description:"The default length of a switch symbol."},
        {name:"rotation closed",value:"0",default:"0",type:Config.CONFIGTYPE_SYMBOL_SWITCH,group:Config.CONFIG_SYMBOL_SWITCH,description:"The default rotation of a line symbol."},
        {name:"rotation open",value:"135",default:"45",type:Config.CONFIGTYPE_SYMBOL_SWITCH,group:Config.CONFIG_SYMBOL_SWITCH,description:"The default rotation of a line symbol."},
        {name:"fill color",value:"white",default:"red",type:Config.CONFIGTYPE_SYMBOL_SWITCH,group:Config.CONFIG_SYMBOL_SWITCH,description:"The default fill color of a switch symbol."},

        {name:"border color",value:"red",default:"red",type:Config.CONFIGTYPE_SYMBOL_ALL,group:Config.CONFIG_SYMBOL_ALL,description:"The default symbol border."},
        {name:"fill color",value:"green",default:"green",type:Config.CONFIGTYPE_SYMBOL_ALL,group:Config.CONFIG_SYMBOL_ALL,description:"The default symbol fill."},

        {name:"font size",value:"30",default:"20",type:Config.CONFIGTYPE_SYMBOL_TEXT,group:Config.CONFIG_SYMBOL_TEXT,description:"The default font size of a text symbol."},
        {name:"font family",value:"Arial",default:"Arial",type:Config.CONFIGTYPE_SYMBOL_TEXT,group:Config.CONFIG_SYMBOL_TEXT,description:"The default font family of a text symbol."},
        {name:"fill color",value:"yellow",default:"green",type:Config.CONFIGTYPE_SYMBOL_TEXT,group:Config.CONFIG_SYMBOL_TEXT,description:"The default fill color of a text symbol."},
        {name:"border color",value:"purple",default:"red",type:Config.CONFIGTYPE_SYMBOL_TEXT,group:Config.CONFIG_SYMBOL_TEXT,description:"The default border color of a text symbol."},
        {name:"isFill",value:"true",default:"false",type:Config.CONFIGTYPE_SYMBOL_TEXT,group:Config.CONFIG_SYMBOL_TEXT,description:"The default fill mode of a text symbol."},
        {name:"text",value:"LABEL",default:"TEXT",type:Config.CONFIGTYPE_SYMBOL_TEXT,group:Config.CONFIG_SYMBOL_TEXT,description:"The default text string of a text symbol."},
    ]; 

    public static Add(entry:string)
    {
        var data = JSON.parse(entry);
        Config.configdata.push(data);
    }

}
